# Ladder Name: 28 - 1800 <= Codeforces Rating <= 1899 (Extra)
## Description
 Extra problems for users satisfying this condition
## Difficulty Level: 4

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[George and Accommodation](http://codeforces.com/problemset/problem/467/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Spit Problem](http://codeforces.com/problemset/problem/29/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Sereja and Mugs](http://codeforces.com/problemset/problem/426/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[Playing with Dice](http://codeforces.com/problemset/problem/378/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Kyoya and Photobooks](http://codeforces.com/problemset/problem/554/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|6|[Haiku](http://codeforces.com/problemset/problem/78/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|7|[Soroban](http://codeforces.com/problemset/problem/363/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|8|[Table](http://codeforces.com/problemset/problem/359/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Valera and Plates](http://codeforces.com/problemset/problem/369/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Sinking Ship](http://codeforces.com/problemset/problem/63/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[Case of the Zeros and Ones](http://codeforces.com/problemset/problem/556/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Drazil and Date](http://codeforces.com/problemset/problem/515/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[Bear and Raspberry](http://codeforces.com/problemset/problem/385/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|14|[Worms Evolution](http://codeforces.com/problemset/problem/31/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|15|[Group of Students](http://codeforces.com/problemset/problem/357/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|16|[Lever](http://codeforces.com/problemset/problem/376/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|17|[Lucky Ticket](http://codeforces.com/problemset/problem/146/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|18|[Game With Sticks](http://codeforces.com/problemset/problem/451/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|19|[Depression](http://codeforces.com/problemset/problem/80/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|20|[Easter Eggs](http://codeforces.com/problemset/problem/78/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|21|[Vasya and Digital Root](http://codeforces.com/problemset/problem/355/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|22|[Sereja and Coat Rack](http://codeforces.com/problemset/problem/368/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|23|[Multiplication Table](http://codeforces.com/problemset/problem/577/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|24|[Canvas Frames](http://codeforces.com/problemset/problem/127/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|25|[Petya and Staircases](http://codeforces.com/problemset/problem/362/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|26|[Progress Bar](http://codeforces.com/problemset/problem/71/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|27|[A and B and Compilation Errors](http://codeforces.com/problemset/problem/519/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|28|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|29|[Dorm Water Supply](http://codeforces.com/problemset/problem/107/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|30|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|31|[Appleman and Toastman](http://codeforces.com/problemset/problem/461/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|32|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|33|[Lexicographically Maximum Subsequence](http://codeforces.com/problemset/problem/196/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|34|[Whose sentence is it?](http://codeforces.com/problemset/problem/312/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|35|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|36|[Sereja and Stairs](http://codeforces.com/problemset/problem/381/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|37|[Good Number](http://codeforces.com/problemset/problem/365/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|38|[Mashmokh and Numbers](http://codeforces.com/problemset/problem/414/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|39|[Fox and Number Game](http://codeforces.com/problemset/problem/389/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|40|[Levko and Permutation](http://codeforces.com/problemset/problem/361/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|41|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|42|[Prizes, Prizes, more Prizes](http://codeforces.com/problemset/problem/208/D)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|43|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|44|[Magic Box](http://codeforces.com/problemset/problem/231/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|45|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|46|[History](http://codeforces.com/problemset/problem/137/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Remainders Game](http://codeforces.com/problemset/problem/687/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|48|[Guess Your Way Out!](http://codeforces.com/problemset/problem/507/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|49|[Guest From the Past](http://codeforces.com/problemset/problem/625/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|50|[Magical Boxes](http://codeforces.com/problemset/problem/269/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|51|[Prime Permutation](http://codeforces.com/problemset/problem/123/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|52|[Yaroslav and Sequence](http://codeforces.com/problemset/problem/301/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|53|[Division into Teams](http://codeforces.com/problemset/problem/149/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|54|[School Marks](http://codeforces.com/problemset/problem/540/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|55|[Prime Swaps](http://codeforces.com/problemset/problem/432/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|56|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|57|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|58|[Alyona and a tree](http://codeforces.com/problemset/problem/739/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|59|[Ilya and Sticks](http://codeforces.com/problemset/problem/525/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|60|[Heap Operations](http://codeforces.com/problemset/problem/681/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|61|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|62|[Bear and Blocks](http://codeforces.com/problemset/problem/573/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|63|[Kolya and Tanya ](http://codeforces.com/problemset/problem/584/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|64|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|65|[Dreamoon and Sets](http://codeforces.com/problemset/problem/476/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|66|[Lazy Student](http://codeforces.com/problemset/problem/605/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|67|[Olympiad](http://codeforces.com/problemset/problem/222/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|68|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|69|[Queue](http://codeforces.com/problemset/problem/545/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|70|[Approximating a Constant Range](http://codeforces.com/problemset/problem/602/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|71|[Biridian Forest](http://codeforces.com/problemset/problem/329/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|72|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|73|[Levko and Array Recovery](http://codeforces.com/problemset/problem/360/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|74|[Robin Hood](http://codeforces.com/problemset/problem/671/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|75|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|76|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|77|[Dynasty Puzzles](http://codeforces.com/problemset/problem/191/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|78|[k-Multiple Free Set](http://codeforces.com/problemset/problem/274/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|79|[Tree Construction](http://codeforces.com/problemset/problem/675/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|80|[Misha and Permutations Summation](http://codeforces.com/problemset/problem/501/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|81|[Inna and Nine](http://codeforces.com/problemset/problem/374/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|82|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|83|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|84|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|85|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|86|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|87|[Non-Secret Cypher](http://codeforces.com/problemset/problem/190/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|88|[Petya and His Friends](http://codeforces.com/problemset/problem/66/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|89|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|90|[The Big Race](http://codeforces.com/problemset/problem/592/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|91|[Cycles](http://codeforces.com/problemset/problem/232/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|92|[The Values You Can Make](http://codeforces.com/problemset/problem/687/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|93|[Road Map](http://codeforces.com/problemset/problem/34/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|94|[Newspaper Headline](http://codeforces.com/problemset/problem/91/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|95|[Valera and Contest](http://codeforces.com/problemset/problem/369/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|96|[Ivan and Powers of Two](http://codeforces.com/problemset/problem/305/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|97|[Polyline](http://codeforces.com/problemset/problem/617/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|98|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|99|[Anagram Search](http://codeforces.com/problemset/problem/144/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|100|[Chips](http://codeforces.com/problemset/problem/333/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|101|[Fish Weight](http://codeforces.com/problemset/problem/297/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|102|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|103|[Falling Anvils](http://codeforces.com/problemset/problem/77/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|104|[Maximal Area Quadrilateral](http://codeforces.com/problemset/problem/340/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|105|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|106|[Jeff and Furik](http://codeforces.com/problemset/problem/351/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|107|[Making Sequences is Fun](http://codeforces.com/problemset/problem/373/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|108|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|109|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|110|[Woodcutters](http://codeforces.com/problemset/problem/545/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|111|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|112|[Watering Flowers](http://codeforces.com/problemset/problem/617/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|113|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|114|[Zuma](http://codeforces.com/problemset/problem/607/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|115|[OR in Matrix](http://codeforces.com/problemset/problem/486/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|116|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|117|[Dima and Two Sequences](http://codeforces.com/problemset/problem/272/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|118|[Queue](http://codeforces.com/problemset/problem/91/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|119|[Dima and Lisa](http://codeforces.com/problemset/problem/584/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|120|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|121|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|122|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|123|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|124|[Subway Innovation](http://codeforces.com/problemset/problem/371/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|125|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|126|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|127|[Anton and Ira](http://codeforces.com/problemset/problem/584/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|128|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|129|[Last Chance](http://codeforces.com/problemset/problem/137/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|130|[Palindromes](http://codeforces.com/problemset/problem/137/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|131|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|132|[Block Tower](http://codeforces.com/problemset/problem/327/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|133|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|134|[Beautiful Decomposition](http://codeforces.com/problemset/problem/279/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|135|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|136|[Broken Monitor](http://codeforces.com/problemset/problem/370/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|137|[Memory and Scores](http://codeforces.com/problemset/problem/712/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|138|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|139|[Games with Rectangle](http://codeforces.com/problemset/problem/128/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|140|[Iahub and Permutations](http://codeforces.com/problemset/problem/340/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|141|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|142|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|143|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|144|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|145|[Cycle in Graph](http://codeforces.com/problemset/problem/263/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|146|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|147|[Wizards and Huge Prize](http://codeforces.com/problemset/problem/167/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|148|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|149|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|150|[Directed Roads](http://codeforces.com/problemset/problem/711/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|151|[Dima and Magic Guitar](http://codeforces.com/problemset/problem/366/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|152|[Free Market](http://codeforces.com/problemset/problem/364/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|153|[Infinite Maze](http://codeforces.com/problemset/problem/196/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|154|[Ilya and Roads](http://codeforces.com/problemset/problem/313/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|155|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|156|[Alyona and Strings](http://codeforces.com/problemset/problem/682/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|157|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|158|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|159|[Xenia and Hamming](http://codeforces.com/problemset/problem/356/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|160|[Let's Play Osu!](http://codeforces.com/problemset/problem/235/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|161|[Happy Tree Party](http://codeforces.com/problemset/problem/593/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|162|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|163|[Shaass and Lights](http://codeforces.com/problemset/problem/294/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|164|[Little Elephant and Elections](http://codeforces.com/problemset/problem/258/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|165|[Theseus and labyrinth](http://codeforces.com/problemset/problem/676/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|166|[Yaroslav and Time](http://codeforces.com/problemset/problem/301/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|167|[Rat Kwesh and Cheese](http://codeforces.com/problemset/problem/621/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|168|[Minesweeper 1D](http://codeforces.com/problemset/problem/404/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|169|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|170|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|171|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|172|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|173|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|174|[Queue](http://codeforces.com/problemset/problem/353/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|175|[Inna and Pink Pony](http://codeforces.com/problemset/problem/374/A)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|176|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|177|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|178|[Minimization](http://codeforces.com/problemset/problem/571/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|179|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|180|[Paths and Trees](http://codeforces.com/problemset/problem/545/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|181|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|182|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|183|[Wet Shark and Blocks](http://codeforces.com/problemset/problem/621/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|184|[Empire Strikes Back](http://codeforces.com/problemset/problem/300/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|185|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|186|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|187|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|188|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|189|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|190|[Coin Troubles](http://codeforces.com/problemset/problem/283/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|191|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|192|[Yet Another Number Game](http://codeforces.com/problemset/problem/282/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|193|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|194|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|195|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|196|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|197|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|198|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|199|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|200|[Optimize!](http://codeforces.com/problemset/problem/338/E)|Codeforces|8|
