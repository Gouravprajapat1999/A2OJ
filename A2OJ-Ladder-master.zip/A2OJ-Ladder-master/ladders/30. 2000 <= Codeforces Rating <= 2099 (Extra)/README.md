# Ladder Name: 30 - 2000 <= Codeforces Rating <= 2099 (Extra)
## Description
 Extra problems for users satisfying this condition
## Difficulty Level: 5

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[George and Accommodation](http://codeforces.com/problemset/problem/467/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Opponents](http://codeforces.com/problemset/problem/688/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Patrick and Shopping](http://codeforces.com/problemset/problem/599/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[Mashmokh and Lights](http://codeforces.com/problemset/problem/415/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Squats](http://codeforces.com/problemset/problem/424/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|6|[Sereja and Mugs](http://codeforces.com/problemset/problem/426/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|7|[Summer Camp](http://codeforces.com/problemset/problem/672/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|8|[Case of the Zeros and Ones](http://codeforces.com/problemset/problem/556/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Lucky String](http://codeforces.com/problemset/problem/110/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Queue on Bus Stop](http://codeforces.com/problemset/problem/435/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[Currency System in Geraldion](http://codeforces.com/problemset/problem/560/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Saitama Destroys Hotel](http://codeforces.com/problemset/problem/608/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[Lecture](http://codeforces.com/problemset/problem/499/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|14|[Uncowed Forces](http://codeforces.com/problemset/problem/604/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|15|[Drazil and Date](http://codeforces.com/problemset/problem/515/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|16|[Different is Good](http://codeforces.com/problemset/problem/672/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|17|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|18|[Plant](http://codeforces.com/problemset/problem/185/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|19|[Infinite Sequence](http://codeforces.com/problemset/problem/675/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|20|[K-special Tables](http://codeforces.com/problemset/problem/625/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|21|[Digital Counter](http://codeforces.com/problemset/problem/495/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|22|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|23|[Memory and Trident](http://codeforces.com/problemset/problem/712/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|24|[Vasya and Football](http://codeforces.com/problemset/problem/493/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|25|[Lucky Mask](http://codeforces.com/problemset/problem/146/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|26|[Alternative Thinking](http://codeforces.com/problemset/problem/603/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|27|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|28|[Sereja and Algorithm ](http://codeforces.com/problemset/problem/367/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|29|[Megacity](http://codeforces.com/problemset/problem/424/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|30|[Beautiful Paintings](http://codeforces.com/problemset/problem/651/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|31|[Petya and Square](http://codeforces.com/problemset/problem/112/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|32|[Valuable Resources](http://codeforces.com/problemset/problem/485/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|33|[Progress Bar](http://codeforces.com/problemset/problem/71/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|34|[Garland](http://codeforces.com/problemset/problem/408/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|35|[War of the Corporations](http://codeforces.com/problemset/problem/625/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|36|[Misha and Changing Handles](http://codeforces.com/problemset/problem/501/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|37|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|38|[Sereja and Mirroring](http://codeforces.com/problemset/problem/426/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|39|[The Child and Homework](http://codeforces.com/problemset/problem/437/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|40|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|41|[Pyramid of Glasses](http://codeforces.com/problemset/problem/676/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|42|[Restoring Painting](http://codeforces.com/problemset/problem/675/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|43|[Petya and Inequiations](http://codeforces.com/problemset/problem/111/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|44|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|45|[Sereja and Prefixes](http://codeforces.com/problemset/problem/380/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|46|[Cthulhu](http://codeforces.com/problemset/problem/103/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Chris and Magic Square](http://codeforces.com/problemset/problem/711/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|48|[Logo Turtle](http://codeforces.com/problemset/problem/132/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|49|[Moodular Arithmetic](http://codeforces.com/problemset/problem/603/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|50|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|51|[Message](http://codeforces.com/problemset/problem/156/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|52|[24 Game](http://codeforces.com/problemset/problem/468/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|53|[Mike and Chocolate Thieves](http://codeforces.com/problemset/problem/689/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|54|[Peter and Snow Blower](http://codeforces.com/problemset/problem/613/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|55|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|56|[Hometask](http://codeforces.com/problemset/problem/154/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|57|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|58|[Memory and De-Evolution](http://codeforces.com/problemset/problem/712/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|59|[Levko and Array Recovery](http://codeforces.com/problemset/problem/360/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|60|[Vasya and Wrestling](http://codeforces.com/problemset/problem/493/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|61|[Kay and Snowflake](http://codeforces.com/problemset/problem/685/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|62|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|63|[Coloring Trees](http://codeforces.com/problemset/problem/711/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|64|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|65|[History](http://codeforces.com/problemset/problem/137/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|66|[Zuma](http://codeforces.com/problemset/problem/607/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|67|[Fish Weight](http://codeforces.com/problemset/problem/297/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|68|[Sereja and Swaps](http://codeforces.com/problemset/problem/425/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|69|[The Child and Set](http://codeforces.com/problemset/problem/437/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|70|[Tavas and Karafs](http://codeforces.com/problemset/problem/535/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|71|[Once Again...](http://codeforces.com/problemset/problem/582/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|72|[Win or Freeze](http://codeforces.com/problemset/problem/150/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|73|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|74|[World Tour](http://codeforces.com/problemset/problem/666/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|75|[Chip 'n Dale Rescue Rangers](http://codeforces.com/problemset/problem/590/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|76|[Pythagorean Triples](http://codeforces.com/problemset/problem/707/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|77|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|78|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|79|[The Two Routes](http://codeforces.com/problemset/problem/601/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|80|[Lipshitz Sequence](http://codeforces.com/problemset/problem/601/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|81|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|82|[Theseus and labyrinth](http://codeforces.com/problemset/problem/676/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|83|[Table](http://codeforces.com/problemset/problem/232/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|84|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|85|[Fragile Bridges](http://codeforces.com/problemset/problem/201/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|86|[Minimization](http://codeforces.com/problemset/problem/571/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|87|[Lengthening Sticks](http://codeforces.com/problemset/problem/571/A)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|88|[Sereja and Periods](http://codeforces.com/problemset/problem/314/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|89|[Anton and Ira](http://codeforces.com/problemset/problem/584/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|90|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|91|[Karen and Supermarket](http://codeforces.com/problemset/problem/815/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|92|[Happy Tree Party](http://codeforces.com/problemset/problem/593/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|93|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|94|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|95|[Little Elephant and Shifts](http://codeforces.com/problemset/problem/220/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|96|[Queue](http://codeforces.com/problemset/problem/353/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|97|[Ksenia and Pawns](http://codeforces.com/problemset/problem/382/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|98|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|99|[Petya and Spiders](http://codeforces.com/problemset/problem/111/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|100|[Free Market](http://codeforces.com/problemset/problem/364/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|101|[Relay Race](http://codeforces.com/problemset/problem/213/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|102|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|103|[Complete The Graph](http://codeforces.com/problemset/problem/715/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|104|[Coloring Brackets](http://codeforces.com/problemset/problem/149/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|105|[Ilya and Roads](http://codeforces.com/problemset/problem/313/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|106|[Lucky Numbers](http://codeforces.com/problemset/problem/95/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|107|[Compartments](http://codeforces.com/problemset/problem/356/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|108|[Xenia and Hamming](http://codeforces.com/problemset/problem/356/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|109|[Little Elephant and Furik and Rubik](http://codeforces.com/problemset/problem/204/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|110|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|111|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|112|[Maxim and Restaurant](http://codeforces.com/problemset/problem/261/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|113|[Spongebob and Squares](http://codeforces.com/problemset/problem/599/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|114|[The table](http://codeforces.com/problemset/problem/226/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|115|[Numbers](http://codeforces.com/problemset/problem/213/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|116|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|117|[Partial Sums](http://codeforces.com/problemset/problem/223/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|118|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|119|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|120|[Alyona and Strings](http://codeforces.com/problemset/problem/682/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|121|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|122|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|123|[Strictly Positive Matrix](http://codeforces.com/problemset/problem/402/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|124|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|125|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|126|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|127|[Time to Raid Cowavans](http://codeforces.com/problemset/problem/103/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|128|[Directed Roads](http://codeforces.com/problemset/problem/711/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|129|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|130|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|131|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|132|[Two Strings](http://codeforces.com/problemset/problem/223/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|133|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|134|[Ring Road 2](http://codeforces.com/problemset/problem/27/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|135|[Lucky Number Representation](http://codeforces.com/problemset/problem/354/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|136|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|137|[Superior Periodic Subarrays](http://codeforces.com/problemset/problem/582/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|138|[Pluses everywhere](http://codeforces.com/problemset/problem/520/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|139|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|140|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|141|[Kleofáš and the n-thlon](http://codeforces.com/problemset/problem/601/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|142|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|143|[Lieges of Legendre](http://codeforces.com/problemset/problem/603/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|144|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|145|[Sonya and Problem Wihtout a Legend](http://codeforces.com/problemset/problem/713/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|146|[Ant Man](http://codeforces.com/problemset/problem/704/B)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|147|[Alyona and towers](http://codeforces.com/problemset/problem/739/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|148|[Double Happiness](http://codeforces.com/problemset/problem/113/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|149|[Lovely Matrix](http://codeforces.com/problemset/problem/274/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|150|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|151|[George and Cards](http://codeforces.com/problemset/problem/387/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|152|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|153|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|154|[Garlands](http://codeforces.com/problemset/problem/707/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|155|[Codeword](http://codeforces.com/problemset/problem/666/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|156|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|157|[Graph Cutting](http://codeforces.com/problemset/problem/405/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|158|[Wilbur and Trees](http://codeforces.com/problemset/problem/596/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|159|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|160|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|161|[ZS and The Birthday Paradox](http://codeforces.com/problemset/problem/711/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|162|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|163|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|164|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|165|[Animals and Puzzle](http://codeforces.com/problemset/problem/713/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|166|[Splitting the Uniqueness](http://codeforces.com/problemset/problem/297/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|167|[Curious Array](http://codeforces.com/problemset/problem/407/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|168|[Igloo Skyscraper](http://codeforces.com/problemset/problem/91/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|169|[Clearing Up](http://codeforces.com/problemset/problem/141/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|170|[President's Path](http://codeforces.com/problemset/problem/416/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|171|[String](http://codeforces.com/problemset/problem/123/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|172|[Painting Square](http://codeforces.com/problemset/problem/300/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|173|[Alphabet Permutations](http://codeforces.com/problemset/problem/610/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|174|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|175|[Sereja and Sets](http://codeforces.com/problemset/problem/425/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|176|[Game with Strings](http://codeforces.com/problemset/problem/354/B)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|177|[Clues](http://codeforces.com/problemset/problem/156/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|178|[Counter Attack](http://codeforces.com/problemset/problem/190/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|179|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|180|[Lucky Country](http://codeforces.com/problemset/problem/95/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|181|[Interval Cubing](http://codeforces.com/problemset/problem/311/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|182|[Little Victor and Set](http://codeforces.com/problemset/problem/460/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|183|[Minimum Modular](http://codeforces.com/problemset/problem/303/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|184|[Sandy and Nuts](http://codeforces.com/problemset/problem/599/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|185|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|186|[Linear Kingdom Races](http://codeforces.com/problemset/problem/115/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|187|[Yaroslav and Points](http://codeforces.com/problemset/problem/295/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|188|[Arpa’s overnight party and Mehrdad’s silent entering](http://codeforces.com/problemset/problem/741/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|189|[Iahub and Xors](http://codeforces.com/problemset/problem/341/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|190|[Working routine](http://codeforces.com/problemset/problem/706/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|191|[Sereja and Sets](http://codeforces.com/problemset/problem/367/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|192|[Levko and Strings](http://codeforces.com/problemset/problem/360/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|193|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|194|[Little Elephant and Tree](http://codeforces.com/problemset/problem/258/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|195|[Maze](http://codeforces.com/problemset/problem/123/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|196|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|197|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|198|[Jeff and Removing Periods](http://codeforces.com/problemset/problem/351/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|199|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|200|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces|8|
