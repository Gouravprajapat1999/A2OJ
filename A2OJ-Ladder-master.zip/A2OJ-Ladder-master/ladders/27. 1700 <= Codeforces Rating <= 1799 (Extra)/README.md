# Ladder Name: 27 - 1700 <= Codeforces Rating <= 1799 (Extra)
## Description
 Extra problems for users satisfying this condition
## Difficulty Level: 4

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Circle Line](http://codeforces.com/problemset/problem/278/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Restoring Password](http://codeforces.com/problemset/problem/94/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Playing with Dice](http://codeforces.com/problemset/problem/378/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[Colorful Stones (Simplified Edition)](http://codeforces.com/problemset/problem/265/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Roma and Lucky Numbers](http://codeforces.com/problemset/problem/262/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|6|[Kyoya and Photobooks](http://codeforces.com/problemset/problem/554/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|7|[Valera and X](http://codeforces.com/problemset/problem/404/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|8|[Game With Sticks](http://codeforces.com/problemset/problem/451/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Vasya and Digital Root](http://codeforces.com/problemset/problem/355/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Multiplication Table](http://codeforces.com/problemset/problem/577/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[Calculating Function](http://codeforces.com/problemset/problem/486/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Valera and Antique Items](http://codeforces.com/problemset/problem/441/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[Kefa and First Steps](http://codeforces.com/problemset/problem/580/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|14|[Toy Cars](http://codeforces.com/problemset/problem/545/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|15|[Joysticks](http://codeforces.com/problemset/problem/651/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|16|[Little Frog](http://codeforces.com/problemset/problem/53/C)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|17|[Sinking Ship](http://codeforces.com/problemset/problem/63/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|18|[Case of the Zeros and Ones](http://codeforces.com/problemset/problem/556/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|19|[Roadside Trees (Simplified Edition)](http://codeforces.com/problemset/problem/265/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|20|[Ciel and Dancing](http://codeforces.com/problemset/problem/322/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|21|[Currency System in Geraldion](http://codeforces.com/problemset/problem/560/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|22|[Prizes, Prizes, more Prizes](http://codeforces.com/problemset/problem/208/D)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|23|[Bear and Poker](http://codeforces.com/problemset/problem/573/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|24|[Fox and Number Game](http://codeforces.com/problemset/problem/389/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|25|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|26|[Misha and Changing Handles](http://codeforces.com/problemset/problem/501/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|27|[Cifera](http://codeforces.com/problemset/problem/114/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|28|[Lucky Tickets](http://codeforces.com/problemset/problem/43/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|29|[Bar](http://codeforces.com/problemset/problem/56/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|30|[Bear and Elections](http://codeforces.com/problemset/problem/574/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|31|[Lexicographically Maximum Subsequence](http://codeforces.com/problemset/problem/196/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|32|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|33|[Lucky Permutation Triple](http://codeforces.com/problemset/problem/303/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|34|[Good Number](http://codeforces.com/problemset/problem/365/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|35|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|36|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|37|[War of the Corporations](http://codeforces.com/problemset/problem/625/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|38|[Fortune Telling](http://codeforces.com/problemset/problem/59/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|39|[Sereja and Algorithm ](http://codeforces.com/problemset/problem/367/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|40|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|41|[Ohana Cleans Up](http://codeforces.com/problemset/problem/554/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|42|[Students and Shoelaces](http://codeforces.com/problemset/problem/129/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|43|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|44|[Maxim and Discounts](http://codeforces.com/problemset/problem/261/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|45|[Kyoya and Colored Balls](http://codeforces.com/problemset/problem/553/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|46|[Heap Operations](http://codeforces.com/problemset/problem/681/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Colliders](http://codeforces.com/problemset/problem/154/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|48|[Day at the Beach](http://codeforces.com/problemset/problem/599/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|49|[History](http://codeforces.com/problemset/problem/137/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|50|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|51|[Sereja and Contest](http://codeforces.com/problemset/problem/314/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|52|[Division into Teams](http://codeforces.com/problemset/problem/149/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|53|[Dima and Two Sequences](http://codeforces.com/problemset/problem/272/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|54|[Marina and Vasya](http://codeforces.com/problemset/problem/584/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|55|[George and Number](http://codeforces.com/problemset/problem/387/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|56|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|57|[Approximating a Constant Range](http://codeforces.com/problemset/problem/602/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|58|[The Big Race](http://codeforces.com/problemset/problem/592/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|59|[Magic Formulas](http://codeforces.com/problemset/problem/424/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|60|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|61|[Gerald is into Art](http://codeforces.com/problemset/problem/560/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|62|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|63|[Plate Game](http://codeforces.com/problemset/problem/197/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|64|[Tavas and Karafs](http://codeforces.com/problemset/problem/535/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|65|[Dima and Lisa](http://codeforces.com/problemset/problem/584/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|66|[Cows and Primitive Roots](http://codeforces.com/problemset/problem/284/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|67|[Secret](http://codeforces.com/problemset/problem/271/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|68|[Fish Weight](http://codeforces.com/problemset/problem/297/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|69|[GCD Table](http://codeforces.com/problemset/problem/582/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|70|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|71|[Olympiad](http://codeforces.com/problemset/problem/222/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|72|[Preparing Olympiad](http://codeforces.com/problemset/problem/550/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|73|[Image Preview](http://codeforces.com/problemset/problem/650/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|74|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|75|[Biridian Forest](http://codeforces.com/problemset/problem/329/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|76|[Gena's Code](http://codeforces.com/problemset/problem/614/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|77|[Dynasty Puzzles](http://codeforces.com/problemset/problem/191/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|78|[Eight Point Sets](http://codeforces.com/problemset/problem/334/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|79|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|80|[Fire Again](http://codeforces.com/problemset/problem/35/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|81|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|82|[Lazy Student](http://codeforces.com/problemset/problem/605/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|83|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|84|[Queue](http://codeforces.com/problemset/problem/545/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|85|[Wet Shark and Flowers](http://codeforces.com/problemset/problem/621/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|86|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|87|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|88|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|89|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|90|[Hometask](http://codeforces.com/problemset/problem/154/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|91|[Case of Matryoshkas](http://codeforces.com/problemset/problem/555/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|92|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|93|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|94|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|95|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|96|[Win or Freeze](http://codeforces.com/problemset/problem/150/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|97|[Soldier and Badges](http://codeforces.com/problemset/problem/546/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|98|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|99|[Woodcutters](http://codeforces.com/problemset/problem/545/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|100|[Perfect Pair](http://codeforces.com/problemset/problem/317/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|101|[Tree Construction](http://codeforces.com/problemset/problem/675/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|102|[The Values You Can Make](http://codeforces.com/problemset/problem/687/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|103|[Magic Five](http://codeforces.com/problemset/problem/327/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|104|[Falling Anvils](http://codeforces.com/problemset/problem/77/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|105|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|106|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|107|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|108|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|109|[Zuma](http://codeforces.com/problemset/problem/607/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|110|[Primes on Interval](http://codeforces.com/problemset/problem/237/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|111|[Road Map](http://codeforces.com/problemset/problem/34/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|112|[Harmony Analysis](http://codeforces.com/problemset/problem/610/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|113|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|114|[Prime Swaps](http://codeforces.com/problemset/problem/432/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|115|[Cthulhu](http://codeforces.com/problemset/problem/103/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|116|[Pasha and Tea](http://codeforces.com/problemset/problem/557/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|117|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|118|[k-Multiple Free Set](http://codeforces.com/problemset/problem/274/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|119|[Recycling Bottles](http://codeforces.com/problemset/problem/671/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|120|[Bear and Three Musketeers](http://codeforces.com/problemset/problem/574/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|121|[Beauty Pageant](http://codeforces.com/problemset/problem/246/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|122|[About Bacteria](http://codeforces.com/problemset/problem/198/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|123|[Spongebob and Joke](http://codeforces.com/problemset/problem/599/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|124|[Bear and Blocks](http://codeforces.com/problemset/problem/573/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|125|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|126|[Chips](http://codeforces.com/problemset/problem/333/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|127|[Guest From the Past](http://codeforces.com/problemset/problem/625/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|128|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|129|[Magic Box](http://codeforces.com/problemset/problem/231/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|130|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|131|[Longtail Hedgehog](http://codeforces.com/problemset/problem/615/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|132|[Queue](http://codeforces.com/problemset/problem/91/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|133|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|134|[Watering Flowers](http://codeforces.com/problemset/problem/617/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|135|[Polyline](http://codeforces.com/problemset/problem/617/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|136|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|137|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|138|[Numbers](http://codeforces.com/problemset/problem/213/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|139|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|140|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|141|[Cipher](http://codeforces.com/problemset/problem/156/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|142|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|143|[Last Chance](http://codeforces.com/problemset/problem/137/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|144|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|145|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|146|[Relay Race](http://codeforces.com/problemset/problem/213/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|147|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|148|[Sereja and Periods](http://codeforces.com/problemset/problem/314/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|149|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|150|[Reducing Fractions](http://codeforces.com/problemset/problem/222/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|151|[Alyona and Strings](http://codeforces.com/problemset/problem/682/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|152|[Police Station](http://codeforces.com/problemset/problem/208/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|153|[Pawn](http://codeforces.com/problemset/problem/41/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|154|[Permutation Sum](http://codeforces.com/problemset/problem/285/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|155|[Ilya and Roads](http://codeforces.com/problemset/problem/313/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|156|[Triangles](http://codeforces.com/problemset/problem/229/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|157|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|158|[Spongebob and Squares](http://codeforces.com/problemset/problem/599/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|159|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|160|[Hydra](http://codeforces.com/problemset/problem/243/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|161|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|162|[Decoding Genome](http://codeforces.com/problemset/problem/222/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|163|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|164|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|165|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|166|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|167|[Minesweeper 1D](http://codeforces.com/problemset/problem/404/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|168|[Two Strings](http://codeforces.com/problemset/problem/223/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|169|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|170|[Shaass and Lights](http://codeforces.com/problemset/problem/294/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|171|[Cycle in Graph](http://codeforces.com/problemset/problem/263/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|172|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|173|[Ring Road 2](http://codeforces.com/problemset/problem/27/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|174|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|175|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|176|[Sum](http://codeforces.com/problemset/problem/257/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|177|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|178|[Journey](http://codeforces.com/problemset/problem/721/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|179|[Paths and Trees](http://codeforces.com/problemset/problem/545/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|180|[Vitaly and Cycle](http://codeforces.com/problemset/problem/557/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|181|[Block Tower](http://codeforces.com/problemset/problem/327/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|182|[Dispute](http://codeforces.com/problemset/problem/242/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|183|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|184|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|185|[Queue](http://codeforces.com/problemset/problem/353/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|186|[Amr and Chemistry](http://codeforces.com/problemset/problem/558/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|187|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|188|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|189|[Kefa and Dishes](http://codeforces.com/problemset/problem/580/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|190|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|191|[Yet Another Number Game](http://codeforces.com/problemset/problem/282/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|192|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|193|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|194|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|195|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|196|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|197|[Vasily the Bear and Beautiful Strings](http://codeforces.com/problemset/problem/336/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|198|[Little Victor and Set](http://codeforces.com/problemset/problem/460/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|199|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|200|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces|7|
