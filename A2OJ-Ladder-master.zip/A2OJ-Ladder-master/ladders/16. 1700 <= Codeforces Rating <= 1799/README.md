# Ladder Name: 16 - 1700 <= Codeforces Rating <= 1799
## Description
 For users satisfying this condition
## Difficulty Level: 4

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Candy Bags](http://codeforces.com/problemset/problem/334/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Word](http://codeforces.com/problemset/problem/59/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Dreamoon and Stairs](http://codeforces.com/problemset/problem/476/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|4|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|5|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|6|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|7|[Little Elephant and Bits](http://codeforces.com/problemset/problem/258/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|8|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|9|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|10|[Greg and Array](http://codeforces.com/problemset/problem/295/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|11|[Table Decorations](http://codeforces.com/problemset/problem/478/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|12|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|13|[Valera and Elections](http://codeforces.com/problemset/problem/369/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|14|[Psychos in a Line](http://codeforces.com/problemset/problem/319/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|15|[Counting Rectangles is Fun](http://codeforces.com/problemset/problem/372/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|16|[Greg and Graph](http://codeforces.com/problemset/problem/295/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|17|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|18|[Renting Bikes](http://codeforces.com/problemset/problem/363/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|19|[Treasure](http://codeforces.com/problemset/problem/494/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|20|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|21|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|22|[Colorful Graph](http://codeforces.com/problemset/problem/246/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|23|[Zero Tree](http://codeforces.com/problemset/problem/274/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|24|[King's Path](http://codeforces.com/problemset/problem/242/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|25|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|26|[Greenhouse Effect](http://codeforces.com/problemset/problem/269/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|27|[The Brand New Function](http://codeforces.com/problemset/problem/243/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|28|[Caesar's Legions](http://codeforces.com/problemset/problem/118/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|29|[Dima and Hares](http://codeforces.com/problemset/problem/358/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|30|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|31|[Hamburgers](http://codeforces.com/problemset/problem/371/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|32|[Petya and Divisors](http://codeforces.com/problemset/problem/111/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|33|[Matrix](http://codeforces.com/problemset/problem/364/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|34|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|35|[Barcode](http://codeforces.com/problemset/problem/225/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|36|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|37|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|38|[Ciel and Robot](http://codeforces.com/problemset/problem/321/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|39|[Little Elephant and Interval](http://codeforces.com/problemset/problem/204/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|40|[Little Elephant and Cards](http://codeforces.com/problemset/problem/204/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|41|[Good Sequences](http://codeforces.com/problemset/problem/264/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|42|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|43|[Mike and Feet](http://codeforces.com/problemset/problem/547/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|44|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|45|[Maximum Submatrix 2](http://codeforces.com/problemset/problem/375/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|46|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Good Substrings](http://codeforces.com/problemset/problem/271/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|48|[GukiZ hates Boxes](http://codeforces.com/problemset/problem/551/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|49|[Regular Bridge](http://codeforces.com/problemset/problem/550/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|50|[MUH and Cube Walls](http://codeforces.com/problemset/problem/471/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|51|[Little Pony and Harmony Chest](http://codeforces.com/problemset/problem/453/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|52|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|53|[Obsessive String](http://codeforces.com/problemset/problem/494/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|54|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|55|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|56|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|57|[Lucky Tree](http://codeforces.com/problemset/problem/109/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|58|[Missile Silos](http://codeforces.com/problemset/problem/144/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|59|[Sereja and the Arrangement of Numbers](http://codeforces.com/problemset/problem/367/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|60|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|61|[A and B and Interesting Substrings](http://codeforces.com/problemset/problem/519/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|62|[Equivalent Strings](http://codeforces.com/problemset/problem/559/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|63|[Book of Evil](http://codeforces.com/problemset/problem/337/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|64|[Dima and Bacteria](http://codeforces.com/problemset/problem/400/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|65|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|66|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|67|[Pashmak and Buses](http://codeforces.com/problemset/problem/459/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|68|[Pashmak and Parmida's problem](http://codeforces.com/problemset/problem/459/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|69|[Count Good Substrings](http://codeforces.com/problemset/problem/451/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|70|[Book of Evil](http://codeforces.com/problemset/problem/337/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|71|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|72|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|73|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|74|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|75|[Choosing Balls](http://codeforces.com/problemset/problem/264/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|76|[Watto and Mechanism](http://codeforces.com/problemset/problem/514/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|77|[Multiplication Table](http://codeforces.com/problemset/problem/448/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|78|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|79|[Lucky Common Subsequence](http://codeforces.com/problemset/problem/346/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|80|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|81|[Sereja ans Anagrams](http://codeforces.com/problemset/problem/367/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|82|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|83|[Porcelain](http://codeforces.com/problemset/problem/148/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|84|[Devu and his Brother](http://codeforces.com/problemset/problem/439/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|85|[Eternal Victory](http://codeforces.com/problemset/problem/61/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|86|[Red-Green Towers](http://codeforces.com/problemset/problem/478/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|87|[Choosing Capital for Treeland](http://codeforces.com/problemset/problem/219/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|88|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|89|[Vessels](http://codeforces.com/problemset/problem/371/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|90|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|91|[Bag of mice](http://codeforces.com/problemset/problem/148/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|92|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|93|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|94|[Pashmak and Graph](http://codeforces.com/problemset/problem/459/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|95|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|96|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|97|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|98|[Little Girl and Problem on Trees](http://codeforces.com/problemset/problem/276/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|99|[Antimatter](http://codeforces.com/problemset/problem/383/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|100|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces|6|
