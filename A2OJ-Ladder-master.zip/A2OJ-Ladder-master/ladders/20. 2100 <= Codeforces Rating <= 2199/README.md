# Ladder Name: 20 - 2100 <= Codeforces Rating <= 2199
## Description
 For users satisfying this condition
## Difficulty Level: 5

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Anton and Letters](http://codeforces.com/problemset/problem/443/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Watching a movie](http://codeforces.com/problemset/problem/499/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|3|[Expression](http://codeforces.com/problemset/problem/479/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|4|[Caisa and Pylons](http://codeforces.com/problemset/problem/463/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|5|[Appleman and Easy Task](http://codeforces.com/problemset/problem/462/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|6|[DZY Loves Strings](http://codeforces.com/problemset/problem/447/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|7|[DZY Loves Hash](http://codeforces.com/problemset/problem/447/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|8|[inc ARG](http://codeforces.com/problemset/problem/465/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Inbox (100500)](http://codeforces.com/problemset/problem/465/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Mike and Fax](http://codeforces.com/problemset/problem/548/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|11|[Caisa and Sugar](http://codeforces.com/problemset/problem/463/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|12|[Laptops](http://codeforces.com/problemset/problem/456/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|13|[Set of Strings](http://codeforces.com/problemset/problem/544/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|14|[DZY Loves Chessboard](http://codeforces.com/problemset/problem/445/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|15|[Fedya and Maths](http://codeforces.com/problemset/problem/456/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|16|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|17|[Suffix Structures](http://codeforces.com/problemset/problem/448/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|18|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|19|[Kyoya and Permutation](http://codeforces.com/problemset/problem/553/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|20|[Kolya and Tandem Repeat](http://codeforces.com/problemset/problem/443/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|21|[Sea and Islands](http://codeforces.com/problemset/problem/544/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|22|[Writing Code](http://codeforces.com/problemset/problem/543/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|23|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|24|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|25|[DZY Loves Physics](http://codeforces.com/problemset/problem/444/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|26|[Maximum Xor Secondary](http://codeforces.com/problemset/problem/280/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|27|[Two Sets](http://codeforces.com/problemset/problem/468/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|28|[Maximum Value](http://codeforces.com/problemset/problem/484/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|29|[Jeff and Permutation](http://codeforces.com/problemset/problem/351/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|30|[Case of Fugitive](http://codeforces.com/problemset/problem/555/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|31|[Main Sequence](http://codeforces.com/problemset/problem/286/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|32|[Gargari and Permutations](http://codeforces.com/problemset/problem/463/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|33|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|34|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|35|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|36|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|37|[Array and Operations](http://codeforces.com/problemset/problem/498/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|38|[Restore Cube ](http://codeforces.com/problemset/problem/464/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|39|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|40|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|41|[Destroying Roads](http://codeforces.com/problemset/problem/543/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|42|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|43|[Little Pony and Summer Sun Celebration](http://codeforces.com/problemset/problem/453/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|44|[Shifting](http://codeforces.com/problemset/problem/286/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|45|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|46|[Appleman and a Sheet of Paper](http://codeforces.com/problemset/problem/461/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|47|[Jzzhu and Chocolate](http://codeforces.com/problemset/problem/449/A)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|48|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|49|[Kalila and Dimna in the Logging Industry](http://codeforces.com/problemset/problem/319/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|50|[Equivalent Strings](http://codeforces.com/problemset/problem/559/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|51|[Substitutes in Number](http://codeforces.com/problemset/problem/464/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|52|[Jzzhu and Cities](http://codeforces.com/problemset/problem/449/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|53|[Information Graph](http://codeforces.com/problemset/problem/466/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|54|[Mike and Foam](http://codeforces.com/problemset/problem/547/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|55|[Brackets in Implications](http://codeforces.com/problemset/problem/550/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|56|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|57|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|58|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|59|[DZY Loves FFT](http://codeforces.com/problemset/problem/444/B)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|60|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|61|[Caisa and Tree](http://codeforces.com/problemset/problem/463/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|62|[Darth Vader and Tree](http://codeforces.com/problemset/problem/514/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|63|[Prefix Product Sequence](http://codeforces.com/problemset/problem/487/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|64|[Traffic Jams in the Land](http://codeforces.com/problemset/problem/498/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|65|[Name That Tune](http://codeforces.com/problemset/problem/498/B)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|66|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|67|[Tricky Function](http://codeforces.com/problemset/problem/429/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|68|[Drazil and Park](http://codeforces.com/problemset/problem/515/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|69|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|70|[Road Improvement](http://codeforces.com/problemset/problem/543/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|71|[Dreamoon and Strings](http://codeforces.com/problemset/problem/476/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|72|[Fox And Dinner](http://codeforces.com/problemset/problem/510/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|73|[Jzzhu and Numbers](http://codeforces.com/problemset/problem/449/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|74|[Adam and Tree](http://codeforces.com/problemset/problem/442/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|75|[Remembering Strings](http://codeforces.com/problemset/problem/543/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|76|[Alex and Complicated Task](http://codeforces.com/problemset/problem/467/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|77|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|78|[Tachibana Kanade's Tofu](http://codeforces.com/problemset/problem/433/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|79|[DZY Loves Strings](http://codeforces.com/problemset/problem/444/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|80|[Guess Your Way Out! II](http://codeforces.com/problemset/problem/558/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|81|[XOR and Favorite Number](http://codeforces.com/problemset/problem/617/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|82|[Volcanoes](http://codeforces.com/problemset/problem/383/B)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|83|[Artem and Array ](http://codeforces.com/problemset/problem/442/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|84|[Arthur and Walls](http://codeforces.com/problemset/problem/525/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|85|[Fedor and Essay](http://codeforces.com/problemset/problem/467/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|86|[Pig and Palindromes](http://codeforces.com/problemset/problem/570/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|87|[GukiZ and Binary Operations](http://codeforces.com/problemset/problem/551/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|88|[Hack it!](http://codeforces.com/problemset/problem/468/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|89|[Case of a Top Secret](http://codeforces.com/problemset/problem/555/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|90|[GukiZ and GukiZiana](http://codeforces.com/problemset/problem/551/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|91|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|92|[Jzzhu and Apples](http://codeforces.com/problemset/problem/449/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|93|[Vowels](http://codeforces.com/problemset/problem/383/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|94|[Ciel and Gondolas](http://codeforces.com/problemset/problem/321/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|95|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|96|[Helping People](http://codeforces.com/problemset/problem/494/C)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|97|[Mike and Fish](http://codeforces.com/problemset/problem/547/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|98|[Mike and Friends](http://codeforces.com/problemset/problem/547/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|99|[Serega and Fun](http://codeforces.com/problemset/problem/455/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|100|[Function](http://codeforces.com/problemset/problem/455/E)|Codeforces|9|
