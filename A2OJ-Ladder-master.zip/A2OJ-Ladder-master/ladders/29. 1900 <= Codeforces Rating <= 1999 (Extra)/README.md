# Ladder Name: 29 - 1900 <= Codeforces Rating <= 1999 (Extra)
## Description
 Extra problems for users satisfying this condition
## Difficulty Level: 5

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Rewards](http://codeforces.com/problemset/problem/448/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Kyoya and Photobooks](http://codeforces.com/problemset/problem/554/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Playing with Dice](http://codeforces.com/problemset/problem/378/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[George and Accommodation](http://codeforces.com/problemset/problem/467/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Bear and Finding Criminals](http://codeforces.com/problemset/problem/680/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|6|[Table](http://codeforces.com/problemset/problem/359/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|7|[Lever](http://codeforces.com/problemset/problem/376/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|8|[Drazil and Date](http://codeforces.com/problemset/problem/515/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Exams](http://codeforces.com/problemset/problem/194/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Bear and Five Cards](http://codeforces.com/problemset/problem/680/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[Amr and Music](http://codeforces.com/problemset/problem/507/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Initial Bet](http://codeforces.com/problemset/problem/478/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[Game With Sticks](http://codeforces.com/problemset/problem/451/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|14|[Devu, the Singer and Churu, the Joker](http://codeforces.com/problemset/problem/439/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|15|[Joysticks](http://codeforces.com/problemset/problem/651/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|16|[Arrays](http://codeforces.com/problemset/problem/572/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|17|[Case of the Zeros and Ones](http://codeforces.com/problemset/problem/556/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|18|[Multiplication Table](http://codeforces.com/problemset/problem/577/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|19|[Currency System in Geraldion](http://codeforces.com/problemset/problem/560/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|20|[Domino Effect](http://codeforces.com/problemset/problem/405/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|21|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|22|[Sereja and Stairs](http://codeforces.com/problemset/problem/381/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|23|[Bear and Poker](http://codeforces.com/problemset/problem/573/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|24|[I.O.U.](http://codeforces.com/problemset/problem/376/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|25|[Nuts](http://codeforces.com/problemset/problem/402/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|26|[The Wall](http://codeforces.com/problemset/problem/340/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|27|[Semifinals](http://codeforces.com/problemset/problem/378/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|28|[Valuable Resources](http://codeforces.com/problemset/problem/485/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|29|[Prizes, Prizes, more Prizes](http://codeforces.com/problemset/problem/208/D)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|30|[Fox and Number Game](http://codeforces.com/problemset/problem/389/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|31|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|32|[Elections](http://codeforces.com/problemset/problem/570/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|33|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|34|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|35|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|36|[Diverse Permutation](http://codeforces.com/problemset/problem/482/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|37|[MUH and Sticks](http://codeforces.com/problemset/problem/471/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|38|[Kyoya and Colored Balls](http://codeforces.com/problemset/problem/553/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|39|[Mashmokh and Numbers](http://codeforces.com/problemset/problem/414/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|40|[Devu, the Dumb Guy](http://codeforces.com/problemset/problem/439/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|41|[Random Teams](http://codeforces.com/problemset/problem/478/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|42|[Chat Online](http://codeforces.com/problemset/problem/469/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|43|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|44|[Basketball Team](http://codeforces.com/problemset/problem/107/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|45|[Dynasty Puzzles](http://codeforces.com/problemset/problem/191/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|46|[Case of Matryoshkas](http://codeforces.com/problemset/problem/555/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|48|[Petya and Inequiations](http://codeforces.com/problemset/problem/111/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|49|[Guess Your Way Out!](http://codeforces.com/problemset/problem/507/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|50|[Naughty Stone Piles](http://codeforces.com/problemset/problem/226/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|51|[Guest From the Past](http://codeforces.com/problemset/problem/625/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|52|[Animals](http://codeforces.com/problemset/problem/35/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|53|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|54|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|55|[Inna and Nine](http://codeforces.com/problemset/problem/374/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|56|[Zuma](http://codeforces.com/problemset/problem/607/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|57|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|58|[Wilbur and Points](http://codeforces.com/problemset/problem/596/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|59|[Pythagorean Triples](http://codeforces.com/problemset/problem/707/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|60|[Ivan and Powers of Two](http://codeforces.com/problemset/problem/305/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|61|[Sereja and Swaps](http://codeforces.com/problemset/problem/425/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|62|[Magic Formulas](http://codeforces.com/problemset/problem/424/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|63|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|64|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|65|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|66|[Bear and Three Musketeers](http://codeforces.com/problemset/problem/574/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|67|[Jumping on Walls](http://codeforces.com/problemset/problem/198/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|68|[Guess a number!](http://codeforces.com/problemset/problem/416/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|69|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|70|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|71|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|72|[Tree Construction](http://codeforces.com/problemset/problem/675/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|73|[Remainders Game](http://codeforces.com/problemset/problem/687/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|74|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|75|[Gerald is into Art](http://codeforces.com/problemset/problem/560/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|76|[Kay and Snowflake](http://codeforces.com/problemset/problem/685/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|77|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|78|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|79|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|80|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|81|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|82|[Unusual Product](http://codeforces.com/problemset/problem/405/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|83|[Chips](http://codeforces.com/problemset/problem/333/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|84|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|85|[The Big Race](http://codeforces.com/problemset/problem/592/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|86|[Borya and Hanabi](http://codeforces.com/problemset/problem/442/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|87|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|88|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|89|[The Values You Can Make](http://codeforces.com/problemset/problem/687/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|90|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|91|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|92|[Ski Base](http://codeforces.com/problemset/problem/91/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|93|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|94|[Police Station](http://codeforces.com/problemset/problem/208/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|95|[Maxim and Restaurant](http://codeforces.com/problemset/problem/261/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|96|[Xenia and Hamming](http://codeforces.com/problemset/problem/356/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|97|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|98|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|99|[Queue](http://codeforces.com/problemset/problem/353/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|100|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|101|[Kleofáš and the n-thlon](http://codeforces.com/problemset/problem/601/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|102|[Little Elephant and Elections](http://codeforces.com/problemset/problem/258/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|103|[Wrong Floyd](http://codeforces.com/problemset/problem/350/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|104|[Free Market](http://codeforces.com/problemset/problem/364/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|105|[Strictly Positive Matrix](http://codeforces.com/problemset/problem/402/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|106|[Hydra](http://codeforces.com/problemset/problem/243/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|107|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|108|[Building Forest](http://codeforces.com/problemset/problem/195/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|109|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|110|[Cipher](http://codeforces.com/problemset/problem/156/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|111|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|112|[Theseus and labyrinth](http://codeforces.com/problemset/problem/676/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|113|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|114|[The table](http://codeforces.com/problemset/problem/226/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|115|[Relay Race](http://codeforces.com/problemset/problem/213/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|116|[Sereja and Periods](http://codeforces.com/problemset/problem/314/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|117|[Lucky Permutation](http://codeforces.com/problemset/problem/121/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|118|[Ilya and Roads](http://codeforces.com/problemset/problem/313/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|119|[Little Elephant and Furik and Rubik](http://codeforces.com/problemset/problem/204/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|120|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|121|[Minesweeper 1D](http://codeforces.com/problemset/problem/404/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|122|[Wizards and Huge Prize](http://codeforces.com/problemset/problem/167/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|123|[Spongebob and Squares](http://codeforces.com/problemset/problem/599/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|124|[Numbers](http://codeforces.com/problemset/problem/213/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|125|[Shortest Path](http://codeforces.com/problemset/problem/59/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|126|[Let's Play Osu!](http://codeforces.com/problemset/problem/235/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|127|[Triangles](http://codeforces.com/problemset/problem/229/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|128|[Lieges of Legendre](http://codeforces.com/problemset/problem/603/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|129|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|130|[Iahub and Permutations](http://codeforces.com/problemset/problem/340/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|131|[Wet Shark and Blocks](http://codeforces.com/problemset/problem/621/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|132|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|133|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|134|[Alyona and Strings](http://codeforces.com/problemset/problem/682/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|135|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|136|[Mushroom Gnomes - 2](http://codeforces.com/problemset/problem/138/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|137|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|138|[Lengthening Sticks](http://codeforces.com/problemset/problem/571/A)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|139|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|140|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|141|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|142|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|143|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|144|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|145|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|146|[Minimization](http://codeforces.com/problemset/problem/571/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|147|[Two Strings](http://codeforces.com/problemset/problem/223/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|148|[Games with Rectangle](http://codeforces.com/problemset/problem/128/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|149|[Interesting Game](http://codeforces.com/problemset/problem/87/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|150|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|151|[Amr and Chemistry](http://codeforces.com/problemset/problem/558/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|152|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|153|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|154|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|155|[Time to Raid Cowavans](http://codeforces.com/problemset/problem/103/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|156|[Decoding Genome](http://codeforces.com/problemset/problem/222/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|157|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|158|[Vitaly and Cycle](http://codeforces.com/problemset/problem/557/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|159|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|160|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|161|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|162|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|163|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|164|[Yet Another Number Game](http://codeforces.com/problemset/problem/282/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|165|[Vasily the Bear and Beautiful Strings](http://codeforces.com/problemset/problem/336/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|166|[Empire Strikes Back](http://codeforces.com/problemset/problem/300/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|167|[George and Cards](http://codeforces.com/problemset/problem/387/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|168|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|169|[Graph Cutting](http://codeforces.com/problemset/problem/405/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|170|[Lovely Matrix](http://codeforces.com/problemset/problem/274/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|171|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|172|[Vanya and Treasure](http://codeforces.com/problemset/problem/677/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|173|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|174|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|175|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|176|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|177|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|178|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|179|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|180|[The Last Fight Between Human and AI](http://codeforces.com/problemset/problem/676/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|181|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|182|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|183|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|184|[Minimum Modular](http://codeforces.com/problemset/problem/303/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|185|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|186|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|187|[Lucky Arrays](http://codeforces.com/problemset/problem/256/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|188|[Working routine](http://codeforces.com/problemset/problem/706/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|189|[Linear Kingdom Races](http://codeforces.com/problemset/problem/115/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|190|[Little Elephant and Tree](http://codeforces.com/problemset/problem/258/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|191|[Lucky Array](http://codeforces.com/problemset/problem/121/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|192|[Alphabet Permutations](http://codeforces.com/problemset/problem/610/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|193|[Sereja and Sets](http://codeforces.com/problemset/problem/367/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|194|[President's Path](http://codeforces.com/problemset/problem/416/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|195|[Counter Attack](http://codeforces.com/problemset/problem/190/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|196|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|197|[Optimize!](http://codeforces.com/problemset/problem/338/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|198|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|199|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces|8|
|<ul><li>- [ ] Done</li></ul>|200|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces|9|
