# Ladder Name: 18 - 1900 <= Codeforces Rating <= 1999
## Description
 For users satisfying this condition
## Difficulty Level: 5

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Sereja and Dima](http://codeforces.com/problemset/problem/381/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Gravity Flip](http://codeforces.com/problemset/problem/405/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Little Pony and Crystal Mine](http://codeforces.com/problemset/problem/454/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[Anton and Letters](http://codeforces.com/problemset/problem/443/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Fox And Snake](http://codeforces.com/problemset/problem/510/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|6|[inc ARG](http://codeforces.com/problemset/problem/465/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|7|[Caisa and Pylons](http://codeforces.com/problemset/problem/463/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|8|[Puzzles](http://codeforces.com/problemset/problem/337/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Chat room](http://codeforces.com/problemset/problem/58/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Vasya and Socks](http://codeforces.com/problemset/problem/460/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[I Wanna Be the Guy](http://codeforces.com/problemset/problem/469/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Expression](http://codeforces.com/problemset/problem/479/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[Counterexample ](http://codeforces.com/problemset/problem/483/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|14|[Flipping Game](http://codeforces.com/problemset/problem/327/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|15|[Pashmak and Garden](http://codeforces.com/problemset/problem/459/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|16|[Ilya and Queries](http://codeforces.com/problemset/problem/313/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|17|[Cheap Travel](http://codeforces.com/problemset/problem/466/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|18|[Little Pony and Expected Maximum](http://codeforces.com/problemset/problem/453/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|19|[Caisa and Sugar](http://codeforces.com/problemset/problem/463/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|20|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|21|[Writing Code](http://codeforces.com/problemset/problem/543/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|22|[Tennis Game](http://codeforces.com/problemset/problem/496/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|23|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|24|[Ryouko's Memory Note](http://codeforces.com/problemset/problem/433/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|25|[Knight Tournament](http://codeforces.com/problemset/problem/356/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|26|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|27|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|28|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|29|[Fox And Two Dots](http://codeforces.com/problemset/problem/510/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|30|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|31|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|32|[Read Time](http://codeforces.com/problemset/problem/343/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|33|[Boredom](http://codeforces.com/problemset/problem/455/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|34|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|35|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|36|[Breaking Good](http://codeforces.com/problemset/problem/507/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|37|[Red-Green Towers](http://codeforces.com/problemset/problem/478/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|38|[Pashmak and Buses](http://codeforces.com/problemset/problem/459/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|39|[Mashmokh and Reverse Operation](http://codeforces.com/problemset/problem/414/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|40|[Sereja and Table ](http://codeforces.com/problemset/problem/425/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|41|[R2D2 and Droid Army](http://codeforces.com/problemset/problem/514/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|42|[Strip](http://codeforces.com/problemset/problem/487/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|43|[Destroying Roads](http://codeforces.com/problemset/problem/543/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|44|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|45|[Obsessive String](http://codeforces.com/problemset/problem/494/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|46|[Restore Cube ](http://codeforces.com/problemset/problem/464/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|47|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|48|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|49|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|50|[Maximum Value](http://codeforces.com/problemset/problem/484/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|51|[Valera and Swaps](http://codeforces.com/problemset/problem/441/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|52|[Increase Sequence](http://codeforces.com/problemset/problem/466/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|53|[Wonder Room](http://codeforces.com/problemset/problem/466/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|54|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|55|[Gerald and Giant Chess](http://codeforces.com/problemset/problem/559/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|56|[Watching Fireworks is Fun](http://codeforces.com/problemset/problem/372/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|57|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|58|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|59|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|60|[Little Pony and Harmony Chest](http://codeforces.com/problemset/problem/453/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|61|[Case of Chocolate](http://codeforces.com/problemset/problem/555/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|62|[Lucky Common Subsequence](http://codeforces.com/problemset/problem/346/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|63|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|64|[Kalila and Dimna in the Logging Industry](http://codeforces.com/problemset/problem/319/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|65|[String](http://codeforces.com/problemset/problem/128/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|66|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|67|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|68|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|69|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|70|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|71|[Jzzhu and Cities](http://codeforces.com/problemset/problem/449/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|72|[Substitutes in Number](http://codeforces.com/problemset/problem/464/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|73|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|74|[Pashmak and Graph](http://codeforces.com/problemset/problem/459/E)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|75|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|76|[Match & Catch](http://codeforces.com/problemset/problem/427/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|77|[A Simple Task](http://codeforces.com/problemset/problem/558/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|78|[Prefix Product Sequence](http://codeforces.com/problemset/problem/487/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|79|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|80|[Road Improvement](http://codeforces.com/problemset/problem/543/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|81|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|82|[Sereja and Squares](http://codeforces.com/problemset/problem/425/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|83|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|84|[Jzzhu and Numbers](http://codeforces.com/problemset/problem/449/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|85|[Captains Mode](http://codeforces.com/problemset/problem/377/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|86|[Mike and Foam](http://codeforces.com/problemset/problem/547/C)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|87|[Devu and Birthday Celebration](http://codeforces.com/problemset/problem/439/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|88|[Martian Strings](http://codeforces.com/problemset/problem/149/E)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|89|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|90|[Antimatter](http://codeforces.com/problemset/problem/383/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|91|[Tricky Function](http://codeforces.com/problemset/problem/429/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|92|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces|6|
|<ul><li>- [ ] Done</li></ul>|93|[Tanya and Password](http://codeforces.com/problemset/problem/508/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|94|[Fedor and Essay](http://codeforces.com/problemset/problem/467/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|95|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|96|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|97|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|98|[Kindergarten](http://codeforces.com/problemset/problem/484/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|99|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces|7|
|<ul><li>- [ ] Done</li></ul>|100|[Serega and Fun](http://codeforces.com/problemset/problem/455/D)|Codeforces|8|
