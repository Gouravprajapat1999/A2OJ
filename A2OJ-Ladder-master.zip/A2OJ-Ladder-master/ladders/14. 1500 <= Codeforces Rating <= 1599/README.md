# Ladder Name: 14 - 1500 <= Codeforces Rating <= 1599
## Description
 For users satisfying this condition
## Difficulty Level: 3

| Checkbox | ID  | Problem Name | Online Judge | Difficulty |
|---|:---:|:---:|---|---|
|<ul><li>- [ ] Done</li></ul>|1|[Presents](http://codeforces.com/problemset/problem/136/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|2|[Nearly Lucky Number](http://codeforces.com/problemset/problem/110/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|3|[Petya and Strings](http://codeforces.com/problemset/problem/112/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|4|[Tram](http://codeforces.com/problemset/problem/116/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|5|[Ultra-Fast Mathematician](http://codeforces.com/problemset/problem/61/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|6|[Amusing Joke](http://codeforces.com/problemset/problem/141/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|7|[Way Too Long Words](http://codeforces.com/problemset/problem/71/A)|Codeforces|1|
|<ul><li>- [ ] Done</li></ul>|8|[Xenia and Ringroad](http://codeforces.com/problemset/problem/339/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|9|[Slightly Decreasing Permutations](http://codeforces.com/problemset/problem/285/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|10|[Football](http://codeforces.com/problemset/problem/96/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|11|[Caisa and Pylons](http://codeforces.com/problemset/problem/463/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|12|[Present from Lena](http://codeforces.com/problemset/problem/118/B)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|13|[k-String](http://codeforces.com/problemset/problem/219/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|14|[Fancy Fence](http://codeforces.com/problemset/problem/270/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|15|[Chat room](http://codeforces.com/problemset/problem/58/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|16|[Contest](http://codeforces.com/problemset/problem/501/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|17|[Twins](http://codeforces.com/problemset/problem/160/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|18|[Puzzles](http://codeforces.com/problemset/problem/337/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|19|[String Task](http://codeforces.com/problemset/problem/118/A)|Codeforces|2|
|<ul><li>- [ ] Done</li></ul>|20|[Mashmokh and ACM](http://codeforces.com/problemset/problem/414/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|21|[The Child and Toy](http://codeforces.com/problemset/problem/437/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|22|[Fence](http://codeforces.com/problemset/problem/363/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|23|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|24|[Rank List](http://codeforces.com/problemset/problem/166/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|25|[Fox and Box Accumulation](http://codeforces.com/problemset/problem/388/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|26|[Cinema Line](http://codeforces.com/problemset/problem/349/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|27|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|28|[Laptops](http://codeforces.com/problemset/problem/456/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|29|[Little Elephant and Bits](http://codeforces.com/problemset/problem/258/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|30|[Flipping Game](http://codeforces.com/problemset/problem/327/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|31|[Mashmokh and ACM](http://codeforces.com/problemset/problem/414/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|32|[Dima and Staircase](http://codeforces.com/problemset/problem/272/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|33|[Building Permutation](http://codeforces.com/problemset/problem/285/C)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|34|[Ilya and Queries](http://codeforces.com/problemset/problem/313/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|35|[Kuriyama Mirai's Stones](http://codeforces.com/problemset/problem/433/B)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|36|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|37|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|38|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces|3|
|<ul><li>- [ ] Done</li></ul>|39|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|40|[Fox And Names](http://codeforces.com/problemset/problem/510/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|41|[Fox And Two Dots](http://codeforces.com/problemset/problem/510/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|42|[Pocket Book](http://codeforces.com/problemset/problem/152/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|43|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|44|[Ladder](http://codeforces.com/problemset/problem/279/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|45|[Divisibility by Eight](http://codeforces.com/problemset/problem/550/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|46|[Little Elephant and Problem](http://codeforces.com/problemset/problem/220/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|47|[Ciel and Flowers](http://codeforces.com/problemset/problem/322/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|48|[Convex Shape](http://codeforces.com/problemset/problem/275/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|49|[Maze](http://codeforces.com/problemset/problem/377/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|50|[View Angle](http://codeforces.com/problemset/problem/257/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|51|[Mr. Kitayuta, the Treasure Hunter](http://codeforces.com/problemset/problem/505/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|52|[Maximum Absurdity](http://codeforces.com/problemset/problem/332/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|53|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|54|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|55|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|56|[Kolya and Tandem Repeat](http://codeforces.com/problemset/problem/443/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|57|[Anya and Ghosts](http://codeforces.com/problemset/problem/508/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|58|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|59|[Beautiful Numbers](http://codeforces.com/problemset/problem/300/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|60|[Vasya and Chess](http://codeforces.com/problemset/problem/493/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|61|[Hamburgers](http://codeforces.com/problemset/problem/371/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|62|[Colorful Graph](http://codeforces.com/problemset/problem/246/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|63|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|64|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|65|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|66|[Arithmetic Progression](http://codeforces.com/problemset/problem/382/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|67|[Friends and Presents](http://codeforces.com/problemset/problem/483/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|68|[Barcode](http://codeforces.com/problemset/problem/225/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|69|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|70|[Little Dima and Equation](http://codeforces.com/problemset/problem/460/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|71|[Long Jumps](http://codeforces.com/problemset/problem/479/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|72|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|73|[Physics Practical](http://codeforces.com/problemset/problem/253/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|74|[Boredom](http://codeforces.com/problemset/problem/455/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|75|[Valera and Tubes ](http://codeforces.com/problemset/problem/441/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|76|[Valera and Elections](http://codeforces.com/problemset/problem/369/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|77|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|78|[George and Job](http://codeforces.com/problemset/problem/467/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|79|[Table Decorations](http://codeforces.com/problemset/problem/478/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|80|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|81|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|82|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|83|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|84|[Exams](http://codeforces.com/problemset/problem/479/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|85|[Caesar's Legions](http://codeforces.com/problemset/problem/118/D)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|86|[Beautiful Sets of Points](http://codeforces.com/problemset/problem/268/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|87|[Boredom](http://codeforces.com/problemset/problem/455/A)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|88|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces|4|
|<ul><li>- [ ] Done</li></ul>|89|[A and B and Interesting Substrings](http://codeforces.com/problemset/problem/519/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|90|[Valid Sets](http://codeforces.com/problemset/problem/486/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|91|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|92|[Good Substrings](http://codeforces.com/problemset/problem/271/D)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|93|[Wonder Room](http://codeforces.com/problemset/problem/466/B)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|94|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|95|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|96|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|97|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|98|[Restore Graph](http://codeforces.com/problemset/problem/404/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|99|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces|5|
|<ul><li>- [ ] Done</li></ul>|100|[Multiplication Table](http://codeforces.com/problemset/problem/448/D)|Codeforces|5|
