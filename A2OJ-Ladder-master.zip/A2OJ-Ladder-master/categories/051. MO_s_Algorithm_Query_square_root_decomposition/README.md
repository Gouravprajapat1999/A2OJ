# 051. MO_s_Algorithm_Query_square_root_decomposition


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[D-query](http://www.spoj.com/problems/DQUERY/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces|Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|3|[GCD 2010](http://acm.timus.ru/problem.aspx?space=1&num=1846)|Timus||3|
|<ul><li>- [ ] Done</li></ul>|4|[Zero Query](http://www.spoj.com/problems/ZQUERY/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|5|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces|Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|6|[Powerful array](http://codeforces.com/problemset/problem/86/D)|Codeforces|Yandex.Algorithm 2011 Round 2|3|
|<ul><li>- [ ] Done</li></ul>|7|[Gao on a tree](http://www.spoj.com/problems/GOT/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|8|[XOR and Favorite Number](http://codeforces.com/problemset/problem/617/E)|Codeforces|Codeforces Round #340 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|9|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces|Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|10|[Little Artem and Time Machine](http://codeforces.com/problemset/problem/641/E)|Codeforces|VK Cup 2016 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|11|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces|Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|12|[DZY Loves Colors](http://codeforces.com/problemset/problem/444/C)|Codeforces|Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|13|[Holidays](http://codeforces.com/problemset/problem/44/C)|Codeforces|School Team Contest #2 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|14|[Ada and Numbering](http://www.spoj.com/problems/ADANUM/)|SPOJ||6|
|<ul><li>- [ ] Done</li></ul>|15|[Holes](http://codeforces.com/problemset/problem/13/E)|Codeforces|Codeforces Beta Round #13|6|
|<ul><li>- [ ] Done</li></ul>|16|[Serega and Fun](http://codeforces.com/problemset/problem/455/D)|Codeforces|Codeforces Round #260 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|17|[Counting diff-pairs](http://www.spoj.com/problems/CPAIR2/)|SPOJ||6|
|<ul><li>- [ ] Done</li></ul>|18|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces|Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|19|[Subset Sums](http://codeforces.com/problemset/problem/348/C)|Codeforces|Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|20|[Conveyor Belts](http://codeforces.com/problemset/problem/487/D)|Codeforces|Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|21|[Ann and Books](http://codeforces.com/problemset/problem/877/F)|Codeforces|Codeforces Round #442 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|22|[Instant Messanger](http://codeforces.com/problemset/problem/398/D)|Codeforces|Codeforces Round #233 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|23|[Jeff and Removing Periods](http://codeforces.com/problemset/problem/351/D)|Codeforces|Codeforces Round #204 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|24|[Destiny](http://codeforces.com/problemset/problem/840/D)|Codeforces|Codeforces Round #429 (Div. 1)|8|
