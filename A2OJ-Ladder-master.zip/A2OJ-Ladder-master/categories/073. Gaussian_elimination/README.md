# 073. Gaussian_elimination


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lost in Madrid](http://www.spoj.com/problems/LIM/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|2|[Going to school](http://www.spoj.com/problems/GS/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|3|[Central Heating](http://acm.timus.ru/problem.aspx?space=1&num=1042)|Timus|3|
|<ul><li>- [ ] Done</li></ul>|4|[Integral Determinant](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=625)|UVA|4|
|<ul><li>- [ ] Done</li></ul>|5|[Square](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2537)|UVA|4|
|<ul><li>- [ ] Done</li></ul>|6|[Solving Systems of Linear Equations](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1050)|UVA|5|
|<ul><li>- [ ] Done</li></ul>|7|[Organising the Organisation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1707)|UVA|5|
|<ul><li>- [ ] Done</li></ul>|8|[Back to Kernighan-Ritchie](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1769)|UVA|5|
|<ul><li>- [ ] Done</li></ul>|9|[Stupid Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2294)|UVA|5|
|<ul><li>- [ ] Done</li></ul>|10|[Kirchhof Law](http://www.spoj.com/problems/RESIST/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|11|[Table Tennis](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2855)|UVA|7|
