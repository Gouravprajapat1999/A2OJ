# 082. Persistent_Segment_Tree


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Count on a tree](http://www.spoj.com/problems/COT/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[K-th Number](http://www.spoj.com/problems/MKTHNUM/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[D-query](http://www.spoj.com/problems/DQUERY/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[To the moon](http://www.spoj.com/problems/TTM/)|SPOJ||4|
|<ul><li>- [ ] Done</li></ul>|5|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces|Codeforces Round #368 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|6|[Pathwalks](http://codeforces.com/problemset/problem/960/F)|Codeforces|Divide by Zero 2018 and Codeforces Round #474 (Div. 1 + Div. 2, combined)|6|
|<ul><li>- [ ] Done</li></ul>|7|[Army Creation](http://codeforces.com/problemset/problem/813/E)|Codeforces|Educational Codeforces Round 22|7|
|<ul><li>- [ ] Done</li></ul>|8|[Till I Collapse](http://codeforces.com/problemset/problem/786/C)|Codeforces|Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|9|[Functions On The Segments](http://codeforces.com/problemset/problem/837/G)|Codeforces|Educational Codeforces Round 26|9|
