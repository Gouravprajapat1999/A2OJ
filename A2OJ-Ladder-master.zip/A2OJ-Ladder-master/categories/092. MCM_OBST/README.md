# 092. MCM_OBST


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Knapsack Problem](http://www.spoj.com/problems/KNAPSACK/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Optimal Array Multiplication Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=284)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|3|[Cutting Sticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=944)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|4|[Mixtures](http://www.spoj.com/problems/MIXTURES/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|5|[Optimal Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1245)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|6|[Help the problem setter](http://www.spoj.com/problems/HELP/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|7|[Huffman´s Greed](http://www.spoj.com/problems/GREEDULM/)|SPOJ|5|
