# 150. Circle_sweep


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Cell Phone](http://www.spoj.com/problems/CERC07C/)|SPOJ|4|
