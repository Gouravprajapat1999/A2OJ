# 080. ad_hoc


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Eternal Immortality](http://codeforces.com/problemset/problem/869/B)|Codeforces|Codeforces Round #439 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Even Numbers](http://www.spoj.com/problems/EC_CONB/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Cards](http://www.spoj.com/problems/CRDS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Adding Reversed Numbers](http://www.spoj.com/problems/ADDREV/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|5|[TEX Quotes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=208)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|6|[Mapmaker](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=330)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|7|[Day of Pay](http://www.spoj.com/problems/DAYOFPAY/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|8|[Complete Binary Tree](http://www.spoj.com/problems/CBINARYT/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|9|[Happy Birthday !!!](http://www.spoj.com/problems/HAPPYB/)|SPOJ||4|
