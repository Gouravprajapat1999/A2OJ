# 026. two_pointers


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Roommate Agreement](http://www.spoj.com/problems/CRAN02/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Queries about less or equal elements](http://codeforces.com/problemset/problem/600/B)|Codeforces|Educational Codeforces Round 2|1|
|<ul><li>- [ ] Done</li></ul>|3|[Kefa and Company](http://codeforces.com/problemset/problem/580/B)|Codeforces|Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[BerSU Ball](http://codeforces.com/problemset/problem/489/B)|Codeforces|Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces|Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Sereja and Dima](http://codeforces.com/problemset/problem/381/A)|Codeforces|Codeforces Round #223 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Books](http://codeforces.com/problemset/problem/279/B)|Codeforces|Codeforces Round #171 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Complete the Word](http://codeforces.com/problemset/problem/716/B)|Codeforces|Codeforces Round #372 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Points on Line](http://codeforces.com/problemset/problem/251/A)|Codeforces|Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|10|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces|Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|11|[Alice, Bob and Chocolate](http://codeforces.com/problemset/problem/6/C)|Codeforces|Codeforces Beta Round #6 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|12|[Audition](http://www.spoj.com/problems/CRAN04/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|13|[Approximating a Constant Range](http://codeforces.com/problemset/problem/602/B)|Codeforces|Codeforces Round #333 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|14|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces|Codeforces Round #319 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|15|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces|Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|16|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces|Codeforces Round #244 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|17|[George and Round](http://codeforces.com/problemset/problem/387/B)|Codeforces|Codeforces Round #227 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|18|[Counting Kangaroos is Fun](http://codeforces.com/problemset/problem/372/A)|Codeforces|Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|19|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces|Codeforces Round #188 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|20|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces|Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|21|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces|Codeforces Round #354 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|22|[Wrath](http://codeforces.com/problemset/problem/892/B)|Codeforces|Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|23|[Kirill And The Game](http://codeforces.com/problemset/problem/842/A)|Codeforces|Codeforces Round #430 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|24|[Physics Practical](http://codeforces.com/problemset/problem/253/B)|Codeforces|Codeforces Round #154 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|25|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces|Codeforces Round #143 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|26|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces|Codeforces Round #138 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|27|[Dress'em in Vests!](http://codeforces.com/problemset/problem/161/A)|Codeforces|VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|28|[Stripe](http://codeforces.com/problemset/problem/18/C)|Codeforces|Codeforces Beta Round #18 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|29|[Hard Process](http://codeforces.com/problemset/problem/660/C)|Codeforces|Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|30|[A and B and Interesting Substrings](http://codeforces.com/problemset/problem/519/D)|Codeforces|Codeforces Round #294 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|31|[Mr. Kitayuta, the Treasure Hunter](http://codeforces.com/problemset/problem/505/C)|Codeforces|Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|32|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces|Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|33|[Maximum Value](http://codeforces.com/problemset/problem/484/B)|Codeforces|Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|34|[Guess a number!](http://codeforces.com/problemset/problem/416/A)|Codeforces|Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|35|[Eugeny and Play List](http://codeforces.com/problemset/problem/302/B)|Codeforces|Codeforces Round #182 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|36|[Ladder](http://codeforces.com/problemset/problem/279/C)|Codeforces|Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|37|[Primes on Interval](http://codeforces.com/problemset/problem/237/C)|Codeforces|Codeforces Round #147 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|38|[Powerful array](http://codeforces.com/problemset/problem/86/D)|Codeforces|Yandex.Algorithm 2011 Round 2|3|
|<ul><li>- [ ] Done</li></ul>|39|[Alyona and Spreadsheet](http://codeforces.com/problemset/problem/777/C)|Codeforces|Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|40|[An impassioned circulation of affection](http://codeforces.com/problemset/problem/814/C)|Codeforces|Codeforces Round #418 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|41|[Voting](http://codeforces.com/problemset/problem/749/C)|Codeforces|Codeforces Round #388 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|42|[Shifts](http://codeforces.com/problemset/problem/229/A)|Codeforces|Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|43|[Where Are My Flakes?](http://codeforces.com/problemset/problem/60/A)|Codeforces|Codeforces Beta Round #56|4|
|<ul><li>- [ ] Done</li></ul>|44|[Image Preview](http://codeforces.com/problemset/problem/650/B)|Codeforces|Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|45|[Processing Queries](http://codeforces.com/problemset/problem/644/B)|Codeforces|CROC 2016 - Qualification|4|
|<ul><li>- [ ] Done</li></ul>|46|[Longest k-Good Segment](http://codeforces.com/problemset/problem/616/D)|Codeforces|Educational Codeforces Round 5|4|
|<ul><li>- [ ] Done</li></ul>|47|[Devu and his Brother](http://codeforces.com/problemset/problem/439/D)|Codeforces|Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|48|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces|Codeforces Round #246 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|49|[Balls Game](http://codeforces.com/problemset/problem/430/B)|Codeforces|Codeforces Round #245 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|50|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces|Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|51|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces|Codeforces Round #209 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|52|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces|Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|53|[Pointers](http://acm.sgu.ru/problem.php?contest=0&problem=359)|SGU||4|
|<ul><li>- [ ] Done</li></ul>|54|[XK Segments](http://codeforces.com/problemset/problem/895/B)|Codeforces|Codeforces Round #448 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|55|[Olympiad](http://codeforces.com/problemset/problem/222/D)|Codeforces|Codeforces Round #137 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|56|[Two Paths](http://codeforces.com/problemset/problem/14/D)|Codeforces|Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|57|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces|Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|58|[Foe Pairs](http://codeforces.com/problemset/problem/652/C)|Codeforces|Educational Codeforces Round 10|5|
|<ul><li>- [ ] Done</li></ul>|59|[Enduring Exodus](http://codeforces.com/problemset/problem/645/C)|Codeforces|CROC 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|60|[Skills](http://codeforces.com/problemset/problem/613/B)|Codeforces|Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|61|[Correcting Mistakes](http://codeforces.com/problemset/problem/533/E)|Codeforces|VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|62|[R2D2 and Droid Army](http://codeforces.com/problemset/problem/514/D)|Codeforces|Codeforces Round #291 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|63|[Strip](http://codeforces.com/problemset/problem/487/B)|Codeforces|Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|64|[Read Time](http://codeforces.com/problemset/problem/343/C)|Codeforces|Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|65|[Nearest Fraction](http://codeforces.com/problemset/problem/281/B)|Codeforces|Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|66|[Maximum Xor Secondary](http://codeforces.com/problemset/problem/280/B)|Codeforces|Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|67|[Jury Meeting](http://codeforces.com/problemset/problem/853/B)|Codeforces|Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises) & Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|5|
|<ul><li>- [ ] Done</li></ul>|68|[The Bakery](http://codeforces.com/problemset/problem/833/B)|Codeforces|Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|69|[Cartons of milk](http://codeforces.com/problemset/problem/767/D)|Codeforces|Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|70|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces|Codeforces Round #142 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|71|[Non-Secret Cypher](http://codeforces.com/problemset/problem/190/D)|Codeforces|Codeforces Round #120 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|72|[Beaver](http://codeforces.com/problemset/problem/79/C)|Codeforces|Codeforces Beta Round #71|6|
|<ul><li>- [ ] Done</li></ul>|73|[Hamsters and Tigers](http://codeforces.com/problemset/problem/46/C)|Codeforces|School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|74|[Gadgets for dollars and pounds](http://codeforces.com/problemset/problem/609/D)|Codeforces|Educational Codeforces Round 3|6|
|<ul><li>- [ ] Done</li></ul>|75|[Segment Tree](http://www.spoj.com/problems/SEGTREE/)|SPOJ||6|
|<ul><li>- [ ] Done</li></ul>|76|[Rooter's Song](http://codeforces.com/problemset/problem/848/B)|Codeforces|Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|77|[Table with Letters - 2](http://codeforces.com/problemset/problem/253/D)|Codeforces|Codeforces Round #154 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|78|[Little Elephant and Inversions](http://codeforces.com/problemset/problem/220/E)|Codeforces|Codeforces Round #136 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|79|[Spider's Web](http://codeforces.com/problemset/problem/216/D)|Codeforces|Codeforces Round #133 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|80|[Ski Base](http://codeforces.com/problemset/problem/91/C)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|81|[Professor GukiZ and Two Arrays](http://codeforces.com/problemset/problem/620/D)|Codeforces|Educational Codeforces Round 6|7|
|<ul><li>- [ ] Done</li></ul>|82|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces|Codeforces Round #337 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|83|[Edo and Magnets](http://codeforces.com/problemset/problem/594/C)|Codeforces|Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|84|[Social Network](http://codeforces.com/problemset/problem/524/D)|Codeforces|VK Cup 2015 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|85|[Name That Tune](http://codeforces.com/problemset/problem/498/B)|Codeforces|Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|86|[Bug in Code](http://codeforces.com/problemset/problem/420/C)|Codeforces|Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|87|[Genetic Engineering](http://codeforces.com/problemset/problem/391/A)|Codeforces|Rockethon 2014|7|
|<ul><li>- [ ] Done</li></ul>|88|[Subway Innovation](http://codeforces.com/problemset/problem/371/E)|Codeforces|Codeforces Round #218 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|89|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces|Codeforces Round #214 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|90|[Building Bridge](http://codeforces.com/problemset/problem/250/D)|Codeforces|CROC-MBTU 2012, Final Round (Online version, Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|91|[Cubes](http://codeforces.com/problemset/problem/180/E)|Codeforces|Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|92|[Nanami's Digital Board](http://codeforces.com/problemset/problem/433/D)|Codeforces|Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|93|[Bamboo Partition](http://codeforces.com/problemset/problem/830/C)|Codeforces|Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|7|
|<ul><li>- [ ] Done</li></ul>|94|[Mad Joe](http://codeforces.com/problemset/problem/250/E)|Codeforces|CROC-MBTU 2012, Final Round (Online version, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|95|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces|Codeforces Round #129 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|96|[Ancient Berland Hieroglyphs](http://codeforces.com/problemset/problem/164/B)|Codeforces|VK Cup 2012 Round 3|8|
|<ul><li>- [ ] Done</li></ul>|97|[Present to Mom](http://codeforces.com/problemset/problem/131/F)|Codeforces|Codeforces Beta Round #95 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|98|[Lucky Tickets](http://codeforces.com/problemset/problem/70/C)|Codeforces|Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|99|[Very simple problem](http://codeforces.com/problemset/problem/55/E)|Codeforces|Codeforces Beta Round #51|8|
|<ul><li>- [ ] Done</li></ul>|100|[Startup Funding](http://codeforces.com/problemset/problem/633/E)|Codeforces|Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|101|[Double Knapsack](http://codeforces.com/problemset/problem/618/F)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|102|[Zublicanes and Mumocrates](http://codeforces.com/problemset/problem/581/F)|Codeforces|Codeforces Round #322 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|103|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces|Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|104|[DZY Loves Strings](http://codeforces.com/problemset/problem/444/D)|Codeforces|Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|105|[Mashmokh and Water Tanks](http://codeforces.com/problemset/problem/414/D)|Codeforces|Codeforces Round #240 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|106|[Diverse Substrings](http://codeforces.com/problemset/problem/386/C)|Codeforces|Testing Round #9|8|
|<ul><li>- [ ] Done</li></ul>|107|[Volcanoes](http://codeforces.com/problemset/problem/383/B)|Codeforces|Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|108|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces|Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|109|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces|Codeforces Round #187 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|110|[Morning run](http://codeforces.com/problemset/problem/309/A)|Codeforces|Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|111|[Alyona and Triangles](http://codeforces.com/problemset/problem/682/E)|Codeforces|Codeforces Round #358 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|112|[Shoe Store](http://codeforces.com/problemset/problem/166/D)|Codeforces|Codeforces Round #113 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|113|[Lucky Segments](http://codeforces.com/problemset/problem/121/D)|Codeforces|Codeforces Beta Round #91 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|114|[Archer's Shot](http://codeforces.com/problemset/problem/78/D)|Codeforces|Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|115|[Mice](http://codeforces.com/problemset/problem/76/B)|Codeforces|All-Ukrainian School Olympiad in Informatics|9|
|<ul><li>- [ ] Done</li></ul>|116|[Race](http://codeforces.com/problemset/problem/43/E)|Codeforces|Codeforces Beta Round #42 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|117|[Context Advertising](http://codeforces.com/problemset/problem/309/B)|Codeforces|Croc Champ 2013 - Finals (online version, Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|118|[Ksusha and Square](http://codeforces.com/problemset/problem/293/D)|Codeforces|Croc Champ 2013 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|119|[Colorful Stones](http://codeforces.com/problemset/problem/264/D)|Codeforces|Codeforces Round #162 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|120|[Maxim and Calculator](http://codeforces.com/problemset/problem/261/E)|Codeforces|Codeforces Round #160 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|121|[Transportation](http://codeforces.com/problemset/problem/203/E)|Codeforces|Codeforces Round #128 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|122|[Cubes](http://codeforces.com/problemset/problem/243/D)|Codeforces|Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|123|[Hellish Constraints](http://codeforces.com/problemset/problem/138/E)|Codeforces|Codeforces Beta Round #99 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|124|[Orchestra](http://codeforces.com/problemset/problem/627/E)|Codeforces|8VC Venture Cup 2016 - Final Round|10|
|<ul><li>- [ ] Done</li></ul>|125|[New Year and Cake](http://codeforces.com/problemset/problem/611/G)|Codeforces|Good Bye 2015|10|
|<ul><li>- [ ] Done</li></ul>|126|[BCPC](http://codeforces.com/problemset/problem/592/E)|Codeforces|Codeforces Round #328 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|127|[Empty Rectangles](http://codeforces.com/problemset/problem/364/E)|Codeforces|Codeforces Round #213 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|128|[Galaxy Union](http://codeforces.com/problemset/problem/48/G)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
