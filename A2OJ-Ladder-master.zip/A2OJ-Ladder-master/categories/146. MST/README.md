# 146. MST


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Anti Brute Force Lock](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3676)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|2|[Imperial roads](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=6218)|Live Archive|2017|Latin America|5|
