# 047. Meet_in_The_Middle


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[ABCDEF](http://www.spoj.com/problems/ABCDEF/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[4 Values whose Sum is 0](http://acm.tju.edu.cn/toj/showp2407.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Subset Sums](http://www.spoj.com/problems/SUBSUMS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[4 values whose sum is 0](http://www.spoj.com/problems/SUMFOUR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[4 Values whose Sum is 0](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1507)|Live Archive|2005|Europe - Southwestern|1|
|<ul><li>- [ ] Done</li></ul>|6|[Solitaire](http://www.spoj.com/problems/SOLIT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|7|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces||Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|8|[Robbing Gringotts](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3996)|Live Archive|2011|Asia - Amritapuri|2|
|<ul><li>- [ ] Done</li></ul>|9|[The Morning after Halloween](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1889)|Live Archive|2007|Asia - Tokyo|3|
|<ul><li>- [ ] Done</li></ul>|10|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces||Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|11|[Face the mate](http://www.spoj.com/problems/FACENEMY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|12|[Parity](http://www.spoj.com/problems/PARITY/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|13|[Inversions problem](http://codeforces.com/problemset/problem/513/G1)|Codeforces||Rockethon 2015|5|
|<ul><li>- [ ] Done</li></ul>|14|[Maximum Subsequence](http://codeforces.com/problemset/problem/888/E)|Codeforces||Educational Codeforces Round 32|5|
|<ul><li>- [ ] Done</li></ul>|15|[Chocolate](http://codeforces.com/problemset/problem/490/D)|Codeforces||Codeforces Round #279 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|16|[Golden System](http://codeforces.com/problemset/problem/457/A)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|17|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|18|[Permutation Sum](http://codeforces.com/problemset/problem/285/D)|Codeforces||Codeforces Round #175 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|19|[Maximal Independent Set](http://www.spoj.com/problems/MAXISET/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|20|[Event Dates](http://codeforces.com/problemset/problem/45/D)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|21|[Lizard Era: Beginning](http://codeforces.com/problemset/problem/585/D)|Codeforces||Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|22|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces||Codeforces Round #191 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|23|[EllysBulls](http://community.topcoder.com/stat?c=problem_statement&pm=12420)|TopCoder||SRM 572 - Div1 medium] (15492)|7|
|<ul><li>- [ ] Done</li></ul>|24|[Mother of Dragons](http://codeforces.com/problemset/problem/839/E)|Codeforces||Codeforces Round #428 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|25|[The Morning after Halloween](http://acm.tju.edu.cn/toj/showp3081.html)|TJU|||8|
|<ul><li>- [ ] Done</li></ul>|26|[Simplified Nonogram](http://codeforces.com/problemset/problem/534/F)|Codeforces||Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|27|[Missing Piece 2001](http://acm.tju.edu.cn/toj/showp2049.html)|TJU|||9|
|<ul><li>- [ ] Done</li></ul>|28|[Permanent](http://codeforces.com/problemset/problem/468/E)|Codeforces||Codeforces Round #268 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|29|[Wavy numbers](http://codeforces.com/problemset/problem/478/E)|Codeforces||Codeforces Round #273 (Div. 2)|10|
