# 122. Range_tree


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Zig-Zag rabbit](http://www.spoj.com/problems/ZIGZAG/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|2|[Frequent values](http://acm.tju.edu.cn/toj/showp2913.html)|TJU|2|
|<ul><li>- [ ] Done</li></ul>|3|[Shortcut](http://www.spoj.com/problems/SHORTCUT/)|SPOJ|3|
