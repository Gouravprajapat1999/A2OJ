# 018. Number_Theory


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Prime Number Theorem](http://www.spoj.com/problems/CPRIME/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Divisors](http://www.spoj.com/problems/DIV/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Euler Totient Function](http://www.spoj.com/problems/ETF/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Factorial](http://www.spoj.com/problems/FCTRL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Game of Lines](http://www.spoj.com/problems/LINES/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Marbles](http://www.spoj.com/problems/MARBLES/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[The Moronic Cowmpouter](http://www.spoj.com/problems/NEG2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Prime or Not](http://www.spoj.com/problems/PON/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Prime Generator](http://www.spoj.com/problems/PRIME1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Two squares or not two squares](http://www.spoj.com/problems/TWOSQRS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Divisor Summation](http://www.spoj.com/problems/DIVSUM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Integer Factorization (15 digits)](http://www.spoj.com/problems/FACT0/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|13|[LCM Sum](http://www.spoj.com/problems/LCMSUM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[GCD Extreme](http://www.spoj.com/problems/GCDEX/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Hexadecimal's theorem](http://codeforces.com/problemset/problem/199/A)|Codeforces||Codeforces Round #125 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Lucky Division](http://codeforces.com/problemset/problem/122/A)|Codeforces||Codeforces Beta Round #91 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Panoramix's Prediction](http://codeforces.com/problemset/problem/80/A)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Almost Prime](http://codeforces.com/problemset/problem/26/A)|Codeforces||Codeforces Beta Round #26 (Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Medium Factorization](http://www.spoj.com/problems/FACTCG2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Cifera](http://codeforces.com/problemset/problem/114/A)|Codeforces||Codeforces Beta Round #86 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|22|[The Equation](http://acm.sgu.ru/problem.php?contest=0&problem=106)|SGU|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Prime Cuts](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=347)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Goldbach's Conjecture](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=484)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Goldbach's Conjecture (II)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=627)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Simply Emirp](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1176)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Twin Primes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1335)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Prime Words](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1865)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|29|[The primary problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1889)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|30|[Ones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1068)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|31|[Relatives](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1240)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|32|[Graph Connectivity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=400)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|33|[Count the factors](http://acm.tju.edu.cn/toj/showp1868.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|34|[Tip Top Game](http://www.spoj.com/problems/TIPTOP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|35|[Factovisors](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1080)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|36|[Play with Floor and Ceil](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1614)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|37|[Totient Extreme](http://www.spoj.com/problems/DCEPCA03/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Factors and Factorials](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=96)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|39|[Fombinatorial](http://www.codechef.com/problems/POWERMUL)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|40|[Celebrity jeopardy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3565)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|41|[Again Twenty Five!](http://codeforces.com/problemset/problem/630/A)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|1|
|<ul><li>- [ ] Done</li></ul>|42|[Multiplication Table](http://codeforces.com/problemset/problem/577/A)|Codeforces||Codeforces Round #319 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|43|[Vasya and Petya's Game](http://codeforces.com/problemset/problem/576/A)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|44|[Bear and Poker](http://codeforces.com/problemset/problem/573/A)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|45|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|46|[Design Tutorial: Learn from Math](http://codeforces.com/problemset/problem/472/A)|Codeforces||Codeforces Round #270|1|
|<ul><li>- [ ] Done</li></ul>|47|[Fedya and Maths](http://codeforces.com/problemset/problem/456/B)|Codeforces||Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|48|[Ilya and Bank Account](http://codeforces.com/problemset/problem/313/A)|Codeforces||Codeforces Round #186 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|49|[Toy Army](http://codeforces.com/problemset/problem/84/A)|Codeforces||Codeforces Beta Round #72 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|50|[Alyona and Numbers](http://codeforces.com/problemset/problem/682/A)|Codeforces||Codeforces Round #358 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|51|[Almost Prime Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1480)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|52|[Bachgold Problem](http://codeforces.com/problemset/problem/749/A)|Codeforces||Codeforces Round #388 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|53|[Arpa’s hard exam and Mehrdad’s naive cheat](http://codeforces.com/problemset/problem/742/A)|Codeforces||Codeforces Round #383 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|54|[Factorial](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=159)|Live Archive|2000|Europe - Central|1|
|<ul><li>- [ ] Done</li></ul>|55|[String Task](http://codeforces.com/problemset/problem/118/A)|Codeforces||Codeforces Beta Round #89 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|56|[The Bytelandian Cryptographer (Act I)](http://www.spoj.com/problems/CRYPTO1/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|57|[Sort fractions](http://www.spoj.com/problems/FRACTION/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|58|[Prime Again ](http://www.spoj.com/problems/PAGAIN/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|59|[Primitive Root](http://www.spoj.com/problems/PROOT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|60|[Divisor Summation (Hard)](http://www.spoj.com/problems/DIVSUM2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|61|[Integer Factorization (20 digits)](http://www.spoj.com/problems/FACT1/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|62|[Divisors 2](http://www.spoj.com/problems/DIV2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|63|[N DIV PHI_N](http://www.spoj.com/problems/NDIVPHI/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|64|[Square-free integers](http://www.spoj.com/problems/SQFREE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|65|[Playing with Marbles](http://www.spoj.com/problems/TUTMRBL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|66|[Odd Numbers of Divisors](http://www.spoj.com/problems/ODDDIV/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|67|[Equation](http://www.spoj.com/problems/KPEQU/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|68|[LCM Challenge](http://codeforces.com/problemset/problem/235/A)|Codeforces||Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|69|[Ice Sculptures](http://codeforces.com/problemset/problem/158/D)|Codeforces||VK Cup 2012 Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|70|[Jumping Champion](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=855)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|71|[Goldbach and Euler](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1252)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|72|[Marbles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1031)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|73|[Mint](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1658)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|74|[Psycho](http://www.spoj.com/problems/PSYCHON/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|75|[Minimum Number](http://www.spoj.com/problems/MINNUM/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|76|[Mr. Azad and his Son!!!!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1431)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|77|[TEX Quotes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3382)|Live Archive|1994|North America - East Central NA|2|
|<ul><li>- [ ] Done</li></ul>|78|[MCQ Exam](p?ID=203)|A2 Online Judge|||2|
|<ul><li>- [ ] Done</li></ul>|79|[Dima and Lisa](http://codeforces.com/problemset/problem/584/D)|Codeforces||Codeforces Round #324 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|80|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces||Codeforces Round #304 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|81|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces||Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|82|[Mashmokh and Numbers](http://codeforces.com/problemset/problem/414/A)|Codeforces||Codeforces Round #240 (Div. 1) & Codeforces Round #240 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|83|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|84|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|85|[Prime Matrix](http://codeforces.com/problemset/problem/271/B)|Codeforces||Codeforces Round #166 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|86|[k-th divisor](http://codeforces.com/problemset/problem/762/A)|Codeforces||Educational Codeforces Round 17|2|
|<ul><li>- [ ] Done</li></ul>|87|[Leha and Function](http://codeforces.com/problemset/problem/840/A)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|88|[Taxes](http://codeforces.com/problemset/problem/735/D)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|89|[Pride](http://codeforces.com/problemset/problem/891/A)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|90|[Vladik and fractions](http://codeforces.com/problemset/problem/743/C)|Codeforces||Codeforces Round #384 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|91|[Pythagorean Triples](http://codeforces.com/problemset/problem/707/C)|Codeforces||Codeforces Round #368 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|92|[Arpa’s obvious problem and Mehrdad’s terrible solution](http://codeforces.com/problemset/problem/742/B)|Codeforces||Codeforces Round #383 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|93|[Number Theory for Newbies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2366)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|94|[Anagrammatic Primes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=838)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|95|[GCD Determinant ](http://www.spoj.com/problems/MSE08H/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|96|[Skyscraper Floors](http://www.spoj.com/problems/SCRAPER/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|97|[Homework](http://www.spoj.com/problems/HOMEW/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|98|[Congruence Equation](http://www.spoj.com/problems/DPEQN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|99|[Sky Code](http://www.spoj.com/problems/MSKYCODE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|100|[Binomial Coefficients](http://www.spoj.com/problems/UCI2009B/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|101|[Primes on Interval](http://codeforces.com/problemset/problem/237/C)|Codeforces||Codeforces Round #147 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|102|[Easy Number Challenge](http://codeforces.com/problemset/problem/236/B)|Codeforces||Codeforces Round #146 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|103|[Little Elephant and Numbers](http://codeforces.com/problemset/problem/221/B)|Codeforces||Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|104|[Win or Freeze](http://codeforces.com/problemset/problem/150/A)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|105|[Modified GCD](http://codeforces.com/problemset/problem/75/C)|Codeforces||Codeforces Beta Round #67 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|106|[Noldbach problem](http://codeforces.com/problemset/problem/17/A)|Codeforces||Codeforces Beta Round #17|3|
|<ul><li>- [ ] Done</li></ul>|107|[Chef and Functions](http://www.codechef.com/problems/FUNC)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|108|[Cows and Primitive Roots](http://codeforces.com/problemset/problem/284/A)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|109|[DDF](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=488)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|110|[A Trivial Problem](http://codeforces.com/problemset/problem/633/B)|Codeforces||Manthan, Codefest 16|3|
|<ul><li>- [ ] Done</li></ul>|111|[Primes or Palindromes?](http://codeforces.com/problemset/problem/568/A)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|112|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|113|[Fox Dividing Cheese](http://codeforces.com/problemset/problem/371/B)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|114|[Levko and Permutation](http://codeforces.com/problemset/problem/361/B)|Codeforces||Codeforces Round #210 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|115|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|116|[Routine Problem](http://codeforces.com/problemset/problem/337/B)|Codeforces||Codeforces Round #196 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|117|[Good Sequences](http://codeforces.com/problemset/problem/264/B)|Codeforces||Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|118|[Permutation Primes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1018)|Live Archive|2004|Asia - Dhaka|3|
|<ul><li>- [ ] Done</li></ul>|119|[Primal Fear](http://www.spoj.com/problems/VECTAR8/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|120|[The Meaningless Game](http://codeforces.com/problemset/problem/833/A)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|121|[Mike and gcd problem](http://codeforces.com/problemset/problem/798/C)|Codeforces||Codeforces Round #410 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|122|[Eugeny and Play List](http://codeforces.com/problemset/problem/302/B)|Codeforces||Codeforces Round #182 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|123|[The Super Powers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2852)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|124|[SETI](http://www.spoj.com/problems/NWERC04H/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|125|[Rank of a Fraction](http://www.spoj.com/problems/FNRANK/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|126|[N DIV PHI_N (Hard)](http://www.spoj.com/problems/NDIVPHI2/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|127|[Chilly Willy](http://codeforces.com/problemset/problem/248/B)|Codeforces||Codeforces Round #152 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|128|[Well-known Numbers](http://codeforces.com/problemset/problem/225/B)|Codeforces||Codeforces Round #139 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|129|[Colliders](http://codeforces.com/problemset/problem/154/B)|Codeforces||Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|130|[Petya and Divisors](http://codeforces.com/problemset/problem/111/B)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|131|[Round Table Knights](http://codeforces.com/problemset/problem/71/C)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|132|[Irrational problem](http://codeforces.com/problemset/problem/68/A)|Codeforces||Codeforces Beta Round #62|4|
|<ul><li>- [ ] Done</li></ul>|133|[Fortune Telling](http://codeforces.com/problemset/problem/59/B)|Codeforces||Codeforces Beta Round #55 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|134|[Dots](http://www.spoj.com/problems/DOTS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|135|[Skyscraper Floors](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=659)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|136|[Boring Card Game](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3890)|Live Archive|2011|Europe - Central|4|
|<ul><li>- [ ] Done</li></ul>|137|[Gaussian Prime Factors](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1197)|Live Archive|2006|Asia - Manila|4|
|<ul><li>- [ ] Done</li></ul>|138|[Broken Keyboard](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1702)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|139|[Subtraction](p?ID=129)|A2 Online Judge|||4|
|<ul><li>- [ ] Done</li></ul>|140|[Multipliers](http://codeforces.com/problemset/problem/615/D)|Codeforces||Codeforces Round #338 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|141|[Gerald and Giant Chess](http://codeforces.com/problemset/problem/559/C)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|142|[Ant colony](http://codeforces.com/problemset/problem/474/F)|Codeforces||Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|143|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces||Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|144|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|145|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces||Codeforces Round #205 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|146|[Ksusha and Array](http://codeforces.com/problemset/problem/299/A)|Codeforces||Croc Champ 2013 - Round 2 (Div. 2 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|147|[Subtractions](http://codeforces.com/problemset/problem/267/A)|Codeforces||Codeforces Testing Round #5|4|
|<ul><li>- [ ] Done</li></ul>|148|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|149|[Remainders Game](http://codeforces.com/problemset/problem/687/B)|Codeforces||Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|150|[Ralph And His Magic Field](http://codeforces.com/problemset/problem/894/B)|Codeforces||Codeforces Round #447 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|151|[The Most Complex Number](http://acm.timus.ru/problem.aspx?space=1&num=1748)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|152|[Rectangular Game](http://codeforces.com/problemset/problem/177/B2)|Codeforces||ABBYY Cup 2.0 - Easy|5|
|<ul><li>- [ ] Done</li></ul>|153|[Rectangular Game](http://codeforces.com/problemset/problem/177/B1)|Codeforces||ABBYY Cup 2.0 - Easy|5|
|<ul><li>- [ ] Done</li></ul>|154|[Pseudorandom Sequence Period](http://codeforces.com/problemset/problem/172/B)|Codeforces||Croc Champ 2012 - Qualification Round|5|
|<ul><li>- [ ] Done</li></ul>|155|[Prime Permutation](http://codeforces.com/problemset/problem/123/A)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|156|[Petya and His Friends](http://codeforces.com/problemset/problem/66/D)|Codeforces||Codeforces Beta Round #61 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|157|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|158|[Monitor](http://codeforces.com/problemset/problem/16/C)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|159|[Line](http://codeforces.com/problemset/problem/7/C)|Codeforces||Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|160|[Moodular Arithmetic](http://codeforces.com/problemset/problem/603/B)|Codeforces||Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|161|[Clique in the Divisibility Graph](http://codeforces.com/problemset/problem/566/F)|Codeforces||VK Cup 2015 - Finals, online mirror|5|
|<ul><li>- [ ] Done</li></ul>|162|[Mike and Foam](http://codeforces.com/problemset/problem/547/C)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|163|[Array and Operations](http://codeforces.com/problemset/problem/498/C)|Codeforces||Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|164|[Chocolate](http://codeforces.com/problemset/problem/490/D)|Codeforces||Codeforces Round #279 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|165|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces||Codeforces Round #235 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|166|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|167|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces||Codeforces Round #195 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|168|[Shaass and Lights](http://codeforces.com/problemset/problem/294/C)|Codeforces||Codeforces Round #178 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|169|[Upgrading Array](http://codeforces.com/problemset/problem/402/D)|Codeforces||Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|170|[Tutorial BFS](http://www.spoj.com/problems/TUTBFS/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|171|[Winter is here](http://codeforces.com/problemset/problem/839/D)|Codeforces||Codeforces Round #428 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|172|[Anton and School - 2](http://codeforces.com/problemset/problem/785/D)|Codeforces||Codeforces Round #404 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|173|[Palindrome Degree](http://codeforces.com/problemset/problem/7/D)|Codeforces||Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|174|[Polygon Encoder](http://www.spoj.com/problems/POLYCODE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|175|[Printing some primes (Hard)](http://www.spoj.com/problems/PRIMES2/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|176|[Reducing Fractions](http://codeforces.com/problemset/problem/222/C)|Codeforces||Codeforces Round #137 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|177|[Calendar Reform](http://codeforces.com/problemset/problem/172/D)|Codeforces||Croc Champ 2012 - Qualification Round|6|
|<ul><li>- [ ] Done</li></ul>|178|[Very Interesting Game](http://codeforces.com/problemset/problem/117/B)|Codeforces||Codeforces Beta Round #88|6|
|<ul><li>- [ ] Done</li></ul>|179|[Beaver Game](http://codeforces.com/problemset/problem/78/C)|Codeforces||Codeforces Beta Round #70 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|180|[Longest Subsequence](http://codeforces.com/problemset/problem/632/D)|Codeforces||Educational Codeforces Round 9|6|
|<ul><li>- [ ] Done</li></ul>|181|[Array GCD](http://codeforces.com/problemset/problem/623/B)|Codeforces||AIM Tech Round (Div. 1) & AIM Tech Round (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|182|[Bots](http://codeforces.com/problemset/problem/575/H)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|6|
|<ul><li>- [ ] Done</li></ul>|183|[GukiZ and Binary Operations](http://codeforces.com/problemset/problem/551/D)|Codeforces||Codeforces Round #307 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|184|[Pluses everywhere](http://codeforces.com/problemset/problem/520/E)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|185|[Prefix Product Sequence](http://codeforces.com/problemset/problem/487/C)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|186|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces||Codeforces Round #258 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|187|[Jzzhu and Apples](http://codeforces.com/problemset/problem/449/C)|Codeforces||Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|188|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces||Codeforces Round #256 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|189|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|190|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|191|[Lucky Permutation](http://codeforces.com/problemset/problem/121/C)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only) & Codeforces Beta Round #91 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|192|[Beautiful numbers](http://codeforces.com/problemset/problem/55/D)|Codeforces||Codeforces Beta Round #51|6|
|<ul><li>- [ ] Done</li></ul>|193|[Goldbach++](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1316)|Live Archive|2005|North America - Southeast USA|6|
|<ul><li>- [ ] Done</li></ul>|194|[Unusual Sequences](http://codeforces.com/problemset/problem/900/D)|Codeforces||Codeforces Round #450 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|195|[ZS and The Birthday Paradox](http://codeforces.com/problemset/problem/711/E)|Codeforces||Codeforces Round #369 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|196|[Integer Factorization (29 digits)](http://www.spoj.com/problems/FACT2/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|197|[Finding the Kth Prime (Hard)](http://www.spoj.com/problems/KPRIMES2/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|198|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|199|[Pairs of Numbers](http://codeforces.com/problemset/problem/134/B)|Codeforces||Codeforces Testing Round #3|7|
|<ul><li>- [ ] Done</li></ul>|200|[Double Happiness](http://codeforces.com/problemset/problem/113/C)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|201|[Chessboard Billiard](http://codeforces.com/problemset/problem/74/C)|Codeforces||Codeforces Beta Round #68|7|
|<ul><li>- [ ] Done</li></ul>|202|[Digital Root](http://codeforces.com/problemset/problem/10/C)|Codeforces||Codeforces Beta Round #10|7|
|<ul><li>- [ ] Done</li></ul>|203|[Sum of Remainders](http://codeforces.com/problemset/problem/616/E)|Codeforces||Educational Codeforces Round 5|7|
|<ul><li>- [ ] Done</li></ul>|204|[Alice, Bob, Oranges and Apples](http://codeforces.com/problemset/problem/585/C)|Codeforces||Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|205|[Traffic Jams in the Land](http://codeforces.com/problemset/problem/498/D)|Codeforces||Codeforces Round #284 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|206|[On Sum of Fractions](http://codeforces.com/problemset/problem/396/B)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|207|[On Number of Decompositions into Multipliers](http://codeforces.com/problemset/problem/396/A)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|208|[Divisor Tree](http://codeforces.com/problemset/problem/337/E)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|209|[ucyhf](http://codeforces.com/problemset/problem/171/F)|Codeforces||April Fools Day Contest|7|
|<ul><li>- [ ] Done</li></ul>|210|[Bamboo Partition](http://codeforces.com/problemset/problem/830/C)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|7|
|<ul><li>- [ ] Done</li></ul>|211|[Fractions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2640)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|212|[Number Challenge](http://codeforces.com/problemset/problem/235/E)|Codeforces||Codeforces Round #146 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|213|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|214|[Unsolvable](http://codeforces.com/problemset/problem/225/E)|Codeforces||Codeforces Round #139 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|215|[Martian Luck](http://codeforces.com/problemset/problem/216/E)|Codeforces||Codeforces Round #133 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|216|[Periodical Numbers](http://codeforces.com/problemset/problem/215/E)|Codeforces||Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|217|[Numbers](http://codeforces.com/problemset/problem/83/D)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|218|[Prime Problem](http://codeforces.com/problemset/problem/45/G)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|219|[Notepad](http://codeforces.com/problemset/problem/17/D)|Codeforces||Codeforces Beta Round #17|8|
|<ul><li>- [ ] Done</li></ul>|220|[Cowslip Collections](http://codeforces.com/problemset/problem/645/F)|Codeforces||CROC 2016 - Elimination Round|8|
|<ul><li>- [ ] Done</li></ul>|221|[REQ](http://codeforces.com/problemset/problem/594/D)|Codeforces||Codeforces Round #330 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|222|[Superior Periodic Subarrays](http://codeforces.com/problemset/problem/582/C)|Codeforces||Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|223|[The Child and Binary Tree](http://codeforces.com/problemset/problem/438/E)|Codeforces||Codeforces Round #250 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|224|[Beautiful Set](http://codeforces.com/problemset/problem/364/C)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|225|[GCD Table](http://codeforces.com/problemset/problem/338/D)|Codeforces||Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|226|[Cube Problem](http://codeforces.com/problemset/problem/293/C)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|227|[Cows and Cool Sequences](http://codeforces.com/problemset/problem/283/D)|Codeforces||Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|228|[Three Horses](http://codeforces.com/problemset/problem/271/E)|Codeforces||Codeforces Round #166 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|229|[Ultimate Weirdness of an Array](http://codeforces.com/problemset/problem/671/C)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|230|[Timofey and remoduling](http://codeforces.com/problemset/problem/763/C)|Codeforces||Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|231|[Mishka and Divisors](http://codeforces.com/problemset/problem/703/E)|Codeforces||Codeforces Round #365 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|232|[Ada and Connections](http://www.spoj.com/problems/ADACON/)|SPOJ|||8|
|<ul><li>- [ ] Done</li></ul>|233|[Tractor College](http://codeforces.com/problemset/problem/200/E)|Codeforces||Codeforces Round #126 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|234|[Visit of the Great](http://codeforces.com/problemset/problem/185/D)|Codeforces||Codeforces Round #118 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|235|[Divisibility Rules](http://codeforces.com/problemset/problem/180/B)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|236|[Morrowindows](http://codeforces.com/problemset/problem/73/E)|Codeforces||Codeforces Beta Round #66|9|
|<ul><li>- [ ] Done</li></ul>|237|[Swap (Easy - Level 2)](http://www.spoj.com/problems/SWAP_ESY/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|238|[Four Divisors](http://codeforces.com/problemset/problem/665/F)|Codeforces||Educational Codeforces Round 12|9|
|<ul><li>- [ ] Done</li></ul>|239|[Present for Vitalik the Philatelist ](http://codeforces.com/problemset/problem/585/E)|Codeforces||Codeforces Round #325 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|240|[Superhero's Job](http://codeforces.com/problemset/problem/542/D)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|9|
|<ul><li>- [ ] Done</li></ul>|241|[Levko and Sets](http://codeforces.com/problemset/problem/360/D)|Codeforces||Codeforces Round #210 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|242|[White, Black and White Again](http://codeforces.com/problemset/problem/306/C)|Codeforces||Testing Round #6|9|
|<ul><li>- [ ] Done</li></ul>|243|[Rotatable Number](http://codeforces.com/problemset/problem/303/D)|Codeforces||Codeforces Round #183 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|244|[Shaass and Painter Robot](http://codeforces.com/problemset/problem/294/D)|Codeforces||Codeforces Round #178 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|245|[Prime factorization](http://codeforces.com/problemset/problem/162/C)|Codeforces||VK Cup 2012 Wild-card Round 1|10|
|<ul><li>- [ ] Done</li></ul>|246|[Number of Binominal Coefficients](http://codeforces.com/problemset/problem/582/D)|Codeforces||Codeforces Round #323 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|247|[New Year Running](http://codeforces.com/problemset/problem/500/G)|Codeforces||Good Bye 2014|10|
|<ul><li>- [ ] Done</li></ul>|248|[Jzzhu and Squares](http://codeforces.com/problemset/problem/449/E)|Codeforces||Codeforces Round #257 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|249|[Mister B and Beacons on Field](http://codeforces.com/problemset/problem/819/C)|Codeforces||Codeforces Round #421 (Div. 1) & Codeforces Round #421 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|250|[Mister B and Astronomers](http://codeforces.com/problemset/problem/819/D)|Codeforces||Codeforces Round #421 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|251|[Nephren Runs a Cinema](http://codeforces.com/problemset/problem/896/D)|Codeforces||Codeforces Round #449 (Div. 1)|10|
