# 098. big_numbers


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Small factorials](http://www.spoj.com/problems/FCTRL2/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Julka](http://www.spoj.com/problems/JULKA/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[X&#7917; lý s&#7889; nguy&#234;n l&#7899;n](http://vn.spoj.com/problems/BIGNUM/)|SPOJ Vietnam|1|
|<ul><li>- [ ] Done</li></ul>|4|[Minimum Number](http://www.spoj.com/problems/MINNUM/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|5|[Recurrence](http://www.spoj.com/problems/REC/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|6|[Binary multiplication](http://www.spoj.com/problems/MUL2COM/)|SPOJ|3|
