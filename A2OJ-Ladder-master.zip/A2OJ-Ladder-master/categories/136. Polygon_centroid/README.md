# 136. Polygon_centroid


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lifting the Stone](http://www.spoj.com/problems/STONE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Area of Polycubes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2239)|Live Archive|2008|North America - Greater NY|1|
