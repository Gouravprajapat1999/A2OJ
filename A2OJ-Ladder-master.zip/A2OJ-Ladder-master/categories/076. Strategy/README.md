# 076. Strategy


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[DOTA HEROES](http://www.spoj.com/problems/DOTAA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[LUCKYNINE](http://www.spoj.com/problems/NITHY/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|3|[TRIVIADOR](http://www.spoj.com/problems/TWOKINGS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|4|[Car with powers](http://www.spoj.com/problems/POWERCAR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|5|[Soldiers](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=275)|Live Archive|2001|Europe - Southeastern|6|
|<ul><li>- [ ] Done</li></ul>|6|[GAMING ARENA](http://www.spoj.com/problems/GAMARENA/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|7|[FLING1](http://www.spoj.com/problems/FLING1/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|8|[TWO KINGS](http://www.spoj.com/problems/CONQUER/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|9|[BLOCK_D SOLVER](http://www.spoj.com/problems/BLOCK_D/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|10|[THE WITTY BOY](http://www.spoj.com/problems/WITTYBOY/)|SPOJ|||10|
