# 014. constructive_algorithms


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Hexadecimal's theorem](http://codeforces.com/problemset/problem/199/A)|Codeforces|Codeforces Round #125 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Insomnia cure](http://codeforces.com/problemset/problem/148/A)|Codeforces|Codeforces Round #105 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Present from Lena](http://codeforces.com/problemset/problem/118/B)|Codeforces|Codeforces Beta Round #89 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Lucky Sum of Digits](http://codeforces.com/problemset/problem/109/A)|Codeforces|Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Before an Exam](http://codeforces.com/problemset/problem/4/B)|Codeforces|Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Far Relative’s Birthday Cake](http://codeforces.com/problemset/problem/629/A)|Codeforces|Codeforces Round #343 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces|Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Quasi Binary](http://codeforces.com/problemset/problem/538/B)|Codeforces|Codeforces Round #300|1|
|<ul><li>- [ ] Done</li></ul>|9|[Exam](http://codeforces.com/problemset/problem/534/A)|Codeforces|Codeforces Round #298 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Game](http://codeforces.com/problemset/problem/513/A)|Codeforces|Rockethon 2015|1|
|<ul><li>- [ ] Done</li></ul>|11|[Diverse Permutation](http://codeforces.com/problemset/problem/482/A)|Codeforces|Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Random Teams](http://codeforces.com/problemset/problem/478/B)|Codeforces|Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|13|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces|Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|14|[Anton and Letters](http://codeforces.com/problemset/problem/443/A)|Codeforces|Codeforces Round #253 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Team](http://codeforces.com/problemset/problem/401/C)|Codeforces|Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Road Construction](http://codeforces.com/problemset/problem/330/B)|Codeforces|Codeforces Round #192 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Array](http://codeforces.com/problemset/problem/300/A)|Codeforces|Codeforces Round #181 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Queue at the School](http://codeforces.com/problemset/problem/266/B)|Codeforces|Codeforces Round #163 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Different is Good](http://codeforces.com/problemset/problem/672/B)|Codeforces|Codeforces Round #352 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Free Ice Cream](http://codeforces.com/problemset/problem/686/A)|Codeforces|Codeforces Round #359 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Bear and Five Cards](http://codeforces.com/problemset/problem/680/A)|Codeforces|Codeforces Round #356 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[Bear and Finding Criminals](http://codeforces.com/problemset/problem/680/B)|Codeforces|Codeforces Round #356 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[Alyona and Numbers](http://codeforces.com/problemset/problem/682/A)|Codeforces|Codeforces Round #358 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[Lovely Palindromes](http://codeforces.com/problemset/problem/688/B)|Codeforces|Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Fraction](http://codeforces.com/problemset/problem/854/A)|Codeforces|Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Timofey and cubes](http://codeforces.com/problemset/problem/764/B)|Codeforces|Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|27|[Shell Game](http://codeforces.com/problemset/problem/777/A)|Codeforces|Codeforces Round #401 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Mahmoud and Longest Uncommon Subsequence](http://codeforces.com/problemset/problem/766/A)|Codeforces|Codeforces Round #396 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Mike and palindrome](http://codeforces.com/problemset/problem/798/A)|Codeforces|Codeforces Round #410 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Mahmoud and a Triangle](http://codeforces.com/problemset/problem/766/B)|Codeforces|Codeforces Round #396 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Chloe and the sequence ](http://codeforces.com/problemset/problem/743/B)|Codeforces|Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Vladik and flights](http://codeforces.com/problemset/problem/743/A)|Codeforces|Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Chris and Magic Square](http://codeforces.com/problemset/problem/711/B)|Codeforces|Codeforces Round #369 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Buggy Sorting](http://codeforces.com/problemset/problem/246/A)|Codeforces|Codeforces Round #151 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|35|[Bear and Forgotten Tree 3](http://codeforces.com/problemset/problem/639/B)|Codeforces|VK Cup 2016 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|36|[Print Check](http://codeforces.com/problemset/problem/631/B)|Codeforces|Codeforces Round #344 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|37|[K-special Tables](http://codeforces.com/problemset/problem/625/C)|Codeforces|Codeforces Round #342 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|38|[War of the Corporations](http://codeforces.com/problemset/problem/625/B)|Codeforces|Codeforces Round #342 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|39|[Guess the Permutation](http://codeforces.com/problemset/problem/618/B)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|2|
|<ul><li>- [ ] Done</li></ul>|40|[Sorting Railway Cars](http://codeforces.com/problemset/problem/605/A)|Codeforces|Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|41|[GCD Table](http://codeforces.com/problemset/problem/582/A)|Codeforces|Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces|Codeforces Round #316 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|43|[Gerald is into Art](http://codeforces.com/problemset/problem/560/B)|Codeforces|Codeforces Round #313 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|44|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces|Codeforces Round #304 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|45|[Sea and Islands](http://codeforces.com/problemset/problem/544/B)|Codeforces|Codeforces Round #302 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|46|[Painting Pebbles](http://codeforces.com/problemset/problem/509/B)|Codeforces|Codeforces Round #289 (Div. 2, ACM ICPC Rules)|2|
|<ul><li>- [ ] Done</li></ul>|47|[New Year Book Reading](http://codeforces.com/problemset/problem/500/C)|Codeforces|Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|48|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces|Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|49|[Vasya and Chess](http://codeforces.com/problemset/problem/493/D)|Codeforces|Codeforces Round #281 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|50|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces|Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|51|[24 Game](http://codeforces.com/problemset/problem/468/A)|Codeforces|Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|52|[Valera and Tubes ](http://codeforces.com/problemset/problem/441/C)|Codeforces|Codeforces Round #252 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|53|[Mashmokh and Numbers](http://codeforces.com/problemset/problem/414/A)|Codeforces|Codeforces Round #240 (Div. 1) & Codeforces Round #240 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|54|[New Year Present](http://codeforces.com/problemset/problem/379/B)|Codeforces|Good Bye 2013|2|
|<ul><li>- [ ] Done</li></ul>|55|[Levko and Table](http://codeforces.com/problemset/problem/361/A)|Codeforces|Codeforces Round #210 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|56|[Vasya and Digital Root](http://codeforces.com/problemset/problem/355/A)|Codeforces|Codeforces Round #206 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|57|[Beautiful Sets of Points](http://codeforces.com/problemset/problem/268/C)|Codeforces|Codeforces Round #164 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|58|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces|Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|59|[Bear and Prime 100](http://codeforces.com/problemset/problem/679/A)|Codeforces|Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|60|[Little Robber Girl's Zoo](http://codeforces.com/problemset/problem/686/B)|Codeforces|Codeforces Round #359 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|61|[Restoring Painting](http://codeforces.com/problemset/problem/675/B)|Codeforces|Codeforces Round #353 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|62|[Alyona and mex](http://codeforces.com/problemset/problem/739/A)|Codeforces|Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|63|[Plus and Square Root](http://codeforces.com/problemset/problem/715/A)|Codeforces|Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|64|[Valued Keys](http://codeforces.com/problemset/problem/801/B)|Codeforces|Codeforces Round #409 (rated, Div. 2, based on VK Cup 2017 Round 2)|2|
|<ul><li>- [ ] Done</li></ul>|65|[Maxim Buys an Apartment](http://codeforces.com/problemset/problem/854/B)|Codeforces|Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|2|
|<ul><li>- [ ] Done</li></ul>|66|[Alyona and flowers](http://codeforces.com/problemset/problem/740/B)|Codeforces|Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|67|[Parallelogram is Back](http://codeforces.com/problemset/problem/749/B)|Codeforces|Codeforces Round #388 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|68|[Lesha and array splitting](http://codeforces.com/problemset/problem/754/A)|Codeforces|Codeforces Round #390 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|69|[Vladik and fractions](http://codeforces.com/problemset/problem/743/C)|Codeforces|Codeforces Round #384 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|70|[An express train to reveries](http://codeforces.com/problemset/problem/814/B)|Codeforces|Codeforces Round #418 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|71|[Cumulative Sum Query](http://www.spoj.com/problems/CSUMQ/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|72|[Cards with Numbers](http://codeforces.com/problemset/problem/254/A)|Codeforces|Codeforces Round #155 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|73|[Lucky String](http://codeforces.com/problemset/problem/110/B)|Codeforces|Codeforces Beta Round #84 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|74|[Easter Eggs](http://codeforces.com/problemset/problem/78/B)|Codeforces|Codeforces Beta Round #70 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|75|[Increasing Sequence](http://codeforces.com/problemset/problem/11/A)|Codeforces|Codeforces Beta Round #11|3|
|<ul><li>- [ ] Done</li></ul>|76|[Kalevitch and Chess](http://codeforces.com/problemset/problem/7/A)|Codeforces|Codeforces Beta Round #7|3|
|<ul><li>- [ ] Done</li></ul>|77|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces|Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|78|[Parliament of Berland](http://codeforces.com/problemset/problem/644/A)|Codeforces|CROC 2016 - Qualification|3|
|<ul><li>- [ ] Done</li></ul>|79|[A Trivial Problem](http://codeforces.com/problemset/problem/633/B)|Codeforces|Manthan, Codefest 16|3|
|<ul><li>- [ ] Done</li></ul>|80|[Cards](http://codeforces.com/problemset/problem/626/B)|Codeforces|8VC Venture Cup 2016 - Elimination Round|3|
|<ul><li>- [ ] Done</li></ul>|81|[Graph and String](http://codeforces.com/problemset/problem/623/A)|Codeforces|AIM Tech Round (Div. 1) & AIM Tech Round (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|82|[Polyline](http://codeforces.com/problemset/problem/617/D)|Codeforces|Codeforces Round #340 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|83|[Marina and Vasya](http://codeforces.com/problemset/problem/584/C)|Codeforces|Codeforces Round #324 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|84|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces|Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|85|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces|Codeforces Round #283 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|86|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces|Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|87|[Pashmak and Buses](http://codeforces.com/problemset/problem/459/C)|Codeforces|Codeforces Round #261 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|88|[Football](http://codeforces.com/problemset/problem/417/C)|Codeforces|RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|89|[A + B Strikes Back](http://codeforces.com/problemset/problem/409/H)|Codeforces|April Fools Day Contest 2014|3|
|<ul><li>- [ ] Done</li></ul>|90|[Searching for Graph](http://codeforces.com/problemset/problem/402/C)|Codeforces|Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|91|[Valera and Contest](http://codeforces.com/problemset/problem/369/B)|Codeforces|Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|92|[Levko and Permutation](http://codeforces.com/problemset/problem/361/B)|Codeforces|Codeforces Round #210 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|93|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces|Codeforces Round #209 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|94|[Flag Day](http://codeforces.com/problemset/problem/357/B)|Codeforces|Codeforces Round #207 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|95|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces|Codeforces Round #197 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|96|[Purification](http://codeforces.com/problemset/problem/329/A)|Codeforces|Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|97|[Ilya and Matrix](http://codeforces.com/problemset/problem/313/C)|Codeforces|Codeforces Round #186 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|98|[Lucky Permutation Triple](http://codeforces.com/problemset/problem/303/A)|Codeforces|Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|99|[Cows and Sequence](http://codeforces.com/problemset/problem/283/A)|Codeforces|Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|100|[XOR and OR](http://codeforces.com/problemset/problem/282/C)|Codeforces|Codeforces Round #173 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|101|[Dice Tower](http://codeforces.com/problemset/problem/225/A)|Codeforces|Codeforces Round #139 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|102|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces|Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|103|[Coat of Anticubism](http://codeforces.com/problemset/problem/667/B)|Codeforces|Codeforces Round #349 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|104|[From Y to Y](http://codeforces.com/problemset/problem/848/A)|Codeforces|Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|105|[Short Program](http://codeforces.com/problemset/problem/878/A)|Codeforces|Codeforces Round #443 (Div. 1) & Codeforces Round #443 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|106|[Mister B and Angle in Polygon](http://codeforces.com/problemset/problem/820/B)|Codeforces|Codeforces Round #421 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|107|[Mike and Cellphone](http://codeforces.com/problemset/problem/689/A)|Codeforces|Codeforces Round #361 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|108|[Magic, Wizardry and Wonders](http://codeforces.com/problemset/problem/231/B)|Codeforces|Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|109|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces|Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|110|[Plate Game](http://codeforces.com/problemset/problem/197/A)|Codeforces|Codeforces Round #124 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|111|[Mysterious numbers - 1](http://codeforces.com/problemset/problem/171/A)|Codeforces|April Fools Day Contest|4|
|<ul><li>- [ ] Done</li></ul>|112|[Little Frog](http://codeforces.com/problemset/problem/53/C)|Codeforces|Codeforces Beta Round #49 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|113|[Rebus](http://codeforces.com/problemset/problem/663/A)|Codeforces|Codeforces Round #347 (Div. 1) & Codeforces Round #347 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|114|[Amity Assessment](http://codeforces.com/problemset/problem/645/A)|Codeforces|CROC 2016 - Elimination Round|4|
|<ul><li>- [ ] Done</li></ul>|115|[Little Artem and Dance](http://codeforces.com/problemset/problem/641/C)|Codeforces|VK Cup 2016 - Round 2|4|
|<ul><li>- [ ] Done</li></ul>|116|[Home Numbers](http://codeforces.com/problemset/problem/638/A)|Codeforces|VK Cup 2016 - Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|117|[Promocodes with Mistakes](http://codeforces.com/problemset/problem/637/C)|Codeforces|VK Cup 2016 - Qualification Round 1|4|
|<ul><li>- [ ] Done</li></ul>|118|[Island Puzzle](http://codeforces.com/problemset/problem/634/A)|Codeforces|8VC Venture Cup 2016 - Final Round (Div. 1 Edition) & 8VC Venture Cup 2016 - Final Round (Div. 2 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|119|[Alice, Bob, Two Teams](http://codeforces.com/problemset/problem/632/B)|Codeforces|Educational Codeforces Round 9|4|
|<ul><li>- [ ] Done</li></ul>|120|[Harmony Analysis](http://codeforces.com/problemset/problem/610/C)|Codeforces|Codeforces Round #337 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|121|[Lazy Student](http://codeforces.com/problemset/problem/605/B)|Codeforces|Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|122|[Three Logos](http://codeforces.com/problemset/problem/581/D)|Codeforces|Codeforces Round #322 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|123|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces|Codeforces Round #316 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|124|[ZgukistringZ](http://codeforces.com/problemset/problem/551/B)|Codeforces|Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|125|[Regular Bridge](http://codeforces.com/problemset/problem/550/D)|Codeforces|Codeforces Round #306 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|126|[Weird Chess](http://codeforces.com/problemset/problem/538/D)|Codeforces|Codeforces Round #300|4|
|<ul><li>- [ ] Done</li></ul>|127|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces|Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|128|[Dreamoon and Sets](http://codeforces.com/problemset/problem/476/D)|Codeforces|Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|129|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces|Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|130|[Pasha and Hamsters](http://codeforces.com/problemset/problem/421/A)|Codeforces|Coder-Strike 2014 - Finals (online edition, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|131|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces|Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|132|[The Closest Pair](http://codeforces.com/problemset/problem/311/A)|Codeforces|Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|133|[Strange Addition](http://codeforces.com/problemset/problem/305/A)|Codeforces|Codeforces Round #184 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|134|[Yaroslav and Sequence](http://codeforces.com/problemset/problem/301/A)|Codeforces|Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|135|[Fish Weight](http://codeforces.com/problemset/problem/297/B)|Codeforces|Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|136|[Parity Game](http://codeforces.com/problemset/problem/297/A)|Codeforces|Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|137|[Lucky Permutation](http://codeforces.com/problemset/problem/286/A)|Codeforces|Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|138|[Secret](http://codeforces.com/problemset/problem/271/C)|Codeforces|Codeforces Round #166 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|139|[Mountain Scenery](http://codeforces.com/problemset/problem/218/A)|Codeforces|Codeforces Round #134 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|140|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces|Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|141|[Marco and GCD Sequence](http://codeforces.com/problemset/problem/894/C)|Codeforces|Codeforces Round #447 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|142|[Beauty Pageant](http://codeforces.com/problemset/problem/246/C)|Codeforces|Codeforces Round #151 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|143|[Restoring Table](http://codeforces.com/problemset/problem/245/D)|Codeforces|CROC-MBTU 2012, Elimination Round (ACM-ICPC)|5|
|<ul><li>- [ ] Done</li></ul>|144|[Not Wool Sequences](http://codeforces.com/problemset/problem/238/A)|Codeforces|Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|145|[Cycles](http://codeforces.com/problemset/problem/232/A)|Codeforces|Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|146|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces|Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|147|[Discounts](http://codeforces.com/problemset/problem/161/B)|Codeforces|VK Cup 2012 Round 1|5|
|<ul><li>- [ ] Done</li></ul>|148|[Terse princess](http://codeforces.com/problemset/problem/148/C)|Codeforces|Codeforces Round #105 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|149|[Lucky Number 2](http://codeforces.com/problemset/problem/145/B)|Codeforces|Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|150|[Queue](http://codeforces.com/problemset/problem/141/C)|Codeforces|Codeforces Round #101 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|151|[Domino](http://codeforces.com/problemset/problem/85/A)|Codeforces|Yandex.Algorithm 2011 Round 1|5|
|<ul><li>- [ ] Done</li></ul>|152|[Sets](http://codeforces.com/problemset/problem/82/B)|Codeforces|Yandex.Algorithm 2011 Qualification 2|5|
|<ul><li>- [ ] Done</li></ul>|153|[Petya and His Friends](http://codeforces.com/problemset/problem/66/D)|Codeforces|Codeforces Beta Round #61 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|154|[Find Color](http://codeforces.com/problemset/problem/40/A)|Codeforces|Codeforces Beta Round #39|5|
|<ul><li>- [ ] Done</li></ul>|155|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces|Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|156|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces|Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|157|[Obsession with Robots](http://codeforces.com/problemset/problem/8/B)|Codeforces|Codeforces Beta Round #8|5|
|<ul><li>- [ ] Done</li></ul>|158|[Stammering Aliens](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3358)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|159|[Simple Subset](http://codeforces.com/problemset/problem/665/D)|Codeforces|Educational Codeforces Round 12|5|
|<ul><li>- [ ] Done</li></ul>|160|[Optimal Number Permutation](http://codeforces.com/problemset/problem/622/D)|Codeforces|Educational Codeforces Round 7|5|
|<ul><li>- [ ] Done</li></ul>|161|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|162|[Tablecity](http://codeforces.com/problemset/problem/575/D)|Codeforces|Bubble Cup 8 - Finals [Online Mirror]|5|
|<ul><li>- [ ] Done</li></ul>|163|[Kyoya and Permutation](http://codeforces.com/problemset/problem/553/B)|Codeforces|Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|164|[Handshakes](http://codeforces.com/problemset/problem/534/D)|Codeforces|Codeforces Round #298 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|165|[Correcting Mistakes](http://codeforces.com/problemset/problem/533/E)|Codeforces|VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|166|[Candy Boxes](http://codeforces.com/problemset/problem/488/B)|Codeforces|Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|167|[4-point polyline](http://codeforces.com/problemset/problem/452/B)|Codeforces|MemSQL Start[c]UP 2.0 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|168|[Points and Segments (easy)](http://codeforces.com/problemset/problem/430/A)|Codeforces|Codeforces Round #245 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|169|[Fox and Minimal path](http://codeforces.com/problemset/problem/388/B)|Codeforces|Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|170|[Queue](http://codeforces.com/problemset/problem/353/D)|Codeforces|Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|171|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces|Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|172|[Block Tower](http://codeforces.com/problemset/problem/327/D)|Codeforces|Codeforces Round #191 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|173|[Convex Shape](http://codeforces.com/problemset/problem/275/B)|Codeforces|Codeforces Round #168 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|174|[Suspects](http://codeforces.com/problemset/problem/156/B)|Codeforces|Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|175|[Help General](http://codeforces.com/problemset/problem/142/B)|Codeforces|Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|176|[Gluttony](http://codeforces.com/problemset/problem/891/B)|Codeforces|Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|177|[Timofey and rectangles](http://codeforces.com/problemset/problem/763/B)|Codeforces|Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|178|[Complete The Graph](http://codeforces.com/problemset/problem/715/B)|Codeforces|Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|179|[Maxim and Array](http://codeforces.com/problemset/problem/721/D)|Codeforces|Codeforces Round #374 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|180|[Dispute](http://codeforces.com/problemset/problem/242/D)|Codeforces|Codeforces Round #149 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|181|[Mathematical Analysis Rocks!](http://codeforces.com/problemset/problem/180/F)|Codeforces|Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|182|[Zero-One](http://codeforces.com/problemset/problem/135/C)|Codeforces|Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|183|[String](http://codeforces.com/problemset/problem/128/B)|Codeforces|Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|184|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces|Codeforces Beta Round #40 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|185|[Ant on the Tree](http://codeforces.com/problemset/problem/29/D)|Codeforces|Codeforces Beta Round #29 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|186|[Party](http://codeforces.com/problemset/problem/23/B)|Codeforces|Codeforces Beta Round #23|6|
|<ul><li>- [ ] Done</li></ul>|187|[International Olympiad](http://codeforces.com/problemset/problem/662/D)|Codeforces|CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|188|[Anton and Ira](http://codeforces.com/problemset/problem/584/E)|Codeforces|Codeforces Round #324 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|189|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces|Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|190|[Brackets in Implications](http://codeforces.com/problemset/problem/550/E)|Codeforces|Codeforces Round #306 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|191|[Looksery Party](http://codeforces.com/problemset/problem/549/B)|Codeforces|Looksery Cup 2015|6|
|<ul><li>- [ ] Done</li></ul>|192|[Prefix Product Sequence](http://codeforces.com/problemset/problem/487/C)|Codeforces|Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|193|[Little Pony and Summer Sun Celebration](http://codeforces.com/problemset/problem/453/C)|Codeforces|Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|194|[Jzzhu and Apples](http://codeforces.com/problemset/problem/449/C)|Codeforces|Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|195|[Mittens](http://codeforces.com/problemset/problem/370/C)|Codeforces|Codeforces Round #217 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|196|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces|Codeforces Round #208 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|197|[Compartments](http://codeforces.com/problemset/problem/356/C)|Codeforces|Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|198|[Palindrome](http://codeforces.com/problemset/problem/335/B)|Codeforces|MemSQL start[c]up Round 2 - online version|6|
|<ul><li>- [ ] Done</li></ul>|199|[Banana](http://codeforces.com/problemset/problem/335/A)|Codeforces|MemSQL start[c]up Round 2 - online version|6|
|<ul><li>- [ ] Done</li></ul>|200|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|201|[Below the Diagonal](http://codeforces.com/problemset/problem/266/C)|Codeforces|Codeforces Round #163 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|202|[Practice](http://codeforces.com/problemset/problem/234/G)|Codeforces|Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|203|[Rooter's Song](http://codeforces.com/problemset/problem/848/B)|Codeforces|Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|204|[Leha and another game about graph](http://codeforces.com/problemset/problem/840/B)|Codeforces|Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|205|[Searching Rectangles](http://codeforces.com/problemset/problem/713/B)|Codeforces|Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|206|[Karen and Test](http://codeforces.com/problemset/problem/815/B)|Codeforces|Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|207|[Arpa’s overnight party and Mehrdad’s silent entering](http://codeforces.com/problemset/problem/741/C)|Codeforces|Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|208|[Vladik and Favorite Game](http://codeforces.com/problemset/problem/811/D)|Codeforces|Codeforces Round #416 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|209|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces|Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|210|[Mike and distribution](http://codeforces.com/problemset/problem/798/D)|Codeforces|Codeforces Round #410 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|211|[Boring Partition](http://codeforces.com/problemset/problem/238/B)|Codeforces|Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|212|[Numbers](http://codeforces.com/problemset/problem/128/D)|Codeforces|Codeforces Beta Round #94 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|213|[Hobbits' Party](http://codeforces.com/problemset/problem/125/C)|Codeforces|Codeforces Testing Round #2|7|
|<ul><li>- [ ] Done</li></ul>|214|[Before Exam](http://codeforces.com/problemset/problem/119/B)|Codeforces|Codeforces Beta Round #90|7|
|<ul><li>- [ ] Done</li></ul>|215|[Russian Roulette](http://codeforces.com/problemset/problem/103/C)|Codeforces|Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|216|[Disposition](http://codeforces.com/problemset/problem/49/C)|Codeforces|Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|217|[Journey](http://codeforces.com/problemset/problem/43/D)|Codeforces|Codeforces Beta Round #42 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|218|[Necklace](http://codeforces.com/problemset/problem/613/C)|Codeforces|Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|219|[Square Root of Permutation](http://codeforces.com/problemset/problem/612/E)|Codeforces|Educational Codeforces Round 4|7|
|<ul><li>- [ ] Done</li></ul>|220|[Bear and Drawing](http://codeforces.com/problemset/problem/573/C)|Codeforces|Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|221|[Idempotent functions](http://codeforces.com/problemset/problem/542/C)|Codeforces|VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|222|[Restoring Numbers](http://codeforces.com/problemset/problem/509/D)|Codeforces|Codeforces Round #289 (Div. 2, ACM ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|223|[Sign on Fence](http://codeforces.com/problemset/problem/484/E)|Codeforces|Codeforces Round #276 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|224|[Kamal-ol-molk's Painting](http://codeforces.com/problemset/problem/475/C)|Codeforces|Bayan 2015 Contest Warm Up|7|
|<ul><li>- [ ] Done</li></ul>|225|[Hack it!](http://codeforces.com/problemset/problem/468/C)|Codeforces|Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|226|[Little Victor and Set](http://codeforces.com/problemset/problem/460/D)|Codeforces|Codeforces Round #262 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|227|[Valera and Swaps](http://codeforces.com/problemset/problem/441/D)|Codeforces|Codeforces Round #252 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|228|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces|Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|229|[Square Table](http://codeforces.com/problemset/problem/417/E)|Codeforces|RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|230|[Lucky Number Representation](http://codeforces.com/problemset/problem/354/E)|Codeforces|Codeforces Round #206 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|231|[Wrong Floyd](http://codeforces.com/problemset/problem/350/E)|Codeforces|Codeforces Round #203 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|232|[Graph Reconstruction](http://codeforces.com/problemset/problem/329/C)|Codeforces|Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|233|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces|Codeforces Round #191 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|234|[Splitting the Uniqueness](http://codeforces.com/problemset/problem/297/C)|Codeforces|Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|235|[Set of Points](http://codeforces.com/problemset/problem/277/B)|Codeforces|Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|236|[Dima and Horses](http://codeforces.com/problemset/problem/272/E)|Codeforces|Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|237|[Maxim and Matrix](http://codeforces.com/problemset/problem/261/C)|Codeforces|Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|238|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces|Codeforces Round #158 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|239|[The table](http://codeforces.com/problemset/problem/226/D)|Codeforces|Codeforces Round #140 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|240|[Graph Cutting](http://codeforces.com/problemset/problem/405/E)|Codeforces|Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|241|[Data Center Drama](http://codeforces.com/problemset/problem/527/E)|Codeforces|Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|242|[Vladik and chat](http://codeforces.com/problemset/problem/754/C)|Codeforces|Codeforces Round #390 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|243|[Challenging Balloons](http://codeforces.com/problemset/problem/241/G)|Codeforces|Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|8|
|<ul><li>- [ ] Done</li></ul>|244|[Trails and Glades](http://codeforces.com/problemset/problem/209/C)|Codeforces|VK Cup 2012 Finals, Practice Session|8|
|<ul><li>- [ ] Done</li></ul>|245|[Hamming Distance](http://codeforces.com/problemset/problem/193/C)|Codeforces|Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|246|[Headquarters](http://codeforces.com/problemset/problem/183/A)|Codeforces|Croc Champ 2012 - Final|8|
|<ul><li>- [ ] Done</li></ul>|247|[Playing with Superglue](http://codeforces.com/problemset/problem/176/C)|Codeforces|Croc Champ 2012 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|248|[Clearing Up](http://codeforces.com/problemset/problem/141/E)|Codeforces|Codeforces Round #101 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|249|[Swaps](http://codeforces.com/problemset/problem/134/C)|Codeforces|Codeforces Testing Round #3|8|
|<ul><li>- [ ] Done</li></ul>|250|[Constants in the language of Shakespeare](http://codeforces.com/problemset/problem/132/D)|Codeforces|Codeforces Beta Round #96 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|251|[E-reader Display](http://codeforces.com/problemset/problem/126/C)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|252|[Lucky Sorting](http://codeforces.com/problemset/problem/109/D)|Codeforces|Codeforces Beta Round #84 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|253|[Superset](http://codeforces.com/problemset/problem/97/B)|Codeforces|Yandex.Algorithm 2011 Finals|8|
|<ul><li>- [ ] Done</li></ul>|254|[Polycarp's Picture Gallery](http://codeforces.com/problemset/problem/81/D)|Codeforces|Yandex.Algorithm Open 2011 Qualification 1|8|
|<ul><li>- [ ] Done</li></ul>|255|[Dividing Island](http://codeforces.com/problemset/problem/63/D)|Codeforces|Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|256|[Team Arrangement](http://codeforces.com/problemset/problem/59/D)|Codeforces|Codeforces Beta Round #55 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|257|[Planting Trees](http://codeforces.com/problemset/problem/45/J)|Codeforces|School Team Contest #3 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|258|[Director](http://codeforces.com/problemset/problem/45/E)|Codeforces|School Team Contest #3 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|259|[Triminoes](http://codeforces.com/problemset/problem/44/J)|Codeforces|School Team Contest #2 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|260|[Safe cracking](http://codeforces.com/problemset/problem/42/C)|Codeforces|Codeforces Beta Round #41|8|
|<ul><li>- [ ] Done</li></ul>|261|[Tricky and Clever Password](http://codeforces.com/problemset/problem/30/E)|Codeforces|Codeforces Beta Round #30 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|262|[Parquet](http://codeforces.com/problemset/problem/26/C)|Codeforces|Codeforces Beta Round #26 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|263|[Oranges and Apples](http://codeforces.com/problemset/problem/23/C)|Codeforces|Codeforces Beta Round #23|8|
|<ul><li>- [ ] Done</li></ul>|264|[Start of the session](http://codeforces.com/problemset/problem/12/E)|Codeforces|Codeforces Beta Round #12 (Div 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|265|[Greedy Change](http://codeforces.com/problemset/problem/10/E)|Codeforces|Codeforces Beta Round #10|8|
|<ul><li>- [ ] Done</li></ul>|266|[Finals in arithmetic](http://codeforces.com/problemset/problem/625/D)|Codeforces|Codeforces Round #342 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|267|[Double Knapsack](http://codeforces.com/problemset/problem/618/F)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|268|[CNF 2](http://codeforces.com/problemset/problem/571/C)|Codeforces|Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|269|[Square Tiling](http://codeforces.com/problemset/problem/432/E)|Codeforces|Codeforces Round #246 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|270|[Biathlon Track](http://codeforces.com/problemset/problem/424/D)|Codeforces|Codeforces Round #242 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|271|[Dominoes](http://codeforces.com/problemset/problem/394/C)|Codeforces|Codeforces Round #231 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|272|[Inna and Sweet Matrix](http://codeforces.com/problemset/problem/390/D)|Codeforces|Codeforces Round #229 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|273|[Broken Monitor](http://codeforces.com/problemset/problem/370/D)|Codeforces|Codeforces Round #217 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|274|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces|Codeforces Round #207 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|275|[Three Swaps](http://codeforces.com/problemset/problem/339/E)|Codeforces|Codeforces Round #197 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|276|[Black-and-White Cube](http://codeforces.com/problemset/problem/323/A)|Codeforces|Testing Round #7|8|
|<ul><li>- [ ] Done</li></ul>|277|[Balance](http://codeforces.com/problemset/problem/317/C)|Codeforces|Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|278|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces|Codeforces Round #186 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|279|[Yaroslav and Algorithm](http://codeforces.com/problemset/problem/301/C)|Codeforces|Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|280|[Ladies' Shop](http://codeforces.com/problemset/problem/286/E)|Codeforces|Codeforces Round #176 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|281|[Three Horses](http://codeforces.com/problemset/problem/271/E)|Codeforces|Codeforces Round #166 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|282|[Merging Two Decks](http://codeforces.com/problemset/problem/234/H)|Codeforces|Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|283|[Stars](http://codeforces.com/problemset/problem/213/D)|Codeforces|Codeforces Round #131 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|284|[Pixels](http://codeforces.com/problemset/problem/209/B)|Codeforces|VK Cup 2012 Finals, Practice Session|9|
|<ul><li>- [ ] Done</li></ul>|285|[Deputies](http://codeforces.com/problemset/problem/173/D)|Codeforces|Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|286|[Two progressions](http://codeforces.com/problemset/problem/125/D)|Codeforces|Codeforces Testing Round #2|9|
|<ul><li>- [ ] Done</li></ul>|287|[Tetris revisited](http://codeforces.com/problemset/problem/86/B)|Codeforces|Yandex.Algorithm 2011 Round 2|9|
|<ul><li>- [ ] Done</li></ul>|288|[Strange town](http://codeforces.com/problemset/problem/42/D)|Codeforces|Codeforces Beta Round #41|9|
|<ul><li>- [ ] Done</li></ul>|289|[Two Paths](http://codeforces.com/problemset/problem/36/E)|Codeforces|Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|290|[Multithreading](http://codeforces.com/problemset/problem/26/E)|Codeforces|Codeforces Beta Round #26 (Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|291|[Beautiful Function](http://codeforces.com/problemset/problem/593/C)|Codeforces|Codeforces Round #329 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|292|[Walking!](http://codeforces.com/problemset/problem/578/E)|Codeforces|Codeforces Round #320 (Div. 1) [Bayan Thanks-Round]|9|
|<ul><li>- [ ] Done</li></ul>|293|[Replicating Processes](http://codeforces.com/problemset/problem/566/B)|Codeforces|VK Cup 2015 - Finals, online mirror|9|
|<ul><li>- [ ] Done</li></ul>|294|[Berland Local Positioning System](http://codeforces.com/problemset/problem/534/E)|Codeforces|Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|295|[Constrained Tree](http://codeforces.com/problemset/problem/513/D2)|Codeforces|Rockethon 2015|9|
|<ul><li>- [ ] Done</li></ul>|296|[Fox And Polygon](http://codeforces.com/problemset/problem/512/E)|Codeforces|Codeforces Round #290 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|297|[Design Tutorial: Change the Goal](http://codeforces.com/problemset/problem/472/F)|Codeforces|Codeforces Round #270|9|
|<ul><li>- [ ] Done</li></ul>|298|[Tree and Array](http://codeforces.com/problemset/problem/398/C)|Codeforces|Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|299|[Candies Game](http://codeforces.com/problemset/problem/341/E)|Codeforces|Codeforces Round #198 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|300|[Lucky Tickets](http://codeforces.com/problemset/problem/333/C)|Codeforces|Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|301|[The Evil Temple and the Moving Rocks](http://codeforces.com/problemset/problem/329/D)|Codeforces|Codeforces Round #192 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|302|[Tournament-graph](http://codeforces.com/problemset/problem/323/B)|Codeforces|Testing Round #7|9|
|<ul><li>- [ ] Done</li></ul>|303|[Color the Carpet](http://codeforces.com/problemset/problem/297/D)|Codeforces|Codeforces Round #180 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|304|[Grocer's Problem](http://codeforces.com/problemset/problem/91/D)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|305|[Parquet Re-laying](http://codeforces.com/problemset/problem/778/D)|Codeforces|Codeforces Round #402 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|306|[Mister B and Flight to the Moon](http://codeforces.com/problemset/problem/819/E)|Codeforces|Codeforces Round #421 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|307|[Mike and code of a permutation](http://codeforces.com/problemset/problem/798/E)|Codeforces|Codeforces Round #410 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|308|[Doe Graphs](http://codeforces.com/problemset/problem/232/C)|Codeforces|Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|309|[Cube Snake](http://codeforces.com/problemset/problem/198/D)|Codeforces|Codeforces Round #125 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|310|[Help Monks](http://codeforces.com/problemset/problem/98/D)|Codeforces|Codeforces Beta Round #78 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|311|[Shift It!](http://codeforces.com/problemset/problem/74/E)|Codeforces|Codeforces Beta Round #68|10|
|<ul><li>- [ ] Done</li></ul>|312|[Black and White](http://codeforces.com/problemset/problem/48/H)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|313|[Ants on a Circle](http://codeforces.com/problemset/problem/652/F)|Codeforces|Educational Codeforces Round 10|10|
|<ul><li>- [ ] Done</li></ul>|314|[New Year  and Forgotten Tree](http://codeforces.com/problemset/problem/611/H)|Codeforces|Good Bye 2015|10|
|<ul><li>- [ ] Done</li></ul>|315|[Restoring Map](http://codeforces.com/problemset/problem/566/E)|Codeforces|VK Cup 2015 - Finals, online mirror|10|
|<ul><li>- [ ] Done</li></ul>|316|[Listening to Music](http://codeforces.com/problemset/problem/543/E)|Codeforces|Codeforces Round #302 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|317|[Berserk Robot ](http://codeforces.com/problemset/problem/538/G)|Codeforces|Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|318|[Design Tutorial: Learn from a Game](http://codeforces.com/problemset/problem/472/E)|Codeforces|Codeforces Round #270|10|
|<ul><li>- [ ] Done</li></ul>|319|[Flow Optimality](http://codeforces.com/problemset/problem/457/E)|Codeforces|MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|320|[Deja Vu](http://codeforces.com/problemset/problem/331/E2)|Codeforces|ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|321|[Deja Vu](http://codeforces.com/problemset/problem/331/E1)|Codeforces|ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|322|[Princess and Her Shadow](http://codeforces.com/problemset/problem/317/E)|Codeforces|Codeforces Round #188 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|323|[Suns and Rays](http://codeforces.com/problemset/problem/316/F3)|Codeforces|ABBYY Cup 3.0|10|
|<ul><li>- [ ] Done</li></ul>|324|[Polygon](http://codeforces.com/problemset/problem/306/D)|Codeforces|Testing Round #6|10|
|<ul><li>- [ ] Done</li></ul>|325|[HQ](http://codeforces.com/problemset/problem/290/E)|Codeforces|April Fools Day Contest 2013|10|
|<ul><li>- [ ] Done</li></ul>|326|[Dynamic Programming](p?ID=410)|A2 Online Judge||10|
|<ul><li>- [ ] Done</li></ul>|327|[Karen and Neighborhood](http://codeforces.com/problemset/problem/815/E)|Codeforces|Codeforces Round #419 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|328|[Chess Championship](http://codeforces.com/problemset/problem/736/E)|Codeforces|Codeforces Round #382 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|329|[Finding lines](http://codeforces.com/problemset/problem/788/D)|Codeforces|Codeforces Round #407 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|330|[Create a Maze](http://codeforces.com/problemset/problem/715/D)|Codeforces|Codeforces Round #372 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|331|[Perpetual Motion Machine](http://codeforces.com/problemset/problem/830/E)|Codeforces|Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|10|
