# 139. Linear_Programming


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[01 Sequence](http://www.spoj.com/problems/SEQ1/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|2|[Integer Linear Programming](http://acm.sgu.ru/problem.php?contest=0&problem=248)|SGU|4|
