# 043. Non-Classical_Dynamic_Programming


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Unidirectional TSP](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=52)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[How do you add?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1884)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|3|[Wedding shopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2445)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|4|[MAXIMUM WOOD CUTTER](http://www.spoj.com/problems/MAXWOODS/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|5|[0110SS](http://www.spoj.com/problems/IWGBS/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|6|[Save Thy Toys](http://www.spoj.com/problems/DCEPC501/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|7|[Divisibility](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=977)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|8|[Philosophers Stone](http://www.spoj.com/problems/BYTESM2/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|9|[DIE HARD](http://www.spoj.com/problems/DIEHARD/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|10|[Homer Simpson](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1406)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|11|[Cutting Sticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=944)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|12|[Piggy-Bank](http://www.spoj.com/problems/PIGBANK/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|13|[Pilots](http://www.spoj.com/problems/MPILOT/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|14|[Easy Jug](http://www.spoj.com/problems/MAY99_3/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|15|[Jugs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=512)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|16|[Simple Minded Hashing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1853)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|17|[Game Show Math](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1341)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|18|[Squares](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2402)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|19|[Bar Codes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1662)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|20|[sqrt log sin](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2750)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|21|[Chest of Drawers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2415)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|22|[The Marriage Interview :-)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1387)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|23|[Flight Planner](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1278)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|24|[Spreadsheet](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=132)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|25|[Marks Distribution](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1851)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|26|[String Popping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3702)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|27|[Test the Rods](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1027)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|28|[Lowest Price in Town](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1921)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|29|[Determine it](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1461)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|30|[Bribe the Prisoners](http://www.spoj.com/problems/GCJ1C09C/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|31|[The Poor Giant](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1629)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|32|[A Grouping Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1967)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|33|[INVITATION FOR TECHOFES](http://www.spoj.com/problems/TECHOFES/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|34|[JUMPING DORA](http://www.spoj.com/problems/JUMPDORA/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|35|[GO FOR DIAMONDS](http://www.spoj.com/problems/GO4DIMON/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|36|[IPL - CRICKET TOURNAMENT](http://www.spoj.com/problems/IPL1/)|SPOJ|5|
