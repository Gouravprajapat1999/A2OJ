# 084. Sqrt_decomposition


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Horrible Queries](http://www.spoj.com/problems/HORRIBLE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[K-th Number](http://www.spoj.com/problems/MKTHNUM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Election Posters](http://www.spoj.com/problems/POSTERS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Interval Product](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4150)|Live Archive|2012|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|5|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Maximum Sum](http://www.spoj.com/problems/KGSS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[K-query](http://www.spoj.com/problems/KQUERY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[K-Query Online](http://www.spoj.com/problems/KQUERYO/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|9|[K-query II](http://www.spoj.com/problems/KQUERY2/)|SPOJ|||3|
