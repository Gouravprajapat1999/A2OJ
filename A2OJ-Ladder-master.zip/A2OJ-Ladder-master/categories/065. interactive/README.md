# 065. interactive


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Bear and Prime 100](http://codeforces.com/problemset/problem/679/A)|Codeforces|Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|2|[Guess the Array](http://codeforces.com/problemset/problem/727/C)|Codeforces|Technocup 2017 - Elimination Round 1 (Unofficially Open for Everyone, Rated for Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|3|[Interactive LowerBound](http://codeforces.com/problemset/problem/843/B)|Codeforces|AIM Tech Round 4 (Div. 1) & AIM Tech Round 4 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|4|[Pick Heroes](http://codeforces.com/problemset/problem/1056/C)|Codeforces|Mail.Ru Cup 2018 Round 3|5|
|<ul><li>- [ ] Done</li></ul>|5|[Mahmoud and Ehab and the binary string](http://codeforces.com/problemset/problem/862/D)|Codeforces|Codeforces Round #435 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|6|[Searching Rectangles](http://codeforces.com/problemset/problem/713/B)|Codeforces|Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|7|[Glad to see you!](http://codeforces.com/problemset/problem/809/B)|Codeforces|Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|8|[Subway Pursuit](http://codeforces.com/problemset/problem/1039/B)|Codeforces|Codeforces Round #507 (Div. 1, based on Olympiad of Metropolises) & Codeforces Round #507 (Div. 2, based on Olympiad of Metropolises)|6|
|<ul><li>- [ ] Done</li></ul>|9|[Vladik and Favorite Game](http://codeforces.com/problemset/problem/811/D)|Codeforces|Codeforces Round #416 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|10|[Divisors](http://codeforces.com/problemset/problem/1033/D)|Codeforces|Lyft Level 5 Challenge 2018 - Elimination Round|6|
|<ul><li>- [ ] Done</li></ul>|11|[Interactive Bulls and Cows (Easy)](http://codeforces.com/problemset/problem/753/B)|Codeforces|Testing Round #13|7|
|<ul><li>- [ ] Done</li></ul>|12|[Something with XOR Queries](http://codeforces.com/problemset/problem/870/D)|Codeforces|Technocup 2018 - Elimination Round 2|7|
|<ul><li>- [ ] Done</li></ul>|13|[The penguin's game](http://codeforces.com/problemset/problem/835/E)|Codeforces|Codeforces Round #427 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|14|[Lost Root](http://codeforces.com/problemset/problem/1061/F)|Codeforces|Codeforces Round #523 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|15|[Interactive Bulls and Cows (Hard)](http://codeforces.com/problemset/problem/753/C)|Codeforces|Testing Round #13|9|
