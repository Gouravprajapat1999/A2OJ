# 028. dsu


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces|Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Graph Connectivity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=400)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Network Connections](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=734)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|4|[Misha and Changing Handles](http://codeforces.com/problemset/problem/501/B)|Codeforces|Codeforces Round #285 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Learning Languages](http://codeforces.com/problemset/problem/277/A)|Codeforces|Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces|Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|7|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces|Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|8|[New Year Permutation](http://codeforces.com/problemset/problem/500/B)|Codeforces|Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|9|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces|Codeforces Round #254 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|10|[Knight Tournament](http://codeforces.com/problemset/problem/356/A)|Codeforces|Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|11|[The Suspects](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3638)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|12|[Timofey and a tree](http://codeforces.com/problemset/problem/763/A)|Codeforces|Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|13|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/505/B)|Codeforces|Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|14|[FRIEND CIRCLE](http://www.spoj.com/problems/FRNDCIRC/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|15|[Lost and survived](http://www.spoj.com/problems/LOSTNSURVIVED/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|16|[Anansi's Cobweb](http://acm.timus.ru/problem.aspx?space=1&num=1671)|Timus||2|
|<ul><li>- [ ] Done</li></ul>|17|[Strange Food Chain](http://www.spoj.com/problems/CHAIN/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|18|[War](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1099)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|19|[Forests](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1168)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|20|[Cthulhu](http://codeforces.com/problemset/problem/103/B)|Codeforces|Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|21|[New Reform](http://codeforces.com/problemset/problem/659/E)|Codeforces|Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|22|[Mike and Feet](http://codeforces.com/problemset/problem/547/B)|Codeforces|Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|23|[Queue](http://codeforces.com/problemset/problem/490/B)|Codeforces|Codeforces Round #279 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|24|[A + B Strikes Back](http://codeforces.com/problemset/problem/409/H)|Codeforces|April Fools Day Contest 2014|3|
|<ul><li>- [ ] Done</li></ul>|25|[Arpa's weak amphitheater and Mehrdad's valuable Hoses](http://codeforces.com/problemset/problem/741/B)|Codeforces|Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|26|[Social Network Community](http://www.spoj.com/problems/SOCNETC/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|27|[Dorm Water Supply](http://codeforces.com/problemset/problem/107/A)|Codeforces|Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|28|[Roads not only in Berland](http://codeforces.com/problemset/problem/25/D)|Codeforces|Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|29|[Lomsat gelral](http://codeforces.com/problemset/problem/600/E)|Codeforces|Educational Codeforces Round 2|4|
|<ul><li>- [ ] Done</li></ul>|30|[Design Tutorial: Inverse the Problem](http://codeforces.com/problemset/problem/472/D)|Codeforces|Codeforces Round #270|4|
|<ul><li>- [ ] Done</li></ul>|31|[Two Sets](http://codeforces.com/problemset/problem/468/B)|Codeforces|Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|32|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces|Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|33|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces|Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|34|[Vessels](http://codeforces.com/problemset/problem/371/D)|Codeforces|Codeforces Round #218 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|35|[Serial Time!](http://codeforces.com/problemset/problem/60/B)|Codeforces|Codeforces Beta Round #56|4|
|<ul><li>- [ ] Done</li></ul>|36|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces|Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|37|[Lucky Tree](http://codeforces.com/problemset/problem/109/C)|Codeforces|Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|38|[pSort](http://codeforces.com/problemset/problem/28/B)|Codeforces|Codeforces Beta Round #28 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|39|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces|Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|40|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces|Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|41|[Moodular Arithmetic](http://codeforces.com/problemset/problem/603/B)|Codeforces|Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|42|[Dungeons and Candies](http://codeforces.com/problemset/problem/436/C)|Codeforces|Zepto Code Rush 2014|5|
|<ul><li>- [ ] Done</li></ul>|43|[Dima and Bacteria](http://codeforces.com/problemset/problem/400/D)|Codeforces|Codeforces Round #234 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|44|[Connected Components](http://codeforces.com/problemset/problem/292/D)|Codeforces|Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|45|[Hierarchy](http://codeforces.com/problemset/problem/17/B)|Codeforces|Codeforces Beta Round #17|5|
|<ul><li>- [ ] Done</li></ul>|46|[Weird journey](http://codeforces.com/problemset/problem/788/B)|Codeforces|Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|47|[Mahmoud and a Dictionary](http://codeforces.com/problemset/problem/766/D)|Codeforces|Codeforces Round #396 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|48|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|Codeforces Round #141 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|49|[Party](http://codeforces.com/problemset/problem/177/C2)|Codeforces|ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|50|[Party](http://codeforces.com/problemset/problem/177/C1)|Codeforces|ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|51|[Holes](http://codeforces.com/problemset/problem/13/E)|Codeforces|Codeforces Beta Round #13|6|
|<ul><li>- [ ] Done</li></ul>|52|[Polycarp and Hay](http://codeforces.com/problemset/problem/659/F)|Codeforces|Codeforces Round #346 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|53|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces|Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|54|[Restructuring Company](http://codeforces.com/problemset/problem/566/D)|Codeforces|VK Cup 2015 - Finals, online mirror|6|
|<ul><li>- [ ] Done</li></ul>|55|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces|Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|56|[New Year Domino](http://codeforces.com/problemset/problem/500/E)|Codeforces|Good Bye 2014|6|
|<ul><li>- [ ] Done</li></ul>|57|[Information Graph](http://codeforces.com/problemset/problem/466/E)|Codeforces|Codeforces Round #266 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|58|[Ring Road 2](http://codeforces.com/problemset/problem/27/D)|Codeforces|Codeforces Beta Round #27 (Codeforces format, Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|59|[Counter Attack](http://codeforces.com/problemset/problem/190/E)|Codeforces|Codeforces Round #120 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|60|[Weak Memory](http://codeforces.com/problemset/problem/187/C)|Codeforces|Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|61|[Range Increments](http://codeforces.com/problemset/problem/174/C)|Codeforces|VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|7|
|<ul><li>- [ ] Done</li></ul>|62|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces|Codeforces Round #112 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|63|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces|Codeforces Round #111 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|64|[Lucky Country](http://codeforces.com/problemset/problem/95/E)|Codeforces|Codeforces Beta Round #77 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|65|[Ski Base](http://codeforces.com/problemset/problem/91/C)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|66|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces|Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|67|[Gift](http://codeforces.com/problemset/problem/76/A)|Codeforces|All-Ukrainian School Olympiad in Informatics|7|
|<ul><li>- [ ] Done</li></ul>|68|[Chessboard Billiard](http://codeforces.com/problemset/problem/74/C)|Codeforces|Codeforces Beta Round #68|7|
|<ul><li>- [ ] Done</li></ul>|69|[Fairy](http://codeforces.com/problemset/problem/19/E)|Codeforces|Codeforces Beta Round #19|7|
|<ul><li>- [ ] Done</li></ul>|70|[Bear and Forgotten Tree 2](http://codeforces.com/problemset/problem/653/E)|Codeforces|IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|71|[Pursuit For Artifacts](http://codeforces.com/problemset/problem/652/E)|Codeforces|Educational Codeforces Round 10|7|
|<ul><li>- [ ] Done</li></ul>|72|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces|Codeforces Round #333 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|73|[Valera and Swaps](http://codeforces.com/problemset/problem/441/D)|Codeforces|Codeforces Round #252 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|74|[Nanami's Digital Board](http://codeforces.com/problemset/problem/433/D)|Codeforces|Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|75|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces|Codeforces Round #214 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|76|[Fools and Foolproof Roads](http://codeforces.com/problemset/problem/362/D)|Codeforces|Codeforces Round #212 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|77|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces|Codeforces Round #158 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|78|[Petya and Spiders](http://codeforces.com/problemset/problem/111/C)|Codeforces|Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|79|[Bear and Square Grid](http://codeforces.com/problemset/problem/679/C)|Codeforces|Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|80|[Envy](http://codeforces.com/problemset/problem/891/C)|Codeforces|Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|81|[Peterson Polyglot](http://codeforces.com/problemset/problem/778/C)|Codeforces|Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|82|[Digit Tree](http://codeforces.com/problemset/problem/715/C)|Codeforces|Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|83|[Mad Joe](http://codeforces.com/problemset/problem/250/E)|Codeforces|CROC-MBTU 2012, Final Round (Online version, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|84|[Trails and Glades](http://codeforces.com/problemset/problem/209/C)|Codeforces|VK Cup 2012 Finals, Practice Session|8|
|<ul><li>- [ ] Done</li></ul>|85|[Opening Portals](http://codeforces.com/problemset/problem/196/E)|Codeforces|Codeforces Round #124 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|86|[Building Forest](http://codeforces.com/problemset/problem/195/E)|Codeforces|Codeforces Round #123 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|87|[Clearing Up](http://codeforces.com/problemset/problem/141/E)|Codeforces|Codeforces Round #101 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|88|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces|Codeforces Beta Round #73 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|89|[Guard Towers](http://codeforces.com/problemset/problem/85/E)|Codeforces|Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|90|[Interestring graph and Apples](http://codeforces.com/problemset/problem/9/E)|Codeforces|Codeforces Beta Round #9 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|91|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces|Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|92|[Three strings](http://codeforces.com/problemset/problem/452/E)|Codeforces|MemSQL Start[c]UP 2.0 - Round 1|8|
|<ul><li>- [ ] Done</li></ul>|93|[DZY Loves Planting](http://codeforces.com/problemset/problem/444/E)|Codeforces|Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|94|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces|Codeforces Round #186 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|95|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces|Codeforces Round #360 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|96|[Vladik and Entertaining Flags](http://codeforces.com/problemset/problem/811/E)|Codeforces|Codeforces Round #416 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|97|[Alien DNA](http://codeforces.com/problemset/problem/217/E)|Codeforces|Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|98|[Cutting a Fence](http://codeforces.com/problemset/problem/212/D)|Codeforces|VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|99|[Savior](http://codeforces.com/problemset/problem/60/D)|Codeforces|Codeforces Beta Round #56|9|
|<ul><li>- [ ] Done</li></ul>|100|[Hercule Poirot Problem](http://codeforces.com/problemset/problem/46/F)|Codeforces|School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|101|[Two Paths](http://codeforces.com/problemset/problem/36/E)|Codeforces|Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|102|[Clockwork Bomb](http://codeforces.com/problemset/problem/650/E)|Codeforces|Codeforces Round #345 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|103|[Pastoral Oddities](http://codeforces.com/problemset/problem/603/E)|Codeforces|Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|104|[Appleman and Complicated Task](http://codeforces.com/problemset/problem/461/D)|Codeforces|Codeforces Round #263 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|105|[Dima and Kicks](http://codeforces.com/problemset/problem/358/E)|Codeforces|Codeforces Round #208 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|106|[The Red Button](http://codeforces.com/problemset/problem/325/E)|Codeforces|MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|107|[Reclamation](http://codeforces.com/problemset/problem/325/D)|Codeforces|MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|108|[Pairs](http://codeforces.com/problemset/problem/81/E)|Codeforces|Yandex.Algorithm Open 2011 Qualification 1|9|
|<ul><li>- [ ] Done</li></ul>|109|[Timofey and our friends animals](http://codeforces.com/problemset/problem/763/E)|Codeforces|Codeforces Round #395 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|110|[Welcome home, Chtholly](http://codeforces.com/problemset/problem/896/E)|Codeforces|Codeforces Round #449 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|111|[Entertaining Geodetics](http://codeforces.com/problemset/problem/105/D)|Codeforces|Codeforces Beta Round #81|10|
|<ul><li>- [ ] Done</li></ul>|112|[Leaders](http://codeforces.com/problemset/problem/97/E)|Codeforces|Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|113|[Campus](http://codeforces.com/problemset/problem/571/D)|Codeforces|Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|114|[MUH and Lots and Lots of Segments](http://codeforces.com/problemset/problem/471/E)|Codeforces|Codeforces Round #269 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|115|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces|Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|116|[School](http://codeforces.com/problemset/problem/45/B)|Codeforces|School Team Contest #3 (Winter Computer School 2010/11)|10|
