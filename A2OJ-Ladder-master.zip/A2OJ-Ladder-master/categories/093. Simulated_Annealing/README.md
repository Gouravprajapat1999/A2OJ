# 093. Simulated_Annealing


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[A Star not a Tree?](http://poj.org/problem?id=2420)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|2|[Run Away](http://poj.org/problem?id=1379)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|3|[Super Star](http://poj.org/problem?id=2069)|PKU|||4|
|<ul><li>- [ ] Done</li></ul>|4|[Studying For Exams](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=6048)|Live Archive|2016|North America - Rocky Mountain|6|
|<ul><li>- [ ] Done</li></ul>|5|[Hongcow Buys a Deck of Cards](http://codeforces.com/problemset/problem/744/C)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|6|[Commentator problem](http://codeforces.com/problemset/problem/2/C)|Codeforces||Codeforces Beta Round #2|7|
|<ul><li>- [ ] Done</li></ul>|7|[Corridor](http://codeforces.com/problemset/problem/82/E)|Codeforces||Yandex.Algorithm 2011 Qualification 2|9|
