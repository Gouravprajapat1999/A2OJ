# 106. Optimization


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[PATHS](http://www.spoj.com/problems/WAYS/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|2|[AVERYEASYPROBLEM](http://www.spoj.com/problems/PROBLEM6/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|3|[Number of digits](http://www.spoj.com/problems/DIGITCNT/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|4|[BF_MODULUS](http://www.spoj.com/problems/MODULUS2/)|SPOJ|9|
|<ul><li>- [ ] Done</li></ul>|5|[JAVA COUNTING](http://www.spoj.com/problems/QWERTY03/)|SPOJ|9|
