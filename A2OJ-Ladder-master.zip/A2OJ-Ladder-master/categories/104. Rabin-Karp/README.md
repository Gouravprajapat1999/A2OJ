# 104. Rabin-Karp


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Extend to Palindrome](http://www.spoj.com/problems/EPALIN/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Palindromes](http://www.spoj.com/problems/PLD/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[Ada and Spring Cleaning](http://www.spoj.com/problems/ADACLEAN/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|4|[Hacking](http://www.spoj.com/problems/HACKING/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|5|[Easy Longest Common Substring](http://www.spoj.com/problems/ELCS/)|SPOJ|4|
