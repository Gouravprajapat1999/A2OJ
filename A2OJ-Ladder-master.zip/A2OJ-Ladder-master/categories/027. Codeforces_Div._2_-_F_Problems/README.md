# 027. Codeforces_Div._2_-_F_Problems


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Ant colony](http://codeforces.com/problemset/problem/474/F)|Codeforces|Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|2|[Video Cards](http://codeforces.com/problemset/problem/731/F)|Codeforces|Codeforces Round #376 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|3|[SUM and REPLACE](http://codeforces.com/problemset/problem/920/F)|Codeforces|Educational Codeforces Round 37 (Rated for Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|4|[Mathematical Analysis Rocks!](http://codeforces.com/problemset/problem/180/F)|Codeforces|Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|5|[Fence](http://codeforces.com/problemset/problem/234/F)|Codeforces|Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|6|[Special Matrices](http://codeforces.com/problemset/problem/489/F)|Codeforces|Codeforces Round #277.5 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|7|[st-Spanning Tree](http://codeforces.com/problemset/problem/723/F)|Codeforces|Codeforces Round #375 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|8|[Polycarp and Hay](http://codeforces.com/problemset/problem/659/F)|Codeforces|Codeforces Round #346 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|9|[New Year Tree](http://codeforces.com/problemset/problem/379/F)|Codeforces|Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|10|[A Heap of Heaps](http://codeforces.com/problemset/problem/538/F)|Codeforces|Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|11|[Group Projects](http://codeforces.com/problemset/problem/626/F)|Codeforces|8VC Venture Cup 2016 - Elimination Round|6|
|<ul><li>- [ ] Done</li></ul>|12|[Treeland Tour](http://codeforces.com/problemset/problem/490/F)|Codeforces|Codeforces Round #279 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|13|[Lizard Era: Beginning](http://codeforces.com/problemset/problem/585/D)|Codeforces|Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|14|[Drivers Dissatisfaction](http://codeforces.com/problemset/problem/733/F)|Codeforces|Codeforces Round #378 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|15|[Tourist Reform](http://codeforces.com/problemset/problem/732/F)|Codeforces|Codeforces Round #377 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|16|[Break Up](http://codeforces.com/problemset/problem/700/C)|Codeforces|Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|17|[Restore a Number](http://codeforces.com/problemset/problem/670/F)|Codeforces|Codeforces Round #350 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|18|[Bacterial Melee](http://codeforces.com/problemset/problem/756/D)|Codeforces|8VC Venture Cup 2017 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|19|[Barrels and boxes](http://codeforces.com/problemset/problem/768/F)|Codeforces|Divide by Zero 2017 and Codeforces Round #399 (Div. 1 + Div. 2, combined)|7|
|<ul><li>- [ ] Done</li></ul>|20|[Peterson Polyglot](http://codeforces.com/problemset/problem/778/C)|Codeforces|Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|21|[Axel and Marston in Bitland](http://codeforces.com/problemset/problem/780/F)|Codeforces|?????????? 2017 - ????? (?????? ??? ??????-??????????)|7|
|<ul><li>- [ ] Done</li></ul>|22|[Expected diameter of a tree](http://codeforces.com/problemset/problem/804/D)|Codeforces|Codeforces Round #411 (Div. 1) & Codeforces Round #411 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|23|[Bamboo Partition](http://codeforces.com/problemset/problem/830/C)|Codeforces|Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|7|
|<ul><li>- [ ] Done</li></ul>|24|[Couple Cover](http://codeforces.com/problemset/problem/691/F)|Codeforces|Educational Codeforces Round 14|7|
|<ul><li>- [ ] Done</li></ul>|25|[PolandBall and Gifts](http://codeforces.com/problemset/problem/755/F)|Codeforces|8VC Venture Cup 2017 - Elimination Round|7|
|<ul><li>- [ ] Done</li></ul>|26|[Coprime Subsequences](http://codeforces.com/problemset/problem/803/F)|Codeforces|Educational Codeforces Round 20|7|
|<ul><li>- [ ] Done</li></ul>|27|[MEX Queries](http://codeforces.com/problemset/problem/817/F)|Codeforces|Educational Codeforces Round 23|7|
|<ul><li>- [ ] Done</li></ul>|28|[Random Query](http://codeforces.com/problemset/problem/846/F)|Codeforces|Educational Codeforces Round 28|7|
|<ul><li>- [ ] Done</li></ul>|29|[Letters Removing](http://codeforces.com/problemset/problem/899/F)|Codeforces|Codeforces Round #452 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|30|[New Year and Rainbow Roads](http://codeforces.com/problemset/problem/908/F)|Codeforces|Good Bye 2017|7|
|<ul><li>- [ ] Done</li></ul>|31|[Present to Mom](http://codeforces.com/problemset/problem/131/F)|Codeforces|Codeforces Beta Round #95 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|32|[Progress Monitoring](http://codeforces.com/problemset/problem/509/F)|Codeforces|Codeforces Round #289 (Div. 2, ACM ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|33|[Zublicanes and Mumocrates](http://codeforces.com/problemset/problem/581/F)|Codeforces|Codeforces Round #322 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|34|[LCS Again](http://codeforces.com/problemset/problem/578/D)|Codeforces|Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|8|
|<ul><li>- [ ] Done</li></ul>|35|[Mausoleum](http://codeforces.com/problemset/problem/567/F)|Codeforces|Codeforces Round #Pi (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|36|[Legen...](http://codeforces.com/problemset/problem/696/D)|Codeforces|Codeforces Round #362 (Div. 1) & Codeforces Round #362 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|37|[Financiers Game](http://codeforces.com/problemset/problem/729/F)|Codeforces|Technocup 2017 - Elimination Round 2|8|
|<ul><li>- [ ] Done</li></ul>|38|[Music in Car](http://codeforces.com/problemset/problem/746/F)|Codeforces|Codeforces Round #386 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|39|[Santa Clauses and a Soccer Championship](http://codeforces.com/problemset/problem/748/F)|Codeforces|Technocup 2017 - Elimination Round 3|8|
|<ul><li>- [ ] Done</li></ul>|40|[Team Rocket Rises Again](http://codeforces.com/problemset/problem/757/F)|Codeforces|Codecraft-17 and Codeforces Round #391 (Div. 1 + Div. 2, combined)|8|
|<ul><li>- [ ] Done</li></ul>|41|[Geometrical Progression](http://codeforces.com/problemset/problem/758/F)|Codeforces|Codeforces Round #392 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|42|[Souvenirs](http://codeforces.com/problemset/problem/765/F)|Codeforces|Codeforces Round #397 by Kaspersky Lab and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|43|[Leha and security system](http://codeforces.com/problemset/problem/794/F)|Codeforces|Tinkoff Challenge - Final Round (Codeforces Round #414, rated, Div. 1 + Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|44|[Best Edge Weight](http://codeforces.com/problemset/problem/827/D)|Codeforces|Codeforces Round #423 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #423 (Div. 2, rated, based on VK Cup Finals)|8|
|<ul><li>- [ ] Done</li></ul>|45|[Cities Excursions](http://codeforces.com/problemset/problem/864/F)|Codeforces|Codeforces Round #436 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|46|[Restoring the Expression](http://codeforces.com/problemset/problem/898/F)|Codeforces|Codeforces Round #451 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|47|[New Year and Cleaning](http://codeforces.com/problemset/problem/611/F)|Codeforces|Good Bye 2015|8|
|<ul><li>- [ ] Done</li></ul>|48|[Double Knapsack](http://codeforces.com/problemset/problem/618/F)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|49|[The Sum of the k-th Powers](http://codeforces.com/problemset/problem/622/F)|Codeforces|Educational Codeforces Round 7|8|
|<ul><li>- [ ] Done</li></ul>|50|[The Chocolate Spree](http://codeforces.com/problemset/problem/633/F)|Codeforces|Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|51|[Magic Matrix](http://codeforces.com/problemset/problem/632/F)|Codeforces|Educational Codeforces Round 9|8|
|<ul><li>- [ ] Done</li></ul>|52|[Cowslip Collections](http://codeforces.com/problemset/problem/645/F)|Codeforces|CROC 2016 - Elimination Round|8|
|<ul><li>- [ ] Done</li></ul>|53|[Paper task](http://codeforces.com/problemset/problem/653/F)|Codeforces|IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|54|[Bear and Bowling 4](http://codeforces.com/problemset/problem/660/F)|Codeforces|Educational Codeforces Round 11|8|
|<ul><li>- [ ] Done</li></ul>|55|[String Set Queries](http://codeforces.com/problemset/problem/710/F)|Codeforces|Educational Codeforces Round 16|8|
|<ul><li>- [ ] Done</li></ul>|56|[Polycarp's problems](http://codeforces.com/problemset/problem/727/F)|Codeforces|Technocup 2017 - Elimination Round 1 (Unofficially Open for Everyone, Rated for Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|57|[Card Game](http://codeforces.com/problemset/problem/808/F)|Codeforces|Educational Codeforces Round 21|8|
|<ul><li>- [ ] Done</li></ul>|58|[Level Generation](http://codeforces.com/problemset/problem/818/F)|Codeforces|Educational Codeforces Round 24|8|
|<ul><li>- [ ] Done</li></ul>|59|[String Compression](http://codeforces.com/problemset/problem/825/F)|Codeforces|Educational Codeforces Round 25|8|
|<ul><li>- [ ] Done</li></ul>|60|[Prefix Sums](http://codeforces.com/problemset/problem/837/F)|Codeforces|Educational Codeforces Round 26|8|
|<ul><li>- [ ] Done</li></ul>|61|[Wizard's Tour](http://codeforces.com/problemset/problem/858/F)|Codeforces|?????????? 2018 - ?????????? ????? 1|8|
|<ul><li>- [ ] Done</li></ul>|62|[Almost Permutation](http://codeforces.com/problemset/problem/863/F)|Codeforces|Educational Codeforces Round 29|8|
|<ul><li>- [ ] Done</li></ul>|63|[Yet Another Minimization Problem](http://codeforces.com/problemset/problem/868/F)|Codeforces|Codeforces Round #438 by Sberbank and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|64|[Forbidden Indices](http://codeforces.com/problemset/problem/873/F)|Codeforces|Educational Codeforces Round 30|8|
|<ul><li>- [ ] Done</li></ul>|65|[Anti-Palindromize](http://codeforces.com/problemset/problem/884/F)|Codeforces|Educational Codeforces Round 31|8|
|<ul><li>- [ ] Done</li></ul>|66|[Subtree Minimum Query](http://codeforces.com/problemset/problem/893/F)|Codeforces|Educational Codeforces Round 33 (Rated for Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|67|[Tree Destruction](http://codeforces.com/problemset/problem/911/F)|Codeforces|Educational Codeforces Round 35 (Rated for Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|68|[Divisibility](http://codeforces.com/problemset/problem/922/F)|Codeforces|Codeforces Round #461 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|69|[Escape Through Leaf](http://codeforces.com/problemset/problem/932/F)|Codeforces|ICM Technex 2018 and Codeforces Round #463 (Div. 1 + Div. 2, combined)|8|
|<ul><li>- [ ] Done</li></ul>|70|[Machine Learning](http://codeforces.com/problemset/problem/940/F)|Codeforces|Codeforces Round #466 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|71|[Smart Boy](http://codeforces.com/problemset/problem/38/F)|Codeforces|School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|72|[New Year Snowflake](http://codeforces.com/problemset/problem/140/F)|Codeforces|Codeforces Round #100|9|
|<ul><li>- [ ] Done</li></ul>|73|[Simplified Nonogram](http://codeforces.com/problemset/problem/534/F)|Codeforces|Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|74|[Pasha and Pipe](http://codeforces.com/problemset/problem/518/F)|Codeforces|Codeforces Round #293 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|75|[Limak and Shooting Points](http://codeforces.com/problemset/problem/698/D)|Codeforces|Codeforces Round #363 (Div. 1) & Codeforces Round #363 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|76|[Igor and Interesting Numbers](http://codeforces.com/problemset/problem/747/F)|Codeforces|Codeforces Round #387 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|77|[Dasha and Photos](http://codeforces.com/problemset/problem/761/F)|Codeforces|Codeforces Round #394 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|78|[Sherlock's bet to Moriarty](http://codeforces.com/problemset/problem/776/F)|Codeforces|ICM Technex 2017 and Codeforces Round #400 (Div. 1 + Div. 2, combined)|9|
|<ul><li>- [ ] Done</li></ul>|79|[Perishable Roads](http://codeforces.com/problemset/problem/773/D)|Codeforces|VK Cup 2017 - Round 3|9|
|<ul><li>- [ ] Done</li></ul>|80|[Roads in the Kingdom](http://codeforces.com/problemset/problem/835/F)|Codeforces|Codeforces Round #427 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|81|[Madness](http://codeforces.com/problemset/problem/822/F)|Codeforces|Codeforces Round #422 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|82|[Design Tutorial: Change the Goal](http://codeforces.com/problemset/problem/472/F)|Codeforces|Codeforces Round #270|9|
|<ul><li>- [ ] Done</li></ul>|83|[New Year Shopping](http://codeforces.com/problemset/problem/500/F)|Codeforces|Good Bye 2014|9|
|<ul><li>- [ ] Done</li></ul>|84|[Edge coloring of bipartite graph](http://codeforces.com/problemset/problem/600/F)|Codeforces|Educational Codeforces Round 2|9|
|<ul><li>- [ ] Done</li></ul>|85|[Expensive Strings](http://codeforces.com/problemset/problem/616/F)|Codeforces|Educational Codeforces Round 5|9|
|<ul><li>- [ ] Done</li></ul>|86|[Xors on Segments](http://codeforces.com/problemset/problem/620/F)|Codeforces|Educational Codeforces Round 6|9|
|<ul><li>- [ ] Done</li></ul>|87|[Bear and Fair Set](http://codeforces.com/problemset/problem/628/F)|Codeforces|Educational Codeforces Round 8|9|
|<ul><li>- [ ] Done</li></ul>|88|[Four Divisors](http://codeforces.com/problemset/problem/665/F)|Codeforces|Educational Codeforces Round 12|9|
|<ul><li>- [ ] Done</li></ul>|89|[T-Shirts](http://codeforces.com/problemset/problem/702/F)|Codeforces|Educational Codeforces Round 15|9|
|<ul><li>- [ ] Done</li></ul>|90|[Cyclic Cipher](http://codeforces.com/problemset/problem/722/F)|Codeforces|Intel Code Challenge Elimination Round (Div. 1 + Div. 2, combined)|9|
|<ul><li>- [ ] Done</li></ul>|91|[Family Photos](http://codeforces.com/problemset/problem/725/F)|Codeforces|Canada Cup 2016|9|
|<ul><li>- [ ] Done</li></ul>|92|[New Year and Finding Roots](http://codeforces.com/problemset/problem/750/F)|Codeforces|Good Bye 2016|9|
|<ul><li>- [ ] Done</li></ul>|93|[Mice and Holes](http://codeforces.com/problemset/problem/797/F)|Codeforces|Educational Codeforces Round 19|9|
|<ul><li>- [ ] Done</li></ul>|94|[Bipartite Checking](http://codeforces.com/problemset/problem/813/F)|Codeforces|Educational Codeforces Round 22|9|
|<ul><li>- [ ] Done</li></ul>|95|[Paths](http://codeforces.com/problemset/problem/870/F)|Codeforces|Technocup 2018 - Elimination Round 2|9|
|<ul><li>- [ ] Done</li></ul>|96|[Connecting Vertices](http://codeforces.com/problemset/problem/888/F)|Codeforces|Educational Codeforces Round 32|9|
|<ul><li>- [ ] Done</li></ul>|97|[Clear The Matrix](http://codeforces.com/problemset/problem/903/F)|Codeforces|Educational Codeforces Round 34 (Rated for Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|98|[AND-permutations](http://codeforces.com/problemset/problem/909/F)|Codeforces|Codeforces Round #455 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|99|[Strongly Connected Tournament](http://codeforces.com/problemset/problem/913/F)|Codeforces|Hello 2018|9|
|<ul><li>- [ ] Done</li></ul>|100|[Substrings in a String](http://codeforces.com/problemset/problem/914/F)|Codeforces|Codecraft-18 and Codeforces Round #458 (Div. 1 + Div. 2, combined)|9|
|<ul><li>- [ ] Done</li></ul>|101|[Erasing Substrings](http://codeforces.com/problemset/problem/938/F)|Codeforces|Educational Codeforces Round 38 (Rated for Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|102|[Cutlet](http://codeforces.com/problemset/problem/939/F)|Codeforces|Codeforces Round #464 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|103|[Fafa and Array](http://codeforces.com/problemset/problem/935/F)|Codeforces|Codeforces Round #465 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|104|[Snow sellers](http://codeforces.com/problemset/problem/48/F)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|105|[Gnomes of Might and Magic](http://codeforces.com/problemset/problem/175/F)|Codeforces|Codeforces Round #115|10|
|<ul><li>- [ ] Done</li></ul>|106|[Duff in Mafia](http://codeforces.com/problemset/problem/587/D)|Codeforces|Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|107|[Bearish Fanpages](http://codeforces.com/problemset/problem/643/D)|Codeforces|VK Cup 2016 - Round 3|10|
|<ul><li>- [ ] Done</li></ul>|108|[Sequence Recovery](http://codeforces.com/problemset/problem/796/F)|Codeforces|Codeforces Round #408 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|109|[Beautiful fountains rows](http://codeforces.com/problemset/problem/799/F)|Codeforces|Playrix Codescapes Cup (Codeforces Round #413, rated, Div. 1 + Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|110|[Cut Length](http://codeforces.com/problemset/problem/598/F)|Codeforces|Educational Codeforces Round 1|10|
|<ul><li>- [ ] Done</li></ul>|111|[Simba on the Circle](http://codeforces.com/problemset/problem/612/F)|Codeforces|Educational Codeforces Round 4|10|
|<ul><li>- [ ] Done</li></ul>|112|[Ants on a Circle](http://codeforces.com/problemset/problem/652/F)|Codeforces|Educational Codeforces Round 10|10|
|<ul><li>- [ ] Done</li></ul>|113|[Tree nesting](http://codeforces.com/problemset/problem/762/F)|Codeforces|Educational Codeforces Round 17|10|
|<ul><li>- [ ] Done</li></ul>|114|[Mages and Monsters](http://codeforces.com/problemset/problem/792/F)|Codeforces|Educational Codeforces Round 18|10|
|<ul><li>- [ ] Done</li></ul>|115|[Guards In The Storehouse](http://codeforces.com/problemset/problem/845/F)|Codeforces|Educational Codeforces Round 27|10|
|<ul><li>- [ ] Done</li></ul>|116|[Mahmoud and Ehab and the final stage](http://codeforces.com/problemset/problem/862/F)|Codeforces|Codeforces Round #435 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|117|[Nagini](http://codeforces.com/problemset/problem/855/F)|Codeforces|Manthan, Codefest 17|10|
|<ul><li>- [ ] Done</li></ul>|118|[Row of Models](http://codeforces.com/problemset/problem/887/F)|Codeforces|Codeforces Round #444 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|119|[A Game With Numbers](http://codeforces.com/problemset/problem/919/F)|Codeforces|Codeforces Round #460 (Div. 2)|10|
