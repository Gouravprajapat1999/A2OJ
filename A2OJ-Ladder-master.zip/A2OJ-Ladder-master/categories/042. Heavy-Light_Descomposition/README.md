# 042. Heavy-Light_Descomposition


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Query on a tree](http://www.spoj.com/problems/QTREE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Query on a tree II](http://www.spoj.com/problems/QTREE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Count on a tree](http://www.spoj.com/problems/COT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Query on a tree again!](http://www.spoj.com/problems/QTREE3/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[OTOCI](http://www.spoj.com/problems/OTOCI/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|6|[Can you answer these queries VII](http://www.spoj.com/problems/GSS7/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|7|[Query on a tree IV](http://www.spoj.com/problems/QTREE4/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|8|[Query on a tree V](http://www.spoj.com/problems/QTREE5/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|9|[Count on a tree II](http://www.spoj.com/problems/COT2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|10|[Tree](http://www.codechef.com/problems/RRTREE)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|11|[Gao on a tree](http://www.spoj.com/problems/GOT/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|12|[Prime Distance On Tree](http://www.codechef.com/problems/PRIMEDST)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|13|[Coloring Trees](http://www.spoj.com/problems/BTCODE_G/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|14|[Query on a tree VI](http://www.spoj.com/problems/QTREE6/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|15|[Dynamic GCD](http://www.codechef.com/problems/DGCD)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|16|[Grass Planting](http://www.spoj.com/problems/GRASSPLA/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|17|[Tree Again](http://www.codechef.com/problems/RRTREE2)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|18|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|19|[Query on a tree VI](http://www.codechef.com/problems/QTREE6)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|20|[Caves and Tunnels](http://acm.timus.ru/problem.aspx?space=1&num=1553)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|21|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|22|[Idols and Fans](http://www.codechef.com/problems/IDOLS)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|23|[Combat on a tree](http://www.spoj.com/problems/COT3/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|24|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|25|[Observing the Tree](http://www.codechef.com/problems/QUERY)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|26|[Imperial roads](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=6218)|Live Archive|2017|Latin America|5|
|<ul><li>- [ ] Done</li></ul>|27|[Fibonacci Numbers on Tree](http://www.codechef.com/problems/FIBTREE)|CodeChef|||6|
|<ul><li>- [ ] Done</li></ul>|28|[Black and White Tree](http://www.codechef.com/problems/GERALD2)|CodeChef|||6|
|<ul><li>- [ ] Done</li></ul>|29|[Case of Computer Network](http://codeforces.com/problemset/problem/555/E)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|30|[Push the Flow!](http://www.codechef.com/problems/PUSHFLOW)|CodeChef|||7|
|<ul><li>- [ ] Done</li></ul>|31|[Happy Tree Party](http://codeforces.com/problemset/problem/593/D)|Codeforces||Codeforces Round #329 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|32|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces||Codeforces Round #112 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|33|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|34|[Graph Game](http://codeforces.com/problemset/problem/235/D)|Codeforces||Codeforces Round #146 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|35|[...Wait for it...](http://codeforces.com/problemset/problem/696/E)|Codeforces||Codeforces Round #362 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|36|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces||Codeforces Beta Round #88|10|
