# 041. bfs


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Water among Cubes](http://www.spoj.com/problems/WATER/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Spreading The News](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=865)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Isenbaev's Number](http://acm.timus.ru/problem.aspx?space=1&num=1837)|Timus||1|
|<ul><li>- [ ] Done</li></ul>|4|[All Roads Lead Where?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=950)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|5|[The Cats and the Mouse](http://www.spoj.com/problems/CATM/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|6|[A Node Too Far](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=272)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|7|[Playing with Wheels](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1008)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|8|[Bombs! NO they are Mines!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1594)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|9|[Bicoloring](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=945)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|10|[Cleaning Robot](http://www.spoj.com/problems/CLEANRBT/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|11|[Knight Moves](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=380)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|12|[Tic-Tac-Toe ( II )](http://www.spoj.com/problems/TOE2/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|13|[Laser Phones](http://www.spoj.com/problems/MLASERP/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|14|[Dungeon Master](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=473)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|15|[Bitmap](http://www.spoj.com/problems/BITMAP/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|16|[Prime Path](http://www.spoj.com/problems/PPATH/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|17|[Risk](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=508)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|18|[Ones and zeros](http://www.spoj.com/problems/ONEZERO/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|19|[We Ship Cheap](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=703)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|20|[Jugs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=512)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|21|[Changing Maze](http://www.spoj.com/problems/CHMAZE/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|22|[Shipping Routes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=319)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|23|[The Party, Part I](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1900)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|24|[Crazy King](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2327)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|25|[The Monocycle](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=988)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|26|[Fire!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2671)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|27|[The Net](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=568)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|28|[The New Villa](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=257)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|29|[THE WEIRD STAIRCASE](http://www.spoj.com/problems/STAR3CAS/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|30|[9 Puzzle](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2508)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|31|[Enchanted Forest](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1918)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|32|[Eternal Truths](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=869)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|33|[Valid BFS?](http://codeforces.com/problemset/problem/1037/D)|Codeforces|Manthan, Codefest 18 (rated, Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|34|[Switch The Lights](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3125)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|35|[GRAVITY](http://www.spoj.com/problems/GRAVITY/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|36|[Repeated Substitution with Sed](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3692)|UVA||6|
|<ul><li>- [ ] Done</li></ul>|37|[TwoKings](http://community.topcoder.com/stat?c=problem_statement&pm=4582)|TopCoder|SRM 243 - Div1 hard] (7218)|9|
