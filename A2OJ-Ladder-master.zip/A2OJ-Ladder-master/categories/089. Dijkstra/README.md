# 089. Dijkstra


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Dijkstra?](http://codeforces.com/problemset/problem/20/C)|Codeforces||Codeforces Alpha Round #20 (Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Labyrinth](http://acm.tju.edu.cn/toj/showp1056.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|3|[The Postal Worker Rings Once](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=53)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Distinct Subsequences](http://www.spoj.com/problems/DSUBSEQ/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Tobo or not Tobo](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2362)|Live Archive|2008|Africa/Middle East - Arab and North Africa|2|
|<ul><li>- [ ] Done</li></ul>|6|[XYZZY](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1498)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|7|[Pick up sticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2733)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|8|[Full Tank?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2352)|UVA|||3|
