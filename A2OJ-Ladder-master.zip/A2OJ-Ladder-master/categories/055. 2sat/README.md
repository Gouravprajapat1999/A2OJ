# 055. 2sat


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[A Bug&#8217;s Life](http://www.spoj.com/problems/BUGLIFE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Piece it together](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3914)|Live Archive|2011|Europe - Northwestern|2|
|<ul><li>- [ ] Done</li></ul>|3|[Idol](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4285)|Live Archive|2012|Europe - Northwestern|3|
|<ul><li>- [ ] Done</li></ul>|4|[Manhattan](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1260)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|5|[Wedding](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2269)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|6|[Two Sets](http://codeforces.com/problemset/problem/468/B)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|7|[TORNJEVI](http://www.spoj.com/problems/TORNJEVI/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|8|[The Door Problem](http://codeforces.com/problemset/problem/776/D)|Codeforces||ICM Technex 2017 and Codeforces Round #400 (Div. 1 + Div. 2, combined)|4|
|<ul><li>- [ ] Done</li></ul>|9|[Cardápio da Sra Montagny](http://br.spoj.com/problems/CARDAPIO/)|SPOJ Brazil|||5|
|<ul><li>- [ ] Done</li></ul>|10|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|11|[The Ministers' Major Mess](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3527)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|12|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces||Codeforces Round #141 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|13|[Ring Road 2](http://codeforces.com/problemset/problem/27/D)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|14|[Football and Lie](http://acm.timus.ru/problem.aspx?space=1&num=1485)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|15|[Rectangles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3081)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|16|[Game with Cards](http://acm.timus.ru/problem.aspx?space=1&num=1382)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|17|[New Language](http://codeforces.com/problemset/problem/568/C)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|18|[Palindromic DNA](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3425)|UVA|||9|
|<ul><li>- [ ] Done</li></ul>|19|[Duff in Mafia](http://codeforces.com/problemset/problem/587/D)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|20|[Summer Dichotomy](http://codeforces.com/problemset/problem/538/H)|Codeforces||Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|21|[Supplying the Suppliers](http://www.spoj.com/problems/SUPSUP/)|SPOJ|||10|
