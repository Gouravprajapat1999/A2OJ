# 128. linked_list


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Burn the Linked Camp](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=2770)|ZOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces|Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|3|[SBE201 Linked List](http://www.spoj.com/problems/SBE201P2/)|SPOJ||4|
