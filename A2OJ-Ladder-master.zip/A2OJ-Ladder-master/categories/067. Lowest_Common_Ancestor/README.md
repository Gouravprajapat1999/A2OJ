# 067. Lowest_Common_Ancestor


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lowest Common Ancestor](http://www.spoj.com/problems/LCA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Query on a tree II](http://www.spoj.com/problems/QTREE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Query on a tree](http://www.spoj.com/problems/QTREE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Ancestor](http://acm.tju.edu.cn/toj/showp2241.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|5|[Closest Common Ancestors](http://acm.tju.edu.cn/toj/showp1051.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|6|[Joining Couples](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4151)|Live Archive|2012|Latin America|2|
|<ul><li>- [ ] Done</li></ul>|7|[Distance Query](http://www.spoj.com/problems/DISQUERY/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|8|[Flea circus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1879)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|9|[Ants Colony](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3390)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|10|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|11|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|12|[Children Trips](http://www.codechef.com/problems/TRIPS)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|13|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|14|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces||Codeforces Round #112 (Div. 2)|7|
