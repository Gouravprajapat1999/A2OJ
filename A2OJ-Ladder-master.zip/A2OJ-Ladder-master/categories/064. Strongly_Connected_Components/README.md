# 064. Strongly_Connected_Components


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Calling Circles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=183)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Capital City](http://www.spoj.com/problems/CAPCITY/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Submerging Islands](http://www.spoj.com/problems/SUBMERGE/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Dominos](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2499)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|5|[Lighting Away](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2870)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|6|[Come and Go](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2938)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|7|[The Ant](http://www.spoj.com/problems/ANTTT/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|8|[Doves and bombs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1706)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|9|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces|Codeforces Round #244 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|10|[Trust groups](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2756)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|11|[True Friends](http://www.spoj.com/problems/TFRIENDS/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|12|[Test](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1672)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|13|[Sub-dictionary](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3670)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|14|[Ralph and Mushrooms](http://codeforces.com/problemset/problem/894/E)|Codeforces|Codeforces Round #447 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|15|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces|Codeforces Beta Round #22 (Div. 2 Only)|8|
