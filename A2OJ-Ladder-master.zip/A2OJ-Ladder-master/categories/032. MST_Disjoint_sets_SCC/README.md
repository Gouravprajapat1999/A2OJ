# 032. MST_Disjoint_sets_SCC


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Connect the Campus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1338)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Ubiquitous Religions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1524)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Arctic Network](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1310)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[ACM Contest and Blackout](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1541)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Bytelandian Blingors Network](http://www.spoj.com/problems/BLINNET/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Frogger](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=475)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Kids Love Candies](p?ID=17)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|8|[The Bottom of a Graph](http://www.spoj.com/problems/BOTTOM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Freckles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=975)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Capital City](http://www.spoj.com/problems/CAPCITY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Calling Circles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=183)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Re-connecting Computer Sites](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=849)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Heavy Cargo](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=485)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|14|[A Bug&#8217;s Life](http://www.spoj.com/problems/BUGLIFE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Cobbled streets](http://www.spoj.com/problems/CSTREET/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Fake tournament](http://www.spoj.com/problems/TOUR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|17|[Virtual Friends](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2498)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Dark roads](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2678)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Network Connections](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=734)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Herding](http://www.spoj.com/problems/HERDING/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Dominos](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2499)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Graph Connectivity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=400)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|23|[The Benefactor](http://www.spoj.com/problems/BENEFACT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Friends](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1549)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Audiophobia](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=989)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Dragon of Loowater](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2267)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|27|[The Tourist Guide](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1040)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Fix the Pond](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4147)|Live Archive|2012|Latin America|2|
|<ul><li>- [ ] Done</li></ul>|29|[Airports](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2833)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|30|[Highways](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1088)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|31|[Reliable Nets](http://www.spoj.com/problems/RELINETS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|32|[Nature](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1626)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|33|[True Friends](http://www.spoj.com/problems/TFRIENDS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|34|[Driving Range](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2957)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|35|[Is There A Second Way Left?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1403)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|36|[Cost](http://www.spoj.com/problems/KOICOST/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|37|[Money Matters](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2737)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|38|[Come and Go](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2938)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|39|[Network](http://acm.tju.edu.cn/toj/showp3499.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|40|[Rings and Glue](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1242)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|41|[Traffic Flow](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1783)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|42|[Heavy Cargo](http://acm.tju.edu.cn/toj/showp1172.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|43|[Fibonacci Tree](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4551)|Live Archive|2013|Asia - Chengdu|2|
|<ul><li>- [ ] Done</li></ul>|44|[War](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1099)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|45|[Transportation system.](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2169)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|46|[Lighting Away](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2870)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|47|[Freckles](http://acm.tju.edu.cn/toj/showp1348.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|48|[IP-TV](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3615)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|49|[Highways](http://acm.tju.edu.cn/toj/showp2288.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|50|[Bus Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=5013)|Live Archive|2014|Asia - Taichung|2|
|<ul><li>- [ ] Done</li></ul>|51|[Heavy Cycle Edges](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2847)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|52|[Strange Food Chain](http://www.spoj.com/problems/CHAIN/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|53|[Buy Car](http://acm.tju.edu.cn/toj/showp3518.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|54|[Expensive subway](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2757)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|55|[Corporative Network](http://www.spoj.com/problems/CORNET/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|56|[Proving Equivalences](http://www.spoj.com/problems/PMATRIX/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|57|[The Dragon of Loowater](http://poj.org/problem?id=3646)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|58|[Almost Union-Find](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3138)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|59|[Madrids One Way Streets](http://www.spoj.com/problems/MOWS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|60|[Oreon](http://acm.tju.edu.cn/toj/showp2531.html)|TJU|||3|
|<ul><li>- [ ] Done</li></ul>|61|[Square dance](http://www.spoj.com/problems/SQDANCE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|62|[X-Plosives](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3601)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|63|[Oreon](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3649)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|64|[Anti Brute Force Lock](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3676)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|65|[RACING](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3675)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|66|[Killing Aliens in Borg Maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1248)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|67|[Fatawy](http://www.spoj.com/problems/FATAWY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|68|[Count Minimum Spanning Trees](http://www.spoj.com/problems/MSTS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|69|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|70|[The Bug Sensor Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3657)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|71|[Island Hopping](http://www.spoj.com/problems/ISLHOP/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|72|[Prim](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1748)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|73|[Hedge Mazes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3785)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|74|[Fix the Pond](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3974)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|75|[Kingdoms](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3951)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|76|[FreeDiv](http://codeforces.com/problemset/problem/73/D)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|77|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces||Codeforces Round #360 (Div. 1)|8|
