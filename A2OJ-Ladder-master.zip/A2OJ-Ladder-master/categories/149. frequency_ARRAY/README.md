# 149. frequency_ARRAY


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[K-Palindrome](p?ID=276)|A2 Online Judge||4|
|<ul><li>- [ ] Done</li></ul>|2|[ZgukistringZ](http://codeforces.com/problemset/problem/551/B)|Codeforces|Codeforces Round #307 (Div. 2)|4|
