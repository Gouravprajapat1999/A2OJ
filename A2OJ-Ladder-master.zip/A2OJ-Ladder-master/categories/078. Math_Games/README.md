# 078. Math_Games


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[M&M Game](http://www.spoj.com/problems/MMMGAME/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Playing With Balls](http://www.spoj.com/problems/IITKWPCN/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[Happy Coins](http://www.spoj.com/problems/HC/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|4|[The Game](http://www.spoj.com/problems/QCJ3/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|5|[A Coin Game](http://www.spoj.com/problems/XOINC/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|6|[Face the mate](http://www.spoj.com/problems/FACENEMY/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|7|[Number Game](http://www.spoj.com/problems/NUMGAME/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|8|[GAMING ARENA](http://www.spoj.com/problems/GAMARENA/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|9|[Black and White Nim](http://www.spoj.com/problems/BNWNIM/)|SPOJ|6|
