# 102. Square_Root_Decomposition


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Potentiometers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3238)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|2|[Race Against Time](http://www.spoj.com/problems/RACETIME/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|3|[K-query II](http://www.spoj.com/problems/KQUERY2/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|4|[Array Transformer](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3154)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|5|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces|Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|6|[Lucky Array](http://codeforces.com/problemset/problem/121/E)|Codeforces|Codeforces Beta Round #91 (Div. 1 Only)|7|
