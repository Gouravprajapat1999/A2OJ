# 012. Codeforces_Div._2_-_E_Problems


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces|Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Expression](http://codeforces.com/problemset/problem/479/A)|Codeforces|Codeforces Round #274 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces|Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|4|[New Reform](http://codeforces.com/problemset/problem/659/E)|Codeforces|Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|5|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces|Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|6|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces|Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|7|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces|Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|8|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces|Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|9|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces|Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|10|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces|Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|11|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces|Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|12|[Pashmak and Graph](http://codeforces.com/problemset/problem/459/E)|Codeforces|Codeforces Round #261 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|13|[Riding in a Lift](http://codeforces.com/problemset/problem/479/E)|Codeforces|Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|14|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces|Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|15|[Paths and Trees](http://codeforces.com/problemset/problem/545/E)|Codeforces|Codeforces Round #303 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|16|[Gerald and Giant Chess](http://codeforces.com/problemset/problem/559/C)|Codeforces|Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|17|[Weakness and Poorness](http://codeforces.com/problemset/problem/578/C)|Codeforces|Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|4|
|<ul><li>- [ ] Done</li></ul>|18|[XOR and Favorite Number](http://codeforces.com/problemset/problem/617/E)|Codeforces|Codeforces Round #340 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|19|[Correct Bracket Sequence Editor](http://codeforces.com/problemset/problem/670/E)|Codeforces|Codeforces Round #350 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|20|[The Values You Can Make](http://codeforces.com/problemset/problem/687/C)|Codeforces|Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|21|[Connecting Universities](http://codeforces.com/problemset/problem/700/B)|Codeforces|Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|22|[Fire](http://codeforces.com/problemset/problem/864/E)|Codeforces|Codeforces Round #436 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|23|[Squares and not squares](http://codeforces.com/problemset/problem/898/E)|Codeforces|Codeforces Round #451 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|24|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces|Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|25|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces|Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|26|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces|Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|27|[Games with Rectangle](http://codeforces.com/problemset/problem/128/C)|Codeforces|Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|28|[Logo Turtle](http://codeforces.com/problemset/problem/132/C)|Codeforces|Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|29|[Porcelain](http://codeforces.com/problemset/problem/148/E)|Codeforces|Codeforces Round #105 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|30|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces|Codeforces Round #112 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|31|[Blood Cousins](http://codeforces.com/problemset/problem/208/E)|Codeforces|Codeforces Round #130 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|32|[Choosing Balls](http://codeforces.com/problemset/problem/264/C)|Codeforces|Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|33|[Sausage Maximization](http://codeforces.com/problemset/problem/282/E)|Codeforces|Codeforces Round #173 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|34|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces|Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|35|[Kalila and Dimna in the Logging Industry](http://codeforces.com/problemset/problem/319/C)|Codeforces|Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|36|[Iahub and Permutations](http://codeforces.com/problemset/problem/340/E)|Codeforces|Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|37|[Read Time](http://codeforces.com/problemset/problem/343/C)|Codeforces|Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|38|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces|Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|39|[Fox and Card Game](http://codeforces.com/problemset/problem/388/C)|Codeforces|Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|40|[Mashmokh and Reverse Operation](http://codeforces.com/problemset/problem/414/C)|Codeforces|Codeforces Round #240 (Div. 1) & Codeforces Round #240 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|41|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces|Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|42|[Array and Operations](http://codeforces.com/problemset/problem/498/C)|Codeforces|Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|43|[Breaking Good](http://codeforces.com/problemset/problem/507/E)|Codeforces|Codeforces Round #287 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|44|[Pretty Song](http://codeforces.com/problemset/problem/509/E)|Codeforces|Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|45|[Soldier and Traveling](http://codeforces.com/problemset/problem/546/E)|Codeforces|Codeforces Round #304 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|46|[Case of Chocolate](http://codeforces.com/problemset/problem/555/C)|Codeforces|Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|47|[A Simple Task](http://codeforces.com/problemset/problem/558/E)|Codeforces|Codeforces Round #312 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|48|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces|Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|49|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces|Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|50|[Three States](http://codeforces.com/problemset/problem/590/C)|Codeforces|Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|51|[Wet Shark and Blocks](http://codeforces.com/problemset/problem/621/E)|Codeforces|Codeforces Round #341 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|52|[Little Artem and Time Machine](http://codeforces.com/problemset/problem/641/E)|Codeforces|VK Cup 2016 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|53|[Sasha and Array](http://codeforces.com/problemset/problem/718/C)|Codeforces|Codeforces Round #373 (Div. 1) & Codeforces Round #373 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|54|[Anton and Tree](http://codeforces.com/problemset/problem/734/E)|Codeforces|Codeforces Round #379 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|55|[Subordinates](http://codeforces.com/problemset/problem/729/E)|Codeforces|Technocup 2017 - Elimination Round 2|5|
|<ul><li>- [ ] Done</li></ul>|56|[Comments](http://codeforces.com/problemset/problem/747/E)|Codeforces|Codeforces Round #387 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|57|[Game of Stones](http://codeforces.com/problemset/problem/768/E)|Codeforces|Divide by Zero 2017 and Codeforces Round #399 (Div. 1 + Div. 2, combined)|5|
|<ul><li>- [ ] Done</li></ul>|58|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces|Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|59|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces|Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|60|[Underground Lab](http://codeforces.com/problemset/problem/780/E)|Codeforces|?????????? 2017 - ????? (?????? ??? ??????-??????????)|5|
|<ul><li>- [ ] Done</li></ul>|61|[Cards Sorting](http://codeforces.com/problemset/problem/830/B)|Codeforces|Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|5|
|<ul><li>- [ ] Done</li></ul>|62|[Maximize!](http://codeforces.com/problemset/problem/939/E)|Codeforces|Codeforces Round #464 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|63|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces|Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|64|[Holes](http://codeforces.com/problemset/problem/13/E)|Codeforces|Codeforces Beta Round #13|6|
|<ul><li>- [ ] Done</li></ul>|65|[Fish](http://codeforces.com/problemset/problem/16/E)|Codeforces|Codeforces Beta Round #16 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|66|[Test](http://codeforces.com/problemset/problem/25/E)|Codeforces|Codeforces Beta Round #25 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|67|[Let's Go Rolling!](http://codeforces.com/problemset/problem/38/E)|Codeforces|School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|68|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces|Codeforces Beta Round #40 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|69|[Interesting Game](http://codeforces.com/problemset/problem/87/C)|Codeforces|Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|70|[Time to Raid Cowavans](http://codeforces.com/problemset/problem/103/D)|Codeforces|Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|71|[Bertown roads](http://codeforces.com/problemset/problem/118/E)|Codeforces|Codeforces Beta Round #89 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|72|[Lucky Permutation](http://codeforces.com/problemset/problem/121/C)|Codeforces|Codeforces Beta Round #91 (Div. 1 Only) & Codeforces Beta Round #91 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|73|[Yet Another Task with Queens](http://codeforces.com/problemset/problem/131/E)|Codeforces|Codeforces Beta Round #95 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|74|[Zero-One](http://codeforces.com/problemset/problem/135/C)|Codeforces|Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|75|[Lucky Subsequence](http://codeforces.com/problemset/problem/145/C)|Codeforces|Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|76|[Martian Strings](http://codeforces.com/problemset/problem/149/E)|Codeforces|Codeforces Round #106 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|77|[Double Profiles](http://codeforces.com/problemset/problem/154/C)|Codeforces|Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|78|[Cipher](http://codeforces.com/problemset/problem/156/C)|Codeforces|Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|79|[Relay Race](http://codeforces.com/problemset/problem/213/C)|Codeforces|Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|80|[Decoding Genome](http://codeforces.com/problemset/problem/222/E)|Codeforces|Codeforces Round #137 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|81|[Partial Sums](http://codeforces.com/problemset/problem/223/C)|Codeforces|Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|82|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces|Codeforces Round #141 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|83|[Triangles](http://codeforces.com/problemset/problem/229/C)|Codeforces|Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|84|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces|Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|85|[Flawed Flow](http://codeforces.com/problemset/problem/269/C)|Codeforces|Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|86|[Beautiful Decomposition](http://codeforces.com/problemset/problem/279/E)|Codeforces|Codeforces Round #171 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|87|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces|Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|88|[Main Sequence](http://codeforces.com/problemset/problem/286/C)|Codeforces|Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|89|[Greg and Friends](http://codeforces.com/problemset/problem/295/C)|Codeforces|Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|90|[Sereja and Subsequences](http://codeforces.com/problemset/problem/314/C)|Codeforces|Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|91|[Number Transformation II](http://codeforces.com/problemset/problem/346/C)|Codeforces|Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|92|[Compartments](http://codeforces.com/problemset/problem/356/C)|Codeforces|Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|93|[Sereja and the Arrangement of Numbers](http://codeforces.com/problemset/problem/367/C)|Codeforces|Codeforces Round #215 (Div. 1) & Codeforces Round #215 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|94|[Valera and Queries](http://codeforces.com/problemset/problem/369/E)|Codeforces|Codeforces Round #216 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|95|[Watching Fireworks is Fun](http://codeforces.com/problemset/problem/372/C)|Codeforces|Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|96|[On Changing Tree](http://codeforces.com/problemset/problem/396/C)|Codeforces|Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|97|[Strictly Positive Matrix](http://codeforces.com/problemset/problem/402/E)|Codeforces|Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|98|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces|Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|99|[Artem and Array ](http://codeforces.com/problemset/problem/442/C)|Codeforces|Codeforces Round #253 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|100|[DZY Loves Colors](http://codeforces.com/problemset/problem/444/C)|Codeforces|Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|101|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces|Codeforces Round #256 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|102|[Jzzhu and Apples](http://codeforces.com/problemset/problem/449/C)|Codeforces|Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|103|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces|Codeforces Round #258 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|104|[Little Pony and Summer Sun Celebration](http://codeforces.com/problemset/problem/453/C)|Codeforces|Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|105|[Appleman and a Sheet of Paper](http://codeforces.com/problemset/problem/461/C)|Codeforces|Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|106|[Caisa and Tree](http://codeforces.com/problemset/problem/463/E)|Codeforces|Codeforces Round #264 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|107|[Substitutes in Number](http://codeforces.com/problemset/problem/464/C)|Codeforces|Codeforces Round #265 (Div. 1) & Codeforces Round #265 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|108|[Information Graph](http://codeforces.com/problemset/problem/466/E)|Codeforces|Codeforces Round #266 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|109|[Dreamoon and Strings](http://codeforces.com/problemset/problem/476/E)|Codeforces|Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|110|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces|Codeforces Round #277 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|111|[Prefix Product Sequence](http://codeforces.com/problemset/problem/488/E)|Codeforces|Codeforces Round #278 (Div. 2) & Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2) & Codeforces Round #278 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|112|[Restoring Increasing Sequence](http://codeforces.com/problemset/problem/490/E)|Codeforces|Codeforces Round #279 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|113|[Vanya and Field](http://codeforces.com/problemset/problem/492/E)|Codeforces|Codeforces Round #280 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|114|[Distributing Parts ](http://codeforces.com/problemset/problem/496/E)|Codeforces|Codeforces Round #283 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|115|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces|Codeforces Round #288 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|116|[Fox And Dinner](http://codeforces.com/problemset/problem/510/E)|Codeforces|Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|117|[Drazil and Park](http://codeforces.com/problemset/problem/515/E)|Codeforces|Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|118|[Pluses everywhere](http://codeforces.com/problemset/problem/520/E)|Codeforces|Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|119|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces|Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|120|[Demiurges Play Again](http://codeforces.com/problemset/problem/538/E)|Codeforces|Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|121|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces|Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|122|[Brackets in Implications](http://codeforces.com/problemset/problem/550/E)|Codeforces|Codeforces Round #306 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|123|[GukiZ and GukiZiana](http://codeforces.com/problemset/problem/551/E)|Codeforces|Codeforces Round #307 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|124|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces|Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|125|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces|Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|126|[Pig and Palindromes](http://codeforces.com/problemset/problem/570/E)|Codeforces|Codeforces Round #316 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|127|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces|Codeforces Round #321 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|128|[Anton and Ira](http://codeforces.com/problemset/problem/584/E)|Codeforces|Codeforces Round #324 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|129|[Lieges of Legendre](http://codeforces.com/problemset/problem/603/C)|Codeforces|Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|130|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces|Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|131|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces|Codeforces Round #353 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|132|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces|Codeforces Round #361 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|133|[PLEASE](http://codeforces.com/problemset/problem/696/C)|Codeforces|Codeforces Round #362 (Div. 1) & Codeforces Round #362 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|134|[ZS and The Birthday Paradox](http://codeforces.com/problemset/problem/711/E)|Codeforces|Codeforces Round #369 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|135|[Sonya and Problem Wihtout a Legend](http://codeforces.com/problemset/problem/713/C)|Codeforces|Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|136|[One-Way Reform](http://codeforces.com/problemset/problem/723/E)|Codeforces|Codeforces Round #375 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|137|[Sockets](http://codeforces.com/problemset/problem/732/E)|Codeforces|Codeforces Round #377 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|138|[Arpa’s overnight party and Mehrdad’s silent entering](http://codeforces.com/problemset/problem/741/C)|Codeforces|Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|139|[Numbers Exchange](http://codeforces.com/problemset/problem/746/E)|Codeforces|Codeforces Round #386 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|140|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces|Codeforces Round #384 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|141|[New Year Domino](http://codeforces.com/problemset/problem/500/E)|Codeforces|Good Bye 2014|6|
|<ul><li>- [ ] Done</li></ul>|142|[Santa Claus and Tangerines](http://codeforces.com/problemset/problem/748/E)|Codeforces|Technocup 2017 - Elimination Round 3|6|
|<ul><li>- [ ] Done</li></ul>|143|[Dasha and Puzzle](http://codeforces.com/problemset/problem/761/E)|Codeforces|Codeforces Round #394 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|144|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces|Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|145|[Tree Folding](http://codeforces.com/problemset/problem/765/E)|Codeforces|Codeforces Round #397 by Kaspersky Lab and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|6|
|<ul><li>- [ ] Done</li></ul>|146|[The Holmes Children](http://codeforces.com/problemset/problem/776/E)|Codeforces|ICM Technex 2017 and Codeforces Round #400 (Div. 1 + Div. 2, combined)|6|
|<ul><li>- [ ] Done</li></ul>|147|[The Great Mixing](http://codeforces.com/problemset/problem/788/C)|Codeforces|Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|148|[Ice cream coloring](http://codeforces.com/problemset/problem/804/C)|Codeforces|Codeforces Round #411 (Div. 1) & Codeforces Round #411 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|149|[Karen and Supermarket](http://codeforces.com/problemset/problem/815/C)|Codeforces|Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|150|[DNA Evolution](http://codeforces.com/problemset/problem/827/C)|Codeforces|Codeforces Round #423 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #423 (Div. 2, rated, based on VK Cup Finals)|6|
|<ul><li>- [ ] Done</li></ul>|151|[Okabe and El Psy Kongroo](http://codeforces.com/problemset/problem/821/E)|Codeforces|Codeforces Round #420 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|152|[National Property](http://codeforces.com/problemset/problem/875/C)|Codeforces|Codeforces Round #441 (Div. 1, by Moscow Team Olympiad) & Codeforces Round #441 (Div. 2, by Moscow Team Olympiad)|6|
|<ul><li>- [ ] Done</li></ul>|153|[Bindian Signalizing](http://codeforces.com/problemset/problem/5/E)|Codeforces|Codeforces Beta Round #5|7|
|<ul><li>- [ ] Done</li></ul>|154|[Camels](http://codeforces.com/problemset/problem/14/E)|Codeforces|Codeforces Beta Round #14 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|155|[Fairy](http://codeforces.com/problemset/problem/19/E)|Codeforces|Codeforces Beta Round #19|7|
|<ul><li>- [ ] Done</li></ul>|156|[TV Game](http://codeforces.com/problemset/problem/31/E)|Codeforces|Codeforces Beta Round #31 (Div. 2, Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|157|[Comb](http://codeforces.com/problemset/problem/46/E)|Codeforces|School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|158|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces|Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|159|[Shortest Path](http://codeforces.com/problemset/problem/59/E)|Codeforces|Codeforces Beta Round #55 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|160|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces|Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|161|[Ski Base](http://codeforces.com/problemset/problem/91/C)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|162|[Petya and Spiders](http://codeforces.com/problemset/problem/111/C)|Codeforces|Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|163|[Double Happiness](http://codeforces.com/problemset/problem/113/C)|Codeforces|Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|164|[Last Chance](http://codeforces.com/problemset/problem/137/E)|Codeforces|Codeforces Beta Round #98 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|165|[Mushroom Gnomes - 2](http://codeforces.com/problemset/problem/138/C)|Codeforces|Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|166|[Cubes](http://codeforces.com/problemset/problem/180/E)|Codeforces|Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|167|[Wooden Fence](http://codeforces.com/problemset/problem/182/E)|Codeforces|Codeforces Round #117 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|168|[Weak Memory](http://codeforces.com/problemset/problem/187/C)|Codeforces|Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|169|[Counter Attack](http://codeforces.com/problemset/problem/190/E)|Codeforces|Codeforces Round #120 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|170|[Paint Tree](http://codeforces.com/problemset/problem/196/C)|Codeforces|Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|171|[Fragile Bridges](http://codeforces.com/problemset/problem/201/C)|Codeforces|Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|172|[Little Elephant and Furik and Rubik](http://codeforces.com/problemset/problem/204/C)|Codeforces|Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|173|[Little Elephant and Shifts](http://codeforces.com/problemset/problem/220/C)|Codeforces|Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|174|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces|Codeforces Round #143 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|175|[Champions' League](http://codeforces.com/problemset/problem/234/E)|Codeforces|Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|176|[Cyclical Quest](http://codeforces.com/problemset/problem/235/C)|Codeforces|Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|177|[Build String](http://codeforces.com/problemset/problem/237/E)|Codeforces|Codeforces Round #147 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|178|[World Eater Brothers](http://codeforces.com/problemset/problem/238/C)|Codeforces|Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|179|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces|Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|180|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces|Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|181|[Furlo and Rublo and Game](http://codeforces.com/problemset/problem/255/E)|Codeforces|Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|182|[Maxim and Matrix](http://codeforces.com/problemset/problem/261/C)|Codeforces|Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|183|[Playlist](http://codeforces.com/problemset/problem/268/E)|Codeforces|Codeforces Round #164 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|184|[Dima and Horses](http://codeforces.com/problemset/problem/272/E)|Codeforces|Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|185|[Little Girl and Problem on Trees](http://codeforces.com/problemset/problem/276/E)|Codeforces|Codeforces Round #169 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|186|[Coin Troubles](http://codeforces.com/problemset/problem/283/C)|Codeforces|Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|187|[Splitting the Uniqueness](http://codeforces.com/problemset/problem/297/C)|Codeforces|Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|188|[Empire Strikes Back](http://codeforces.com/problemset/problem/300/E)|Codeforces|Codeforces Round #181 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|189|[Minimum Modular](http://codeforces.com/problemset/problem/303/C)|Codeforces|Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|190|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces|Codeforces Round #191 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|191|[Graph Reconstruction](http://codeforces.com/problemset/problem/329/C)|Codeforces|Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|192|[Divisor Tree](http://codeforces.com/problemset/problem/337/E)|Codeforces|Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|193|[Subset Sums](http://codeforces.com/problemset/problem/348/C)|Codeforces|Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|194|[Wrong Floyd](http://codeforces.com/problemset/problem/350/E)|Codeforces|Codeforces Round #203 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|195|[Levko and Strings](http://codeforces.com/problemset/problem/360/C)|Codeforces|Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|196|[Subway Innovation](http://codeforces.com/problemset/problem/371/E)|Codeforces|Codeforces Round #218 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|197|[Captains Mode](http://codeforces.com/problemset/problem/377/C)|Codeforces|Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|198|[George and Cards](http://codeforces.com/problemset/problem/387/E)|Codeforces|Codeforces Round #227 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|199|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces|Codeforces Round #234 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|200|[Graph Cutting](http://codeforces.com/problemset/problem/405/E)|Codeforces|Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|201|[Curious Array](http://codeforces.com/problemset/problem/407/C)|Codeforces|Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|202|[President's Path](http://codeforces.com/problemset/problem/416/E)|Codeforces|Codeforces Round #241 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|203|[Sereja and Two Sequences](http://codeforces.com/problemset/problem/425/C)|Codeforces|Codeforces Round #243 (Div. 1) & Codeforces Round #243 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|204|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces|Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|205|[Devu and Birthday Celebration](http://codeforces.com/problemset/problem/439/E)|Codeforces|Codeforces Round #251 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|206|[Hack it!](http://codeforces.com/problemset/problem/468/C)|Codeforces|Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|207|[Hiking](http://codeforces.com/problemset/problem/489/E)|Codeforces|Codeforces Round #277.5 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|208|[Darth Vader and Tree](http://codeforces.com/problemset/problem/514/E)|Codeforces|Codeforces Round #291 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|209|[Arthur and Questions](http://codeforces.com/problemset/problem/518/E)|Codeforces|Codeforces Round #293 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|210|[Data Center Drama](http://codeforces.com/problemset/problem/527/E)|Codeforces|Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|211|[Tavas and Pashmaks](http://codeforces.com/problemset/problem/535/E)|Codeforces|Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|212|[Remembering Strings](http://codeforces.com/problemset/problem/543/C)|Codeforces|Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|213|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces|Codeforces Round #311 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|214|[President and Roads](http://codeforces.com/problemset/problem/567/E)|Codeforces|Codeforces Round #Pi (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|215|[Bear and Drawing](http://codeforces.com/problemset/problem/573/C)|Codeforces|Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|216|[Alice, Bob, Oranges and Apples](http://codeforces.com/problemset/problem/585/C)|Codeforces|Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|217|[Edo and Magnets](http://codeforces.com/problemset/problem/594/C)|Codeforces|Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|218|[Kleofáš and the n-thlon](http://codeforces.com/problemset/problem/601/C)|Codeforces|Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|219|[Freelancer's Dreams](http://codeforces.com/problemset/problem/605/C)|Codeforces|Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|220|[Marbles](http://codeforces.com/problemset/problem/607/C)|Codeforces|Codeforces Round #336 (Div. 1) & Codeforces Round #336 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|221|[Hexagons](http://codeforces.com/problemset/problem/615/E)|Codeforces|Codeforces Round #338 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|222|[Necklace](http://codeforces.com/problemset/problem/613/C)|Codeforces|Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|223|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces|Codeforces Round #343 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|224|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces|Codeforces Round #344 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|225|[Levels and Regions](http://codeforces.com/problemset/problem/643/C)|Codeforces|VK Cup 2016 - Round 3|7|
|<ul><li>- [ ] Done</li></ul>|226|[The Last Fight Between Human and AI](http://codeforces.com/problemset/problem/676/E)|Codeforces|Codeforces Round #354 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|227|[Bear and Square Grid](http://codeforces.com/problemset/problem/679/C)|Codeforces|Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|228|[LRU](http://codeforces.com/problemset/problem/698/C)|Codeforces|Codeforces Round #363 (Div. 1) & Codeforces Round #363 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|229|[Working routine](http://codeforces.com/problemset/problem/706/E)|Codeforces|Codeforces Round #367 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|230|[Garlands](http://codeforces.com/problemset/problem/707/E)|Codeforces|Codeforces Round #368 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|231|[Digit Tree](http://codeforces.com/problemset/problem/715/C)|Codeforces|Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|232|[Funny Game](http://codeforces.com/problemset/problem/731/E)|Codeforces|Codeforces Round #376 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|233|[Alyona and towers](http://codeforces.com/problemset/problem/739/C)|Codeforces|Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|234|[Hongcow Buys a Deck of Cards](http://codeforces.com/problemset/problem/744/C)|Codeforces|Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|235|[Bash Plays with Functions](http://codeforces.com/problemset/problem/757/E)|Codeforces|Codecraft-17 and Codeforces Round #391 (Div. 1 + Div. 2, combined)|7|
|<ul><li>- [ ] Done</li></ul>|236|[Nikita and stack](http://codeforces.com/problemset/problem/756/C)|Codeforces|8VC Venture Cup 2017 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|237|[Change-free](http://codeforces.com/problemset/problem/767/E)|Codeforces|Codeforces Round #398 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|238|[Anton and Permutation](http://codeforces.com/problemset/problem/785/E)|Codeforces|Codeforces Round #404 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|239|[Bear and Company](http://codeforces.com/problemset/problem/771/D)|Codeforces|VK Cup 2017 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|240|[Till I Collapse](http://codeforces.com/problemset/problem/786/C)|Codeforces|Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|241|[Sagheer and Apple Tree](http://codeforces.com/problemset/problem/812/E)|Codeforces|Codeforces Round #417 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|242|[Aquarium decoration](http://codeforces.com/problemset/problem/799/E)|Codeforces|Playrix Codescapes Cup (Codeforces Round #413, rated, Div. 1 + Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|243|[Prairie Partition](http://codeforces.com/problemset/problem/773/C)|Codeforces|VK Cup 2017 - Round 3|7|
|<ul><li>- [ ] Done</li></ul>|244|[Vulnerable Kerbals](http://codeforces.com/problemset/problem/772/C)|Codeforces|VK Cup 2017 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|245|[On the Bench](http://codeforces.com/problemset/problem/840/C)|Codeforces|Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|246|[Points, Lines and Ready-made Titles](http://codeforces.com/problemset/problem/870/E)|Codeforces|Technocup 2018 - Elimination Round 2|7|
|<ul><li>- [ ] Done</li></ul>|247|[The Untended Antiquity](http://codeforces.com/problemset/problem/869/E)|Codeforces|Codeforces Round #439 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|248|[Short Code](http://codeforces.com/problemset/problem/965/E)|Codeforces|Codeforces Round #476 (Div. 2) [Thanks, Telegram!]|7|
|<ul><li>- [ ] Done</li></ul>|249|[Army Creation](http://codeforces.com/problemset/problem/813/E)|Codeforces|Educational Codeforces Round 22|7|
|<ul><li>- [ ] Done</li></ul>|250|[Defining Macros](http://codeforces.com/problemset/problem/7/E)|Codeforces|Codeforces Beta Round #7|8|
|<ul><li>- [ ] Done</li></ul>|251|[Beads](http://codeforces.com/problemset/problem/8/E)|Codeforces|Codeforces Beta Round #8|8|
|<ul><li>- [ ] Done</li></ul>|252|[Interestring graph and Apples](http://codeforces.com/problemset/problem/9/E)|Codeforces|Codeforces Beta Round #9 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|253|[Greedy Change](http://codeforces.com/problemset/problem/10/E)|Codeforces|Codeforces Beta Round #10|8|
|<ul><li>- [ ] Done</li></ul>|254|[Start of the session](http://codeforces.com/problemset/problem/12/E)|Codeforces|Codeforces Beta Round #12 (Div 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|255|[Palisection](http://codeforces.com/problemset/problem/17/E)|Codeforces|Codeforces Beta Round #17|8|
|<ul><li>- [ ] Done</li></ul>|256|[Flag 2](http://codeforces.com/problemset/problem/18/E)|Codeforces|Codeforces Beta Round #18 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|257|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces|Codeforces Beta Round #22 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|258|[Tree](http://codeforces.com/problemset/problem/23/E)|Codeforces|Codeforces Beta Round #23|8|
|<ul><li>- [ ] Done</li></ul>|259|[Berland collider](http://codeforces.com/problemset/problem/24/E)|Codeforces|Codeforces Beta Round #24|8|
|<ul><li>- [ ] Done</li></ul>|260|[Quarrel](http://codeforces.com/problemset/problem/29/E)|Codeforces|Codeforces Beta Round #29 (Div. 2, Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|261|[Tricky and Clever Password](http://codeforces.com/problemset/problem/30/E)|Codeforces|Codeforces Beta Round #30 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|262|[Collisions](http://codeforces.com/problemset/problem/34/E)|Codeforces|Codeforces Beta Round #34 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|263|[Parade](http://codeforces.com/problemset/problem/35/E)|Codeforces|Codeforces Beta Round #35 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|264|[Number Table](http://codeforces.com/problemset/problem/40/E)|Codeforces|Codeforces Beta Round #39|8|
|<ul><li>- [ ] Done</li></ul>|265|[Common ancestor](http://codeforces.com/problemset/problem/49/E)|Codeforces|Codeforces Beta Round #46 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|266|[Dead Ends](http://codeforces.com/problemset/problem/53/E)|Codeforces|Codeforces Beta Round #49 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|267|[Very simple problem](http://codeforces.com/problemset/problem/55/E)|Codeforces|Codeforces Beta Round #51|8|
|<ul><li>- [ ] Done</li></ul>|268|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces|Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|269|[Petya and Post](http://codeforces.com/problemset/problem/66/E)|Codeforces|Codeforces Beta Round #61 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|270|[Chip Play](http://codeforces.com/problemset/problem/89/C)|Codeforces|Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|271|[Vectors](http://codeforces.com/problemset/problem/101/C)|Codeforces|Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|272|[Space Rescuers](http://codeforces.com/problemset/problem/106/E)|Codeforces|Codeforces Beta Round #82 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|273|[Plumber](http://codeforces.com/problemset/problem/115/C)|Codeforces|Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|274|[Brackets](http://codeforces.com/problemset/problem/123/C)|Codeforces|Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|275|[E-reader Display](http://codeforces.com/problemset/problem/126/C)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|276|[New Year Garland](http://codeforces.com/problemset/problem/140/E)|Codeforces|Codeforces Round #100|8|
|<ul><li>- [ ] Done</li></ul>|277|[Clearing Up](http://codeforces.com/problemset/problem/141/E)|Codeforces|Codeforces Round #101 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|278|[Help Caretaker](http://codeforces.com/problemset/problem/142/C)|Codeforces|Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|279|[Competition](http://codeforces.com/problemset/problem/144/E)|Codeforces|Codeforces Round #103 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|280|[Smart Cheater](http://codeforces.com/problemset/problem/150/C)|Codeforces|Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|281|[Wizards and Numbers](http://codeforces.com/problemset/problem/167/C)|Codeforces|Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|282|[Hamming Distance](http://codeforces.com/problemset/problem/193/C)|Codeforces|Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|283|[Building Forest](http://codeforces.com/problemset/problem/195/E)|Codeforces|Codeforces Round #123 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|284|[Periodical Numbers](http://codeforces.com/problemset/problem/215/E)|Codeforces|Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|285|[Martian Luck](http://codeforces.com/problemset/problem/216/E)|Codeforces|Codeforces Round #133 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|286|[Parking Lot](http://codeforces.com/problemset/problem/219/E)|Codeforces|Codeforces Round #135 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|287|[Unsolvable](http://codeforces.com/problemset/problem/225/E)|Codeforces|Codeforces Round #139 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|288|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces|Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|289|[Colorado Potato Beetle](http://codeforces.com/problemset/problem/243/C)|Codeforces|Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|290|[Printer](http://codeforces.com/problemset/problem/253/E)|Codeforces|Codeforces Round #154 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|291|[More Queries to Array...](http://codeforces.com/problemset/problem/266/E)|Codeforces|Codeforces Round #163 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|292|[Three Horses](http://codeforces.com/problemset/problem/271/E)|Codeforces|Codeforces Round #166 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|293|[Game](http://codeforces.com/problemset/problem/277/C)|Codeforces|Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|294|[Positions in Permutations](http://codeforces.com/problemset/problem/285/E)|Codeforces|Codeforces Round #175 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|295|[Shaass the Great](http://codeforces.com/problemset/problem/294/E)|Codeforces|Codeforces Round #178 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|296|[Yaroslav and Algorithm](http://codeforces.com/problemset/problem/301/C)|Codeforces|Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|297|[Playing with String](http://codeforces.com/problemset/problem/305/E)|Codeforces|Codeforces Round #184 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|298|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces|Codeforces Round #186 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|299|[Balance](http://codeforces.com/problemset/problem/317/C)|Codeforces|Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|300|[Three Swaps](http://codeforces.com/problemset/problem/339/E)|Codeforces|Codeforces Round #197 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|301|[Jeff and Brackets](http://codeforces.com/problemset/problem/351/C)|Codeforces|Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|302|[Antichain](http://codeforces.com/problemset/problem/353/E)|Codeforces|Codeforces Round #205 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|303|[Petya and Pipes](http://codeforces.com/problemset/problem/362/E)|Codeforces|Codeforces Round #212 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|304|[Beautiful Set](http://codeforces.com/problemset/problem/364/C)|Codeforces|Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|305|[Dima and Magic Guitar](http://codeforces.com/problemset/problem/366/E)|Codeforces|Codeforces Round #214 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|306|[Volcanoes](http://codeforces.com/problemset/problem/383/B)|Codeforces|Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|307|[Bear in the Field](http://codeforces.com/problemset/problem/385/E)|Codeforces|Codeforces Round #226 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|308|[Maze 1D](http://codeforces.com/problemset/problem/404/E)|Codeforces|Codeforces Round #237 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|309|[Square Tiling](http://codeforces.com/problemset/problem/432/E)|Codeforces|Codeforces Round #246 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|310|[The Child and Polygon](http://codeforces.com/problemset/problem/437/E)|Codeforces|Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|311|[Alex and Complicated Task](http://codeforces.com/problemset/problem/467/E)|Codeforces|Codeforces Round #267 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|312|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces|Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|313|[Strange Sorting](http://codeforces.com/problemset/problem/484/C)|Codeforces|Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|314|[Vasya and Polynomial](http://codeforces.com/problemset/problem/493/E)|Codeforces|Codeforces Round #281 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|315|[Helping People](http://codeforces.com/problemset/problem/494/C)|Codeforces|Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|316|[Misha and Palindrome Degree](http://codeforces.com/problemset/problem/501/E)|Codeforces|Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|317|[Mike and Friends](http://codeforces.com/problemset/problem/547/E)|Codeforces|Codeforces Round #305 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|318|[New Language](http://codeforces.com/problemset/problem/568/C)|Codeforces|Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|319|[CNF 2](http://codeforces.com/problemset/problem/571/C)|Codeforces|Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|320|[Superior Periodic Subarrays](http://codeforces.com/problemset/problem/582/C)|Codeforces|Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|321|[Alphabet Permutations](http://codeforces.com/problemset/problem/610/E)|Codeforces|Codeforces Round #337 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|322|[Ultimate Weirdness of an Array](http://codeforces.com/problemset/problem/671/C)|Codeforces|Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|323|[Vanya and Balloons](http://codeforces.com/problemset/problem/677/E)|Codeforces|Codeforces Round #355 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|324|[Alyona and Triangles](http://codeforces.com/problemset/problem/682/E)|Codeforces|Codeforces Round #358 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|325|[Mishka and Divisors](http://codeforces.com/problemset/problem/703/E)|Codeforces|Codeforces Round #365 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|326|[Memory and Casinos](http://codeforces.com/problemset/problem/712/E)|Codeforces|Codeforces Round #370 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|327|[Sleep in Class](http://codeforces.com/problemset/problem/733/E)|Codeforces|Codeforces Round #378 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|328|[Inversions After Shuffle](http://codeforces.com/problemset/problem/749/E)|Codeforces|Codeforces Round #388 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|329|[Timofey and remoduling](http://codeforces.com/problemset/problem/763/C)|Codeforces|Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|330|[Exam Cheating](http://codeforces.com/problemset/problem/796/E)|Codeforces|Codeforces Round #408 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|331|[Vladik and Entertaining Flags](http://codeforces.com/problemset/problem/811/E)|Codeforces|Codeforces Round #416 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|332|[Find a car](http://codeforces.com/problemset/problem/809/C)|Codeforces|Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|333|[Shortest Path Problem?](http://codeforces.com/problemset/problem/845/G)|Codeforces|Educational Codeforces Round 27|8|
|<ul><li>- [ ] Done</li></ul>|334|[Mother of Dragons](http://codeforces.com/problemset/problem/839/E)|Codeforces|Codeforces Round #428 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|335|[The penguin's game](http://codeforces.com/problemset/problem/835/E)|Codeforces|Codeforces Round #427 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|336|[Liar](http://codeforces.com/problemset/problem/822/E)|Codeforces|Codeforces Round #422 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|337|[An unavoidable detour for home](http://codeforces.com/problemset/problem/814/E)|Codeforces|Codeforces Round #418 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|338|[Nastya and King-Shamans](http://codeforces.com/problemset/problem/992/E)|Codeforces|Codeforces Round #489 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|339|[Triangles](http://codeforces.com/problemset/problem/15/E)|Codeforces|Codeforces Beta Round #15|9|
|<ul><li>- [ ] Done</li></ul>|340|[Multithreading](http://codeforces.com/problemset/problem/26/E)|Codeforces|Codeforces Beta Round #26 (Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|341|[Hide-and-Seek](http://codeforces.com/problemset/problem/32/E)|Codeforces|Codeforces Beta Round #32 (Div. 2, Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|342|[Two Paths](http://codeforces.com/problemset/problem/36/E)|Codeforces|Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|343|[Trial for Chief](http://codeforces.com/problemset/problem/37/E)|Codeforces|Codeforces Beta Round #37|9|
|<ul><li>- [ ] Done</li></ul>|344|[Race](http://codeforces.com/problemset/problem/43/E)|Codeforces|Codeforces Beta Round #42 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|345|[Cannon](http://codeforces.com/problemset/problem/47/E)|Codeforces|Codeforces Beta Round #44 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|346|[Ivan the Fool VS Gorynych the Dragon](http://codeforces.com/problemset/problem/48/E)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|347|[Square Equation Roots](http://codeforces.com/problemset/problem/50/E)|Codeforces|Codeforces Beta Round #47|9|
|<ul><li>- [ ] Done</li></ul>|348|[Pentagon](http://codeforces.com/problemset/problem/51/E)|Codeforces|Codeforces Beta Round #48|9|
|<ul><li>- [ ] Done</li></ul>|349|[Mushroom Gnomes](http://codeforces.com/problemset/problem/60/E)|Codeforces|Codeforces Beta Round #56|9|
|<ul><li>- [ ] Done</li></ul>|350|[Information Reform](http://codeforces.com/problemset/problem/70/E)|Codeforces|Codeforces Beta Round #64|9|
|<ul><li>- [ ] Done</li></ul>|351|[Nuclear Fusion](http://codeforces.com/problemset/problem/71/E)|Codeforces|Codeforces Beta Round #65 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|352|[Morrowindows](http://codeforces.com/problemset/problem/73/E)|Codeforces|Codeforces Beta Round #66|9|
|<ul><li>- [ ] Done</li></ul>|353|[Ship's Shortest Path](http://codeforces.com/problemset/problem/75/E)|Codeforces|Codeforces Beta Round #67 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|354|[Evacuation](http://codeforces.com/problemset/problem/78/E)|Codeforces|Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|355|[Track](http://codeforces.com/problemset/problem/83/C)|Codeforces|Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|356|[Azembler](http://codeforces.com/problemset/problem/93/C)|Codeforces|Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|357|[Horse Races](http://codeforces.com/problemset/problem/95/D)|Codeforces|Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|358|[Help Greg the Dwarf](http://codeforces.com/problemset/problem/98/C)|Codeforces|Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|359|[Arrangement](http://codeforces.com/problemset/problem/107/C)|Codeforces|Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|360|[Garden](http://codeforces.com/problemset/problem/152/E)|Codeforces|Codeforces Round #108 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|361|[Buses and People](http://codeforces.com/problemset/problem/160/E)|Codeforces|Codeforces Round #111 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|362|[Power Defence](http://codeforces.com/problemset/problem/175/E)|Codeforces|Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|363|[Delivering Carcinogen](http://codeforces.com/problemset/problem/198/C)|Codeforces|Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|364|[Tractor College](http://codeforces.com/problemset/problem/200/E)|Codeforces|Codeforces Round #126 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|365|[Transportation](http://codeforces.com/problemset/problem/203/E)|Codeforces|Codeforces Round #128 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|366|[Formurosa](http://codeforces.com/problemset/problem/217/C)|Codeforces|Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|367|[Piglet's Birthday](http://codeforces.com/problemset/problem/248/E)|Codeforces|Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|368|[Dormitory](http://codeforces.com/problemset/problem/254/E)|Codeforces|Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|369|[Dividing Kingdom](http://codeforces.com/problemset/problem/260/E)|Codeforces|Codeforces Round #158 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|370|[Greedy Elevator](http://codeforces.com/problemset/problem/257/E)|Codeforces|Codeforces Round #159 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|371|[Rhombus](http://codeforces.com/problemset/problem/263/E)|Codeforces|Codeforces Round #161 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|372|[The Last Hole!](http://codeforces.com/problemset/problem/274/C)|Codeforces|Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|373|[Fetch the Treasure](http://codeforces.com/problemset/problem/311/C)|Codeforces|Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|374|[Binary Key](http://codeforces.com/problemset/problem/332/E)|Codeforces|Codeforces Round #193 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|375|[Lucky Tickets](http://codeforces.com/problemset/problem/333/C)|Codeforces|Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|376|[Dima and Kicks](http://codeforces.com/problemset/problem/358/E)|Codeforces|Codeforces Round #208 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|377|[Neatness](http://codeforces.com/problemset/problem/359/E)|Codeforces|Codeforces Round #209 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|378|[Circling Round Treasures](http://codeforces.com/problemset/problem/375/C)|Codeforces|Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|379|[Ksenia and Combinatorics](http://codeforces.com/problemset/problem/382/E)|Codeforces|Codeforces Round #224 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|380|[Inna and Large Sweet Matrix](http://codeforces.com/problemset/problem/390/E)|Codeforces|Codeforces Round #229 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|381|[Yet Another Number Sequence](http://codeforces.com/problemset/problem/392/C)|Codeforces|Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|382|[Tree and Array](http://codeforces.com/problemset/problem/398/C)|Codeforces|Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|383|[Chemistry Experiment](http://codeforces.com/problemset/problem/431/E)|Codeforces|Codeforces Round #247 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|384|[Tachibana Kanade's Tofu](http://codeforces.com/problemset/problem/433/E)|Codeforces|Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|385|[Special Graph](http://codeforces.com/problemset/problem/435/E)|Codeforces|Codeforces Round #249 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|386|[Valera and Number](http://codeforces.com/problemset/problem/441/E)|Codeforces|Codeforces Round #252 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|387|[Roland and Rose](http://codeforces.com/problemset/problem/460/E)|Codeforces|Codeforces Round #262 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|388|[Mr. Kitayuta vs. Bamboos](http://codeforces.com/problemset/problem/505/E)|Codeforces|Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|389|[Berland Local Positioning System](http://codeforces.com/problemset/problem/534/E)|Codeforces|Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|390|[Strange Calculation and Cats](http://codeforces.com/problemset/problem/593/E)|Codeforces|Codeforces Round #329 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|391|[Wilbur and Strings](http://codeforces.com/problemset/problem/596/E)|Codeforces|Codeforces Round #331 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|392|[Sandy and Nuts](http://codeforces.com/problemset/problem/599/E)|Codeforces|Codeforces Round #332 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|393|[Runaway to a Shadow](http://codeforces.com/problemset/problem/681/E)|Codeforces|Codeforces Round #357 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|394|[Optimal Point](http://codeforces.com/problemset/problem/685/C)|Codeforces|Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|395|[Black Widow](http://codeforces.com/problemset/problem/704/C)|Codeforces|Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|396|[Road to Home](http://codeforces.com/problemset/problem/721/E)|Codeforces|Codeforces Round #374 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|397|[Dasha and cyclic table](http://codeforces.com/problemset/problem/754/E)|Codeforces|Codeforces Round #390 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|398|[Broken Tree](http://codeforces.com/problemset/problem/758/E)|Codeforces|Codeforces Round #392 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|399|[Choosing Carrot](http://codeforces.com/problemset/problem/794/E)|Codeforces|Tinkoff Challenge - Final Round (Codeforces Round #414, rated, Div. 1 + Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|400|[Mike and code of a permutation](http://codeforces.com/problemset/problem/798/E)|Codeforces|Codeforces Round #410 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|401|[Ever-Hungry Krakozyabra](http://codeforces.com/problemset/problem/833/C)|Codeforces|Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|402|[Vasya and Shifts](http://codeforces.com/problemset/problem/832/E)|Codeforces|Codeforces Round #425 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|403|[Awards For Contestants](http://codeforces.com/problemset/problem/873/E)|Codeforces|Educational Codeforces Round 30|9|
|<ul><li>- [ ] Done</li></ul>|404|[Policeman and a Tree](http://codeforces.com/problemset/problem/868/E)|Codeforces|Codeforces Round #438 by Sberbank and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|9|
|<ul><li>- [ ] Done</li></ul>|405|[Forward, march!](http://codeforces.com/problemset/problem/11/E)|Codeforces|Codeforces Beta Round #11|10|
|<ul><li>- [ ] Done</li></ul>|406|[DravDe saves the world](http://codeforces.com/problemset/problem/28/E)|Codeforces|Codeforces Beta Round #28 (Codeforces format)|10|
|<ul><li>- [ ] Done</li></ul>|407|[Helper](http://codeforces.com/problemset/problem/33/E)|Codeforces|Codeforces Beta Round #33 (Codeforces format)|10|
|<ul><li>- [ ] Done</li></ul>|408|[Baldman and the military](http://codeforces.com/problemset/problem/42/E)|Codeforces|Codeforces Beta Round #41|10|
|<ul><li>- [ ] Done</li></ul>|409|[Vacuum ?leaner](http://codeforces.com/problemset/problem/54/E)|Codeforces|Codeforces Beta Round #50|10|
|<ul><li>- [ ] Done</li></ul>|410|[Chess](http://codeforces.com/problemset/problem/57/E)|Codeforces|Codeforces Beta Round #53|10|
|<ul><li>- [ ] Done</li></ul>|411|[Expression](http://codeforces.com/problemset/problem/58/E)|Codeforces|Codeforces Beta Round #54 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|412|[World Evil](http://codeforces.com/problemset/problem/62/E)|Codeforces|Codeforces Beta Round #58|10|
|<ul><li>- [ ] Done</li></ul>|413|[Harry Potter and Moving Staircases](http://codeforces.com/problemset/problem/65/E)|Codeforces|Codeforces Beta Round #60|10|
|<ul><li>- [ ] Done</li></ul>|414|[Contact](http://codeforces.com/problemset/problem/68/E)|Codeforces|Codeforces Beta Round #62|10|
|<ul><li>- [ ] Done</li></ul>|415|[Shift It!](http://codeforces.com/problemset/problem/74/E)|Codeforces|Codeforces Beta Round #68|10|
|<ul><li>- [ ] Done</li></ul>|416|[Security System](http://codeforces.com/problemset/problem/79/E)|Codeforces|Codeforces Beta Round #71|10|
|<ul><li>- [ ] Done</li></ul>|417|[Lift and Throw](http://codeforces.com/problemset/problem/105/E)|Codeforces|Codeforces Beta Round #81|10|
|<ul><li>- [ ] Done</li></ul>|418|[Lucky Interval](http://codeforces.com/problemset/problem/109/E)|Codeforces|Codeforces Beta Round #84 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|419|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces|Codeforces Beta Round #88|10|
|<ul><li>- [ ] Done</li></ul>|420|[Alternative Reality](http://codeforces.com/problemset/problem/119/E)|Codeforces|Codeforces Beta Round #90|10|
|<ul><li>- [ ] Done</li></ul>|421|[Clever Fat Rat](http://codeforces.com/problemset/problem/185/C)|Codeforces|Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|422|[Doe Graphs](http://codeforces.com/problemset/problem/232/C)|Codeforces|Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|423|[Vasily the Bear and Painting Square](http://codeforces.com/problemset/problem/336/E)|Codeforces|Codeforces Round #195 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|424|[Two Circles](http://codeforces.com/problemset/problem/363/E)|Codeforces|Codeforces Round #211 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|425|[Summer Reading](http://codeforces.com/problemset/problem/370/E)|Codeforces|Codeforces Round #217 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|426|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces|Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|427|[Lightbulb for Minister](http://codeforces.com/problemset/problem/394/E)|Codeforces|Codeforces Round #231 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|428|[Olympic Games](http://codeforces.com/problemset/problem/401/E)|Codeforces|Codeforces Round #235 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|429|[Colored Jenga](http://codeforces.com/problemset/problem/424/E)|Codeforces|Codeforces Round #242 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|430|[DZY Loves Bridges](http://codeforces.com/problemset/problem/446/E)|Codeforces|Codeforces Round #255 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|431|[MUH and Lots and Lots of Segments](http://codeforces.com/problemset/problem/471/E)|Codeforces|Codeforces Round #269 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|432|[Design Tutorial: Learn from a Game](http://codeforces.com/problemset/problem/472/E)|Codeforces|Codeforces Round #270|10|
|<ul><li>- [ ] Done</li></ul>|433|[Wavy numbers](http://codeforces.com/problemset/problem/478/E)|Codeforces|Codeforces Round #273 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|434|[Kojiro and Furrari](http://codeforces.com/problemset/problem/581/E)|Codeforces|Codeforces Round #322 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|435|[BCPC](http://codeforces.com/problemset/problem/592/E)|Codeforces|Codeforces Round #328 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|436|[Frog Fights](http://codeforces.com/problemset/problem/625/E)|Codeforces|Codeforces Round #342 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|437|[To Hack or not to Hack](http://codeforces.com/problemset/problem/662/E)|Codeforces|CROC 2016 - Final Round [Private, For Onsite Finalists Only]|10|
|<ul><li>- [ ] Done</li></ul>|438|[Chain Reaction](http://codeforces.com/problemset/problem/666/D)|Codeforces|Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|439|[Mister B and Beacons on Field](http://codeforces.com/problemset/problem/819/C)|Codeforces|Codeforces Round #421 (Div. 1) & Codeforces Round #421 (Div. 2)|10|
