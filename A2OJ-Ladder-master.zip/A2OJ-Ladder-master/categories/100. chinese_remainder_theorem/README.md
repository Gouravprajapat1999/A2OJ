# 100. chinese_remainder_theorem


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces|Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|2|[Remainders Game](http://codeforces.com/problemset/problem/687/B)|Codeforces|Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|3|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces|Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|4|[GCD Table](http://codeforces.com/problemset/problem/338/D)|Codeforces|Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|5|[Little Elephant and Triangle](http://codeforces.com/problemset/problem/220/D)|Codeforces|Codeforces Round #136 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|6|[Nephren Runs a Cinema](http://codeforces.com/problemset/problem/896/D)|Codeforces|Codeforces Round #449 (Div. 1)|10|
