# 118. AI


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[TRIVIADOR](http://www.spoj.com/problems/TWOKINGS/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|2|[TRIVIADOR](http://www.spoj.com/problems/QWERTY04/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|3|[TWO KINGS](http://www.spoj.com/problems/CONQUER/)|SPOJ|9|
|<ul><li>- [ ] Done</li></ul>|4|[THE WITTY BOY](http://www.spoj.com/problems/WITTYBOY/)|SPOJ|10|
