# 124. Float_precision


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[GRADE POINT AVERAGE](http://www.spoj.com/problems/GPA1/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|2|[IPL - CRICKET TOURNAMENT](http://www.spoj.com/problems/IPL1/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|3|[CUBE ROOT](http://www.spoj.com/problems/CUBEROO2/)|SPOJ|6|
