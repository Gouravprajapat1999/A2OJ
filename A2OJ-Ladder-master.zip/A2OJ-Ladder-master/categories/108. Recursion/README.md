# 108. Recursion


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[I'm bored with life](http://codeforces.com/problemset/problem/822/A)|Codeforces|Codeforces Round #422 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Fibonacci Array](https://www.urionlinejudge.com.br/judge/en/problems/view/1176)|URI||1|
|<ul><li>- [ ] Done</li></ul>|3|[Hello Recursion](http://www.spoj.com/problems/HRECURS/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|4|[THE WEIRD STAIRCASE](http://www.spoj.com/problems/STAR3CAS/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|5|[PICK UP DROP ESCAPE](http://www.spoj.com/problems/CODEIT02/)|SPOJ||3|
