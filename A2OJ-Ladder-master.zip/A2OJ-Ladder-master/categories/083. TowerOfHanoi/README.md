# 083. TowerOfHanoi


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Tower Parking](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1980)|Live Archive|2007|Europe - Northwestern|1|
|<ul><li>- [ ] Done</li></ul>|2|[Hanoi Towers](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2051)|Live Archive|2007|Europe - Northeastern|2|
|<ul><li>- [ ] Done</li></ul>|3|[Strange Towers of Hanoi](http://acm.tju.edu.cn/toj/showp1731.html)|TJU|||3|
|<ul><li>- [ ] Done</li></ul>|4|[The Never Ending Towers of Hanoi](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=958)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|5|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces||Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|6|[Towers of Hanoi](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=409)|Live Archive|2001|North America - Rocky Mountain|5|
|<ul><li>- [ ] Done</li></ul>|7|[Four-Tower Towers of Hanoi](p?ID=189)|A2 Online Judge|||7|
|<ul><li>- [ ] Done</li></ul>|8|[Tower of Hanoi](http://codeforces.com/problemset/problem/392/B)|Codeforces||Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|9|[One Move from Towers of Hanoi](p?ID=188)|A2 Online Judge|||8|
