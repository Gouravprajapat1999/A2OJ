# 037. CUET


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Street Parade](http://www.spoj.com/problems/STPAR/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Team Queue](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=481)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Group Reverse](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2133)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|4|[Error Correction](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=482)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|5|[Exams](http://codeforces.com/problemset/problem/479/C)|Codeforces|Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Laptops](http://codeforces.com/problemset/problem/456/A)|Codeforces|Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Mass of Molecule](http://www.spoj.com/problems/MMASS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|8|[Queue](http://codeforces.com/problemset/problem/545/D)|Codeforces|Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Box of Bricks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=532)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|10|[WERTYU](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1023)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|11|[Rails](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=455)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|12|[Transform the Expression](http://www.spoj.com/problems/ONP/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|13|[Army Buddies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3778)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|14|[Adding Reversed Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=654)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|15|[A and B and Compilation Errors](http://codeforces.com/problemset/problem/519/B)|Codeforces|Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Fraction](http://codeforces.com/problemset/problem/854/A)|Codeforces|Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|1|
|<ul><li>- [ ] Done</li></ul>|17|["Accordian" Patience](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=63)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|18|[Web Navigation](http://poj.org/problem?id=1028)|PKU||1|
|<ul><li>- [ ] Done</li></ul>|19|[Mother bear](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1886)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|20|[The New Year: Meeting Friends](http://codeforces.com/problemset/problem/723/A)|Codeforces|Codeforces Round #375 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Newspaper](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2315)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|22|[The Bus Driver Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2384)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|23|[Machined Surfaces](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=355)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|24|[Timofey and cubes](http://codeforces.com/problemset/problem/764/B)|Codeforces|Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Sort the Array](http://codeforces.com/problemset/problem/451/B)|Codeforces|Codeforces Round #258 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Equation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=668)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|27|[Unimodal Array](http://codeforces.com/problemset/problem/831/A)|Codeforces|Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Sale](http://codeforces.com/problemset/problem/34/B)|Codeforces|Codeforces Beta Round #34 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces|Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Parentheses Balance](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=614)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|31|[Keyboard Layouts](http://codeforces.com/problemset/problem/831/B)|Codeforces|Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Vanya and Lanterns](http://codeforces.com/problemset/problem/492/B)|Codeforces|Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces|Codeforces Round #316 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|34|[Is it rated?](http://codeforces.com/problemset/problem/807/A)|Codeforces|Codeforces Round #412 (rated, Div. 2, base on VK Cup 2017 Round 3)|2|
|<ul><li>- [ ] Done</li></ul>|35|[DONALDO](http://www.spoj.com/problems/DONALDO/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|36|[Ada and Queue](http://www.spoj.com/problems/ADAQUEUE/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|37|[Chess Tourney](http://codeforces.com/problemset/problem/845/A)|Codeforces|Educational Codeforces Round 27|2|
|<ul><li>- [ ] Done</li></ul>|38|[Containers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3503)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|39|[Borrowers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=166)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|40|[Grid Successors](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2628)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|41|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces|Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[Musical Loop](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2491)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|43|[Chat Order](http://codeforces.com/problemset/problem/637/B)|Codeforces|VK Cup 2016 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|44|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces|Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|45|[Time Jumper (Easy)](p?ID=133)|A2 Online Judge||3|
|<ul><li>- [ ] Done</li></ul>|46|[Pole Position](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3302)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|47|[z-sort](http://codeforces.com/problemset/problem/652/B)|Codeforces|Educational Codeforces Round 10|3|
|<ul><li>- [ ] Done</li></ul>|48|[Unique Factorization](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1799)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|49|[Synching Signals](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=408)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|50|[Formula 1](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2935)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|51|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces|Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|52|[Minimal string](http://codeforces.com/problemset/problem/797/C)|Codeforces|Educational Codeforces Round 19|4|
|<ul><li>- [ ] Done</li></ul>|53|[Fruits](http://codeforces.com/problemset/problem/12/C)|Codeforces|Codeforces Beta Round #12 (Div 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|54|[The Smallest String Concatenation](http://codeforces.com/problemset/problem/632/C)|Codeforces|Educational Codeforces Round 9|4|
|<ul><li>- [ ] Done</li></ul>|55|[Brothers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3339)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|56|[Maximum Xor Secondary](http://codeforces.com/problemset/problem/280/B)|Codeforces|Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|5|
