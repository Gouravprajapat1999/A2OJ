# 131. Prefix_Sums


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Nikita and string](http://codeforces.com/problemset/problem/877/B)|Codeforces|Codeforces Round #442 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|2|[Star sky](http://codeforces.com/problemset/problem/835/C)|Codeforces|Codeforces Round #427 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|3|[Monitor](http://codeforces.com/problemset/problem/846/D)|Codeforces|Educational Codeforces Round 28|6|
