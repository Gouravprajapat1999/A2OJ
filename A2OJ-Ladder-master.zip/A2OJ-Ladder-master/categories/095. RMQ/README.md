# 095. RMQ


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Frequent values](http://www.spoj.com/problems/FREQUENT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Largest Rectangle in a Histogram](http://www.spoj.com/problems/HISTOGRA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Query on a tree II](http://www.spoj.com/problems/QTREE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Frequent values](http://acm.tju.edu.cn/toj/showp2913.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|5|[Binary Search Heap Construction](http://www.spoj.com/problems/HEAPULM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|6|[Imperial roads](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=6218)|Live Archive|2017|Latin America|5|
