# 112. 2D_Range_Queries


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Anton and Permutation](http://codeforces.com/problemset/problem/785/E)|Codeforces|Codeforces Round #404 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|2|[The Untended Antiquity](http://codeforces.com/problemset/problem/869/E)|Codeforces|Codeforces Round #439 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|3|[Iahub and Xors](http://codeforces.com/problemset/problem/341/D)|Codeforces|Codeforces Round #198 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|4|[Subtree Minimum Query](http://codeforces.com/problemset/problem/893/F)|Codeforces|Educational Codeforces Round 33 (Rated for Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|5|[Andryusha and Nervous Barriers](http://codeforces.com/problemset/problem/780/G)|Codeforces|?????????? 2017 - ????? (?????? ??? ??????-??????????)|9|
