# 075. Coin_Change


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Ingenuous Cubrency](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2078)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[Coin Change](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=615)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|3|[Making Change](http://acm.tju.edu.cn/toj/showp2768.html)|TJU|1|
|<ul><li>- [ ] Done</li></ul>|4|[Let Me Count The Ways](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=293)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|5|[Dollars](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=83)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|6|[Making Change](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=102)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|7|[Pay the Price](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1254)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|8|[Exact Change](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2512)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|9|[e-Coins](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1247)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|10|[Charu and Coin Distribution](http://www.spoj.com/problems/CBANK/)|SPOJ|3|
