# 048. Suffix_Array_Tree


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[I Love Strings!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1620)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Stammering Aliens](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2514)|Live Archive|2009|Europe - Southwestern|1|
|<ul><li>- [ ] Done</li></ul>|3|[Longest Common Substring](http://www.spoj.com/problems/LCS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Suffix Array](http://www.spoj.com/problems/SARRAY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[New Distinct Substrings](http://www.spoj.com/problems/SUBST1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Distinct Substrings](http://www.spoj.com/problems/DISUBSTR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Glass Beads](http://www.spoj.com/problems/BEADS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Lexicographical Substring Search](http://www.spoj.com/problems/SUBLEX/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Hidden Password](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=756)|Live Archive|2003|Europe - Southeastern|1|
|<ul><li>- [ ] Done</li></ul>|10|[Longest Contiguous Subsequence](http://acm.tju.edu.cn/toj/showp3601.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|11|[GATTACA](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2507)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|12|[Longest Common Substring II ](http://www.spoj.com/problems/LCS2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|13|[Glass Beads](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=660)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|14|[Minimum Rotations](http://www.spoj.com/problems/MINMOVE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|15|[Frequent Substrings](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1175)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|16|[Hidden Password](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4060)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|17|[Stammering Aliens](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3358)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|18|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|19|[Petya the Hero](http://acm.sgu.ru/problem.php?contest=0&problem=411)|SGU|||5|
|<ul><li>- [ ] Done</li></ul>|20|[Martian Strings](http://codeforces.com/problemset/problem/149/E)|Codeforces||Codeforces Round #106 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|21|[String](http://codeforces.com/problemset/problem/128/B)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|22|[Cyclical Quest](http://codeforces.com/problemset/problem/235/C)|Codeforces||Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|23|[String](http://codeforces.com/problemset/problem/123/D)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|24|[Genetic engineering](http://codeforces.com/problemset/problem/86/C)|Codeforces||Yandex.Algorithm 2011 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|25|[Deletion of Repeats](http://codeforces.com/problemset/problem/19/C)|Codeforces||Codeforces Beta Round #19|8|
|<ul><li>- [ ] Done</li></ul>|26|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces||Codeforces Round #129 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|27|[Fence](http://codeforces.com/problemset/problem/232/D)|Codeforces||Codeforces Round #144 (Div. 1)|9|
