# 135. Minimum_Enclosing_Circle


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Aliens](http://www.spoj.com/problems/ALIENS/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|2|[Minimum Diameter Circle](http://www.spoj.com/problems/QCJ4/)|SPOJ|2|
