# 119. tries


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Hardwood Species](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1167)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Phone List](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2347)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Hyper Prefix Sets](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2483)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|4|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces|Codeforces Round #367 (Div. 2)|3|
