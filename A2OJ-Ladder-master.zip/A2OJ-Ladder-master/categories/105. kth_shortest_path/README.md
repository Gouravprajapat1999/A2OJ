# 105. kth_shortest_path


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Dijkstra, Dijkstra.](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1747)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|2|[Connections](http://www.spoj.com/problems/CONNECT/)|SPOJ|4|
|<ul><li>- [ ] Done</li></ul>|3|[Not the Best](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1681)|UVA|4|
|<ul><li>- [ ] Done</li></ul>|4|[Always Late](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1283)|UVA|4|
|<ul><li>- [ ] Done</li></ul>|5|[Kth Shortest Path](http://www.spoj.com/problems/MKTHPATH/)|SPOJ|8|
