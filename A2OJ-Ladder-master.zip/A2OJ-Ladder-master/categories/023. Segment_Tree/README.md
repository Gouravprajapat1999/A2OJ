# 023. Segment_Tree


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Brackets](http://www.spoj.com/problems/BRCKTS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[The Great Ball](http://www.spoj.com/problems/BYTESE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Can you answer these queries I](http://www.spoj.com/problems/GSS1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Can you answer these queries III](http://www.spoj.com/problems/GSS3/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Can you answer these queries V](http://www.spoj.com/problems/GSS5/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Maximum Sum](http://www.spoj.com/problems/KGSS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Election Posters](http://www.spoj.com/problems/POSTERS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[The day of the competitors](http://www.spoj.com/problems/NICEDAY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[K-th Number](http://www.spoj.com/problems/MKTHNUM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Yodaness Level](http://www.spoj.com/problems/YODANESS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[AND Rounds](http://www.spoj.com/problems/ANDROUND/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Multiples of 3](http://www.spoj.com/problems/MULTQ3/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Light Switching](http://www.spoj.com/problems/LITE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[D-query](http://www.spoj.com/problems/DQUERY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Frequent values](http://www.spoj.com/problems/FREQUENT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Can you answer these queries II](http://www.spoj.com/problems/GSS2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|17|[Sum of Squares with Segment Tree](http://www.spoj.com/problems/SEGSQRSS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Horrible Queries](http://www.spoj.com/problems/HORRIBLE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|19|[K-query](http://www.spoj.com/problems/KQUERY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Largest Rectangle in a Histogram](http://www.spoj.com/problems/HISTOGRA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[Ordering the Soldiers](http://www.spoj.com/problems/ORDERS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Frequent values](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2176)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Roti Prata](http://www.spoj.com/problems/PRATA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Negative Score](http://www.spoj.com/problems/RPLN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Can you answer these queries IV](http://www.spoj.com/problems/GSS4/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Query on a tree again!](http://www.spoj.com/problems/QTREE3/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Order statistic set](http://www.spoj.com/problems/ORDERSET/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|29|[Interval Product](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4150)|Live Archive|2012|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|30|[Coin Flip](http://www.codechef.com/problems/CONFLIP)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|31|[Find String Roots](http://www.spoj.com/problems/FINDSR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|32|[Count on a tree](http://www.spoj.com/problems/COT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|33|[Flipping Coins](http://www.codechef.com/problems/FLIPCOIN)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|34|[Inversion Count](http://www.spoj.com/problems/INVCNT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|35|[Help R2-D2!](http://www.spoj.com/problems/HELPR2D2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|36|[Race Against Time](http://www.spoj.com/problems/RACETIME/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|37|[Can you answer these queries VI](http://www.spoj.com/problems/GSS6/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|38|[Mummy Madness](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3137)|Live Archive|2011|World Finals - Orlando|2|
|<ul><li>- [ ] Done</li></ul>|39|[Counting Primes ](http://www.spoj.com/problems/CNTPRIME/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|40|[Snow White and the N dwarfs](http://www.spoj.com/problems/PATULJCI/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|41|[Greg and Array](http://codeforces.com/problemset/problem/295/A)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[Ahoy, Pirates!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2397)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|43|[Interval Product](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3977)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|44|[Living with Courage](http://www.spoj.com/problems/COURAGE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|45|[Frequent values](http://acm.tju.edu.cn/toj/showp2913.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|46|[Light Switching](http://acm.tju.edu.cn/toj/showp3148.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|47|[Potentiometers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3238)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|48|[WIND VANE](http://www.spoj.com/problems/WINDVANE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|49|[Handball](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|50|[Query on a tree IV](http://www.spoj.com/problems/QTREE4/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|51|[Query on a tree V](http://www.spoj.com/problems/QTREE5/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|52|[Brackets II](http://www.spoj.com/problems/BRCKTS2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|53|[Can you answer these queries VII](http://www.spoj.com/problems/GSS7/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|54|[Chef and medium problem 2](http://www.codechef.com/problems/CHEFD)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|55|[Binary Search Heap Construction](http://www.spoj.com/problems/HEAPULM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|56|[Congruence Equation](http://www.spoj.com/problems/DPEQN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|57|[Temple Queues](http://www.spoj.com/problems/TEMPLEQ/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|58|[GM plants](http://www.spoj.com/problems/IOPC1207/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|59|[Blue Mary Needs Help Again](http://www.spoj.com/problems/CASHIER/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|60|[Sum of Distinct Numbers](http://www.spoj.com/problems/XXXXXXXX/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|61|[GCD 2010](http://acm.timus.ru/problem.aspx?space=1&num=1846)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|62|[Dima and Staircase](http://codeforces.com/problemset/problem/272/C)|Codeforces||Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|63|[Salary Management](http://www.spoj.com/problems/SALMAN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|64|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|65|[Query on a tree VI](http://www.spoj.com/problems/QTREE6/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|66|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|67|[Maximum number, GCD condition](http://www.codechef.com/problems/ANUGCD)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|68|[Xor Queries](http://www.codechef.com/problems/XRQRS)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|69|[K-query II](http://www.spoj.com/problems/KQUERY2/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|70|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces||Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|71|[Multiply Game](http://acm.tju.edu.cn/toj/showp3440.html)|TJU|||3|
|<ul><li>- [ ] Done</li></ul>|72|[ForbiddenSum](http://www.codechef.com/problems/FRBSUM)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|73|[Pashmak and Parmida's problem](http://codeforces.com/problemset/problem/459/D)|Codeforces||Codeforces Round #261 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|74|[Modular Equations](http://codeforces.com/problemset/problem/495/B)|Codeforces||Codeforces Round #282 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|75|[Destroying Array](http://codeforces.com/problemset/problem/722/C)|Codeforces||Intel Code Challenge Elimination Round (Div. 1 + Div. 2, combined)|3|
|<ul><li>- [ ] Done</li></ul>|76|[Stern-Brocot Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2325)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|77|[Squares](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1048)|Live Archive|2004|North America - Rocky Mountain|3|
|<ul><li>- [ ] Done</li></ul>|78|[Interval Product](https://www.urionlinejudge.com.br/judge/en/problems/view/1301)|URI|||3|
|<ul><li>- [ ] Done</li></ul>|79|[LCM GCD Love](http://www.spoj.com/problems/LGLOVE/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|80|[Who is The Boss](http://www.spoj.com/problems/VBOSS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|81|[01 Sequence](http://www.spoj.com/problems/SEQ1/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|82|[Enjoy Sum with Operations](http://www.spoj.com/problems/SUMSUM/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|83|[Impossible Boss](http://www.spoj.com/problems/DCEPC11I/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|84|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|85|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces||Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|86|[Lucky Number](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1850)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|87|[Query on a tree VII](http://www.spoj.com/problems/QTREE7/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|88|[Roots of a Tree](http://www.codechef.com/problems/TROOT)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|89|[Brute-force Algorithm](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2745)|Live Archive|2009|Asia - Shanghai|4|
|<ul><li>- [ ] Done</li></ul>|90|[Nested Segments](http://acm.timus.ru/problem.aspx?space=1&num=1987)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|91|[SKYLINE](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3673)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|92|[Circular RMQ](http://codeforces.com/problemset/problem/52/C)|Codeforces||Codeforces Testing Round #1|4|
|<ul><li>- [ ] Done</li></ul>|93|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces||Codeforces Round #343 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|94|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|95|[Ant colony](http://codeforces.com/problemset/problem/474/F)|Codeforces||Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|96|[The Closest Pair](http://codeforces.com/problemset/problem/311/A)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|97|[XOR Minimization](http://www.codechef.com/problems/MINXOR)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|98|[Preparing for Merge Sort](http://codeforces.com/problemset/problem/847/B)|Codeforces||2017-2018 ACM-ICPC, NEERC, Southern Subregional Contest, qualification stage (Online Mirror, ACM-ICPC Rules, Teams Preferred)|4|
|<ul><li>- [ ] Done</li></ul>|99|[Bash and a Tough Math Puzzle](http://codeforces.com/problemset/problem/914/D)|Codeforces||Codecraft-18 and Codeforces Round #458 (Div. 1 + Div. 2, combined)|4|
|<ul><li>- [ ] Done</li></ul>|100|[Rip Van Winkle's Code](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3867)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|101|[Copying Data](http://codeforces.com/problemset/problem/292/E)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|102|[``Dynamic'' Inversion](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3141)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|103|[Rectangle Query](http://www.codechef.com/problems/QRECT)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|104|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces||Codeforces Round #250 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|105|[Fun with AGp](http://www.codechef.com/problems/FUNAGP)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|106|[A Simple Task](http://codeforces.com/problemset/problem/558/E)|Codeforces||Codeforces Round #312 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|107|[Misha and Permutations Summation](http://codeforces.com/problemset/problem/501/D)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|108|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces||Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|109|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces||Codeforces Round #200 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|110|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces||Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|111|[Cards Sorting](http://codeforces.com/problemset/problem/830/B)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|5|
|<ul><li>- [ ] Done</li></ul>|112|[PolandBall and Polygon](http://codeforces.com/problemset/problem/755/D)|Codeforces||8VC Venture Cup 2017 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|113|[R2D2 and Droid Army](http://codeforces.com/problemset/problem/514/D)|Codeforces||Codeforces Round #291 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|114|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces||Codeforces Round #365 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|115|[Factory Repairs](http://codeforces.com/problemset/problem/627/B)|Codeforces||8VC Venture Cup 2016 - Final Round|5|
|<ul><li>- [ ] Done</li></ul>|116|[Danil and a Part-time Job](http://codeforces.com/problemset/problem/877/E)|Codeforces||Codeforces Round #442 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|117|[SUM and REPLACE](http://codeforces.com/problemset/problem/920/F)|Codeforces||Educational Codeforces Round 37 (Rated for Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|118|[High and Low](http://www.spoj.com/problems/HILO/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|119|[On Changing Tree](http://codeforces.com/problemset/problem/396/C)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|120|[DZY Loves Colors](http://codeforces.com/problemset/problem/444/C)|Codeforces||Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|121|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|122|[Segment Tree](http://www.spoj.com/problems/SEGTREE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|123|[Drazil and Park](http://codeforces.com/problemset/problem/515/E)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|124|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces||Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|125|[Lucky Queries](http://codeforces.com/problemset/problem/145/E)|Codeforces||Codeforces Round #104 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|126|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces||Codeforces Round #321 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|127|[Valera and Queries](http://codeforces.com/problemset/problem/369/E)|Codeforces||Codeforces Round #216 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|128|[Yaroslav and Divisors](http://codeforces.com/problemset/problem/301/D)|Codeforces||Codeforces Round #182 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|129|[New Year Domino](http://codeforces.com/problemset/problem/500/E)|Codeforces||Good Bye 2014|6|
|<ul><li>- [ ] Done</li></ul>|130|[Subsequences](http://codeforces.com/problemset/problem/597/C)|Codeforces||Testing Round #12|6|
|<ul><li>- [ ] Done</li></ul>|131|[Turn Off The TV](http://codeforces.com/problemset/problem/863/E)|Codeforces||Educational Codeforces Round 29|6|
|<ul><li>- [ ] Done</li></ul>|132|[Save the Python Programmers!](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3128)|Live Archive|2010|North America - Pacific Northwest|6|
|<ul><li>- [ ] Done</li></ul>|133|[Union on Tree](http://www.codechef.com/problems/BTREE)|CodeChef|||7|
|<ul><li>- [ ] Done</li></ul>|134|[Sign on Fence](http://codeforces.com/problemset/problem/484/E)|Codeforces||Codeforces Round #276 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|135|[Count The Indexes 2](http://www.spoj.com/problems/CNTINDX2/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|136|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|137|[Little Elephant and Inversions](http://codeforces.com/problemset/problem/220/E)|Codeforces||Codeforces Round #136 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|138|[Points](http://codeforces.com/problemset/problem/19/D)|Codeforces||Codeforces Beta Round #19|7|
|<ul><li>- [ ] Done</li></ul>|139|[Lucky Array](http://codeforces.com/problemset/problem/121/E)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|140|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces||Codeforces Round #337 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|141|[Little Girl and Problem on Trees](http://codeforces.com/problemset/problem/276/E)|Codeforces||Codeforces Round #169 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|142|[Kool Konstructions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4622)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|143|[Army Creation](http://codeforces.com/problemset/problem/813/E)|Codeforces||Educational Codeforces Round 22|7|
|<ul><li>- [ ] Done</li></ul>|144|[Segments](p?ID=166)|A2 Online Judge|||7|
|<ul><li>- [ ] Done</li></ul>|145|[Allowance](https://www.urionlinejudge.com.br/judge/en/problems/view/2546)|URI|||7|
|<ul><li>- [ ] Done</li></ul>|146|[Blogger language](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4407)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|147|[Misha and Palindrome Degree](http://codeforces.com/problemset/problem/501/E)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|148|[Optimize!](http://codeforces.com/problemset/problem/338/E)|Codeforces||Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|149|[Jeff and Removing Periods](http://codeforces.com/problemset/problem/351/D)|Codeforces||Codeforces Round #204 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|150|[REQ](http://codeforces.com/problemset/problem/594/D)|Codeforces||Codeforces Round #330 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|151|[TorCoder](http://codeforces.com/problemset/problem/240/F)|Codeforces||Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|152|[Linear Kingdom Races](http://codeforces.com/problemset/problem/115/E)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|153|[Alphabet Permutations](http://codeforces.com/problemset/problem/610/E)|Codeforces||Codeforces Round #337 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|154|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces||Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|155|[Eyes Closed](http://codeforces.com/problemset/problem/895/E)|Codeforces||Codeforces Round #448 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|156|[Ada and Species](http://www.spoj.com/problems/ADACABAA/)|SPOJ|||8|
|<ul><li>- [ ] Done</li></ul>|157|[Function](http://codeforces.com/problemset/problem/455/E)|Codeforces||Codeforces Round #260 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|158|[Camping Groups](http://codeforces.com/problemset/problem/173/E)|Codeforces||Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|159|[To the moon](http://acm.tju.edu.cn/toj/showp3913.html)|TJU|||10|
|<ul><li>- [ ] Done</li></ul>|160|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces||Codeforces Beta Round #88|10|
|<ul><li>- [ ] Done</li></ul>|161|[#dynamic-programming&nbsp;(168)</span>](http://www.spoj.com/problems/tag/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|162|[Nikita](http://acm.timus.ru/problem.aspx?space=1&num=2042)|Timus|||10|
