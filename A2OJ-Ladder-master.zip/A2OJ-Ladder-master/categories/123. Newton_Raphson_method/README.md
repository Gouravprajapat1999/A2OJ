# 123. Newton_Raphson_method


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Easy Calculation](http://www.spoj.com/problems/TRIGALGE/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Square Root](http://www.spoj.com/problems/SQRROOT/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|3|[Cube Root](http://www.spoj.com/problems/CUBERT/)|SPOJ|3|
