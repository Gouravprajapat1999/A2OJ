# 061. Aho-Corasick


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[I Love Strings!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1620)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Word Puzzles](http://www.spoj.com/problems/WPUZZLES/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|3|[Substring Problem](http://www.spoj.com/problems/SUB_PROB/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|4|[Emoticons](http://www.spoj.com/problems/EMOTICON/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|5|[Censored!](http://acm.timus.ru/problem.aspx?space=1&num=1158)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|6|[Substring](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2463)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|7|[Lost in Space](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=677)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|8|[GRE Words Revenge](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4552)|Live Archive|2013|Asia - Chengdu|5|
|<ul><li>- [ ] Done</li></ul>|9|[Lucky Common Subsequence](http://codeforces.com/problemset/problem/346/B)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|10|[Obscene Words Filter](http://acm.timus.ru/problem.aspx?space=1&num=1269)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|11|[Prefixes and suffixes](http://acm.sgu.ru/problem.php?contest=0&problem=505)|SGU|||7|
|<ul><li>- [ ] Done</li></ul>|12|[Growing Strings](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3396)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|13|[Frequency of String](http://codeforces.com/problemset/problem/963/D)|Codeforces||Tinkoff Internship Warmup Round 2018 and Codeforces Round #475 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|14|[e-Government](http://codeforces.com/problemset/problem/163/E)|Codeforces||VK Cup 2012 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|15|[Duff is Mad](http://codeforces.com/problemset/problem/587/F)|Codeforces||Codeforces Round #326 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|16|[Digits of Number Pi](http://codeforces.com/problemset/problem/585/F)|Codeforces||Codeforces Round #325 (Div. 1)|10|
