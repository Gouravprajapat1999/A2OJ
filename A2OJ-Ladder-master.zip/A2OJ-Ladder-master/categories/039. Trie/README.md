# 039. Trie


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[XOR Sum](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2683)|Live Archive|2009|Asia - Amritapuri|1|
|<ul><li>- [ ] Done</li></ul>|2|[Phone List](http://www.spoj.com/problems/PHONELST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Chocolate](http://www.spoj.com/problems/CHOCOLA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Search in the dictionary!](http://www.spoj.com/problems/DICT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Phone List](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2347)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Distinct Substrings](http://www.spoj.com/problems/DISUBSTR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Order statistic set](http://www.spoj.com/problems/ORDERSET/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Multiple Morse Matches](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=427)|Live Archive|2001|Europe - Central & Europe - Southwestern|2|
|<ul><li>- [ ] Done</li></ul>|9|[SubXor](http://www.spoj.com/problems/SUBXOR/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|10|[Decoding Morse Sequences](http://www.spoj.com/problems/MORSE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|11|[Phone List](http://acm.tju.edu.cn/toj/showp2935.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|12|[Diccionário Portuñol](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3803)|Live Archive|2011|Latin America|2|
|<ul><li>- [ ] Done</li></ul>|13|[Chu&#7895;i t&#7915;](http://vn.spoj.com/problems/CHAIN2/)|SPOJ Vietnam|||2|
|<ul><li>- [ ] Done</li></ul>|14|[Hyper Prefix Sets](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2483)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|15|[Watto and Mechanism](http://codeforces.com/problemset/problem/514/C)|Codeforces||Codeforces Round #291 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|16|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces||Codeforces Round #367 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|17|[Perfect Rhyme](http://www.spoj.com/problems/PRHYME/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|18|[Designing T-Shirts](http://www.spoj.com/problems/TAP2012D/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|19|[Polo the Penguin and the Tree](http://www.codechef.com/problems/PPTREE)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|20|[Good Substrings](http://codeforces.com/problemset/problem/271/D)|Codeforces||Codeforces Round #166 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|21|[Tin m&#7853;t](http://vn.spoj.com/problems/SEC/)|SPOJ Vietnam|||3|
|<ul><li>- [ ] Done</li></ul>|22|[Xor Queries](http://www.codechef.com/problems/XRQRS)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|23|[Perfect Security](http://codeforces.com/problemset/problem/923/C)|Codeforces||VK Cup 2018 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|24|[Matrix Matcher](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1960)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|25|[Frequent Substrings](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1175)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|26|[Sevenk Love Oimaster](http://www.spoj.com/problems/JZPGYZ/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|27|[Shortest Names](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3950)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|28|[Secret Message](http://acm.tju.edu.cn/toj/showp3166.html)|TJU|||4|
|<ul><li>- [ ] Done</li></ul>|29|[Cellphone Typing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3971)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|30|[Polycarp's phone book](http://codeforces.com/problemset/problem/858/D)|Codeforces||?????????? 2018 - ?????????? ????? 1|4|
|<ul><li>- [ ] Done</li></ul>|31|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|32|[XOR Minimization](http://www.codechef.com/problems/MINXOR)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|33|[Message Coding](http://www.codechef.com/problems/KGP13G)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|34|[Subarray Xor](http://www.codechef.com/problems/SUBBXOR)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|35|[Sausage Maximization](http://codeforces.com/problemset/problem/282/E)|Codeforces||Codeforces Round #173 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|36|[Vitya and Strange Lesson](http://codeforces.com/problemset/problem/842/D)|Codeforces||Codeforces Round #430 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|37|[Multiple Morse Matches](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3554)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|38|[Tree](p?ID=262)|A2 Online Judge|||7|
|<ul><li>- [ ] Done</li></ul>|39|[Old Berland Language](http://codeforces.com/problemset/problem/37/C)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|40|[Beautiful Subarrays](http://codeforces.com/problemset/problem/665/E)|Codeforces||Educational Codeforces Round 12|7|
|<ul><li>- [ ] Done</li></ul>|41|[Kuro and GCD and XOR and SUM](http://codeforces.com/problemset/problem/979/D)|Codeforces||Codeforces Round #482 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|42|[Xor-MST](http://codeforces.com/problemset/problem/888/G)|Codeforces||Educational Codeforces Round 32|8|
