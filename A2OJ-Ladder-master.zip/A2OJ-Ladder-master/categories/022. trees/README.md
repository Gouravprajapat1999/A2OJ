# 022. trees


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Longest path in a tree](http://www.spoj.com/problems/PT07Z/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Chocolate](http://www.spoj.com/problems/CHOCOLA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Kefa and Park](http://codeforces.com/problemset/problem/580/C)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces||Codeforces Round #247 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Nice Binary Trees](http://www.spoj.com/problems/NICEBTRE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Pashmak and Garden](http://codeforces.com/problemset/problem/459/A)|Codeforces||Codeforces Round #261 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3769)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|10|[Bear and Forgotten Tree 3](http://codeforces.com/problemset/problem/639/B)|Codeforces||VK Cup 2016 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|11|[Reposts](http://codeforces.com/problemset/problem/522/A)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|12|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|13|[Tree _order](http://www.spoj.com/problems/TREEORD/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|14|[Timofey and a tree](http://codeforces.com/problemset/problem/763/A)|Codeforces||Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|15|[Journey](http://codeforces.com/problemset/problem/839/C)|Codeforces||Codeforces Round #428 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|16|[Fibonacci System](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2377)|Live Archive|2008|Europe - Northeastern|2|
|<ul><li>- [ ] Done</li></ul>|17|[Choosing Capital for Treeland](http://codeforces.com/problemset/problem/219/D)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|18|[Distance in Tree](http://codeforces.com/problemset/problem/161/D)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|19|[Ants Colony](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3390)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|20|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|21|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|22|[Valera and Elections](http://codeforces.com/problemset/problem/369/C)|Codeforces||Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|23|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces||Codeforces Round #358 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|24|[Anton and Making Potions](http://codeforces.com/problemset/problem/734/C)|Codeforces||Codeforces Round #379 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|25|[Okabe and Boxes](http://codeforces.com/problemset/problem/821/C)|Codeforces||Codeforces Round #420 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|26|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces||Codeforces Round #367 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|27|[AVL Tree](http://www.spoj.com/problems/SDITSAVL/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|28|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|29|[Eternal Victory](http://codeforces.com/problemset/problem/61/D)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|30|[Roads not only in Berland](http://codeforces.com/problemset/problem/25/D)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|31|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|32|[Count Minimum Spanning Trees](http://www.spoj.com/problems/MSTS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|33|[Closest distance](http://www.spoj.com/problems/GANNHAT/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|34|[Lomsat gelral](http://codeforces.com/problemset/problem/600/E)|Codeforces||Educational Codeforces Round 2|4|
|<ul><li>- [ ] Done</li></ul>|35|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces||Codeforces Round #316 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|36|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|37|[New Year Santa Network](http://codeforces.com/problemset/problem/500/D)|Codeforces||Good Bye 2014|4|
|<ul><li>- [ ] Done</li></ul>|38|[Design Tutorial: Inverse the Problem](http://codeforces.com/problemset/problem/472/D)|Codeforces||Codeforces Round #270|4|
|<ul><li>- [ ] Done</li></ul>|39|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|40|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|41|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|42|[Vessels](http://codeforces.com/problemset/problem/371/D)|Codeforces||Codeforces Round #218 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|43|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|44|[Book of Evil](http://codeforces.com/problemset/problem/337/D)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|45|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|46|[Zero Tree](http://codeforces.com/problemset/problem/274/B)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|47|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|48|[Tree Construction](http://codeforces.com/problemset/problem/675/D)|Codeforces||Codeforces Round #353 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|49|[Connecting Universities](http://codeforces.com/problemset/problem/700/B)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|50|[Alyona and a tree](http://codeforces.com/problemset/problem/739/B)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|51|[Chloe and pleasant prizes](http://codeforces.com/problemset/problem/743/D)|Codeforces||Codeforces Round #384 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|52|[Ilya And The Tree](http://codeforces.com/problemset/problem/842/C)|Codeforces||Codeforces Round #430 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|53|[Garland](http://codeforces.com/problemset/problem/767/C)|Codeforces||Codeforces Round #398 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|54|[Blood Cousins](http://codeforces.com/problemset/problem/208/E)|Codeforces||Codeforces Round #130 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|55|[Spiders](http://codeforces.com/problemset/problem/120/F)|Codeforces||School Regional Team Contest, Saratov, 2011|5|
|<ul><li>- [ ] Done</li></ul>|56|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|57|[Lucky Tree](http://codeforces.com/problemset/problem/109/C)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|58|[Two Paths](http://codeforces.com/problemset/problem/14/D)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|59|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|60|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces||Codeforces Round #338 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|61|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces||Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|62|[Super M](http://codeforces.com/problemset/problem/592/D)|Codeforces||Codeforces Round #328 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|63|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|64|[Valid Sets](http://codeforces.com/problemset/problem/486/D)|Codeforces||Codeforces Round #277 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|65|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces||Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|66|[4-point polyline](http://codeforces.com/problemset/problem/452/B)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|67|[Dungeons and Candies](http://codeforces.com/problemset/problem/436/C)|Codeforces||Zepto Code Rush 2014|5|
|<ul><li>- [ ] Done</li></ul>|68|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces||Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|69|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces||Codeforces Round #200 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|70|[Sausage Maximization](http://codeforces.com/problemset/problem/282/E)|Codeforces||Codeforces Round #173 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|71|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|72|[Kay and Snowflake](http://codeforces.com/problemset/problem/685/B)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|73|[Misha, Grisha and Underground](http://codeforces.com/problemset/problem/832/D)|Codeforces||Codeforces Round #425 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|74|[An overnight dance in discotheque](http://codeforces.com/problemset/problem/814/D)|Codeforces||Codeforces Round #418 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|75|[Count on a Treap](http://www.codechef.com/problems/COT5)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|76|[Vasya and a Tree](http://codeforces.com/problemset/problem/1076/E)|Codeforces||Educational Codeforces Round 54 (Rated for Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|77|[Ant on the Tree](http://codeforces.com/problemset/problem/29/D)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|78|[Ants in Leaves](http://codeforces.com/problemset/problem/622/E)|Codeforces||Educational Codeforces Round 7|6|
|<ul><li>- [ ] Done</li></ul>|79|[Hamiltonian Spanning Tree](http://codeforces.com/problemset/problem/618/D)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|6|
|<ul><li>- [ ] Done</li></ul>|80|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|81|[Road Improvement](http://codeforces.com/problemset/problem/543/D)|Codeforces||Codeforces Round #302 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|82|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces||Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|83|[Demiurges Play Again](http://codeforces.com/problemset/problem/538/E)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|84|[Work Group](http://codeforces.com/problemset/problem/533/B)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|6|
|<ul><li>- [ ] Done</li></ul>|85|[Information Graph](http://codeforces.com/problemset/problem/466/E)|Codeforces||Codeforces Round #266 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|86|[Caisa and Tree](http://codeforces.com/problemset/problem/463/E)|Codeforces||Codeforces Round #264 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|87|[On Changing Tree](http://codeforces.com/problemset/problem/396/C)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|88|[New Year Tree](http://codeforces.com/problemset/problem/379/F)|Codeforces||Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|89|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|90|[WTF?](http://codeforces.com/problemset/problem/290/C)|Codeforces||April Fools Day Contest 2013|6|
|<ul><li>- [ ] Done</li></ul>|91|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|92|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces||Codeforces Round #357 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|93|[Avoiding a disaster](p?ID=214)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|94|[Karen and Supermarket](http://codeforces.com/problemset/problem/815/C)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|95|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces||Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|96|[Little Elephant and Tree](http://codeforces.com/problemset/problem/258/E)|Codeforces||Codeforces Round #157 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|97|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces||Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|98|[World Eater Brothers](http://codeforces.com/problemset/problem/238/C)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|99|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces||Codeforces Round #143 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|100|[Paint Tree](http://codeforces.com/problemset/problem/196/C)|Codeforces||Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|101|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces||Codeforces Round #112 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|102|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|103|[Gift](http://codeforces.com/problemset/problem/76/A)|Codeforces||All-Ukrainian School Olympiad in Informatics|7|
|<ul><li>- [ ] Done</li></ul>|104|[Pursuit For Artifacts](http://codeforces.com/problemset/problem/652/E)|Codeforces||Educational Codeforces Round 10|7|
|<ul><li>- [ ] Done</li></ul>|105|[Road Improvement](http://codeforces.com/problemset/problem/638/C)|Codeforces||VK Cup 2016 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|106|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces||Codeforces Round #343 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|107|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces||Codeforces Round #333 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|108|[Happy Tree Party](http://codeforces.com/problemset/problem/593/D)|Codeforces||Codeforces Round #329 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|109|[Bribes](http://codeforces.com/problemset/problem/575/B)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|110|[Bear and Drawing](http://codeforces.com/problemset/problem/573/C)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|111|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces||Codeforces Round #311 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|112|[Case of Computer Network](http://codeforces.com/problemset/problem/555/E)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|113|[Treeland Tour](http://codeforces.com/problemset/problem/490/F)|Codeforces||Codeforces Round #279 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|114|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|115|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces||Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|116|[Ksenia and Pawns](http://codeforces.com/problemset/problem/382/D)|Codeforces||Codeforces Round #224 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|117|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces||Codeforces Round #220 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|118|[Divisor Tree](http://codeforces.com/problemset/problem/337/E)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|119|[Little Girl and Problem on Trees](http://codeforces.com/problemset/problem/276/E)|Codeforces||Codeforces Round #169 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|120|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces||Codeforces Round #158 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|121|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|122|[Old Berland Language](http://codeforces.com/problemset/problem/37/C)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|123|[Iahub and Xors](http://codeforces.com/problemset/problem/341/D)|Codeforces||Codeforces Round #198 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|124|[New Roads](http://codeforces.com/problemset/problem/746/G)|Codeforces||Codeforces Round #386 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|125|[Peterson Polyglot](http://codeforces.com/problemset/problem/778/C)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|126|[Ralph And His Tour in Binary Country](http://codeforces.com/problemset/problem/894/D)|Codeforces||Codeforces Round #447 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|127|[Tree](p?ID=262)|A2 Online Judge|||7|
|<ul><li>- [ ] Done</li></ul>|128|[IT Restaurants](http://codeforces.com/problemset/problem/212/E)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|8|
|<ul><li>- [ ] Done</li></ul>|129|[Archaeology](http://codeforces.com/problemset/problem/176/E)|Codeforces||Croc Champ 2012 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|130|[e-Government](http://codeforces.com/problemset/problem/163/E)|Codeforces||VK Cup 2012 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|131|[Castle](http://codeforces.com/problemset/problem/101/D)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|132|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|133|[Genetic engineering](http://codeforces.com/problemset/problem/86/C)|Codeforces||Yandex.Algorithm 2011 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|134|[Petya and Tree](http://codeforces.com/problemset/problem/85/C)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|135|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|136|[The Chocolate Spree](http://codeforces.com/problemset/problem/633/F)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|137|[Magic Matrix](http://codeforces.com/problemset/problem/632/F)|Codeforces||Educational Codeforces Round 9|8|
|<ul><li>- [ ] Done</li></ul>|138|[Preorder Test](http://codeforces.com/problemset/problem/627/D)|Codeforces||8VC Venture Cup 2016 - Final Round|8|
|<ul><li>- [ ] Done</li></ul>|139|[Kingdom and its Cities](http://codeforces.com/problemset/problem/613/D)|Codeforces||Codeforces Round #339 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|140|[Zublicanes and Mumocrates](http://codeforces.com/problemset/problem/581/F)|Codeforces||Codeforces Round #322 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|141|[Matching Names](http://codeforces.com/problemset/problem/566/A)|Codeforces||VK Cup 2015 - Finals, online mirror|8|
|<ul><li>- [ ] Done</li></ul>|142|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces||Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|143|[Birthday](http://codeforces.com/problemset/problem/494/D)|Codeforces||Codeforces Round #282 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|144|[Tourists](http://codeforces.com/problemset/problem/487/E)|Codeforces||Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|145|[DZY Loves Planting](http://codeforces.com/problemset/problem/444/E)|Codeforces||Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|146|[Adam and Tree](http://codeforces.com/problemset/problem/442/D)|Codeforces||Codeforces Round #253 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|147|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces||Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|148|[Balance](http://codeforces.com/problemset/problem/317/C)|Codeforces||Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|149|[Shaass the Great](http://codeforces.com/problemset/problem/294/E)|Codeforces||Codeforces Round #178 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|150|[Close Vertices](http://codeforces.com/problemset/problem/293/E)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|151|[Polo the Penguin and Trees ](http://codeforces.com/problemset/problem/288/D)|Codeforces||Codeforces Round #177 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|152|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces||Codeforces Round #121 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|153|[Arpa’s letter-marked tree and Mehrdad’s Dokhtar-kosh paths](http://codeforces.com/problemset/problem/741/D)|Codeforces||Codeforces Round #383 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|154|[Noble Knight's Path](http://codeforces.com/problemset/problem/226/E)|Codeforces||Codeforces Round #140 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|155|[Alien DNA](http://codeforces.com/problemset/problem/217/E)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|156|[Garden](http://codeforces.com/problemset/problem/152/E)|Codeforces||Codeforces Round #108 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|157|[Freezing with Style](http://codeforces.com/problemset/problem/150/E)|Codeforces||Codeforces Round #107 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|158|[Pairs](http://codeforces.com/problemset/problem/81/E)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|9|
|<ul><li>- [ ] Done</li></ul>|159|[Information Reform](http://codeforces.com/problemset/problem/70/E)|Codeforces||Codeforces Beta Round #64|9|
|<ul><li>- [ ] Done</li></ul>|160|[Caterpillar](http://codeforces.com/problemset/problem/51/F)|Codeforces||Codeforces Beta Round #48|9|
|<ul><li>- [ ] Done</li></ul>|161|[Clockwork Bomb](http://codeforces.com/problemset/problem/650/E)|Codeforces||Codeforces Round #345 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|162|[Pastoral Oddities](http://codeforces.com/problemset/problem/603/E)|Codeforces||Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|163|[Tavas on the Path](http://codeforces.com/problemset/problem/536/E)|Codeforces||Codeforces Round #299 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|164|[Fox And Travelling](http://codeforces.com/problemset/problem/512/D)|Codeforces||Codeforces Round #290 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|165|[Random Function and Tree](http://codeforces.com/problemset/problem/482/D)|Codeforces||Codeforces Round #275 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|166|[Berland Federalization](http://codeforces.com/problemset/problem/440/D)|Codeforces||Testing Round #10|9|
|<ul><li>- [ ] Done</li></ul>|167|[Big Problems for Organizers](http://codeforces.com/problemset/problem/418/D)|Codeforces||RCC 2014 Warmup (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|168|[Pilgrims](http://codeforces.com/problemset/problem/348/E)|Codeforces||Codeforces Round #202 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|169|[Maze](http://codeforces.com/problemset/problem/123/E)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|170|[Singer House](http://codeforces.com/problemset/problem/830/D)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|9|
|<ul><li>- [ ] Done</li></ul>|171|[Arkady and a Nobody-men](http://codeforces.com/problemset/problem/860/E)|Codeforces||Codeforces Round #434 (Div. 1, based on Technocup 2018 Elimination Round 1)|9|
|<ul><li>- [ ] Done</li></ul>|172|[Timofey and a flat tree](http://codeforces.com/problemset/problem/763/D)|Codeforces||Codeforces Round #395 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|173|[Surprise me!](http://codeforces.com/problemset/problem/809/E)|Codeforces||Codeforces Round #415 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|174|[Tree and Table](http://codeforces.com/problemset/problem/251/E)|Codeforces||Codeforces Round #153 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|175|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces||Codeforces Beta Round #88|10|
|<ul><li>- [ ] Done</li></ul>|176|[Help King](http://codeforces.com/problemset/problem/98/B)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|10|
|<ul><li>- [ ] Done</li></ul>|177|[Leaders](http://codeforces.com/problemset/problem/97/E)|Codeforces||Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|178|[Galaxy Union](http://codeforces.com/problemset/problem/48/G)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|179|[Bear and Chemistry](http://codeforces.com/problemset/problem/639/F)|Codeforces||VK Cup 2016 - Round 1|10|
|<ul><li>- [ ] Done</li></ul>|180|[Island Puzzle](http://codeforces.com/problemset/problem/627/F)|Codeforces||8VC Venture Cup 2016 - Final Round|10|
|<ul><li>- [ ] Done</li></ul>|181|[Mirror Box](http://codeforces.com/problemset/problem/578/F)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round]|10|
|<ul><li>- [ ] Done</li></ul>|182|[Campus](http://codeforces.com/problemset/problem/571/D)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|183|[Restoring Map](http://codeforces.com/problemset/problem/566/E)|Codeforces||VK Cup 2015 - Finals, online mirror|10|
|<ul><li>- [ ] Done</li></ul>|184|[Logistical Questions](http://codeforces.com/problemset/problem/566/C)|Codeforces||VK Cup 2015 - Finals, online mirror|10|
|<ul><li>- [ ] Done</li></ul>|185|[Berland Miners](http://codeforces.com/problemset/problem/533/A)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|186|[Spiders Evil Plan](http://codeforces.com/problemset/problem/526/G)|Codeforces||ZeptoLab Code Rush 2015|10|
|<ul><li>- [ ] Done</li></ul>|187|[Misha and LCP on Tree](http://codeforces.com/problemset/problem/504/E)|Codeforces||Codeforces Round #285 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|188|[New Year Running](http://codeforces.com/problemset/problem/500/G)|Codeforces||Good Bye 2014|10|
|<ul><li>- [ ] Done</li></ul>|189|[ELCA](http://codeforces.com/problemset/problem/482/E)|Codeforces||Codeforces Round #275 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|190|[An easy problem about trees](http://codeforces.com/problemset/problem/457/F)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|191|[Furukawa Nagisa's Tree](http://codeforces.com/problemset/problem/434/E)|Codeforces||Codeforces Round #248 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|192|[Escaping on Beaveractor](http://codeforces.com/problemset/problem/331/D3)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|193|[Red-Black Cobweb](http://codeforces.com/problemset/problem/833/D)|Codeforces||Codeforces Round #426 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|194|[ALT](http://codeforces.com/problemset/problem/786/E)|Codeforces||Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|195|[Sloth](http://codeforces.com/problemset/problem/891/D)|Codeforces||Codeforces Round #446 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|196|[In a Trap](http://codeforces.com/problemset/problem/840/E)|Codeforces||Codeforces Round #429 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|197|[Restore the Tree](http://codeforces.com/problemset/problem/871/E)|Codeforces||Codeforces Round #440 (Div. 1, based on Technocup 2018 Elimination Round 2)|10|
|<ul><li>- [ ] Done</li></ul>|198|[Perpetual Motion Machine](http://codeforces.com/problemset/problem/830/E)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|10|
|<ul><li>- [ ] Done</li></ul>|199|[Rap God](http://codeforces.com/problemset/problem/786/D)|Codeforces||Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|200|[Iron Man](http://codeforces.com/problemset/problem/704/E)|Codeforces||Codeforces Round #366 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|201|[Nikita and game](http://codeforces.com/problemset/problem/842/E)|Codeforces||Codeforces Round #430 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|202|[Tree and XOR](http://codeforces.com/problemset/problem/1055/F)|Codeforces||Mail.Ru Cup 2018 Round 2|10|
