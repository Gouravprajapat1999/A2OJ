# 144. dp


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[A DP Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3641)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|2|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces|Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
