# 049. 0_1_Knapsack


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[CD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=565)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Party Schedule](http://www.spoj.com/problems/PARTY/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Scuba diver](http://www.spoj.com/problems/SCUBADIV/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Piggy-Bank](http://www.spoj.com/problems/PIGBANK/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|5|[The Knapsack Problem](http://www.spoj.com/problems/KNAPSACK/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|6|[Dividing coins](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=503)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|7|[Divisible Group Sums](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1557)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|8|[Wachovia Bank](http://www.spoj.com/problems/WACHOVIA/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|9|[SuperSale](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1071)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|10|[Luggage](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1605)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|11|[Blueberries](http://www.spoj.com/problems/RPLB/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|12|[Large Knapsack](http://www.spoj.com/problems/LKS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|13|[Sum of Different Primes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3654)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|14|[Cow Frisbee Team](http://acm.tju.edu.cn/toj/showp3208.html)|TJU||2|
|<ul><li>- [ ] Done</li></ul>|15|[Blackout](http://www.spoj.com/problems/BLACKOUT/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|16|[Ferry Loading](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1202)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|17|[Trouble of 13-Dots](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1760)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|18|[Diving for Gold](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=931)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|19|[Boxes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1944)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|20|[Eat or Study](http://acm.tju.edu.cn/toj/showp3991.html)|TJU||3|
|<ul><li>- [ ] Done</li></ul>|21|[Arpa's weak amphitheater and Mehrdad's valuable Hoses](http://codeforces.com/problemset/problem/741/B)|Codeforces|Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|22|[Best Coalitions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2705)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|23|[Term Strategy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2316)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|24|[Let's Yum Cha!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2613)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|25|[Bag Problem](http://acm.tju.edu.cn/toj/showp3539.html)|TJU||4|
|<ul><li>- [ ] Done</li></ul>|26|[First Blood](http://acm.tju.edu.cn/toj/showp4091.html)|TJU||4|
|<ul><li>- [ ] Done</li></ul>|27|[Account Book](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2932)|UVA||4|
