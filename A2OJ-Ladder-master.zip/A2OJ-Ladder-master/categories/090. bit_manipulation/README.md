# 090. bit_manipulation


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Bitmap](http://www.spoj.com/problems/BITMAP/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[XOR Maximization](http://www.spoj.com/problems/XMAX/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Assignments](http://www.spoj.com/problems/ASSIGN/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Polo the Penguin and the XOR](http://www.codechef.com/problems/PPXOR)|CodeChef||2|
|<ul><li>- [ ] Done</li></ul>|5|[Fetching Cooking Tools](http://www.codechef.com/problems/TOOLS)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|6|[A Simple Task](http://codeforces.com/problemset/problem/11/D)|Codeforces|Codeforces Beta Round #11|5|
|<ul><li>- [ ] Done</li></ul>|7|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces|Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|8|[Design Tutorial: Change the Goal](http://codeforces.com/problemset/problem/472/F)|Codeforces|Codeforces Round #270|9|
