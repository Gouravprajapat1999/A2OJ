# 072. Reasoning


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Why this kolaveri di](http://www.spoj.com/problems/WTK/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[DOTA HEROES](http://www.spoj.com/problems/DOTAA/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[FANCY NUMBERS](http://www.spoj.com/problems/FANCY/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|4|[HOW MANY GAMES](http://www.spoj.com/problems/GAMES/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|5|[DIE HARD](http://www.spoj.com/problems/DIEHARD/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|6|[EVEN COUNT](http://www.spoj.com/problems/GEEKOUNT/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|7|[FUN WITH LETTERS](http://www.spoj.com/problems/FUNNUMS/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|8|[LUCKYNINE](http://www.spoj.com/problems/NITHY/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|9|[FOREVER ALONE](http://www.spoj.com/problems/ALONE/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|10|[THE JUMPING BALL](http://www.spoj.com/problems/JUMPBALL/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|11|[GAMING ARENA](http://www.spoj.com/problems/GAMARENA/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|12|[THE N WITTY FRIENDS](http://www.spoj.com/problems/WITTY/)|SPOJ|7|
|<ul><li>- [ ] Done</li></ul>|13|[TREE SHAPES](http://www.spoj.com/problems/CODEIT01/)|SPOJ|8|
