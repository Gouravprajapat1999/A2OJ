# 021. Codeforces_Div._1_D


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces|Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces|Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|3|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces|Codeforces Round #250 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|4|[Tricky Function](http://codeforces.com/problemset/problem/429/D)|Codeforces|Codeforces Round #245 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|5|[Antimatter](http://codeforces.com/problemset/problem/383/D)|Codeforces|Codeforces Round #225 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|6|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces|Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|7|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces|Codeforces Round #200 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|8|[Little Artem and Time Machine](http://codeforces.com/problemset/problem/641/E)|Codeforces|VK Cup 2016 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|9|[Clique in the Divisibility Graph](http://codeforces.com/problemset/problem/566/F)|Codeforces|VK Cup 2015 - Finals, online mirror|5|
|<ul><li>- [ ] Done</li></ul>|10|[Kindergarten](http://codeforces.com/problemset/problem/484/D)|Codeforces|Codeforces Round #276 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|11|[Serega and Fun](http://codeforces.com/problemset/problem/455/D)|Codeforces|Codeforces Round #260 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|12|[Jzzhu and Numbers](http://codeforces.com/problemset/problem/449/D)|Codeforces|Codeforces Round #257 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|13|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces|Codeforces Round #194 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|14|[Yaroslav and Divisors](http://codeforces.com/problemset/problem/301/D)|Codeforces|Codeforces Round #182 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|15|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces|Codeforces Round #142 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|16|[Road Improvement](http://codeforces.com/problemset/problem/543/D)|Codeforces|Codeforces Round #302 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|17|[High Cry](http://codeforces.com/problemset/problem/875/D)|Codeforces|Codeforces Round #441 (Div. 1, by Moscow Team Olympiad) & Codeforces Round #441 (Div. 2, by Moscow Team Olympiad)|6|
|<ul><li>- [ ] Done</li></ul>|18|[Zip-line](http://codeforces.com/problemset/problem/650/D)|Codeforces|Codeforces Round #345 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|19|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces|Codeforces Round #333 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|20|[Top Secret Task](http://codeforces.com/problemset/problem/590/D)|Codeforces|Codeforces Round #327 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|21|[Mike and Fish](http://codeforces.com/problemset/problem/547/D)|Codeforces|Codeforces Round #305 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|22|[Fuzzy Search](http://codeforces.com/problemset/problem/528/D)|Codeforces|Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|23|[Traffic Jams in the Land](http://codeforces.com/problemset/problem/498/D)|Codeforces|Codeforces Round #284 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|24|[Sereja and Squares](http://codeforces.com/problemset/problem/425/D)|Codeforces|Codeforces Round #243 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|25|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces|Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|26|[Beautiful Pairs of Numbers](http://codeforces.com/problemset/problem/403/D)|Codeforces|Codeforces Round #236 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|27|[Iahub and Xors](http://codeforces.com/problemset/problem/341/D)|Codeforces|Codeforces Round #198 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|28|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces|Codeforces Round #188 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|29|[Lovely Matrix](http://codeforces.com/problemset/problem/274/D)|Codeforces|Codeforces Round #168 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|30|[The table](http://codeforces.com/problemset/problem/226/D)|Codeforces|Codeforces Round #140 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|31|[Couple Cover](http://codeforces.com/problemset/problem/691/F)|Codeforces|Educational Codeforces Round 14|7|
|<ul><li>- [ ] Done</li></ul>|32|[Package Delivery](http://codeforces.com/problemset/problem/627/C)|Codeforces|8VC Venture Cup 2016 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|33|[Lizard Era: Beginning](http://codeforces.com/problemset/problem/585/D)|Codeforces|Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|34|[Case of a Top Secret](http://codeforces.com/problemset/problem/555/D)|Codeforces|Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|35|[Anton and School](http://codeforces.com/problemset/problem/734/F)|Codeforces|Codeforces Round #379 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|36|[Social Network](http://codeforces.com/problemset/problem/524/D)|Codeforces|VK Cup 2015 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|37|[Nudist Beach](http://codeforces.com/problemset/problem/553/D)|Codeforces|Codeforces Round #309 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|38|[Bacterial Melee](http://codeforces.com/problemset/problem/756/D)|Codeforces|8VC Venture Cup 2017 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|39|[Axel and Marston in Bitland](http://codeforces.com/problemset/problem/780/F)|Codeforces|?????????? 2017 - ????? (?????? ??? ??????-??????????)|7|
|<ul><li>- [ ] Done</li></ul>|40|[Power Tree](http://codeforces.com/problemset/problem/607/D)|Codeforces|Codeforces Round #336 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|41|[Board Game](http://codeforces.com/problemset/problem/605/D)|Codeforces|Codeforces Round #335 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|42|[REQ](http://codeforces.com/problemset/problem/594/D)|Codeforces|Codeforces Round #330 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|43|[Shop](http://codeforces.com/problemset/problem/521/D)|Codeforces|Codeforces Round #295 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|44|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces|Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|45|[Birthday](http://codeforces.com/problemset/problem/494/D)|Codeforces|Codeforces Round #282 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|46|[Parcels](http://codeforces.com/problemset/problem/480/D)|Codeforces|Codeforces Round #274 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|47|[World of Darkraft - 2](http://codeforces.com/problemset/problem/464/D)|Codeforces|Codeforces Round #265 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|48|[DZY Loves Strings](http://codeforces.com/problemset/problem/444/D)|Codeforces|Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|49|[Adam and Tree](http://codeforces.com/problemset/problem/442/D)|Codeforces|Codeforces Round #253 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|50|[Mashmokh and Water Tanks](http://codeforces.com/problemset/problem/414/D)|Codeforces|Codeforces Round #240 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|51|[Instant Messanger](http://codeforces.com/problemset/problem/398/D)|Codeforces|Codeforces Round #233 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|52|[Developing Game](http://codeforces.com/problemset/problem/377/D)|Codeforces|Codeforces Round #222 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|53|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces|Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|54|[Sereja and Sets](http://codeforces.com/problemset/problem/367/D)|Codeforces|Codeforces Round #215 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|55|[Ghd](http://codeforces.com/problemset/problem/364/D)|Codeforces|Codeforces Round #213 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|56|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces|Codeforces Round #207 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|57|[Jeff and Removing Periods](http://codeforces.com/problemset/problem/351/D)|Codeforces|Codeforces Round #204 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|58|[Turtles](http://codeforces.com/problemset/problem/348/D)|Codeforces|Codeforces Round #202 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|59|[Robot Control](http://codeforces.com/problemset/problem/346/D)|Codeforces|Codeforces Round #201 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|60|[GCD Table](http://codeforces.com/problemset/problem/338/D)|Codeforces|Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|61|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces|Codeforces Round #187 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|62|[Interval Cubing](http://codeforces.com/problemset/problem/311/D)|Codeforces|Codeforces Round #185 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|63|[Greg and Caves](http://codeforces.com/problemset/problem/295/D)|Codeforces|Codeforces Round #179 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|64|[Polo the Penguin and Trees ](http://codeforces.com/problemset/problem/288/D)|Codeforces|Codeforces Round #177 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|65|[Cows and Cool Sequences](http://codeforces.com/problemset/problem/283/D)|Codeforces|Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|66|[k-Maximum Subsequence Sum](http://codeforces.com/problemset/problem/280/D)|Codeforces|Codeforces Round #172 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|67|[Maxim and Increasing Subsequence](http://codeforces.com/problemset/problem/261/D)|Codeforces|Codeforces Round #160 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|68|[Little Elephant and Broken Sorting](http://codeforces.com/problemset/problem/258/D)|Codeforces|Codeforces Round #157 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|69|[Clues](http://codeforces.com/problemset/problem/156/D)|Codeforces|Codeforces Round #110 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|70|[Legen...](http://codeforces.com/problemset/problem/696/D)|Codeforces|Codeforces Round #362 (Div. 1) & Codeforces Round #362 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|71|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces|Codeforces Round #360 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|72|[Kay and Eternity](http://codeforces.com/problemset/problem/685/D)|Codeforces|Codeforces Round #359 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|73|[Roads in Yusland](http://codeforces.com/problemset/problem/671/D)|Codeforces|Codeforces Round #352 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|74|[Bear and Bowling 4](http://codeforces.com/problemset/problem/660/F)|Codeforces|Educational Codeforces Round 11|8|
|<ul><li>- [ ] Done</li></ul>|75|[Paper task](http://codeforces.com/problemset/problem/653/F)|Codeforces|IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|76|[Magic Matrix](http://codeforces.com/problemset/problem/632/F)|Codeforces|Educational Codeforces Round 9|8|
|<ul><li>- [ ] Done</li></ul>|77|[Double Knapsack](http://codeforces.com/problemset/problem/618/F)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|78|[Kingdom and its Cities](http://codeforces.com/problemset/problem/613/D)|Codeforces|Codeforces Round #339 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|79|[Frogs and mosquitoes](http://codeforces.com/problemset/problem/609/F)|Codeforces|Educational Codeforces Round 3|8|
|<ul><li>- [ ] Done</li></ul>|80|[LCS Again](http://codeforces.com/problemset/problem/578/D)|Codeforces|Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|8|
|<ul><li>- [ ] Done</li></ul>|81|[Flights for Regular Customers](http://codeforces.com/problemset/problem/576/D)|Codeforces|Codeforces Round #319 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|82|[Conveyor Belts](http://codeforces.com/problemset/problem/487/D)|Codeforces|Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|83|[Cup Trick](http://codeforces.com/problemset/problem/420/D)|Codeforces|Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|84|[New Year and Cleaning](http://codeforces.com/problemset/problem/611/F)|Codeforces|Good Bye 2015|8|
|<ul><li>- [ ] Done</li></ul>|85|[Animals and Puzzle](http://codeforces.com/problemset/problem/713/D)|Codeforces|Codeforces Round #371 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|86|[Arpa’s letter-marked tree and Mehrdad’s Dokhtar-kosh paths](http://codeforces.com/problemset/problem/741/D)|Codeforces|Codeforces Round #383 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|87|[Best Edge Weight](http://codeforces.com/problemset/problem/827/D)|Codeforces|Codeforces Round #423 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #423 (Div. 2, rated, based on VK Cup Finals)|8|
|<ul><li>- [ ] Done</li></ul>|88|[Destiny](http://codeforces.com/problemset/problem/840/D)|Codeforces|Codeforces Round #429 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|89|[Michael and Charging Stations](http://codeforces.com/problemset/problem/853/D)|Codeforces|Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises)|8|
|<ul><li>- [ ] Done</li></ul>|90|[Wizard's Tour](http://codeforces.com/problemset/problem/858/F)|Codeforces|?????????? 2018 - ?????????? ????? 1|8|
|<ul><li>- [ ] Done</li></ul>|91|[Power Tower](http://codeforces.com/problemset/problem/906/D)|Codeforces|Codeforces Round #454 (Div. 1, based on Technocup 2018 Elimination Round 4) & Codeforces Round #454 (Div. 2, based on Technocup 2018 Elimination Round 4)|8|
|<ul><li>- [ ] Done</li></ul>|92|[Birthday](http://codeforces.com/problemset/problem/623/D)|Codeforces|AIM Tech Round (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|93|[Ruminations on Ruminants](http://codeforces.com/problemset/problem/603/D)|Codeforces|Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|94|[Tavas in Kansas](http://codeforces.com/problemset/problem/536/D)|Codeforces|Codeforces Round #299 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|95|[Fox And Travelling](http://codeforces.com/problemset/problem/512/D)|Codeforces|Codeforces Round #290 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|96|[Misha and XOR](http://codeforces.com/problemset/problem/504/D)|Codeforces|Codeforces Round #285 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|97|[Random Function and Tree](http://codeforces.com/problemset/problem/482/D)|Codeforces|Codeforces Round #275 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|98|[Dreamoon and Binary](http://codeforces.com/problemset/problem/477/D)|Codeforces|Codeforces Round #272 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|99|[Appleman and Complicated Task](http://codeforces.com/problemset/problem/461/D)|Codeforces|Codeforces Round #263 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|100|[Little Pony and Elements of Harmony](http://codeforces.com/problemset/problem/453/D)|Codeforces|Codeforces Round #259 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|101|[Nanami's Power Plant](http://codeforces.com/problemset/problem/434/D)|Codeforces|Codeforces Round #248 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|102|[Largest Submatrix 3](http://codeforces.com/problemset/problem/407/D)|Codeforces|Codeforces Round #239 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|103|[On Sum of Number of Inversions in Permutations](http://codeforces.com/problemset/problem/396/D)|Codeforces|Codeforces Round #232 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|104|[Fox and Perfect Sets](http://codeforces.com/problemset/problem/388/D)|Codeforces|Codeforces Round #228 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|105|[Sereja and Cinema](http://codeforces.com/problemset/problem/380/D)|Codeforces|Codeforces Round #223 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|106|[Levko and Sets](http://codeforces.com/problemset/problem/360/D)|Codeforces|Codeforces Round #210 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|107|[Transferring Pyramid](http://codeforces.com/problemset/problem/354/D)|Codeforces|Codeforces Round #206 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|108|[The Evil Temple and the Moving Rocks](http://codeforces.com/problemset/problem/329/D)|Codeforces|Codeforces Round #192 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|109|[Ciel and Flipboard](http://codeforces.com/problemset/problem/321/D)|Codeforces|Codeforces Round #190 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|110|[Have You Ever Heard About the Word?](http://codeforces.com/problemset/problem/319/D)|Codeforces|Codeforces Round #189 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|111|[Rotatable Number](http://codeforces.com/problemset/problem/303/D)|Codeforces|Codeforces Round #183 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|112|[Color the Carpet](http://codeforces.com/problemset/problem/297/D)|Codeforces|Codeforces Round #180 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|113|[Tourists](http://codeforces.com/problemset/problem/286/D)|Codeforces|Codeforces Round #176 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|114|[Google Code Jam](http://codeforces.com/problemset/problem/277/D)|Codeforces|Codeforces Round #170 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|115|[Dima and Figure](http://codeforces.com/problemset/problem/273/D)|Codeforces|Codeforces Round #167 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|116|[Maximum Waterfall](http://codeforces.com/problemset/problem/269/D)|Codeforces|Codeforces Round #165 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|117|[Colorful Stones](http://codeforces.com/problemset/problem/264/D)|Codeforces|Codeforces Round #162 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|118|[Liars and Serge](http://codeforces.com/problemset/problem/256/D)|Codeforces|Codeforces Round #156 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|119|[Two Sets](http://codeforces.com/problemset/problem/251/D)|Codeforces|Codeforces Round #153 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|120|[Donkey and Stars](http://codeforces.com/problemset/problem/249/D)|Codeforces|Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|121|[Graph Game](http://codeforces.com/problemset/problem/235/D)|Codeforces|Codeforces Round #146 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|122|[Fence](http://codeforces.com/problemset/problem/232/D)|Codeforces|Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|123|[Little Elephant and Triangle](http://codeforces.com/problemset/problem/220/D)|Codeforces|Codeforces Round #136 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|124|[Bitonix' Patrol](http://codeforces.com/problemset/problem/217/D)|Codeforces|Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|125|[Stars](http://codeforces.com/problemset/problem/213/D)|Codeforces|Codeforces Round #131 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|126|[Little Elephant and Retro Strings](http://codeforces.com/problemset/problem/204/D)|Codeforces|Codeforces Round #129 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|127|[Brand New Problem](http://codeforces.com/problemset/problem/201/D)|Codeforces|Codeforces Round #127 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|128|[The Next Good String](http://codeforces.com/problemset/problem/196/D)|Codeforces|Codeforces Round #124 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|129|[Two Segments](http://codeforces.com/problemset/problem/193/D)|Codeforces|Codeforces Round #122 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|130|[Metro Scheme](http://codeforces.com/problemset/problem/191/D)|Codeforces|Codeforces Round #121 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|131|[BRT Contract ](http://codeforces.com/problemset/problem/187/D)|Codeforces|Codeforces Round #119 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|132|[Visit of the Great](http://codeforces.com/problemset/problem/185/D)|Codeforces|Codeforces Round #118 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|133|[Flatland Fencing](http://codeforces.com/problemset/problem/154/D)|Codeforces|Codeforces Round #109 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|134|[Mission Impassable](http://codeforces.com/problemset/problem/150/D)|Codeforces|Codeforces Round #107 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|135|[Lucky Pair](http://codeforces.com/problemset/problem/145/D)|Codeforces|Codeforces Round #104 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|136|[Help Shrek and Donkey 2](http://codeforces.com/problemset/problem/142/D)|Codeforces|Codeforces Round #102 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|137|[World of Darkraft](http://codeforces.com/problemset/problem/138/D)|Codeforces|Codeforces Beta Round #99 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|138|[Incorrect Flow](http://codeforces.com/problemset/problem/708/D)|Codeforces|AIM Tech Round 3 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|139|[T-Shirts](http://codeforces.com/problemset/problem/702/F)|Codeforces|Educational Codeforces Round 15|9|
|<ul><li>- [ ] Done</li></ul>|140|[Huffman Coding on Segment](http://codeforces.com/problemset/problem/700/D)|Codeforces|Codeforces Round #364 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|141|[Limak and Shooting Points](http://codeforces.com/problemset/problem/698/D)|Codeforces|Codeforces Round #363 (Div. 1) & Codeforces Round #363 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|142|[Lena and Queries](http://codeforces.com/problemset/problem/678/F)|Codeforces|Educational Codeforces Round 13|9|
|<ul><li>- [ ] Done</li></ul>|143|[Bear and Chase](http://codeforces.com/problemset/problem/679/D)|Codeforces|Codeforces Round #356 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|144|[Bear and Paradox](http://codeforces.com/problemset/problem/639/E)|Codeforces|VK Cup 2016 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|145|[Edge coloring of bipartite graph](http://codeforces.com/problemset/problem/600/F)|Codeforces|Educational Codeforces Round 2|9|
|<ul><li>- [ ] Done</li></ul>|146|[Bear and Cavalry](http://codeforces.com/problemset/problem/573/D)|Codeforces|Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|147|[Sign Posts](http://codeforces.com/problemset/problem/568/D)|Codeforces|Codeforces Round #315 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|148|[Randomizer](http://codeforces.com/problemset/problem/559/D)|Codeforces|Codeforces Round #313 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|149|[Superhero's Job](http://codeforces.com/problemset/problem/542/D)|Codeforces|VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|9|
|<ul><li>- [ ] Done</li></ul>|150|[Sereja and Squares](http://codeforces.com/problemset/problem/314/E)|Codeforces|Codeforces Round #187 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|151|[Big Problems for Organizers](http://codeforces.com/problemset/problem/418/D)|Codeforces|RCC 2014 Warmup (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|152|[Large Refrigerator](http://codeforces.com/problemset/problem/163/D)|Codeforces|VK Cup 2012 Round 2|9|
|<ul><li>- [ ] Done</li></ul>|153|[Deputies](http://codeforces.com/problemset/problem/173/D)|Codeforces|Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|154|[Minimum Diameter](http://codeforces.com/problemset/problem/164/D)|Codeforces|VK Cup 2012 Round 3|9|
|<ul><li>- [ ] Done</li></ul>|155|[Hyper String](http://codeforces.com/problemset/problem/176/D)|Codeforces|Croc Champ 2012 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|156|[T-shirt](http://codeforces.com/problemset/problem/183/D)|Codeforces|Croc Champ 2012 - Final|9|
|<ul><li>- [ ] Done</li></ul>|157|[Cutting a Fence](http://codeforces.com/problemset/problem/212/D)|Codeforces|VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|158|[Ksusha and Square](http://codeforces.com/problemset/problem/293/D)|Codeforces|Croc Champ 2013 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|159|[Reclamation](http://codeforces.com/problemset/problem/325/D)|Codeforces|MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|160|[Rectangles and Square](http://codeforces.com/problemset/problem/335/D)|Codeforces|MemSQL start[c]up Round 2 - online version|9|
|<ul><li>- [ ] Done</li></ul>|161|[Andrew and Chemistry](http://codeforces.com/problemset/problem/718/D)|Codeforces|Codeforces Round #373 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|162|[Permutations](http://codeforces.com/problemset/problem/736/D)|Codeforces|Codeforces Round #382 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|163|[Timofey and a flat tree](http://codeforces.com/problemset/problem/763/D)|Codeforces|Codeforces Round #395 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|164|[Parquet Re-laying](http://codeforces.com/problemset/problem/778/D)|Codeforces|Codeforces Round #402 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|165|[Varying Kibibits](http://codeforces.com/problemset/problem/772/D)|Codeforces|VK Cup 2017 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|166|[Perishable Roads](http://codeforces.com/problemset/problem/773/D)|Codeforces|VK Cup 2017 - Round 3|9|
|<ul><li>- [ ] Done</li></ul>|167|[Hitchhiking in the Baltic States](http://codeforces.com/problemset/problem/809/D)|Codeforces|Codeforces Round #415 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|168|[Karen and Cards](http://codeforces.com/problemset/problem/815/D)|Codeforces|Codeforces Round #419 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|169|[Singer House](http://codeforces.com/problemset/problem/830/D)|Codeforces|Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|9|
|<ul><li>- [ ] Done</li></ul>|170|[Tournament Construction](http://codeforces.com/problemset/problem/850/D)|Codeforces|Codeforces Round #432 (Div. 1, based on IndiaHacks Final Round 2017)|9|
|<ul><li>- [ ] Done</li></ul>|171|[Magic Breeding](http://codeforces.com/problemset/problem/878/D)|Codeforces|Codeforces Round #443 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|172|[Weighting a Tree](http://codeforces.com/problemset/problem/901/D)|Codeforces|Codeforces Round #453 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|173|[Stranger Trees](http://codeforces.com/problemset/problem/917/D)|Codeforces|Codeforces Round #459 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|174|[Chain Reaction](http://codeforces.com/problemset/problem/666/D)|Codeforces|Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|175|[Gears](http://codeforces.com/problemset/problem/497/D)|Codeforces|Codeforces Round #283 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|176|[Tree](http://codeforces.com/problemset/problem/468/D)|Codeforces|Codeforces Round #268 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|177|[DZY Loves Games](http://codeforces.com/problemset/problem/446/D)|Codeforces|Codeforces Round #255 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|178|[Three Arrays](http://codeforces.com/problemset/problem/392/D)|Codeforces|Codeforces Round #230 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|179|[Cubes](http://codeforces.com/problemset/problem/243/D)|Codeforces|Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|180|[Tape Programming](http://codeforces.com/problemset/problem/238/D)|Codeforces|Codeforces Round #148 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|181|[Spider](http://codeforces.com/problemset/problem/223/D)|Codeforces|Codeforces Round #138 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|182|[Cube Snake](http://codeforces.com/problemset/problem/198/D)|Codeforces|Codeforces Round #125 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|183|[Wizards and Roads](http://codeforces.com/problemset/problem/167/D)|Codeforces|Codeforces Round #114 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|184|[Captain America](http://codeforces.com/problemset/problem/704/D)|Codeforces|Codeforces Round #366 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|185|[Bearish Fanpages](http://codeforces.com/problemset/problem/643/D)|Codeforces|VK Cup 2016 - Round 3|10|
|<ul><li>- [ ] Done</li></ul>|186|[To Hack or not to Hack](http://codeforces.com/problemset/problem/662/E)|Codeforces|CROC 2016 - Final Round [Private, For Onsite Finalists Only]|10|
|<ul><li>- [ ] Done</li></ul>|187|[Simba on the Circle](http://codeforces.com/problemset/problem/612/F)|Codeforces|Educational Codeforces Round 4|10|
|<ul><li>- [ ] Done</li></ul>|188|[Cut Length](http://codeforces.com/problemset/problem/598/F)|Codeforces|Educational Codeforces Round 1|10|
|<ul><li>- [ ] Done</li></ul>|189|[Duff in Mafia](http://codeforces.com/problemset/problem/587/D)|Codeforces|Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|190|[Number of Binominal Coefficients](http://codeforces.com/problemset/problem/582/D)|Codeforces|Codeforces Round #323 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|191|[Campus](http://codeforces.com/problemset/problem/571/D)|Codeforces|Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|192|[Landmarks](http://codeforces.com/problemset/problem/533/D)|Codeforces|VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|193|[Tennis Rackets](http://codeforces.com/problemset/problem/309/D)|Codeforces|Croc Champ 2013 - Finals (online version, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|194|[Create a Maze](http://codeforces.com/problemset/problem/715/D)|Codeforces|Codeforces Round #372 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|195|[Bingo!](http://codeforces.com/problemset/problem/457/D)|Codeforces|MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|196|[Recover a functional graph](http://codeforces.com/problemset/problem/739/D)|Codeforces|Codeforces Round #381 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|197|[Hongcow Draws a Circle](http://codeforces.com/problemset/problem/744/D)|Codeforces|Codeforces Round #385 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|198|[Bear and Rectangle Strips](http://codeforces.com/problemset/problem/771/E)|Codeforces|VK Cup 2017 - Round 1|10|
|<ul><li>- [ ] Done</li></ul>|199|[Rap God](http://codeforces.com/problemset/problem/786/D)|Codeforces|Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|200|[Mister B and Astronomers](http://codeforces.com/problemset/problem/819/D)|Codeforces|Codeforces Round #421 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|201|[Red-Black Cobweb](http://codeforces.com/problemset/problem/833/D)|Codeforces|Codeforces Round #426 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|202|[Dynamic Shortest Path](http://codeforces.com/problemset/problem/843/D)|Codeforces|AIM Tech Round 4 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|203|[Shake It!](http://codeforces.com/problemset/problem/848/D)|Codeforces|Codeforces Round #431 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|204|[Hex Dyslexia](http://codeforces.com/problemset/problem/865/E)|Codeforces|MemSQL Start[c]UP 3.0 - Round 2 (onsite finalists)|10|
|<ul><li>- [ ] Done</li></ul>|205|[Symmetric Projections](http://codeforces.com/problemset/problem/886/F)|Codeforces|?????????? 2018 - ?????????? ????? 3|10|
|<ul><li>- [ ] Done</li></ul>|206|[Sloth](http://codeforces.com/problemset/problem/891/D)|Codeforces|Codeforces Round #446 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|207|[Nephren Runs a Cinema](http://codeforces.com/problemset/problem/896/D)|Codeforces|Codeforces Round #449 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|208|[A Creative Cutout](http://codeforces.com/problemset/problem/933/D)|Codeforces|Codeforces Round #462 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|209|[World of Tank](http://codeforces.com/problemset/problem/936/D)|Codeforces|Codeforces Round #467 (Div. 1)|10|
