# 114. ETF


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Totient Extreme](http://www.spoj.com/problems/DCEPCA03/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Euler Totient Function](http://www.spoj.com/problems/ETF/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[Euler Totient Function Sieve](http://www.spoj.com/problems/ETFS/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|4|[Smallest Inverse Euler Totient Function](http://www.spoj.com/problems/INVPHI/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|5|[Totient in permutation (easy)](http://www.spoj.com/problems/TIP1/)|SPOJ|5|
