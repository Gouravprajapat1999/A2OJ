# 004. Greedy


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Wine trading in Gergovia](http://www.spoj.com/problems/GERGOVIA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[All in All](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1281)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Help the soldier](http://www.spoj.com/problems/SOLDIER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Little Elephant and Bits](http://codeforces.com/problemset/problem/258/A)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Team](http://codeforces.com/problemset/problem/231/A)|Codeforces||Codeforces Round #143 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Dragons](http://codeforces.com/problemset/problem/230/A)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Twins](http://codeforces.com/problemset/problem/160/A)|Codeforces||Codeforces Round #111 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Taxi](http://codeforces.com/problemset/problem/158/B)|Codeforces||VK Cup 2012 Qualification Round 1|1|
|<ul><li>- [ ] Done</li></ul>|9|[Chat room](http://codeforces.com/problemset/problem/58/A)|Codeforces||Codeforces Beta Round #54 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Domino piling](http://codeforces.com/problemset/problem/50/A)|Codeforces||Codeforces Beta Round #47|1|
|<ul><li>- [ ] Done</li></ul>|11|[Sale](http://codeforces.com/problemset/problem/34/B)|Codeforces||Codeforces Beta Round #34 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Shortest path of the king](http://codeforces.com/problemset/problem/3/A)|Codeforces||Codeforces Beta Round #3|1|
|<ul><li>- [ ] Done</li></ul>|13|[Theatre Square](http://codeforces.com/problemset/problem/1/A)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|14|[Adding Reversed Numbers](http://www.spoj.com/problems/ADDREV/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Army](http://codeforces.com/problemset/problem/38/A)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Before an Exam](http://codeforces.com/problemset/problem/4/B)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Maximum Sum (II)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1597)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Dragon of Loowater](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2267)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Shopaholic](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2354)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|20|[The Bus Driver Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2384)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Chocolate](http://www.spoj.com/problems/CHOCOLA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|22|[I AM VERY BUSY](http://www.spoj.com/problems/BUSYMAN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|23|[DIE HARD](http://www.spoj.com/problems/DIEHARD/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Optimal Array Multiplication Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=284)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Bon Appetit](http://www.codechef.com/problems/FGFS)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Tanya and Toys](http://codeforces.com/problemset/problem/659/C)|Codeforces||Codeforces Round #346 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|27|[Beautiful Paintings](http://codeforces.com/problemset/problem/651/B)|Codeforces||Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Joysticks](http://codeforces.com/problemset/problem/651/A)|Codeforces||Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[USB Flash Drives](http://codeforces.com/problemset/problem/609/A)|Codeforces||Educational Codeforces Round 3|1|
|<ul><li>- [ ] Done</li></ul>|30|[Wilbur and Array](http://codeforces.com/problemset/problem/596/B)|Codeforces||Codeforces Round #331 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Duff and Meat](http://codeforces.com/problemset/problem/588/A)|Codeforces||Codeforces Round #326 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces||Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Ilya and Diplomas](http://codeforces.com/problemset/problem/557/A)|Codeforces||Codeforces Round #311 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Case of the Zeros and Ones](http://codeforces.com/problemset/problem/556/A)|Codeforces||Codeforces Round #310 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|35|[Soldier and Badges](http://codeforces.com/problemset/problem/546/B)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[Queue](http://codeforces.com/problemset/problem/545/D)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|37|[Woodcutters](http://codeforces.com/problemset/problem/545/C)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|38|[Equidistant String](http://codeforces.com/problemset/problem/545/B)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Quasi Binary](http://codeforces.com/problemset/problem/538/B)|Codeforces||Codeforces Round #300|1|
|<ul><li>- [ ] Done</li></ul>|40|[Vitaliy and Pie](http://codeforces.com/problemset/problem/525/A)|Codeforces||Codeforces Round #297 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|41|[Two Buttons](http://codeforces.com/problemset/problem/520/B)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|42|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|43|[Drazil and Factorial](http://codeforces.com/problemset/problem/515/C)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|44|[Chewba?ca and Number](http://codeforces.com/problemset/problem/514/A)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|45|[Anton and currency you all know](http://codeforces.com/problemset/problem/508/B)|Codeforces||Codeforces Round #288 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|46|[Amr and Music](http://codeforces.com/problemset/problem/507/A)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|47|[Team Olympiad](http://codeforces.com/problemset/problem/490/A)|Codeforces||Codeforces Round #279 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|48|[Given Length and Sum of Digits...](http://codeforces.com/problemset/problem/489/C)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|49|[BerSU Ball](http://codeforces.com/problemset/problem/489/B)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|50|[OR in Matrix](http://codeforces.com/problemset/problem/486/B)|Codeforces||Codeforces Round #277 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|51|[Diverse Permutation](http://codeforces.com/problemset/problem/482/A)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|52|[Exams](http://codeforces.com/problemset/problem/479/C)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|53|[Table Decorations](http://codeforces.com/problemset/problem/478/C)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|54|[Random Teams](http://codeforces.com/problemset/problem/478/B)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|55|[I Wanna Be the Guy](http://codeforces.com/problemset/problem/469/A)|Codeforces||Codeforces Round #268 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|56|[Appleman and Toastman](http://codeforces.com/problemset/problem/461/A)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|57|[DZY Loves Strings](http://codeforces.com/problemset/problem/447/B)|Codeforces||Codeforces Round #255 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|58|[Devu, the Singer and Churu, the Joker](http://codeforces.com/problemset/problem/439/A)|Codeforces||Codeforces Round #251 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|59|[Choosing Teams](http://codeforces.com/problemset/problem/432/A)|Codeforces||Codeforces Round #246 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|60|[Gravity Flip](http://codeforces.com/problemset/problem/405/A)|Codeforces||Codeforces Round #238 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|61|[Team](http://codeforces.com/problemset/problem/401/C)|Codeforces||Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|62|[Fox and Number Game](http://codeforces.com/problemset/problem/389/A)|Codeforces||Codeforces Round #228 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|63|[Bear and Raspberry](http://codeforces.com/problemset/problem/385/A)|Codeforces||Codeforces Round #226 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|64|[Sereja and Dima](http://codeforces.com/problemset/problem/381/A)|Codeforces||Codeforces Round #223 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|65|[TL](http://codeforces.com/problemset/problem/350/A)|Codeforces||Codeforces Round #203 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|66|[Cinema Line](http://codeforces.com/problemset/problem/349/A)|Codeforces||Codeforces Round #202 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|67|[Helpful Maths](http://codeforces.com/problemset/problem/339/A)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|68|[Puzzles](http://codeforces.com/problemset/problem/337/A)|Codeforces||Codeforces Round #196 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|69|[Magic Numbers](http://codeforces.com/problemset/problem/320/A)|Codeforces||Codeforces Round #189 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|70|[Building Permutation](http://codeforces.com/problemset/problem/285/C)|Codeforces||Codeforces Round #175 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|71|[Slightly Decreasing Permutations](http://codeforces.com/problemset/problem/285/A)|Codeforces||Codeforces Round #175 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|72|[Little Girl and Game](http://codeforces.com/problemset/problem/276/B)|Codeforces||Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|73|[Roadside Trees (Simplified Edition)](http://codeforces.com/problemset/problem/265/B)|Codeforces||Codeforces Round #162 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|74|[Business trip](http://codeforces.com/problemset/problem/149/A)|Codeforces||Codeforces Round #106 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|75|[At most twice](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=5215)|Live Archive|2015|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|76|[Expedition](http://www.spoj.com/problems/EXPEDI/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|77|[Bachgold Problem](http://codeforces.com/problemset/problem/749/A)|Codeforces||Codeforces Round #388 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|78|[Mahmoud and a Triangle](http://codeforces.com/problemset/problem/766/B)|Codeforces||Codeforces Round #396 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|79|[Anton and Classes](http://codeforces.com/problemset/problem/785/B)|Codeforces||Codeforces Round #404 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|80|[Vladik and flights](http://codeforces.com/problemset/problem/743/A)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|81|[Patrick and Shopping](http://codeforces.com/problemset/problem/599/A)|Codeforces||Codeforces Round #332 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|82|[The number of positions](http://codeforces.com/problemset/problem/124/A)|Codeforces||Codeforces Beta Round #92 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|83|[The Stern-Brocot Number System](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1018)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|84|[Train TimeTable](http://www.spoj.com/problems/TTTABLE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|85|[Station Balance](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=351)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|86|[Ambitious Manager](http://www.spoj.com/problems/AMBM/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|87|[Boys and Girls](http://codeforces.com/problemset/problem/253/A)|Codeforces||Codeforces Round #154 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|88|[Points on Line](http://codeforces.com/problemset/problem/251/A)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|89|[Increase and Decrease](http://codeforces.com/problemset/problem/246/B)|Codeforces||Codeforces Round #151 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|90|[Buggy Sorting](http://codeforces.com/problemset/problem/246/A)|Codeforces||Codeforces Round #151 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|91|[Two Bags of Potatoes](http://codeforces.com/problemset/problem/239/A)|Codeforces||Codeforces Round #148 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|92|[Airport](http://codeforces.com/problemset/problem/218/B)|Codeforces||Codeforces Round #134 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|93|[Unlucky Ticket](http://codeforces.com/problemset/problem/160/B)|Codeforces||Codeforces Round #111 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|94|[Combination](http://codeforces.com/problemset/problem/155/B)|Codeforces||Codeforces Round #109 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|95|[Lucky Conversion](http://codeforces.com/problemset/problem/145/A)|Codeforces||Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|96|[Permutation](http://codeforces.com/problemset/problem/137/B)|Codeforces||Codeforces Beta Round #98 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|97|[Little Pigs and Wolves](http://codeforces.com/problemset/problem/116/B)|Codeforces||Codeforces Beta Round #87 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|98|[Coins](http://codeforces.com/problemset/problem/58/B)|Codeforces||Codeforces Beta Round #54 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|99|[Yaroslav and Permutations](http://codeforces.com/problemset/problem/296/A)|Codeforces||Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|100|[Dynamic Frog](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2098)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|101|[Saruman of Many Colours](http://www.spoj.com/problems/AMR12I/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|102|[Watering Grass](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1323)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|103|[Painting Eggs](http://codeforces.com/problemset/problem/282/B)|Codeforces||Codeforces Round #173 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|104|[Cupboards](http://codeforces.com/problemset/problem/248/A)|Codeforces||Codeforces Round #152 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|105|[Making a String](http://codeforces.com/problemset/problem/624/B)|Codeforces||AIM Tech Round (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|106|[Dinner with Emma](http://codeforces.com/problemset/problem/616/B)|Codeforces||Educational Codeforces Round 5|2|
|<ul><li>- [ ] Done</li></ul>|107|[Sorting Railway Cars](http://codeforces.com/problemset/problem/605/A)|Codeforces||Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|108|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces||Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|109|[Alternative Thinking](http://codeforces.com/problemset/problem/603/A)|Codeforces||Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|110|[Duff and Weight Lifting](http://codeforces.com/problemset/problem/587/A)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|111|[GCD Table](http://codeforces.com/problemset/problem/582/A)|Codeforces||Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|112|[Inventory](http://codeforces.com/problemset/problem/569/B)|Codeforces||Codeforces Round #315 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|113|[Mike and Fun](http://codeforces.com/problemset/problem/548/B)|Codeforces||Codeforces Round #305 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|114|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|115|[Covered Path](http://codeforces.com/problemset/problem/534/B)|Codeforces||Codeforces Round #298 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|116|[Pasha and String](http://codeforces.com/problemset/problem/525/B)|Codeforces||Codeforces Round #297 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|117|[Painting Pebbles](http://codeforces.com/problemset/problem/509/B)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|2|
|<ul><li>- [ ] Done</li></ul>|118|[New Year Book Reading](http://codeforces.com/problemset/problem/500/C)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|119|[New Year Permutation](http://codeforces.com/problemset/problem/500/B)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|120|[Vanya and Exams](http://codeforces.com/problemset/problem/492/C)|Codeforces||Codeforces Round #280 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|121|[Palindrome Transformation](http://codeforces.com/problemset/problem/486/C)|Codeforces||Codeforces Round #277 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|122|[Valuable Resources](http://codeforces.com/problemset/problem/485/B)|Codeforces||Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|123|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces||Codeforces Round #274 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|124|[Design Tutorial: Make It Nondeterministic](http://codeforces.com/problemset/problem/472/C)|Codeforces||Codeforces Round #270|2|
|<ul><li>- [ ] Done</li></ul>|125|[24 Game](http://codeforces.com/problemset/problem/468/A)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|126|[Appleman and Card Game](http://codeforces.com/problemset/problem/462/B)|Codeforces||Codeforces Round #263 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|127|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces||Codeforces Round #254 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|128|[The Child and Toy](http://codeforces.com/problemset/problem/437/C)|Codeforces||Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|129|[Football Kit](http://codeforces.com/problemset/problem/432/B)|Codeforces||Codeforces Round #246 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|130|[Fox and Cross](http://codeforces.com/problemset/problem/389/B)|Codeforces||Codeforces Round #228 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|131|[Fox and Box Accumulation](http://codeforces.com/problemset/problem/388/A)|Codeforces||Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|132|[George and Round](http://codeforces.com/problemset/problem/387/B)|Codeforces||Codeforces Round #227 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|133|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces||Codeforces Round #226 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|134|[Ksenia and Pan Scales](http://codeforces.com/problemset/problem/382/A)|Codeforces||Codeforces Round #224 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|135|[New Year Ratings Change](http://codeforces.com/problemset/problem/379/C)|Codeforces||Good Bye 2013|2|
|<ul><li>- [ ] Done</li></ul>|136|[Counting Kangaroos is Fun](http://codeforces.com/problemset/problem/372/A)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|137|[Fixing Typos](http://codeforces.com/problemset/problem/363/C)|Codeforces||Codeforces Round #211 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|138|[Table](http://codeforces.com/problemset/problem/359/A)|Codeforces||Codeforces Round #209 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|139|[Group of Students](http://codeforces.com/problemset/problem/357/A)|Codeforces||Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|140|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces||Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|141|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|142|[Xenia and Divisors](http://codeforces.com/problemset/problem/342/A)|Codeforces||Codeforces Round #199 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|143|[Ciel and Dancing](http://codeforces.com/problemset/problem/322/A)|Codeforces||Codeforces Round #190 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|144|[Sail](http://codeforces.com/problemset/problem/298/B)|Codeforces||Codeforces Round #180 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|145|[Polo the Penguin and Strings](http://codeforces.com/problemset/problem/288/A)|Codeforces||Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|146|[k-Multiple Free Set](http://codeforces.com/problemset/problem/274/A)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|147|[Squares](http://codeforces.com/problemset/problem/263/B)|Codeforces||Codeforces Round #161 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|148|[Alice, Bob and Chocolate](http://codeforces.com/problemset/problem/6/C)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|149|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|150|[Fox And Names](http://codeforces.com/problemset/problem/510/C)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|151|[Milk Scheduling](http://www.spoj.com/problems/MSCHED/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|152|[Little Elephant and Music](http://www.codechef.com/problems/LEMUSIC)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|153|[Planning](http://codeforces.com/problemset/problem/853/A)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises) & Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|2|
|<ul><li>- [ ] Done</li></ul>|154|[Leha and Function](http://codeforces.com/problemset/problem/840/A)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|155|[String Game](http://codeforces.com/problemset/problem/778/A)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|156|[Alyona and mex](http://codeforces.com/problemset/problem/739/A)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|157|[Pride](http://codeforces.com/problemset/problem/891/A)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|158|[Valued Keys](http://codeforces.com/problemset/problem/801/B)|Codeforces||Codeforces Round #409 (rated, Div. 2, based on VK Cup 2017 Round 2)|2|
|<ul><li>- [ ] Done</li></ul>|159|[Urbanization](http://codeforces.com/problemset/problem/735/B)|Codeforces||Codeforces Round #382 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|160|[Game of Credit Cards](http://codeforces.com/problemset/problem/777/B)|Codeforces||Codeforces Round #401 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|161|[Lesha and array splitting](http://codeforces.com/problemset/problem/754/A)|Codeforces||Codeforces Round #390 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|162|[Summer sell-off](http://codeforces.com/problemset/problem/810/B)|Codeforces||Codeforces Round #415 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|163|[Not Afraid](http://codeforces.com/problemset/problem/787/B)|Codeforces||Codeforces Round #406 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|164|[Our Tanya is Crying Out Loud](http://codeforces.com/problemset/problem/940/B)|Codeforces||Codeforces Round #466 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|165|[Conan and Agasa play a Card Game](http://codeforces.com/problemset/problem/914/B)|Codeforces||Codecraft-18 and Codeforces Round #458 (Div. 1 + Div. 2, combined)|2|
|<ul><li>- [ ] Done</li></ul>|166|[Coin Collector](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2231)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|167|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|168|[Photographer](http://codeforces.com/problemset/problem/203/C)|Codeforces||Codeforces Round #128 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|169|[LLPS](http://codeforces.com/problemset/problem/202/A)|Codeforces||Codeforces Round #127 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|170|[Lexicographically Maximum Subsequence](http://codeforces.com/problemset/problem/196/A)|Codeforces||Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|171|[Vasya and the Bus](http://codeforces.com/problemset/problem/190/A)|Codeforces||Codeforces Round #120 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|172|[Median](http://codeforces.com/problemset/problem/166/C)|Codeforces||Codeforces Round #113 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|173|[Dress'em in Vests!](http://codeforces.com/problemset/problem/161/A)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|174|[Ternary Logic](http://codeforces.com/problemset/problem/136/B)|Codeforces||Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|175|[Petya and Inequiations](http://codeforces.com/problemset/problem/111/A)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|176|[Testing Pants for Sadness](http://codeforces.com/problemset/problem/103/A)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|177|[Regular Bracket Sequence](http://codeforces.com/problemset/problem/26/B)|Codeforces||Codeforces Beta Round #26 (Codeforces format)|3|
|<ul><li>- [ ] Done</li></ul>|178|[Burglar and Matches](http://codeforces.com/problemset/problem/16/B)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|179|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces||Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|180|[Greedy Hydra](http://www.spoj.com/problems/DRAGON/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|181|[Football](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4411)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|182|[Catch Me If You Can ](http://www.spoj.com/problems/CMIYC/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|183|[Ilya and Matrix](http://codeforces.com/problemset/problem/313/C)|Codeforces||Codeforces Round #186 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|184|[Sockets](http://codeforces.com/problemset/problem/257/A)|Codeforces||Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|185|[Simple Strings](http://codeforces.com/problemset/problem/665/C)|Codeforces||Educational Codeforces Round 12|3|
|<ul><li>- [ ] Done</li></ul>|186|[Co-prime Array](http://codeforces.com/problemset/problem/660/A)|Codeforces||Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|187|[New Reform](http://codeforces.com/problemset/problem/659/E)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|188|[Bear and String Distance](http://codeforces.com/problemset/problem/628/C)|Codeforces||Educational Codeforces Round 8|3|
|<ul><li>- [ ] Done</li></ul>|189|[Block Towers](http://codeforces.com/problemset/problem/626/C)|Codeforces||8VC Venture Cup 2016 - Elimination Round|3|
|<ul><li>- [ ] Done</li></ul>|190|[Pearls in a Row](http://codeforces.com/problemset/problem/620/C)|Codeforces||Educational Codeforces Round 6|3|
|<ul><li>- [ ] Done</li></ul>|191|[Marina and Vasya](http://codeforces.com/problemset/problem/584/C)|Codeforces||Codeforces Round #324 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|192|["Or" Game](http://codeforces.com/problemset/problem/578/B)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|193|[Order Book](http://codeforces.com/problemset/problem/572/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|194|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces||Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|195|[School Marks](http://codeforces.com/problemset/problem/540/B)|Codeforces||Codeforces Round #301 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|196|[Error Correct System](http://codeforces.com/problemset/problem/527/B)|Codeforces||Codeforces Round #296 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|197|[Om Nom and Dark Park](http://codeforces.com/problemset/problem/526/B)|Codeforces||ZeptoLab Code Rush 2015|3|
|<ul><li>- [ ] Done</li></ul>|198|[Ilya and Sticks](http://codeforces.com/problemset/problem/525/C)|Codeforces||Codeforces Round #297 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|199|[Anya and Ghosts](http://codeforces.com/problemset/problem/508/C)|Codeforces||Codeforces Round #288 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|200|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|201|[Treasure](http://codeforces.com/problemset/problem/494/A)|Codeforces||Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|202|[Long Jumps](http://codeforces.com/problemset/problem/479/D)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|203|[No to Palindromes!](http://codeforces.com/problemset/problem/464/A)|Codeforces||Codeforces Round #265 (Div. 1) & Codeforces Round #265 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|204|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces||Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|205|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces||Codeforces Round #262 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|206|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces||Codeforces Round #256 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|207|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|208|[Valera and Fruits](http://codeforces.com/problemset/problem/441/B)|Codeforces||Codeforces Round #252 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|209|[The Child and Set](http://codeforces.com/problemset/problem/437/B)|Codeforces||Codeforces Round #250 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|210|[Pasha Maximizes](http://codeforces.com/problemset/problem/435/B)|Codeforces||Codeforces Round #249 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|211|[Megacity](http://codeforces.com/problemset/problem/424/B)|Codeforces||Codeforces Round #242 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|212|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|213|[Guess a number!](http://codeforces.com/problemset/problem/416/A)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|214|[Mashmokh and Tokens](http://codeforces.com/problemset/problem/415/B)|Codeforces||Codeforces Round #240 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|215|[Nuts](http://codeforces.com/problemset/problem/402/A)|Codeforces||Codeforces Round #236 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|216|[Sereja and Contests](http://codeforces.com/problemset/problem/401/B)|Codeforces||Codeforces Round #235 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|217|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|218|[Sereja and Stairs](http://codeforces.com/problemset/problem/381/B)|Codeforces||Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|219|[Vasya and Public Transport](http://codeforces.com/problemset/problem/355/B)|Codeforces||Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|220|[Vasya and Robot](http://codeforces.com/problemset/problem/354/A)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|221|[Bombs](http://codeforces.com/problemset/problem/350/C)|Codeforces||Codeforces Round #203 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|222|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces||Codeforces Round #197 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|223|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|224|[Routine Problem](http://codeforces.com/problemset/problem/337/B)|Codeforces||Codeforces Round #196 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|225|[Secrets](http://codeforces.com/problemset/problem/333/A)|Codeforces||Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|226|[Purification](http://codeforces.com/problemset/problem/329/A)|Codeforces||Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|227|[Snow Footprints](http://codeforces.com/problemset/problem/298/A)|Codeforces||Codeforces Round #180 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|228|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces||Codeforces Round #169 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|229|[Multithreading](http://codeforces.com/problemset/problem/270/B)|Codeforces||Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|230|[Roma and Changing Signs](http://codeforces.com/problemset/problem/262/B)|Codeforces||Codeforces Round #160 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|231|[Maxim and Discounts](http://codeforces.com/problemset/problem/261/A)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|232|[Playing Cubes](http://codeforces.com/problemset/problem/257/B)|Codeforces||Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|233|[Dice Tower](http://codeforces.com/problemset/problem/225/A)|Codeforces||Codeforces Round #139 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|234|[DNA Alignment](http://codeforces.com/problemset/problem/520/C)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|235|[Recycling Bottles](http://codeforces.com/problemset/problem/671/A)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|236|[Heap Operations](http://codeforces.com/problemset/problem/681/C)|Codeforces||Codeforces Round #357 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|237|[Santa Claus and Robot](http://codeforces.com/problemset/problem/748/C)|Codeforces||Technocup 2017 - Elimination Round 3|3|
|<ul><li>- [ ] Done</li></ul>|238|[Karen and Game](http://codeforces.com/problemset/problem/815/A)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|239|[Memory and De-Evolution](http://codeforces.com/problemset/problem/712/C)|Codeforces||Codeforces Round #370 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|240|[Voting](http://codeforces.com/problemset/problem/749/C)|Codeforces||Codeforces Round #388 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|241|[Cloud of Hashtags](http://codeforces.com/problemset/problem/777/D)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|242|[Mike and gcd problem](http://codeforces.com/problemset/problem/798/C)|Codeforces||Codeforces Round #410 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|243|[Palindromes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3486)|Live Archive|1995|North America - South Central USA|3|
|<ul><li>- [ ] Done</li></ul>|244|[Paper Work](http://codeforces.com/problemset/problem/250/A)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|245|[Magic, Wizardry and Wonders](http://codeforces.com/problemset/problem/231/B)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|246|[Well-known Numbers](http://codeforces.com/problemset/problem/225/B)|Codeforces||Codeforces Round #139 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|247|[Olympic Medal](http://codeforces.com/problemset/problem/215/B)|Codeforces||Codeforces Round #132 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|248|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces||Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|249|[Little Elephant and Sorting](http://codeforces.com/problemset/problem/205/B)|Codeforces||Codeforces Round #129 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|250|[Growing Mushrooms](http://codeforces.com/problemset/problem/186/B)|Codeforces||Codeforces Round #118 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|251|[Matchmaker](http://codeforces.com/problemset/problem/159/B)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|252|[Friends or Not](http://codeforces.com/problemset/problem/159/A)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|253|[Hometask](http://codeforces.com/problemset/problem/154/A)|Codeforces||Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|254|[Division into Teams](http://codeforces.com/problemset/problem/149/C)|Codeforces||Codeforces Round #106 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|255|[New Year Snowmen](http://codeforces.com/problemset/problem/140/C)|Codeforces||Codeforces Round #100|4|
|<ul><li>- [ ] Done</li></ul>|256|[Homework](http://codeforces.com/problemset/problem/101/A)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|257|[Binary Number](http://codeforces.com/problemset/problem/92/B)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|258|[Cableway](http://codeforces.com/problemset/problem/90/A)|Codeforces||Codeforces Beta Round #74 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|259|[Bus Game](http://codeforces.com/problemset/problem/79/A)|Codeforces||Codeforces Beta Round #71|4|
|<ul><li>- [ ] Done</li></ul>|260|[A Student's Dream](http://codeforces.com/problemset/problem/62/A)|Codeforces||Codeforces Beta Round #58|4|
|<ul><li>- [ ] Done</li></ul>|261|[Eternal Victory](http://codeforces.com/problemset/problem/61/D)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|262|[Lucky Tickets](http://codeforces.com/problemset/problem/43/C)|Codeforces||Codeforces Beta Round #42 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|263|[You're Given a String...](http://codeforces.com/problemset/problem/23/A)|Codeforces||Codeforces Beta Round #23|4|
|<ul><li>- [ ] Done</li></ul>|264|[Lorry](http://codeforces.com/problemset/problem/3/B)|Codeforces||Codeforces Beta Round #3|4|
|<ul><li>- [ ] Done</li></ul>|265|[INVITATION FOR TECHOFES](http://www.spoj.com/problems/TECHOFES/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|266|[Jersey Politics](http://poj.org/problem?id=2454)|PKU|||4|
|<ul><li>- [ ] Done</li></ul>|267|[Troops of Sand Monsters](http://www.spoj.com/problems/TROOPS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|268|[Two Semiknights Meet](http://codeforces.com/problemset/problem/362/A)|Codeforces||Codeforces Round #212 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|269|[Subtraction](p?ID=129)|A2 Online Judge|||4|
|<ul><li>- [ ] Done</li></ul>|270|[K-Palindrome](p?ID=276)|A2 Online Judge|||4|
|<ul><li>- [ ] Done</li></ul>|271|[Rebus](http://codeforces.com/problemset/problem/663/A)|Codeforces||Codeforces Round #347 (Div. 1) & Codeforces Round #347 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|272|[Mischievous Mess Makers](http://codeforces.com/problemset/problem/645/B)|Codeforces||CROC 2016 - Elimination Round|4|
|<ul><li>- [ ] Done</li></ul>|273|[Make Palindrome](http://codeforces.com/problemset/problem/600/C)|Codeforces||Educational Codeforces Round 2|4|
|<ul><li>- [ ] Done</li></ul>|274|[Amr and Chemistry](http://codeforces.com/problemset/problem/558/C)|Codeforces||Codeforces Round #312 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|275|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces||Codeforces Round #311 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|276|[Case of Fugitive](http://codeforces.com/problemset/problem/555/B)|Codeforces||Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|277|[GukiZ hates Boxes](http://codeforces.com/problemset/problem/551/C)|Codeforces||Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|278|[Paths and Trees](http://codeforces.com/problemset/problem/545/E)|Codeforces||Codeforces Round #303 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|279|[Tavas and Malekas](http://codeforces.com/problemset/problem/535/D)|Codeforces||Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|280|[Clique Problem](http://codeforces.com/problemset/problem/527/D)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|281|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|282|[Dreamoon and Sets](http://codeforces.com/problemset/problem/476/D)|Codeforces||Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|283|[MUH and House of Cards](http://codeforces.com/problemset/problem/471/C)|Codeforces||Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|284|[Two Sets](http://codeforces.com/problemset/problem/468/B)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|285|[DZY Loves Modification](http://codeforces.com/problemset/problem/446/B)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|286|[DZY Loves Physics](http://codeforces.com/problemset/problem/444/A)|Codeforces||Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|287|[Feed with Candy](http://codeforces.com/problemset/problem/436/A)|Codeforces||Zepto Code Rush 2014|4|
|<ul><li>- [ ] Done</li></ul>|288|[Network Configuration](http://codeforces.com/problemset/problem/412/B)|Codeforces||Coder-Strike 2014 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|289|[Poster](http://codeforces.com/problemset/problem/412/A)|Codeforces||Coder-Strike 2014 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|290|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|291|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces||Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|292|[Inna and Nine](http://codeforces.com/problemset/problem/374/B)|Codeforces||Codeforces Round #220 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|293|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|294|[Xenia and Spies](http://codeforces.com/problemset/problem/342/B)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|295|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|296|[Special Task](http://codeforces.com/problemset/problem/316/A1)|Codeforces||ABBYY Cup 3.0|4|
|<ul><li>- [ ] Done</li></ul>|297|[Fish Weight](http://codeforces.com/problemset/problem/297/B)|Codeforces||Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|298|[Shaass and Bookshelf](http://codeforces.com/problemset/problem/294/B)|Codeforces||Codeforces Round #178 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|299|[Zero Tree](http://codeforces.com/problemset/problem/274/B)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|300|[Magical Boxes](http://codeforces.com/problemset/problem/269/A)|Codeforces||Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|301|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|302|[Robin Hood](http://codeforces.com/problemset/problem/671/B)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|303|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces||Codeforces Round #353 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|304|[Office Keys](http://codeforces.com/problemset/problem/830/A)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|305|[Garland](http://codeforces.com/problemset/problem/767/C)|Codeforces||Codeforces Round #398 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|306|[Game of the Rows](http://codeforces.com/problemset/problem/839/B)|Codeforces||Codeforces Round #428 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|307|[Text Editor](http://codeforces.com/problemset/problem/253/C)|Codeforces||Codeforces Round #154 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|308|[Beauty Pageant](http://codeforces.com/problemset/problem/246/C)|Codeforces||Codeforces Round #151 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|309|[Restoring Table](http://codeforces.com/problemset/problem/245/D)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|5|
|<ul><li>- [ ] Done</li></ul>|310|[Old Peykan](http://codeforces.com/problemset/problem/241/A)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|5|
|<ul><li>- [ ] Done</li></ul>|311|[Cycles](http://codeforces.com/problemset/problem/232/A)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|312|[Olympiad](http://codeforces.com/problemset/problem/222/D)|Codeforces||Codeforces Round #137 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|313|[Permutations](http://codeforces.com/problemset/problem/187/A)|Codeforces||Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|314|[Replacing Digits](http://codeforces.com/problemset/problem/169/B)|Codeforces||VK Cup 2012 Round 2 (Unofficial Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|315|[Discounts](http://codeforces.com/problemset/problem/161/B)|Codeforces||VK Cup 2012 Round 1|5|
|<ul><li>- [ ] Done</li></ul>|316|[Terse princess](http://codeforces.com/problemset/problem/148/C)|Codeforces||Codeforces Round #105 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|317|[Help General](http://codeforces.com/problemset/problem/142/B)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|318|[Queue](http://codeforces.com/problemset/problem/141/C)|Codeforces||Codeforces Round #101 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|319|[New Year Contest](http://codeforces.com/problemset/problem/140/D)|Codeforces||Codeforces Round #100|5|
|<ul><li>- [ ] Done</li></ul>|320|[Spiders](http://codeforces.com/problemset/problem/120/F)|Codeforces||School Regional Team Contest, Saratov, 2011|5|
|<ul><li>- [ ] Done</li></ul>|321|[Fancy Number](http://codeforces.com/problemset/problem/118/C)|Codeforces||Codeforces Beta Round #89 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|322|[Lawnmower](http://codeforces.com/problemset/problem/115/B)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|323|[Newspaper Headline](http://codeforces.com/problemset/problem/91/A)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|324|[Bets](http://codeforces.com/problemset/problem/69/B)|Codeforces||Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|325|[Square Earth?](http://codeforces.com/problemset/problem/57/A)|Codeforces||Codeforces Beta Round #53|5|
|<ul><li>- [ ] Done</li></ul>|326|[What is for dinner?](http://codeforces.com/problemset/problem/33/A)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|327|[Hierarchy](http://codeforces.com/problemset/problem/17/B)|Codeforces||Codeforces Beta Round #17|5|
|<ul><li>- [ ] Done</li></ul>|328|[Least Cost Bracket Sequence](http://codeforces.com/problemset/problem/3/D)|Codeforces||Codeforces Beta Round #3|5|
|<ul><li>- [ ] Done</li></ul>|329|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|330|[Game with Points](http://acm.sgu.ru/problem.php?contest=0&problem=408)|SGU|||5|
|<ul><li>- [ ] Done</li></ul>|331|[Simple Subset](http://codeforces.com/problemset/problem/665/D)|Codeforces||Educational Codeforces Round 12|5|
|<ul><li>- [ ] Done</li></ul>|332|[Running with Obstacles](http://codeforces.com/problemset/problem/637/D)|Codeforces||VK Cup 2016 - Qualification Round 1|5|
|<ul><li>- [ ] Done</li></ul>|333|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces||Codeforces Round #338 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|334|[Restaurant](http://codeforces.com/problemset/problem/597/B)|Codeforces||Testing Round #12|5|
|<ul><li>- [ ] Done</li></ul>|335|[Wilbur and Points](http://codeforces.com/problemset/problem/596/C)|Codeforces||Codeforces Round #331 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|336|[Gourmet and Banquet](http://codeforces.com/problemset/problem/589/F)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|5|
|<ul><li>- [ ] Done</li></ul>|337|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|338|[Minimization](http://codeforces.com/problemset/problem/571/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|339|[Happy Line](http://codeforces.com/problemset/problem/549/G)|Codeforces||Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|340|[Haar Features](http://codeforces.com/problemset/problem/549/D)|Codeforces||Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|341|[Handshakes](http://codeforces.com/problemset/problem/534/D)|Codeforces||Codeforces Round #298 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|342|[Correcting Mistakes](http://codeforces.com/problemset/problem/533/E)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|343|[Board Game](http://codeforces.com/problemset/problem/533/C)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|344|[Om Nom and Candies](http://codeforces.com/problemset/problem/526/C)|Codeforces||ZeptoLab Code Rush 2015|5|
|<ul><li>- [ ] Done</li></ul>|345|[Name Quest](http://codeforces.com/problemset/problem/523/C)|Codeforces||VK Cup 2015 - Qualification Round 2|5|
|<ul><li>- [ ] Done</li></ul>|346|[Sums of Digits](http://codeforces.com/problemset/problem/509/C)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|347|[Dungeons and Candies](http://codeforces.com/problemset/problem/436/C)|Codeforces||Zepto Code Rush 2014|5|
|<ul><li>- [ ] Done</li></ul>|348|[Prime Swaps](http://codeforces.com/problemset/problem/432/C)|Codeforces||Codeforces Round #246 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|349|[Upgrading Array](http://codeforces.com/problemset/problem/402/D)|Codeforces||Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|350|[Fox and Card Game](http://codeforces.com/problemset/problem/388/C)|Codeforces||Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|351|[George and Number](http://codeforces.com/problemset/problem/387/C)|Codeforces||Codeforces Round #227 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|352|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|353|[Inna and Pink Pony](http://codeforces.com/problemset/problem/374/A)|Codeforces||Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|354|[Renting Bikes](http://codeforces.com/problemset/problem/363/D)|Codeforces||Codeforces Round #211 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|355|[Levko and Array Recovery](http://codeforces.com/problemset/problem/360/A)|Codeforces||Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|356|[Dima and Hares](http://codeforces.com/problemset/problem/358/D)|Codeforces||Codeforces Round #208 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|357|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces||Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|358|[Read Time](http://codeforces.com/problemset/problem/343/C)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|359|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces||Codeforces Round #195 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|360|[Chips](http://codeforces.com/problemset/problem/333/B)|Codeforces||Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|361|[Ciel and Duel](http://codeforces.com/problemset/problem/321/B)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|362|[Weird Game](http://codeforces.com/problemset/problem/293/A)|Codeforces||Croc Champ 2013 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|363|[Parallel Programming](http://codeforces.com/problemset/problem/291/D)|Codeforces||Croc Champ 2013 - Qualification Round|5|
|<ul><li>- [ ] Done</li></ul>|364|[Balls and Boxes](http://codeforces.com/problemset/problem/260/C)|Codeforces||Codeforces Round #158 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|365|[Guilty --- to the kitchen!](http://codeforces.com/problemset/problem/42/A)|Codeforces||Codeforces Beta Round #41|5|
|<ul><li>- [ ] Done</li></ul>|366|[Bear and Tower of Cubes](http://codeforces.com/problemset/problem/679/B)|Codeforces||Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|367|[Jury Meeting](http://codeforces.com/problemset/problem/853/B)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises) & Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|5|
|<ul><li>- [ ] Done</li></ul>|368|[An overnight dance in discotheque](http://codeforces.com/problemset/problem/814/D)|Codeforces||Codeforces Round #418 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|369|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces||Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|370|[Cartons of milk](http://codeforces.com/problemset/problem/767/D)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|371|[The Queue](http://codeforces.com/problemset/problem/767/B)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|372|[Fedor and coupons](http://codeforces.com/problemset/problem/754/D)|Codeforces||Codeforces Round #390 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|373|[Maxim and Array](http://codeforces.com/problemset/problem/721/D)|Codeforces||Codeforces Round #374 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|374|[Anagram](http://codeforces.com/problemset/problem/254/C)|Codeforces||Codeforces Round #155 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|375|[Movie Critics](http://codeforces.com/problemset/problem/250/C)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|376|[Game with Coins](http://codeforces.com/problemset/problem/245/C)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|6|
|<ul><li>- [ ] Done</li></ul>|377|[Dispute](http://codeforces.com/problemset/problem/242/D)|Codeforces||Codeforces Round #149 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|378|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces||Codeforces Round #142 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|379|[Naughty Stone Piles](http://codeforces.com/problemset/problem/226/B)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|380|[Hiring Staff](http://codeforces.com/problemset/problem/216/C)|Codeforces||Codeforces Round #133 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|381|[Hot Days](http://codeforces.com/problemset/problem/215/D)|Codeforces||Codeforces Round #132 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|382|[Game](http://codeforces.com/problemset/problem/213/A)|Codeforces||Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|383|[Trading Business](http://codeforces.com/problemset/problem/176/A)|Codeforces||Croc Champ 2012 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|384|[File List](http://codeforces.com/problemset/problem/174/B)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|385|[New Year Cards](http://codeforces.com/problemset/problem/140/B)|Codeforces||Codeforces Round #100|6|
|<ul><li>- [ ] Done</li></ul>|386|[Zero-One](http://codeforces.com/problemset/problem/135/C)|Codeforces||Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|387|[Robbery](http://codeforces.com/problemset/problem/89/A)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|388|[Beaver](http://codeforces.com/problemset/problem/79/C)|Codeforces||Codeforces Beta Round #71|6|
|<ul><li>- [ ] Done</li></ul>|389|[Train](http://codeforces.com/problemset/problem/74/B)|Codeforces||Codeforces Beta Round #68|6|
|<ul><li>- [ ] Done</li></ul>|390|[The Elder Trolls IV: Oblivon](http://codeforces.com/problemset/problem/73/A)|Codeforces||Codeforces Beta Round #66|6|
|<ul><li>- [ ] Done</li></ul>|391|[Text Messaging](http://codeforces.com/problemset/problem/70/B)|Codeforces||Codeforces Beta Round #64|6|
|<ul><li>- [ ] Done</li></ul>|392|[Partial Teacher](http://codeforces.com/problemset/problem/67/A)|Codeforces||Manthan 2011|6|
|<ul><li>- [ ] Done</li></ul>|393|[Harry Potter and the History of Magic](http://codeforces.com/problemset/problem/65/B)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|394|[Permutations](http://codeforces.com/problemset/problem/48/D)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|395|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces||Codeforces Beta Round #40 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|396|[Company Income Growth](http://codeforces.com/problemset/problem/39/B)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|397|[Animals](http://codeforces.com/problemset/problem/35/D)|Codeforces||Codeforces Beta Round #35 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|398|[Segments](http://codeforces.com/problemset/problem/22/D)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|399|[Washer, Dryer, Folder](http://codeforces.com/problemset/problem/452/D)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|400|[Train Passengers](p?ID=306)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|401|[Fishing Soldier](p?ID=75)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|402|[Snakes](p?ID=284)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|403|[International Olympiad](http://codeforces.com/problemset/problem/662/D)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|404|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|405|[Array GCD](http://codeforces.com/problemset/problem/623/B)|Codeforces||AIM Tech Round (Div. 1) & AIM Tech Round (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|406|[Ants in Leaves](http://codeforces.com/problemset/problem/622/E)|Codeforces||Educational Codeforces Round 7|6|
|<ul><li>- [ ] Done</li></ul>|407|[Anton and Ira](http://codeforces.com/problemset/problem/584/E)|Codeforces||Codeforces Round #324 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|408|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|409|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces||Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|410|[Brackets in Implications](http://codeforces.com/problemset/problem/550/E)|Codeforces||Codeforces Round #306 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|411|[Looksery Party](http://codeforces.com/problemset/problem/549/B)|Codeforces||Looksery Cup 2015|6|
|<ul><li>- [ ] Done</li></ul>|412|[Arthur and Walls](http://codeforces.com/problemset/problem/525/D)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|413|[???? ?? ?????? - 2 (round version)](http://codeforces.com/problemset/problem/524/B)|Codeforces||VK Cup 2015 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|414|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|415|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces||Codeforces Round #288 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|416|[Distributing Parts ](http://codeforces.com/problemset/problem/496/E)|Codeforces||Codeforces Round #283 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|417|[Restoring Increasing Sequence](http://codeforces.com/problemset/problem/490/E)|Codeforces||Codeforces Round #279 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|418|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces||Codeforces Round #277 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|419|[Kindergarten](http://codeforces.com/problemset/problem/484/D)|Codeforces||Codeforces Round #276 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|420|[Artem and Array ](http://codeforces.com/problemset/problem/442/C)|Codeforces||Codeforces Round #253 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|421|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces||Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|422|[Sereja and Table ](http://codeforces.com/problemset/problem/425/B)|Codeforces||Codeforces Round #243 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|423|[Cunning Gena](http://codeforces.com/problemset/problem/417/D)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|424|[Jeopardy!](http://codeforces.com/problemset/problem/413/C)|Codeforces||Coder-Strike 2014 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|425|[Mittens](http://codeforces.com/problemset/problem/370/C)|Codeforces||Codeforces Round #217 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|426|[Sereja and the Arrangement of Numbers](http://codeforces.com/problemset/problem/367/C)|Codeforces||Codeforces Round #215 (Div. 1) & Codeforces Round #215 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|427|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces||Codeforces Round #208 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|428|[Compartments](http://codeforces.com/problemset/problem/356/C)|Codeforces||Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|429|[Number Transformation II](http://codeforces.com/problemset/problem/346/C)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|430|[Banana](http://codeforces.com/problemset/problem/335/A)|Codeforces||MemSQL start[c]up Round 2 - online version|6|
|<ul><li>- [ ] Done</li></ul>|431|[Main Sequence](http://codeforces.com/problemset/problem/286/C)|Codeforces||Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|432|[Beautiful Decomposition](http://codeforces.com/problemset/problem/279/E)|Codeforces||Codeforces Round #171 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|433|[Below the Diagonal](http://codeforces.com/problemset/problem/266/C)|Codeforces||Codeforces Round #163 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|434|[Sum](http://codeforces.com/problemset/problem/257/D)|Codeforces||Codeforces Round #159 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|435|[Wonderful Randomized Sum](http://codeforces.com/problemset/problem/33/C)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|436|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces||Codeforces Round #353 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|437|[Trees](http://codeforces.com/problemset/problem/58/C)|Codeforces||Codeforces Beta Round #54 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|438|[Ithea Plays With Chtholly](http://codeforces.com/problemset/problem/896/B)|Codeforces||Codeforces Round #449 (Div. 1) & Codeforces Round #449 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|439|[Divide and conquer](http://acm.sgu.ru/problem.php?contest=0&problem=229)|SGU|||6|
|<ul><li>- [ ] Done</li></ul>|440|[World Eater Brothers](http://codeforces.com/problemset/problem/238/C)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|441|[Boring Partition](http://codeforces.com/problemset/problem/238/B)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|442|[The table](http://codeforces.com/problemset/problem/226/D)|Codeforces||Codeforces Round #140 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|443|[Demonstration](http://codeforces.com/problemset/problem/191/B)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|444|[Geometry Horse](http://codeforces.com/problemset/problem/175/C)|Codeforces||Codeforces Round #115|7|
|<ul><li>- [ ] Done</li></ul>|445|[Zebra Tower](http://codeforces.com/problemset/problem/159/E)|Codeforces||VK Cup 2012 Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|446|[Digits Permutations](http://codeforces.com/problemset/problem/138/B)|Codeforces||Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|447|[Hobbits' Party](http://codeforces.com/problemset/problem/125/C)|Codeforces||Codeforces Testing Round #2|7|
|<ul><li>- [ ] Done</li></ul>|448|[Russian Roulette](http://codeforces.com/problemset/problem/103/C)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|449|[Lucky Numbers](http://codeforces.com/problemset/problem/95/B)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|450|[End of Exams](http://codeforces.com/problemset/problem/93/B)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|451|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|452|[Plus and xor](http://codeforces.com/problemset/problem/76/D)|Codeforces||All-Ukrainian School Olympiad in Informatics|7|
|<ul><li>- [ ] Done</li></ul>|453|[Restoration of the Permutation](http://codeforces.com/problemset/problem/67/B)|Codeforces||Manthan 2011|7|
|<ul><li>- [ ] Done</li></ul>|454|[Three Base Stations](http://codeforces.com/problemset/problem/51/C)|Codeforces||Codeforces Beta Round #48|7|
|<ul><li>- [ ] Done</li></ul>|455|[TCMCF+++](http://codeforces.com/problemset/problem/45/I)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|456|[Event Dates](http://codeforces.com/problemset/problem/45/D)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|457|[Old Berland Language](http://codeforces.com/problemset/problem/37/C)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|458|[Computer Game](http://codeforces.com/problemset/problem/37/B)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|459|[Seller Bob](http://codeforces.com/problemset/problem/18/D)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|460|[Intellectual Inquiry](http://codeforces.com/problemset/problem/645/E)|Codeforces||CROC 2016 - Elimination Round|7|
|<ul><li>- [ ] Done</li></ul>|461|[Bear and Contribution](http://codeforces.com/problemset/problem/639/D)|Codeforces||VK Cup 2016 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|462|[Road Improvement](http://codeforces.com/problemset/problem/638/C)|Codeforces||VK Cup 2016 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|463|[Package Delivery](http://codeforces.com/problemset/problem/627/C)|Codeforces||8VC Venture Cup 2016 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|464|[New Year and Three Musketeers](http://codeforces.com/problemset/problem/611/E)|Codeforces||Good Bye 2015|7|
|<ul><li>- [ ] Done</li></ul>|465|[Bulbo](http://codeforces.com/problemset/problem/575/F)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|466|[Nudist Beach](http://codeforces.com/problemset/problem/553/D)|Codeforces||Codeforces Round #309 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|467|[Quest](http://codeforces.com/problemset/problem/542/F)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|468|[Group Photo 2 (online mirror version)](http://codeforces.com/problemset/problem/529/B)|Codeforces||VK Cup 2015 - Round 1 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|469|[Social Network](http://codeforces.com/problemset/problem/524/D)|Codeforces||VK Cup 2015 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|470|[Chicken or Fish?](http://codeforces.com/problemset/problem/522/C)|Codeforces||VK Cup 2015 - Qualification Round 1|7|
|<ul><li>- [ ] Done</li></ul>|471|[Arthur and Questions](http://codeforces.com/problemset/problem/518/E)|Codeforces||Codeforces Round #293 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|472|[Kamal-ol-molk's Painting](http://codeforces.com/problemset/problem/475/C)|Codeforces||Bayan 2015 Contest Warm Up|7|
|<ul><li>- [ ] Done</li></ul>|473|[Distributed Join](http://codeforces.com/problemset/problem/457/B)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|474|[Special Grid](http://codeforces.com/problemset/problem/435/D)|Codeforces||Codeforces Round #249 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|475|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|476|[Population Size](http://codeforces.com/problemset/problem/416/D)|Codeforces||Codeforces Round #241 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|477|[Free Market](http://codeforces.com/problemset/problem/364/B)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|478|[Fools and Foolproof Roads](http://codeforces.com/problemset/problem/362/D)|Codeforces||Codeforces Round #212 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|479|[Jeff and Permutation](http://codeforces.com/problemset/problem/351/E)|Codeforces||Codeforces Round #204 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|480|[Students' Revenge](http://codeforces.com/problemset/problem/332/C)|Codeforces||Codeforces Round #193 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|481|[Sheldon and Ice Pieces](http://codeforces.com/problemset/problem/328/B)|Codeforces||Testing Round #8|7|
|<ul><li>- [ ] Done</li></ul>|482|[Lovely Matrix](http://codeforces.com/problemset/problem/274/D)|Codeforces||Codeforces Round #168 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|483|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces||Codeforces Round #158 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|484|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|485|[Educational Game](http://codeforces.com/problemset/problem/178/A3)|Codeforces||ABBYY Cup 2.0 - Hard|7|
|<ul><li>- [ ] Done</li></ul>|486|[Educational Game](http://codeforces.com/problemset/problem/178/A2)|Codeforces||ABBYY Cup 2.0 - Hard|7|
|<ul><li>- [ ] Done</li></ul>|487|[Range Increments](http://codeforces.com/problemset/problem/174/C)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|7|
|<ul><li>- [ ] Done</li></ul>|488|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|489|[Dima and Horses](http://codeforces.com/problemset/problem/272/E)|Codeforces||Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|490|[Hamiltonian Cycle](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3551)|Live Archive|1997|Latin America - South America|7|
|<ul><li>- [ ] Done</li></ul>|491|[Ant Man](http://codeforces.com/problemset/problem/704/B)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|492|[Change-free](http://codeforces.com/problemset/problem/767/E)|Codeforces||Codeforces Round #398 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|493|[Sweets for Everyone!](http://codeforces.com/problemset/problem/248/D)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|494|[T-decomposition](http://codeforces.com/problemset/problem/237/D)|Codeforces||Codeforces Round #147 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|495|[Merging Two Decks](http://codeforces.com/problemset/problem/234/H)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|496|[Trails and Glades](http://codeforces.com/problemset/problem/209/C)|Codeforces||VK Cup 2012 Finals, Practice Session|8|
|<ul><li>- [ ] Done</li></ul>|497|[Hamming Distance](http://codeforces.com/problemset/problem/193/C)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|498|[Optimal Sum](http://codeforces.com/problemset/problem/182/C)|Codeforces||Codeforces Round #117 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|499|[Name](http://codeforces.com/problemset/problem/180/D)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|500|[Competition](http://codeforces.com/problemset/problem/144/E)|Codeforces||Codeforces Round #103 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|501|[Swaps](http://codeforces.com/problemset/problem/134/C)|Codeforces||Codeforces Testing Round #3|8|
|<ul><li>- [ ] Done</li></ul>|502|[Constants in the language of Shakespeare](http://codeforces.com/problemset/problem/132/D)|Codeforces||Codeforces Beta Round #96 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|503|[E-reader Display](http://codeforces.com/problemset/problem/126/C)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|504|[Brackets](http://codeforces.com/problemset/problem/123/C)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|505|[Castle](http://codeforces.com/problemset/problem/101/D)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|506|[Polycarp's Picture Gallery](http://codeforces.com/problemset/problem/81/D)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|8|
|<ul><li>- [ ] Done</li></ul>|507|[FreeDiv](http://codeforces.com/problemset/problem/73/D)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|508|[Need For Brake](http://codeforces.com/problemset/problem/73/B)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|509|[Team Arrangement](http://codeforces.com/problemset/problem/59/D)|Codeforces||Codeforces Beta Round #55 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|510|[Calendar](http://codeforces.com/problemset/problem/58/D)|Codeforces||Codeforces Beta Round #54 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|511|[Director](http://codeforces.com/problemset/problem/45/E)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|512|[Triminoes](http://codeforces.com/problemset/problem/44/J)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|513|[C*++ Calculations](http://codeforces.com/problemset/problem/39/A)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|514|[Tricky and Clever Password](http://codeforces.com/problemset/problem/30/E)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|515|[Deletion of Repeats](http://codeforces.com/problemset/problem/19/C)|Codeforces||Codeforces Beta Round #19|8|
|<ul><li>- [ ] Done</li></ul>|516|[LCS Again](http://codeforces.com/problemset/problem/578/D)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|8|
|<ul><li>- [ ] Done</li></ul>|517|[CNF 2](http://codeforces.com/problemset/problem/571/C)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|518|[New Language](http://codeforces.com/problemset/problem/568/C)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|519|[Shop](http://codeforces.com/problemset/problem/521/D)|Codeforces||Codeforces Round #295 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|520|[Alex and Complicated Task](http://codeforces.com/problemset/problem/467/E)|Codeforces||Codeforces Round #267 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|521|[Cardboard Box](http://codeforces.com/problemset/problem/436/E)|Codeforces||Zepto Code Rush 2014|8|
|<ul><li>- [ ] Done</li></ul>|522|[Square Tiling](http://codeforces.com/problemset/problem/432/E)|Codeforces||Codeforces Round #246 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|523|[Mashmokh and Water Tanks](http://codeforces.com/problemset/problem/414/D)|Codeforces||Codeforces Round #240 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|524|[Maze 1D](http://codeforces.com/problemset/problem/404/E)|Codeforces||Codeforces Round #237 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|525|[Dominoes](http://codeforces.com/problemset/problem/394/C)|Codeforces||Codeforces Round #231 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|526|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces||Codeforces Round #207 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|527|[Antichain](http://codeforces.com/problemset/problem/353/E)|Codeforces||Codeforces Round #205 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|528|[Three Swaps](http://codeforces.com/problemset/problem/339/E)|Codeforces||Codeforces Round #197 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|529|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces||Codeforces Round #186 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|530|[Memory for Arrays](http://codeforces.com/problemset/problem/309/C)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|531|[Roads in Yusland](http://codeforces.com/problemset/problem/671/D)|Codeforces||Codeforces Round #352 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|532|[Factorial](http://codeforces.com/problemset/problem/64/A)|Codeforces||Unknown Language Round #1|8|
|<ul><li>- [ ] Done</li></ul>|533|[Road Repairs](http://codeforces.com/problemset/problem/240/E)|Codeforces||Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|534|[Beaver's Calculator 1.0](http://codeforces.com/problemset/problem/207/A3)|Codeforces||Abbyy Cup 2.0 - Final (unofficial)|9|
|<ul><li>- [ ] Done</li></ul>|535|[Beaver's Calculator 1.0](http://codeforces.com/problemset/problem/207/A2)|Codeforces||Abbyy Cup 2.0 - Final (unofficial)|9|
|<ul><li>- [ ] Done</li></ul>|536|[Beaver's Calculator 1.0](http://codeforces.com/problemset/problem/207/A1)|Codeforces||Abbyy Cup 2.0 - Final (unofficial)|9|
|<ul><li>- [ ] Done</li></ul>|537|[Transportation](http://codeforces.com/problemset/problem/203/E)|Codeforces||Codeforces Round #128 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|538|[The Next Good String](http://codeforces.com/problemset/problem/196/D)|Codeforces||Codeforces Round #124 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|539|[Metro Scheme](http://codeforces.com/problemset/problem/191/D)|Codeforces||Codeforces Round #121 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|540|[T-shirt](http://codeforces.com/problemset/problem/183/D)|Codeforces||Croc Champ 2012 - Final|9|
|<ul><li>- [ ] Done</li></ul>|541|[Power Defence](http://codeforces.com/problemset/problem/175/E)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|542|[Deputies](http://codeforces.com/problemset/problem/173/D)|Codeforces||Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|543|[Shoe Store](http://codeforces.com/problemset/problem/166/D)|Codeforces||Codeforces Round #113 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|544|[Two progressions](http://codeforces.com/problemset/problem/125/D)|Codeforces||Codeforces Testing Round #2|9|
|<ul><li>- [ ] Done</li></ul>|545|[Luck is in Numbers](http://codeforces.com/problemset/problem/120/I)|Codeforces||School Regional Team Contest, Saratov, 2011|9|
|<ul><li>- [ ] Done</li></ul>|546|[Grocer's Problem](http://codeforces.com/problemset/problem/91/D)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|547|[Tetris revisited](http://codeforces.com/problemset/problem/86/B)|Codeforces||Yandex.Algorithm 2011 Round 2|9|
|<ul><li>- [ ] Done</li></ul>|548|[Track](http://codeforces.com/problemset/problem/83/C)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|549|[Mice](http://codeforces.com/problemset/problem/76/B)|Codeforces||All-Ukrainian School Olympiad in Informatics|9|
|<ul><li>- [ ] Done</li></ul>|550|[Presents](http://codeforces.com/problemset/problem/64/D)|Codeforces||Unknown Language Round #1|9|
|<ul><li>- [ ] Done</li></ul>|551|[Table](http://codeforces.com/problemset/problem/64/C)|Codeforces||Unknown Language Round #1|9|
|<ul><li>- [ ] Done</li></ul>|552|[Trial for Chief](http://codeforces.com/problemset/problem/37/E)|Codeforces||Codeforces Beta Round #37|9|
|<ul><li>- [ ] Done</li></ul>|553|[King's Problem?](http://codeforces.com/problemset/problem/30/D)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|554|[Bear and Paradox](http://codeforces.com/problemset/problem/639/E)|Codeforces||VK Cup 2016 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|555|[Raffles](http://codeforces.com/problemset/problem/626/G)|Codeforces||8VC Venture Cup 2016 - Elimination Round|9|
|<ul><li>- [ ] Done</li></ul>|556|[Birthday](http://codeforces.com/problemset/problem/623/D)|Codeforces||AIM Tech Round (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|557|[Walking!](http://codeforces.com/problemset/problem/578/E)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round]|9|
|<ul><li>- [ ] Done</li></ul>|558|[Replicating Processes](http://codeforces.com/problemset/problem/566/B)|Codeforces||VK Cup 2015 - Finals, online mirror|9|
|<ul><li>- [ ] Done</li></ul>|559|[Berland Local Positioning System](http://codeforces.com/problemset/problem/534/E)|Codeforces||Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|560|[Mr. Kitayuta vs. Bamboos](http://codeforces.com/problemset/problem/505/E)|Codeforces||Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|561|[New York Hotel](http://codeforces.com/problemset/problem/491/B)|Codeforces||Testing Round #11|9|
|<ul><li>- [ ] Done</li></ul>|562|[Levko and Game](http://codeforces.com/problemset/problem/360/E)|Codeforces||Codeforces Round #210 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|563|[Pumping Stations](http://codeforces.com/problemset/problem/343/E)|Codeforces||Codeforces Round #200 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|564|[Candies Game](http://codeforces.com/problemset/problem/341/E)|Codeforces||Codeforces Round #198 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|565|[Binary Key](http://codeforces.com/problemset/problem/332/E)|Codeforces||Codeforces Round #193 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|566|[The Red Button](http://codeforces.com/problemset/problem/325/E)|Codeforces||MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|567|[Ciel and Flipboard](http://codeforces.com/problemset/problem/321/D)|Codeforces||Codeforces Round #190 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|568|[Have You Ever Heard About the Word?](http://codeforces.com/problemset/problem/319/D)|Codeforces||Codeforces Round #189 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|569|[Optimizer](http://codeforces.com/problemset/problem/306/B)|Codeforces||Testing Round #6|9|
|<ul><li>- [ ] Done</li></ul>|570|[Ever-Hungry Krakozyabra](http://codeforces.com/problemset/problem/833/C)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|571|[Huffman Coding on Segment](http://codeforces.com/problemset/problem/700/D)|Codeforces||Codeforces Round #364 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|572|[Heaven Tour](http://codeforces.com/problemset/problem/187/E)|Codeforces||Codeforces Round #119 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|573|[Candy Shop](http://codeforces.com/problemset/problem/183/E)|Codeforces||Croc Champ 2012 - Final|10|
|<ul><li>- [ ] Done</li></ul>|574|[Interval Coloring](http://codeforces.com/problemset/problem/100/J)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|575|[Fire and Ice](http://codeforces.com/problemset/problem/89/E)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|576|[Oil](http://codeforces.com/problemset/problem/72/F)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|577|[Goshtasp, Vishtasp and Eidi](http://codeforces.com/problemset/problem/72/A)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|578|[Snow sellers](http://codeforces.com/problemset/problem/48/F)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|579|[Forward, march!](http://codeforces.com/problemset/problem/11/E)|Codeforces||Codeforces Beta Round #11|10|
|<ul><li>- [ ] Done</li></ul>|580|[Dynamic Programming](p?ID=410)|A2 Online Judge|||10|
|<ul><li>- [ ] Done</li></ul>|581|[To Hack or not to Hack](http://codeforces.com/problemset/problem/662/E)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|10|
|<ul><li>- [ ] Done</li></ul>|582|[Frog Fights](http://codeforces.com/problemset/problem/625/E)|Codeforces||Codeforces Round #342 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|583|[Agricultural Archaeology](http://codeforces.com/problemset/problem/589/L)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|10|
|<ul><li>- [ ] Done</li></ul>|584|[Kojiro and Furrari](http://codeforces.com/problemset/problem/581/E)|Codeforces||Codeforces Round #322 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|585|[Bear and Bowling](http://codeforces.com/problemset/problem/573/E)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|586|[Summer Dichotomy](http://codeforces.com/problemset/problem/538/H)|Codeforces||Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|587|[Berland Miners](http://codeforces.com/problemset/problem/533/A)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|588|[Spiders Evil Plan](http://codeforces.com/problemset/problem/526/G)|Codeforces||ZeptoLab Code Rush 2015|10|
|<ul><li>- [ ] Done</li></ul>|589|[An easy problem about trees](http://codeforces.com/problemset/problem/457/F)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|590|[Stock Trading](http://codeforces.com/problemset/problem/391/F2)|Codeforces||Rockethon 2014|10|
|<ul><li>- [ ] Done</li></ul>|591|[The Tournament](http://codeforces.com/problemset/problem/391/C2)|Codeforces||Rockethon 2014|10|
|<ul><li>- [ ] Done</li></ul>|592|[Summer Reading](http://codeforces.com/problemset/problem/370/E)|Codeforces||Codeforces Round #217 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|593|[Buy One, Get One Free](http://codeforces.com/problemset/problem/335/F)|Codeforces||MemSQL start[c]up Round 2 - online version|10|
|<ul><li>- [ ] Done</li></ul>|594|[Sheep](http://codeforces.com/problemset/problem/309/E)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|595|[Greedy Petya](http://codeforces.com/problemset/problem/290/F)|Codeforces||April Fools Day Contest 2013|10|
|<ul><li>- [ ] Done</li></ul>|596|[Goats and Wolves](http://codeforces.com/problemset/problem/45/F)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|597|[Organizing a Race](http://codeforces.com/problemset/problem/671/E)|Codeforces||Codeforces Round #352 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|598|[Chess Championship](http://codeforces.com/problemset/problem/736/E)|Codeforces||Codeforces Round #382 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|599|[Restore the Tree](http://codeforces.com/problemset/problem/871/E)|Codeforces||Codeforces Round #440 (Div. 1, based on Technocup 2018 Elimination Round 2)|10|
