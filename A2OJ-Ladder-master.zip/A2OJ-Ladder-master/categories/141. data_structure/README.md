# 141. data_structure


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[subarrays](http://www.spoj.com/problems/ARRAYSUB/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces|Codeforces Round #169 (Div. 2)|1|
