# 151. maximum_empty_rectangle


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[City Game](http://www.spoj.com/problems/CTGAME/)|SPOJ|1|
