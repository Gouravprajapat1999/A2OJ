# 115. Partitioning


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[SAM I AM](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2414)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|2|[Star Wars](http://www.spoj.com/problems/GCJ08C/)|SPOJ|5|
|<ul><li>- [ ] Done</li></ul>|3|[Electric Fences](http://www.spoj.com/problems/FENCE3/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|4|[Texas Trip](http://www.spoj.com/problems/WLOO0707/)|SPOJ|6|
