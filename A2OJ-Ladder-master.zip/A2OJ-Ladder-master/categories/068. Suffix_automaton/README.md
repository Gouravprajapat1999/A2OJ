# 068. Suffix_automaton


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Long Long Message](http://poj.org/problem?id=2774)|PKU||1|
|<ul><li>- [ ] Done</li></ul>|2|[Longest Common Substring](http://www.spoj.com/problems/LCS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Lexicographical Substring Search](http://www.spoj.com/problems/SUBLEX/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Longest Common Substring II ](http://www.spoj.com/problems/LCS2/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|5|[Substrings](http://www.spoj.com/problems/NSUBSTR/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|6|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|7|[Substring Query](http://www.codechef.com/problems/SUBQUERY)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|8|[Substrings on a Tree](http://www.codechef.com/problems/TSUBSTR)|CodeChef||4|
|<ul><li>- [ ] Done</li></ul>|9|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces|Codeforces Round #246 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|10|[Martian Strings](http://codeforces.com/problemset/problem/149/E)|Codeforces|Codeforces Round #106 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|11|[Cyclical Quest](http://codeforces.com/problemset/problem/235/C)|Codeforces|Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|12|[Three strings](http://codeforces.com/problemset/problem/452/E)|Codeforces|MemSQL Start[c]UP 2.0 - Round 1|8|
|<ul><li>- [ ] Done</li></ul>|13|[String](http://codeforces.com/problemset/problem/123/D)|Codeforces|Codeforces Beta Round #92 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|14|[Deletion of Repeats](http://codeforces.com/problemset/problem/19/C)|Codeforces|Codeforces Beta Round #19|8|
