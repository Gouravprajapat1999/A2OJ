# 071. Hungarian_Algorithm


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Asteroids](http://poj.org/problem?id=3041)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|2|[The Great Wall Game](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1277)|Live Archive|2005|World Finals - Shanghai|1|
|<ul><li>- [ ] Done</li></ul>|3|[Antenna Placement](http://poj.org/problem?id=3020)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|4|[Selfish Cities](http://www.spoj.com/problems/SCITIES/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|5|[Baby](http://www.spoj.com/problems/BABY/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|6|[Beloved Sons](http://acm.sgu.ru/problem.php?contest=0&problem=210)|SGU|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Crime Wave - The Sequel](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1687)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Jogging Trails](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1237)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|9|[Golden Tiger Claw](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2378)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|10|[Warehouse](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1829)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|11|[30 Minutes or Less](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4385)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|12|[Gödel's Dream](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4386)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|13|[Deciphering](http://codeforces.com/problemset/problem/491/C)|Codeforces||Testing Round #11|9|
