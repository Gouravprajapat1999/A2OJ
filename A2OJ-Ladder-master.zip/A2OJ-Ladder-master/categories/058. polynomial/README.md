# 058. polynomial


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Polynomial Coefficients](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1046)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Summation of Polynomials](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1243)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Evaluate the polynomial](http://www.spoj.com/problems/POLEVAL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Polly the Polynomial](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=439)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Polynomial Showdown](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=328)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Quotient Polynomial](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1660)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|7|[The Polynomial Equation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1267)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Polynomial Remains](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1527)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|9|[Polynomial-time Reductions](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2273)|Live Archive|2008|Asia - Hefei|3|
|<ul><li>- [ ] Done</li></ul>|10|[Polynomial](http://www.spoj.com/problems/POLYNOM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|11|[Polynomial GCD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1892)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|12|[Polynomial f(x) to Polynomial h(x)](http://www.spoj.com/problems/POLTOPOL/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|13|[Polynomial Derivative](https://www.urionlinejudge.com.br/judge/en/problems/view/2154)|URI|||5|
|<ul><li>- [ ] Done</li></ul>|14|[Recover Polynomials](http://www.spoj.com/problems/BTCODE_E/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|15|[Polynomial Multiplication](http://acm.timus.ru/problem.aspx?space=1&num=1408)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|16|[Polynomial Equations](http://www.spoj.com/problems/POLYEQ/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|17|[Irreducible polynomials over GF2](http://www.spoj.com/problems/GF2/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|18|[Roots of polynomial](http://www.spoj.com/problems/KMSL4B/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|19|[Polynomial Evaluation - Angry Teacher](http://www.spoj.com/problems/MPOLEVAL/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|20|[Polynomial Roots](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=871)|UVA|||7|
