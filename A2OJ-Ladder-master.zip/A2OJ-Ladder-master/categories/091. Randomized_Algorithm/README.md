# 091. Randomized_Algorithm


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Dima and Lisa](http://codeforces.com/problemset/problem/584/D)|Codeforces|Codeforces Round #324 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|2|[Taxes](http://codeforces.com/problemset/problem/735/D)|Codeforces|Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|3|[Troublemakers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1923)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|4|[Interactive LowerBound](http://codeforces.com/problemset/problem/843/B)|Codeforces|AIM Tech Round 4 (Div. 1) & AIM Tech Round 4 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|5|[Ghd](http://codeforces.com/problemset/problem/364/D)|Codeforces|Codeforces Round #213 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|6|[Oranges and Apples](http://codeforces.com/problemset/problem/23/C)|Codeforces|Codeforces Beta Round #23|8|
|<ul><li>- [ ] Done</li></ul>|7|[Lost Root](http://codeforces.com/problemset/problem/1061/F)|Codeforces|Codeforces Round #523 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|8|[Digits](http://codeforces.com/problemset/problem/852/A)|Codeforces|Bubble Cup X - Finals [Online Mirror]|9|
