# 110. matrix_exponentiation


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Yet another Number Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1630)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|2|[Sum of products](http://www.spoj.com/problems/SUMMUL/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|3|[Plant](http://codeforces.com/problemset/problem/185/A)|Codeforces|Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|4|[Blocks for kids](http://www.spoj.com/problems/PBOARD/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|5|[Decoding Genome](http://codeforces.com/problemset/problem/222/E)|Codeforces|Codeforces Round #137 (Div. 2)|6|
