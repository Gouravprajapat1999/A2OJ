# 003. math


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Perfect Permutation](http://codeforces.com/problemset/problem/233/A)|Codeforces||Codeforces Round #144 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Parallelepiped](http://codeforces.com/problemset/problem/224/A)|Codeforces||Codeforces Round #138 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Drinks](http://codeforces.com/problemset/problem/200/B)|Codeforces||Codeforces Round #126 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces||Codeforces Round #119 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces||Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Insomnia cure](http://codeforces.com/problemset/problem/148/A)|Codeforces||Codeforces Round #105 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[The number of positions](http://codeforces.com/problemset/problem/124/A)|Codeforces||Codeforces Beta Round #92 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Cifera](http://codeforces.com/problemset/problem/114/A)|Codeforces||Codeforces Beta Round #86 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Chips](http://codeforces.com/problemset/problem/92/A)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Toy Army](http://codeforces.com/problemset/problem/84/A)|Codeforces||Codeforces Beta Round #72 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Double Cola](http://codeforces.com/problemset/problem/82/A)|Codeforces||Yandex.Algorithm 2011 Qualification 2|1|
|<ul><li>- [ ] Done</li></ul>|13|[Panoramix's Prediction](http://codeforces.com/problemset/problem/80/A)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|14|[Domino piling](http://codeforces.com/problemset/problem/50/A)|Codeforces||Codeforces Beta Round #47|1|
|<ul><li>- [ ] Done</li></ul>|15|[Die Roll](http://codeforces.com/problemset/problem/9/A)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Triangle](http://codeforces.com/problemset/problem/6/A)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Watermelon](http://codeforces.com/problemset/problem/4/A)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Spreadsheet](http://codeforces.com/problemset/problem/1/B)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|19|[Theatre Square](http://codeforces.com/problemset/problem/1/A)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|20|[Buttons](http://codeforces.com/problemset/problem/268/B)|Codeforces||Codeforces Round #164 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Fibonacci Numbers](http://acm.tju.edu.cn/toj/showp1208.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Playing With Balls](http://www.spoj.com/problems/IITKWPCN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Carmichael Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=947)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Clock Hands](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=520)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Why this kolaveri di](http://www.spoj.com/problems/WTK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|26|[FANCY NUMBERS](http://www.spoj.com/problems/FANCY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Play with Dates](http://www.spoj.com/problems/CODEIT03/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|28|[HOW MANY GAMES](http://www.spoj.com/problems/GAMES/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|29|[Touch of Venom](http://www.spoj.com/problems/VENOM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|30|[Array fill I](https://www.urionlinejudge.com.br/judge/en/problems/view/1173)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|31|[Relational Operator](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2113)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|32|[The Large Family](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4416)|Live Archive|2013|South Pacific|1|
|<ul><li>- [ ] Done</li></ul>|33|[Prime Distance](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1081)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|34|[New Year Candles](http://codeforces.com/problemset/problem/379/A)|Codeforces||Good Bye 2013|1|
|<ul><li>- [ ] Done</li></ul>|35|[N-Factorful](http://www.spoj.com/problems/NFACTOR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|36|[To Carry or not to Carry](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1410)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|37|[Add them twice](p?ID=346)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Complicated GCD](http://codeforces.com/problemset/problem/664/A)|Codeforces||Codeforces Round #347 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Round House](http://codeforces.com/problemset/problem/659/A)|Codeforces||Codeforces Round #346 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Watchmen](http://codeforces.com/problemset/problem/650/A)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|41|[Lucky Numbers](http://codeforces.com/problemset/problem/630/C)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|1|
|<ul><li>- [ ] Done</li></ul>|42|[Save Luke](http://codeforces.com/problemset/problem/624/A)|Codeforces||AIM Tech Round (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|43|[Professor GukiZ's Robot](http://codeforces.com/problemset/problem/620/A)|Codeforces||Educational Codeforces Round 6|1|
|<ul><li>- [ ] Done</li></ul>|44|[Elephant](http://codeforces.com/problemset/problem/617/A)|Codeforces||Codeforces Round #340 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|45|[Pasha and Stick](http://codeforces.com/problemset/problem/610/A)|Codeforces||Codeforces Round #337 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|46|[Tricky Sum](http://codeforces.com/problemset/problem/598/A)|Codeforces||Educational Codeforces Round 1|1|
|<ul><li>- [ ] Done</li></ul>|47|[The Monster and the Squirrel](http://codeforces.com/problemset/problem/592/B)|Codeforces||Codeforces Round #328 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|48|[Wizards' Duel](http://codeforces.com/problemset/problem/591/A)|Codeforces||Codeforces Round #327 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|49|[Duff in Love](http://codeforces.com/problemset/problem/588/B)|Codeforces||Codeforces Round #326 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|50|[Olesya and Rodion](http://codeforces.com/problemset/problem/584/A)|Codeforces||Codeforces Round #324 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|51|[Vasya and Petya's Game](http://codeforces.com/problemset/problem/576/A)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|52|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces||Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|53|[Gerald's Hexagon](http://codeforces.com/problemset/problem/559/A)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|54|[Kyoya and Photobooks](http://codeforces.com/problemset/problem/554/A)|Codeforces||Codeforces Round #309 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|55|[Vanya and Books](http://codeforces.com/problemset/problem/552/B)|Codeforces||Codeforces Round #308 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|56|[Vanya and Table](http://codeforces.com/problemset/problem/552/A)|Codeforces||Codeforces Round #308 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|57|[Divisibility by Eight](http://codeforces.com/problemset/problem/550/C)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|58|[Soldier and Bananas](http://codeforces.com/problemset/problem/546/A)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|59|[Playing with Paper](http://codeforces.com/problemset/problem/527/A)|Codeforces||Codeforces Round #296 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|60|[Two Buttons](http://codeforces.com/problemset/problem/520/B)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|61|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|62|[Drazil and Factorial](http://codeforces.com/problemset/problem/515/C)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|63|[Drazil and Date](http://codeforces.com/problemset/problem/515/A)|Codeforces||Codeforces Round #292 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|64|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|65|[Game](http://codeforces.com/problemset/problem/513/A)|Codeforces||Rockethon 2015|1|
|<ul><li>- [ ] Done</li></ul>|66|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|67|[Minimum Difficulty](http://codeforces.com/problemset/problem/496/A)|Codeforces||Codeforces Round #283 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|68|[Vanya and Lanterns](http://codeforces.com/problemset/problem/492/B)|Codeforces||Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|69|[Calculating Function](http://codeforces.com/problemset/problem/486/A)|Codeforces||Codeforces Round #277 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|70|[Expression](http://codeforces.com/problemset/problem/479/A)|Codeforces||Codeforces Round #274 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|71|[Random Teams](http://codeforces.com/problemset/problem/478/B)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|72|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|73|[Dreamoon and Stairs](http://codeforces.com/problemset/problem/476/A)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|74|[Design Tutorial: Learn from Math](http://codeforces.com/problemset/problem/472/A)|Codeforces||Codeforces Round #270|1|
|<ul><li>- [ ] Done</li></ul>|75|[Caisa and Pylons](http://codeforces.com/problemset/problem/463/B)|Codeforces||Codeforces Round #264 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|76|[Fedya and Maths](http://codeforces.com/problemset/problem/456/B)|Codeforces||Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|77|[Jzzhu and Sequences](http://codeforces.com/problemset/problem/450/B)|Codeforces||Codeforces Round #257 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|78|[Vanya and Cards](http://codeforces.com/problemset/problem/401/A)|Codeforces||Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|79|[Fox and Number Game](http://codeforces.com/problemset/problem/389/A)|Codeforces||Codeforces Round #228 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|80|[Domino](http://codeforces.com/problemset/problem/353/A)|Codeforces||Codeforces Round #205 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|81|[Jeff and Digits](http://codeforces.com/problemset/problem/352/A)|Codeforces||Codeforces Round #204 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|82|[Hungry Sequence](http://codeforces.com/problemset/problem/327/B)|Codeforces||Codeforces Round #191 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|83|[Even Odds](http://codeforces.com/problemset/problem/318/A)|Codeforces||Codeforces Round #188 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|84|[Shaass and Oskols](http://codeforces.com/problemset/problem/294/A)|Codeforces||Codeforces Round #178 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|85|[Dima and Friends](http://codeforces.com/problemset/problem/272/A)|Codeforces||Codeforces Round #167 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|86|[Fancy Fence](http://codeforces.com/problemset/problem/270/A)|Codeforces||Codeforces Round #165 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|87|[Little Elephant and Bits](http://codeforces.com/problemset/problem/258/A)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|88|[Young Physicist](http://codeforces.com/problemset/problem/69/A)|Codeforces||Codeforces Beta Round #63 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|89|[Infinite Sequence](http://codeforces.com/problemset/problem/675/A)|Codeforces||Codeforces Round #353 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|90|[Hashmat the Brave Warrior](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=996)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|91|[Simple Math](p?ID=347)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|92|[Initial Bet](http://codeforces.com/problemset/problem/478/A)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|93|[Prime Generator](http://www.spoj.com/problems/PRIME1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|94|[I'm bored with life](http://codeforces.com/problemset/problem/822/A)|Codeforces||Codeforces Round #422 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|95|[Sasha and Sticks](http://codeforces.com/problemset/problem/832/A)|Codeforces||Codeforces Round #425 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|96|[Hello](p?ID=343)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|97|[Add Two numbers](p?ID=344)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|98|[Roommate Agreement](http://www.spoj.com/problems/CRAN02/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|99|[Prime or Not](http://www.spoj.com/problems/PON/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|100|[DDD](https://www.urionlinejudge.com.br/judge/en/problems/view/1050)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|101|[Factorial Frequencies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=260)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|102|[Bachgold Problem](http://codeforces.com/problemset/problem/749/A)|Codeforces||Codeforces Round #388 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|103|[Taymyr is calling you](http://codeforces.com/problemset/problem/764/A)|Codeforces||Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|104|[Fraction](http://codeforces.com/problemset/problem/854/A)|Codeforces||Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|1|
|<ul><li>- [ ] Done</li></ul>|105|[Lovely Palindromes](http://codeforces.com/problemset/problem/688/B)|Codeforces||Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|106|[Arpa’s hard exam and Mehrdad’s naive cheat](http://codeforces.com/problemset/problem/742/A)|Codeforces||Codeforces Round #383 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|107|[Anastasia and pebbles](http://codeforces.com/problemset/problem/789/A)|Codeforces||Codeforces Round #407 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|108|[The Eternal Immortality](http://codeforces.com/problemset/problem/869/B)|Codeforces||Codeforces Round #439 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|109|[Meeting of Old Friends](http://codeforces.com/problemset/problem/714/A)|Codeforces||Codeforces Round #371 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|110|[Godsend](http://codeforces.com/problemset/problem/841/B)|Codeforces||Codeforces Round #429 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|111|[The Monster](http://codeforces.com/problemset/problem/787/A)|Codeforces||Codeforces Round #406 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|112|[Maximum Clique](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=1492)|ZOJ|||1|
|<ul><li>- [ ] Done</li></ul>|113|[Dragons](http://codeforces.com/problemset/problem/230/A)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|114|[Soldier and Cards](http://codeforces.com/problemset/problem/546/C)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|115|[Simple Equations](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2612)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|116|[Simple Sum](https://www.urionlinejudge.com.br/judge/en/problems/view/1003)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|117|[Simple Product](https://www.urionlinejudge.com.br/judge/en/problems/view/1004)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|118|[Average 2](https://www.urionlinejudge.com.br/judge/en/problems/view/1006)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|119|[Difference](https://www.urionlinejudge.com.br/judge/en/problems/view/1007)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|120|[Salary with Bonus](https://www.urionlinejudge.com.br/judge/en/problems/view/1009)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|121|[Area](https://www.urionlinejudge.com.br/judge/en/problems/view/1012)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|122|[Sphere](https://www.urionlinejudge.com.br/judge/en/problems/view/1011)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|123|[Time Conversion](https://www.urionlinejudge.com.br/judge/en/problems/view/1019)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|124|[Distance Between Two Points](https://www.urionlinejudge.com.br/judge/en/problems/view/1015)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|125|[Fuel Spent](https://www.urionlinejudge.com.br/judge/en/problems/view/1017)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|126|[Simple Calculate](https://www.urionlinejudge.com.br/judge/en/problems/view/1010)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|127|[Bachelor Arithmetic](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2056)|Live Archive|2007|Asia - Dhaka|1|
|<ul><li>- [ ] Done</li></ul>|128|[GCD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2412)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|129|[Little Elephant and Magic Square](http://codeforces.com/problemset/problem/259/B)|Codeforces||Codeforces Round #157 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|130|[Increase and Decrease](http://codeforces.com/problemset/problem/246/B)|Codeforces||Codeforces Round #151 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|131|[Little Elephant and Function](http://codeforces.com/problemset/problem/221/A)|Codeforces||Codeforces Round #136 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|132|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|133|[The World is a Theatre](http://codeforces.com/problemset/problem/131/C)|Codeforces||Codeforces Beta Round #95 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|134|[Opposites Attract](http://codeforces.com/problemset/problem/131/B)|Codeforces||Codeforces Beta Round #95 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|135|[Faulty Odometer](http://acm.tju.edu.cn/toj/showp1987.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|136|[Marbles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1031)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|137|[Permutations](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=882)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|138|[Coconuts, Revisited](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=557)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|139|[PRIMITIVEROOTS](http://www.spoj.com/problems/PROBLEM4/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|140|[GRADE POINT AVERAGE](http://www.spoj.com/problems/GPA1/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|141|[EVEN COUNT](http://www.spoj.com/problems/GEEKOUNT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|142|[Triangular numbers](http://codeforces.com/problemset/problem/47/A)|Codeforces||Codeforces Beta Round #44 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|143|[Matrix Multiplication](http://poj.org/problem?id=3318)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|144|[Lever](http://codeforces.com/problemset/problem/376/A)|Codeforces||Codeforces Round #221 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|145|[Help Vasilisa the Wise 2](http://codeforces.com/problemset/problem/143/A)|Codeforces||Codeforces Round #102 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|146|[Simple Addition](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1935)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|147|[Little Dima and Equation](http://codeforces.com/problemset/problem/460/B)|Codeforces||Codeforces Round #262 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|148|[Mafia](http://codeforces.com/problemset/problem/348/A)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|149|[Ebony and Ivory](http://codeforces.com/problemset/problem/633/A)|Codeforces||Manthan, Codefest 16|2|
|<ul><li>- [ ] Done</li></ul>|150|[Divisibility](http://codeforces.com/problemset/problem/630/J)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|2|
|<ul><li>- [ ] Done</li></ul>|151|[Hexagons!](http://codeforces.com/problemset/problem/630/D)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|2|
|<ul><li>- [ ] Done</li></ul>|152|[Infinite Sequence](http://codeforces.com/problemset/problem/622/A)|Codeforces||Educational Codeforces Round 7|2|
|<ul><li>- [ ] Done</li></ul>|153|[Saitama Destroys Hotel](http://codeforces.com/problemset/problem/608/A)|Codeforces||Codeforces Round #336 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|154|[Kyoya and Colored Balls](http://codeforces.com/problemset/problem/553/A)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|155|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces||Codeforces Round #304 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|156|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|157|[Covered Path](http://codeforces.com/problemset/problem/534/B)|Codeforces||Codeforces Round #298 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|158|[New Year Book Reading](http://codeforces.com/problemset/problem/500/C)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|159|[New Year Permutation](http://codeforces.com/problemset/problem/500/B)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|160|[Hacking Cypher](http://codeforces.com/problemset/problem/490/C)|Codeforces||Codeforces Round #279 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|161|[Factory](http://codeforces.com/problemset/problem/485/A)|Codeforces||Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|162|[24 Game](http://codeforces.com/problemset/problem/468/A)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|163|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces||Codeforces Round #226 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|164|[Fixed Points](http://codeforces.com/problemset/problem/347/B)|Codeforces||Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|165|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|166|[Simple Molecules](http://codeforces.com/problemset/problem/344/B)|Codeforces||Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|167|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|168|[The Wall](http://codeforces.com/problemset/problem/340/A)|Codeforces||Codeforces Round #198 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|169|[Vasily the Bear and Triangle](http://codeforces.com/problemset/problem/336/A)|Codeforces||Codeforces Round #195 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|170|[Ciel and Flowers](http://codeforces.com/problemset/problem/322/B)|Codeforces||Codeforces Round #190 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|171|[Archer](http://codeforces.com/problemset/problem/312/B)|Codeforces||Codeforces Round #185 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|172|[Yaroslav and Permutations](http://codeforces.com/problemset/problem/296/A)|Codeforces||Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|173|[Painting Eggs](http://codeforces.com/problemset/problem/282/B)|Codeforces||Codeforces Round #173 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|174|[Prime Matrix](http://codeforces.com/problemset/problem/271/B)|Codeforces||Codeforces Round #166 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|175|[Adding Digits](http://codeforces.com/problemset/problem/260/A)|Codeforces||Codeforces Round #158 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|176|[Two Bags of Potatoes](http://codeforces.com/problemset/problem/239/A)|Codeforces||Codeforces Round #148 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|177|[Hexadecimal's Numbers](http://codeforces.com/problemset/problem/9/C)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|178|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces||Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|179|[Little Artem and Presents](http://codeforces.com/problemset/problem/669/A)|Codeforces||Codeforces Round #348 (VK Cup 2016 Round 2, Div. 2 Edition)|2|
|<ul><li>- [ ] Done</li></ul>|180|[Pouring Rain](http://codeforces.com/problemset/problem/667/A)|Codeforces||Codeforces Round #349 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|181|[Restoring Painting](http://codeforces.com/problemset/problem/675/B)|Codeforces||Codeforces Round #353 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|182|[Vanya and Food Processor](http://codeforces.com/problemset/problem/677/B)|Codeforces||Codeforces Round #355 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|183|[Queries on a String](http://codeforces.com/problemset/problem/598/B)|Codeforces||Educational Codeforces Round 1|2|
|<ul><li>- [ ] Done</li></ul>|184|[Searching the Graph](http://pl.spoj.com/problems/TDBFS/)|SPOJ Poland|||2|
|<ul><li>- [ ] Done</li></ul>|185|[Frugal Search](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1599)|Live Archive|2006|North America - Mid-Central USA|2|
|<ul><li>- [ ] Done</li></ul>|186|[Leha and Function](http://codeforces.com/problemset/problem/840/A)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|187|[Plus and Square Root](http://codeforces.com/problemset/problem/715/A)|Codeforces||Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|188|[Tennis Championship](http://codeforces.com/problemset/problem/735/C)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|189|[Taxes](http://codeforces.com/problemset/problem/735/D)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|190|[Pride](http://codeforces.com/problemset/problem/891/A)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|191|[Straight <<A>>](http://codeforces.com/problemset/problem/810/A)|Codeforces||Codeforces Round #415 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|192|[Okabe and Banana Trees](http://codeforces.com/problemset/problem/821/B)|Codeforces||Codeforces Round #420 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|193|[Position in Fraction](http://codeforces.com/problemset/problem/900/B)|Codeforces||Codeforces Round #450 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|194|[Mishka and trip](http://codeforces.com/problemset/problem/703/B)|Codeforces||Codeforces Round #365 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|195|[Vladik and fractions](http://codeforces.com/problemset/problem/743/C)|Codeforces||Codeforces Round #384 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|196|[Pythagorean Triples](http://codeforces.com/problemset/problem/707/C)|Codeforces||Codeforces Round #368 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|197|[Arpa’s obvious problem and Mehrdad’s terrible solution](http://codeforces.com/problemset/problem/742/B)|Codeforces||Codeforces Round #383 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|198|[Anton and Fairy Tale](http://codeforces.com/problemset/problem/785/C)|Codeforces||Codeforces Round #404 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|199|[GCD Table](http://codeforces.com/problemset/problem/582/A)|Codeforces||Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|200|[Non-square Equation](http://codeforces.com/problemset/problem/233/B)|Codeforces||Codeforces Round #144 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|201|[Tiling with Hexagons](http://codeforces.com/problemset/problem/216/A)|Codeforces||Codeforces Round #133 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|202|[Let's Watch Football](http://codeforces.com/problemset/problem/195/A)|Codeforces||Codeforces Round #123 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|203|[Exams](http://codeforces.com/problemset/problem/194/A)|Codeforces||Codeforces Round #122 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|204|[Vasya and the Bus](http://codeforces.com/problemset/problem/190/A)|Codeforces||Codeforces Round #120 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|205|[Plant](http://codeforces.com/problemset/problem/185/A)|Codeforces||Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|206|[Median](http://codeforces.com/problemset/problem/166/C)|Codeforces||Codeforces Round #113 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|207|[New Year Table](http://codeforces.com/problemset/problem/140/A)|Codeforces||Codeforces Round #100|3|
|<ul><li>- [ ] Done</li></ul>|208|[Ternary Logic](http://codeforces.com/problemset/problem/136/B)|Codeforces||Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|209|[Testing Pants for Sadness](http://codeforces.com/problemset/problem/103/A)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|210|[Noldbach problem](http://codeforces.com/problemset/problem/17/A)|Codeforces||Codeforces Beta Round #17|3|
|<ul><li>- [ ] Done</li></ul>|211|[Numbers](http://codeforces.com/problemset/problem/13/A)|Codeforces||Codeforces Beta Round #13|3|
|<ul><li>- [ ] Done</li></ul>|212|[Increasing Sequence](http://codeforces.com/problemset/problem/11/A)|Codeforces||Codeforces Beta Round #11|3|
|<ul><li>- [ ] Done</li></ul>|213|[The least round way](http://codeforces.com/problemset/problem/2/B)|Codeforces||Codeforces Beta Round #2|3|
|<ul><li>- [ ] Done</li></ul>|214|[Azooz](http://www.spoj.com/problems/AZOOZ/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|215|[Fox Dividing Cheese](http://codeforces.com/problemset/problem/371/B)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|216|[Catch Me If You Can ](http://www.spoj.com/problems/CMIYC/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|217|[FUN WITH LETTERS](http://www.spoj.com/problems/FUNNUMS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|218|[ZEROES IN RANGE V2](http://www.spoj.com/problems/RANGZER2/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|219|[N - DIGIT NUMBERS](http://www.spoj.com/problems/NDIGITS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|220|[LUCKYNINE](http://www.spoj.com/problems/NITHY/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|221|[SPIRAL RUN](http://www.spoj.com/problems/SPIRAL2/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|222|[Easy Sum-2](p?ID=155)|A2 Online Judge|||3|
|<ul><li>- [ ] Done</li></ul>|223|[Burger](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=498)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|224|[Pashmak and Buses](http://codeforces.com/problemset/problem/459/C)|Codeforces||Codeforces Round #261 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|225|[Rook, Bishop and King](http://codeforces.com/problemset/problem/370/A)|Codeforces||Codeforces Round #217 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|226|[Cows and Primitive Roots](http://codeforces.com/problemset/problem/284/A)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|227|[Modular Equations](http://codeforces.com/problemset/problem/495/B)|Codeforces||Codeforces Round #282 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|228|[Polynomial-time Reductions](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2273)|Live Archive|2008|Asia - Hefei|3|
|<ul><li>- [ ] Done</li></ul>|229|[Powerful array](http://codeforces.com/problemset/problem/86/D)|Codeforces||Yandex.Algorithm 2011 Round 2|3|
|<ul><li>- [ ] Done</li></ul>|230|[Geometry Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2677)|Live Archive|2009|Asia - Amritapuri|3|
|<ul><li>- [ ] Done</li></ul>|231|[Bicycle Race](http://codeforces.com/problemset/problem/659/D)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|232|[A Trivial Problem](http://codeforces.com/problemset/problem/633/B)|Codeforces||Manthan, Codefest 16|3|
|<ul><li>- [ ] Done</li></ul>|233|[Moore's Law](http://codeforces.com/problemset/problem/630/B)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|3|
|<ul><li>- [ ] Done</li></ul>|234|[Guest From the Past](http://codeforces.com/problemset/problem/625/A)|Codeforces||Codeforces Round #342 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|235|[Replace To Make Regular Bracket Sequence](http://codeforces.com/problemset/problem/612/C)|Codeforces||Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|236|[A Problem about Polyline](http://codeforces.com/problemset/problem/578/A)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|237|[Music](http://codeforces.com/problemset/problem/569/A)|Codeforces||Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|238|[Primes or Palindromes?](http://codeforces.com/problemset/problem/568/A)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|239|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces||Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|240|[Polycarpus' Dice](http://codeforces.com/problemset/problem/534/C)|Codeforces||Codeforces Round #298 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|241|[DNA Alignment](http://codeforces.com/problemset/problem/520/C)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|242|[Guess Your Way Out!](http://codeforces.com/problemset/problem/507/C)|Codeforces||Codeforces Round #287 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|243|[Maximum Value](http://codeforces.com/problemset/problem/484/B)|Codeforces||Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|244|[Dreamoon and Sums](http://codeforces.com/problemset/problem/476/C)|Codeforces||Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|245|[Jzzhu and Chocolate](http://codeforces.com/problemset/problem/449/A)|Codeforces||Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|246|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|247|[Mashmokh and Tokens](http://codeforces.com/problemset/problem/415/B)|Codeforces||Codeforces Round #240 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|248|[Triangle](http://codeforces.com/problemset/problem/407/A)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|249|[Unusual Product](http://codeforces.com/problemset/problem/405/C)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|250|[Nuts](http://codeforces.com/problemset/problem/402/A)|Codeforces||Codeforces Round #236 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|251|[Sereja and Contests](http://codeforces.com/problemset/problem/401/B)|Codeforces||Codeforces Round #235 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|252|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|253|[K-Periodic Array](http://codeforces.com/problemset/problem/371/A)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|254|[Valera and Contest](http://codeforces.com/problemset/problem/369/B)|Codeforces||Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|255|[Levko and Permutation](http://codeforces.com/problemset/problem/361/B)|Codeforces||Codeforces Round #210 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|256|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces||Codeforces Round #209 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|257|[Vasya and Robot](http://codeforces.com/problemset/problem/354/A)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|258|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|259|[Routine Problem](http://codeforces.com/problemset/problem/337/B)|Codeforces||Codeforces Round #196 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|260|[Pythagorean Theorem II](http://codeforces.com/problemset/problem/304/A)|Codeforces||Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|261|[Lucky Permutation Triple](http://codeforces.com/problemset/problem/303/A)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|262|[XOR and OR](http://codeforces.com/problemset/problem/282/C)|Codeforces||Codeforces Round #173 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|263|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces||Codeforces Round #169 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|264|[Common Divisors](http://codeforces.com/problemset/problem/182/D)|Codeforces||Codeforces Round #117 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|265|[Robbers' watch](http://codeforces.com/problemset/problem/685/A)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|266|[Do you want a date?](http://codeforces.com/problemset/problem/809/A)|Codeforces||Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|267|[Arpa's loud Owf and Mehrdad's evil plan](http://codeforces.com/problemset/problem/741/A)|Codeforces||Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|268|[The Meaningless Game](http://codeforces.com/problemset/problem/833/A)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|269|[Arpa and an exam about geometry](http://codeforces.com/problemset/problem/851/B)|Codeforces||Codeforces Round #432 (Div. 2, based on IndiaHacks Final Round 2017)|3|
|<ul><li>- [ ] Done</li></ul>|270|[Memory and De-Evolution](http://codeforces.com/problemset/problem/712/C)|Codeforces||Codeforces Round #370 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|271|[Masha and geometric depression](http://codeforces.com/problemset/problem/789/B)|Codeforces||Codeforces Round #407 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|272|[Simple Arithmetics](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=154)|Live Archive|2000|Europe - Central|3|
|<ul><li>- [ ] Done</li></ul>|273|[Year of University Entrance](http://codeforces.com/problemset/problem/769/A)|Codeforces||VK Cup 2017 - Qualification 1|3|
|<ul><li>- [ ] Done</li></ul>|274|[Flying Saucer Segments](http://codeforces.com/problemset/problem/226/A)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|275|[Olympic Medal](http://codeforces.com/problemset/problem/215/B)|Codeforces||Codeforces Round #132 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|276|[About Bacteria](http://codeforces.com/problemset/problem/198/A)|Codeforces||Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|277|[Limit](http://codeforces.com/problemset/problem/197/B)|Codeforces||Codeforces Round #124 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|278|[Plate Game](http://codeforces.com/problemset/problem/197/A)|Codeforces||Codeforces Round #124 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|279|[After Training](http://codeforces.com/problemset/problem/195/B)|Codeforces||Codeforces Round #123 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|280|[Square](http://codeforces.com/problemset/problem/194/B)|Codeforces||Codeforces Round #122 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|281|[Counting Rhombi](http://codeforces.com/problemset/problem/189/B)|Codeforces||Codeforces Round #119 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|282|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces||Codeforces Round #111 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|283|[Colliders](http://codeforces.com/problemset/problem/154/B)|Codeforces||Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|284|[Quantity of Strings](http://codeforces.com/problemset/problem/150/B)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|285|[Division into Teams](http://codeforces.com/problemset/problem/149/C)|Codeforces||Codeforces Round #106 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|286|[Bag of mice](http://codeforces.com/problemset/problem/148/D)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|287|[Escape](http://codeforces.com/problemset/problem/148/B)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|288|[Hopscotch](http://codeforces.com/problemset/problem/141/B)|Codeforces||Codeforces Round #101 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|289|[Winnie-the-Pooh and honey](http://codeforces.com/problemset/problem/120/C)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|290|[Elevator](http://codeforces.com/problemset/problem/120/A)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|291|[Petya and Square](http://codeforces.com/problemset/problem/112/B)|Codeforces||Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|292|[Binary Number](http://codeforces.com/problemset/problem/92/B)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|293|[Cableway](http://codeforces.com/problemset/problem/90/A)|Codeforces||Codeforces Beta Round #74 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|294|[Trains](http://codeforces.com/problemset/problem/87/A)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|295|[Magical Array](http://codeforces.com/problemset/problem/83/A)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|296|[Depression](http://codeforces.com/problemset/problem/80/B)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|297|[Round Table Knights](http://codeforces.com/problemset/problem/71/C)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|298|[Progress Bar](http://codeforces.com/problemset/problem/71/B)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|299|[Cookies](http://codeforces.com/problemset/problem/70/A)|Codeforces||Codeforces Beta Round #64|4|
|<ul><li>- [ ] Done</li></ul>|300|[A Student's Dream](http://codeforces.com/problemset/problem/62/A)|Codeforces||Codeforces Beta Round #58|4|
|<ul><li>- [ ] Done</li></ul>|301|[Weird Fence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2229)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|302|[Face the mate](http://www.spoj.com/problems/FACENEMY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|303|[Rebus](http://codeforces.com/problemset/problem/663/A)|Codeforces||Codeforces Round #347 (Div. 1) & Codeforces Round #347 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|304|[Mischievous Mess Makers](http://codeforces.com/problemset/problem/645/B)|Codeforces||CROC 2016 - Elimination Round|4|
|<ul><li>- [ ] Done</li></ul>|305|[Forecast](http://codeforces.com/problemset/problem/630/N)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|4|
|<ul><li>- [ ] Done</li></ul>|306|[Indivisibility](http://codeforces.com/problemset/problem/630/K)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|4|
|<ul><li>- [ ] Done</li></ul>|307|[XOR Equation](http://codeforces.com/problemset/problem/627/A)|Codeforces||8VC Venture Cup 2016 - Final Round|4|
|<ul><li>- [ ] Done</li></ul>|308|[Multipliers](http://codeforces.com/problemset/problem/615/D)|Codeforces||Codeforces Round #338 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|309|[Spongebob and Squares](http://codeforces.com/problemset/problem/599/D)|Codeforces||Codeforces Round #332 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|310|[Divisibility](http://codeforces.com/problemset/problem/597/A)|Codeforces||Testing Round #12|4|
|<ul><li>- [ ] Done</li></ul>|311|[Pasha and Phone](http://codeforces.com/problemset/problem/595/B)|Codeforces||Codeforces Round #330 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|312|[The Big Race](http://codeforces.com/problemset/problem/592/C)|Codeforces||Codeforces Round #328 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|313|[Three Logos](http://codeforces.com/problemset/problem/581/D)|Codeforces||Codeforces Round #322 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|314|[Gerald and Giant Chess](http://codeforces.com/problemset/problem/559/C)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|315|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces||Codeforces Round #308 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|316|[Tavas and Karafs](http://codeforces.com/problemset/problem/535/C)|Codeforces||Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|317|[Permutations](http://codeforces.com/problemset/problem/513/B2)|Codeforces||Rockethon 2015|4|
|<ul><li>- [ ] Done</li></ul>|318|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|319|[Vanya and Computer Game](http://codeforces.com/problemset/problem/492/D)|Codeforces||Codeforces Round #280 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|320|[Friends and Presents](http://codeforces.com/problemset/problem/483/B)|Codeforces||Codeforces Round #275 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|321|[Dreamoon and Sets](http://codeforces.com/problemset/problem/476/D)|Codeforces||Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|322|[MUH and House of Cards](http://codeforces.com/problemset/problem/471/C)|Codeforces||Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|323|[Wonder Room](http://codeforces.com/problemset/problem/466/B)|Codeforces||Codeforces Round #266 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|324|[Count Good Substrings](http://codeforces.com/problemset/problem/451/D)|Codeforces||Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|325|[Predict Outcome of the Game](http://codeforces.com/problemset/problem/451/C)|Codeforces||Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|326|[DZY Loves Physics](http://codeforces.com/problemset/problem/444/A)|Codeforces||Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|327|[Om Nom and Spiders](http://codeforces.com/problemset/problem/436/B)|Codeforces||Zepto Code Rush 2014|4|
|<ul><li>- [ ] Done</li></ul>|328|[Magic Formulas](http://codeforces.com/problemset/problem/424/C)|Codeforces||Codeforces Round #242 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|329|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|330|[Marathon](http://codeforces.com/problemset/problem/404/B)|Codeforces||Codeforces Round #237 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|331|[Inna and Huge Candy Matrix](http://codeforces.com/problemset/problem/400/C)|Codeforces||Codeforces Round #234 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|332|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|333|[Two Semiknights Meet](http://codeforces.com/problemset/problem/362/A)|Codeforces||Codeforces Round #212 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|334|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces||Codeforces Round #209 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|335|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces||Codeforces Round #205 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|336|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|337|[Tourist Problem](http://codeforces.com/problemset/problem/340/C)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|338|[Magic Five](http://codeforces.com/problemset/problem/327/C)|Codeforces||Codeforces Round #191 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|339|[Ciel and Robot](http://codeforces.com/problemset/problem/321/A)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|340|[Pipeline](http://codeforces.com/problemset/problem/287/B)|Codeforces||Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|341|[Lucky Permutation](http://codeforces.com/problemset/problem/286/A)|Codeforces||Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|342|[Dima and Sequence](http://codeforces.com/problemset/problem/272/B)|Codeforces||Codeforces Round #167 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|343|[Magical Boxes](http://codeforces.com/problemset/problem/269/A)|Codeforces||Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|344|[Subtractions](http://codeforces.com/problemset/problem/267/A)|Codeforces||Codeforces Testing Round #5|4|
|<ul><li>- [ ] Done</li></ul>|345|[View Angle](http://codeforces.com/problemset/problem/257/C)|Codeforces||Codeforces Round #159 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|346|[Chilly Willy](http://codeforces.com/problemset/problem/248/B)|Codeforces||Codeforces Round #152 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|347|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces||Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|348|[Ancient Berland Circus](http://codeforces.com/problemset/problem/1/C)|Codeforces||Codeforces Beta Round #1|4|
|<ul><li>- [ ] Done</li></ul>|349|[Remainders Game](http://codeforces.com/problemset/problem/687/B)|Codeforces||Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|350|[Cylinder](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2173)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|351|[As Fast As Possible](http://codeforces.com/problemset/problem/700/A)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|352|[Mike and Chocolate Thieves](http://codeforces.com/problemset/problem/689/C)|Codeforces||Codeforces Round #361 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|353|[The Intriguing Obsession](http://codeforces.com/problemset/problem/869/C)|Codeforces||Codeforces Round #439 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|354|[Ralph And His Magic Field](http://codeforces.com/problemset/problem/894/B)|Codeforces||Codeforces Round #447 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|355|[Directed Roads](http://codeforces.com/problemset/problem/711/D)|Codeforces||Codeforces Round #369 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|356|[Marco and GCD Sequence](http://codeforces.com/problemset/problem/894/C)|Codeforces||Codeforces Round #447 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|357|[Ilya And The Tree](http://codeforces.com/problemset/problem/842/C)|Codeforces||Codeforces Round #430 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|358|[Alternating Sum](http://codeforces.com/problemset/problem/963/A)|Codeforces||Tinkoff Internship Warmup Round 2018 and Codeforces Round #475 (Div. 1) & Tinkoff Internship Warmup Round 2018 and Codeforces Round #475 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|359|[Not Wool Sequences](http://codeforces.com/problemset/problem/238/A)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|360|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces||Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|361|[Rock-Paper-Scissors](http://codeforces.com/problemset/problem/173/A)|Codeforces||Croc Champ 2012 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|362|[Help Farmer](http://codeforces.com/problemset/problem/142/A)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|363|[Rectangle and Square](http://codeforces.com/problemset/problem/135/B)|Codeforces||Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|364|[Measuring Lengths in Baden](http://codeforces.com/problemset/problem/125/A)|Codeforces||Codeforces Testing Round #2|5|
|<ul><li>- [ ] Done</li></ul>|365|[Elevator](http://codeforces.com/problemset/problem/117/A)|Codeforces||Codeforces Beta Round #88|5|
|<ul><li>- [ ] Done</li></ul>|366|[Lucky Tree](http://codeforces.com/problemset/problem/109/C)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|367|[Datatypes](http://codeforces.com/problemset/problem/108/B)|Codeforces||Codeforces Beta Round #83 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|368|[Friends](http://codeforces.com/problemset/problem/94/B)|Codeforces||Codeforces Beta Round #76 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|369|[Colorful Field](http://codeforces.com/problemset/problem/79/B)|Codeforces||Codeforces Beta Round #71|5|
|<ul><li>- [ ] Done</li></ul>|370|[Falling Anvils](http://codeforces.com/problemset/problem/77/B)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|371|[Petya and His Friends](http://codeforces.com/problemset/problem/66/D)|Codeforces||Codeforces Beta Round #61 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|372|[Flea travel](http://codeforces.com/problemset/problem/55/A)|Codeforces||Codeforces Beta Round #51|5|
|<ul><li>- [ ] Done</li></ul>|373|[Sum](http://codeforces.com/problemset/problem/49/B)|Codeforces||Codeforces Beta Round #46 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|374|[Find Color](http://codeforces.com/problemset/problem/40/A)|Codeforces||Codeforces Beta Round #39|5|
|<ul><li>- [ ] Done</li></ul>|375|[Cubical Planet](http://codeforces.com/problemset/problem/39/D)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|5|
|<ul><li>- [ ] Done</li></ul>|376|[Chess](http://codeforces.com/problemset/problem/38/B)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|377|[Accounting](http://codeforces.com/problemset/problem/30/A)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|378|[Equation](http://codeforces.com/problemset/problem/20/B)|Codeforces||Codeforces Alpha Round #20 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|379|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|380|[Jumping Jack](http://codeforces.com/problemset/problem/11/B)|Codeforces||Codeforces Beta Round #11|5|
|<ul><li>- [ ] Done</li></ul>|381|[Line](http://codeforces.com/problemset/problem/7/C)|Codeforces||Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|382|[N-ARY TREE](http://www.spoj.com/problems/NARYTREE/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|383|[Careful teacher](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3891)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|384|[Fancy Number](http://codeforces.com/problemset/problem/118/C)|Codeforces||Codeforces Beta Round #89 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|385|[Fibonacci-ish](http://codeforces.com/problemset/problem/633/D)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|386|[Moodular Arithmetic](http://codeforces.com/problemset/problem/603/B)|Codeforces||Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|387|[Chip 'n Dale Rescue Rangers](http://codeforces.com/problemset/problem/590/B)|Codeforces||Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|388|[Lengthening Sticks](http://codeforces.com/problemset/problem/571/A)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|389|[Symmetric and Transitive](http://codeforces.com/problemset/problem/568/B)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|390|[Clique in the Divisibility Graph](http://codeforces.com/problemset/problem/566/F)|Codeforces||VK Cup 2015 - Finals, online mirror|5|
|<ul><li>- [ ] Done</li></ul>|391|[Vitaly and Cycle](http://codeforces.com/problemset/problem/557/D)|Codeforces||Codeforces Round #311 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|392|[Kyoya and Permutation](http://codeforces.com/problemset/problem/553/B)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|393|[Degenerate Matrix](http://codeforces.com/problemset/problem/549/H)|Codeforces||Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|394|[Mike and Frog](http://codeforces.com/problemset/problem/547/A)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|395|[Soldier and Traveling](http://codeforces.com/problemset/problem/546/E)|Codeforces||Codeforces Round #304 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|396|[Board Game](http://codeforces.com/problemset/problem/533/C)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|397|[Om Nom and Candies](http://codeforces.com/problemset/problem/526/C)|Codeforces||ZeptoLab Code Rush 2015|5|
|<ul><li>- [ ] Done</li></ul>|398|[Pretty Song](http://codeforces.com/problemset/problem/509/E)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|399|[Chocolate](http://codeforces.com/problemset/problem/490/D)|Codeforces||Codeforces Round #279 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|400|[Valid Sets](http://codeforces.com/problemset/problem/486/D)|Codeforces||Codeforces Round #277 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|401|[CGCDSSQ](http://codeforces.com/problemset/problem/475/D)|Codeforces||Bayan 2015 Contest Warm Up|5|
|<ul><li>- [ ] Done</li></ul>|402|[Ryouko's Memory Note](http://codeforces.com/problemset/problem/433/C)|Codeforces||Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|403|[Elimination](http://codeforces.com/problemset/problem/417/A)|Codeforces||RCC 2014 Warmup (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|404|[Upgrading Array](http://codeforces.com/problemset/problem/402/D)|Codeforces||Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|405|[Fox and Minimal path](http://codeforces.com/problemset/problem/388/B)|Codeforces||Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|406|[Making Sequences is Fun](http://codeforces.com/problemset/problem/373/B)|Codeforces||Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|407|[Prime Number](http://codeforces.com/problemset/problem/359/C)|Codeforces||Codeforces Round #209 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|408|[Xenia and Hamming](http://codeforces.com/problemset/problem/356/B)|Codeforces||Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|409|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces||Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|410|[Iahub and Permutations](http://codeforces.com/problemset/problem/340/E)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|411|[Malek Dance Club](http://codeforces.com/problemset/problem/319/A)|Codeforces||Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|412|[Special Task](http://codeforces.com/problemset/problem/316/A2)|Codeforces||ABBYY Cup 3.0|5|
|<ul><li>- [ ] Done</li></ul>|413|[Continued Fractions](http://codeforces.com/problemset/problem/305/B)|Codeforces||Codeforces Round #184 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|414|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces||Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|415|[Dima and Two Sequences](http://codeforces.com/problemset/problem/272/D)|Codeforces||Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|416|[Expensive Drink](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2028)|Live Archive|2007|Asia - Beijing|5|
|<ul><li>- [ ] Done</li></ul>|417|[Misha and Permutations Summation](http://codeforces.com/problemset/problem/501/D)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|418|[Array Game](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2654)|Live Archive|2009|Asia - Tehran|5|
|<ul><li>- [ ] Done</li></ul>|419|[Square Subsets](http://codeforces.com/problemset/problem/895/C)|Codeforces||Codeforces Round #448 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|420|[Winter is here](http://codeforces.com/problemset/problem/839/D)|Codeforces||Codeforces Round #428 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|421|[Anton and School - 2](http://codeforces.com/problemset/problem/785/D)|Codeforces||Codeforces Round #404 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|422|[Hunting Digletts](https://www.urionlinejudge.com.br/judge/en/problems/view/2063)|URI|||5|
|<ul><li>- [ ] Done</li></ul>|423|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|424|[Mr. Bender and Square](http://codeforces.com/problemset/problem/255/D)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|425|[Playing with Permutations](http://codeforces.com/problemset/problem/251/B)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|426|[Let's Play Osu!](http://codeforces.com/problemset/problem/235/B)|Codeforces||Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|427|[Table](http://codeforces.com/problemset/problem/232/B)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|428|[Triangles](http://codeforces.com/problemset/problem/229/C)|Codeforces||Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|429|[Partial Sums](http://codeforces.com/problemset/problem/223/C)|Codeforces||Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|430|[Hit Ball](http://codeforces.com/problemset/problem/203/D)|Codeforces||Codeforces Round #128 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|431|[Guess That Car!](http://codeforces.com/problemset/problem/201/B)|Codeforces||Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|432|[Mushroom Scientists](http://codeforces.com/problemset/problem/185/B)|Codeforces||Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|433|[Mathematical Analysis Rocks!](http://codeforces.com/problemset/problem/180/F)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|434|[Problem About Equation](http://codeforces.com/problemset/problem/174/A)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|435|[Lucky Subsequence](http://codeforces.com/problemset/problem/145/C)|Codeforces||Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|436|[Wallpaper](http://codeforces.com/problemset/problem/139/B)|Codeforces||Codeforces Beta Round #99 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|437|[Hot Bath](http://codeforces.com/problemset/problem/126/A)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|438|[Doctor](http://codeforces.com/problemset/problem/83/B)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|439|[Average Score](http://codeforces.com/problemset/problem/81/C)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|6|
|<ul><li>- [ ] Done</li></ul>|440|[Points](http://codeforces.com/problemset/problem/76/E)|Codeforces||All-Ukrainian School Olympiad in Informatics|6|
|<ul><li>- [ ] Done</li></ul>|441|[The Elder Trolls IV: Oblivon](http://codeforces.com/problemset/problem/73/A)|Codeforces||Codeforces Beta Round #66|6|
|<ul><li>- [ ] Done</li></ul>|442|[Harry Potter and Three Spells](http://codeforces.com/problemset/problem/65/A)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|443|[Array](http://codeforces.com/problemset/problem/57/C)|Codeforces||Codeforces Beta Round #53|6|
|<ul><li>- [ ] Done</li></ul>|444|[3-cycles](http://codeforces.com/problemset/problem/41/E)|Codeforces||Codeforces Beta Round #40 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|445|[Flea](http://codeforces.com/problemset/problem/32/C)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|446|[Platforms](http://codeforces.com/problemset/problem/18/B)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|447|[Collision Detection](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4205)|Live Archive|2012|North America - Mid-Atlantic USA & North America - Southeast USA|6|
|<ul><li>- [ ] Done</li></ul>|448|[GAMING ARENA](http://www.spoj.com/problems/GAMARENA/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|449|[ZEROES IN RANGE](http://www.spoj.com/problems/RANGEZER/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|450|[ANYTHING FOR ATTENDANCE](http://www.spoj.com/problems/DIE4MARK/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|451|[CHOCOLATES](http://www.spoj.com/problems/CHOCLATE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|452|[CUBE ROOT](http://www.spoj.com/problems/CUBEROO2/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|453|[Parallel Expectations](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=345)|Live Archive|2001|Asia - Tehran|6|
|<ul><li>- [ ] Done</li></ul>|454|[International Olympiad](http://codeforces.com/problemset/problem/662/D)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|455|[Bear and Polynomials](http://codeforces.com/problemset/problem/639/C)|Codeforces||VK Cup 2016 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|456|[Longest Subsequence](http://codeforces.com/problemset/problem/632/D)|Codeforces||Educational Codeforces Round 9|6|
|<ul><li>- [ ] Done</li></ul>|457|[A rectangle](http://codeforces.com/problemset/problem/630/E)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|6|
|<ul><li>- [ ] Done</li></ul>|458|[GukiZ and Binary Operations](http://codeforces.com/problemset/problem/551/D)|Codeforces||Codeforces Round #307 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|459|[A Heap of Heaps](http://codeforces.com/problemset/problem/538/F)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|460|[Demiurges Play Again](http://codeforces.com/problemset/problem/538/E)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|461|[Pluses everywhere](http://codeforces.com/problemset/problem/520/E)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|462|[Vanya and Field](http://codeforces.com/problemset/problem/492/E)|Codeforces||Codeforces Round #280 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|463|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces||Codeforces Round #277 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|464|[Golden System](http://codeforces.com/problemset/problem/457/A)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|465|[Magic Trick](http://codeforces.com/problemset/problem/452/C)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|466|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces||Codeforces Round #247 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|467|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces||Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|468|[Jeopardy!](http://codeforces.com/problemset/problem/413/C)|Codeforces||Coder-Strike 2014 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|469|[Number Busters](http://codeforces.com/problemset/problem/382/B)|Codeforces||Codeforces Round #224 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|470|[Watching Fireworks is Fun](http://codeforces.com/problemset/problem/372/C)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|471|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces||Codeforces Round #212 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|472|[Number Transformation II](http://codeforces.com/problemset/problem/346/C)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|473|[Vasily the Bear and Fly](http://codeforces.com/problemset/problem/336/B)|Codeforces||Codeforces Round #195 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|474|[Stadium and Games](http://codeforces.com/problemset/problem/325/B)|Codeforces||MemSQL start[c]up Round 1|6|
|<ul><li>- [ ] Done</li></ul>|475|[Rectangle Puzzle II](http://codeforces.com/problemset/problem/303/B)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|476|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|477|[Below the Diagonal](http://codeforces.com/problemset/problem/266/C)|Codeforces||Codeforces Round #163 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|478|[Maxim and Restaurant](http://codeforces.com/problemset/problem/261/B)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|479|[Sum](http://codeforces.com/problemset/problem/257/D)|Codeforces||Codeforces Round #159 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|480|[Party](http://codeforces.com/problemset/problem/23/B)|Codeforces||Codeforces Beta Round #23|6|
|<ul><li>- [ ] Done</li></ul>|481|[Functions](p?ID=292)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|482|[Prizes](p?ID=310)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|483|[Karen and Test](http://codeforces.com/problemset/problem/815/B)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|484|[Unusual Sequences](http://codeforces.com/problemset/problem/900/D)|Codeforces||Codeforces Round #450 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|485|[ZS and The Birthday Paradox](http://codeforces.com/problemset/problem/711/E)|Codeforces||Codeforces Round #369 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|486|[Fibonacci 2.0](p?ID=291)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|487|[Design Space](https://www.urionlinejudge.com.br/judge/en/problems/view/2683)|URI|||6|
|<ul><li>- [ ] Done</li></ul>|488|[Furlo and Rublo and Game](http://codeforces.com/problemset/problem/255/E)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|489|[Blackboard Fibonacci](http://codeforces.com/problemset/problem/217/B)|Codeforces||Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|490|[Little Elephant and Furik and Rubik](http://codeforces.com/problemset/problem/204/C)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|491|[Analyzing Polyline](http://codeforces.com/problemset/problem/195/D)|Codeforces||Codeforces Round #123 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|492|[Pairs of Numbers](http://codeforces.com/problemset/problem/134/B)|Codeforces||Codeforces Testing Round #3|7|
|<ul><li>- [ ] Done</li></ul>|493|[Squares](http://codeforces.com/problemset/problem/123/B)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|494|[Reflection](http://codeforces.com/problemset/problem/86/A)|Codeforces||Yandex.Algorithm 2011 Round 2|7|
|<ul><li>- [ ] Done</li></ul>|495|[Plus and xor](http://codeforces.com/problemset/problem/76/D)|Codeforces||All-Ukrainian School Olympiad in Informatics|7|
|<ul><li>- [ ] Done</li></ul>|496|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|497|[First Digit Law](http://codeforces.com/problemset/problem/54/C)|Codeforces||Codeforces Beta Round #50|7|
|<ul><li>- [ ] Done</li></ul>|498|[Disposition](http://codeforces.com/problemset/problem/49/C)|Codeforces||Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|499|[Repaintings](http://codeforces.com/problemset/problem/40/B)|Codeforces||Codeforces Beta Round #39|7|
|<ul><li>- [ ] Done</li></ul>|500|[Sequence of points](http://codeforces.com/problemset/problem/24/C)|Codeforces||Codeforces Beta Round #24|7|
|<ul><li>- [ ] Done</li></ul>|501|[Intersection](http://codeforces.com/problemset/problem/21/B)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|502|[Laser](http://codeforces.com/problemset/problem/15/B)|Codeforces||Codeforces Beta Round #15|7|
|<ul><li>- [ ] Done</li></ul>|503|[Follow Traffic Rules](http://codeforces.com/problemset/problem/5/D)|Codeforces||Codeforces Beta Round #5|7|
|<ul><li>- [ ] Done</li></ul>|504|[The Water Taps](http://www.spoj.com/problems/TAPS/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|505|[On Corruption and Numbers](http://codeforces.com/problemset/problem/397/B)|Codeforces||Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|506|[Binary Table](http://codeforces.com/problemset/problem/662/C)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|7|
|<ul><li>- [ ] Done</li></ul>|507|[Little Artem and Random Variable](http://codeforces.com/problemset/problem/641/D)|Codeforces||VK Cup 2016 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|508|[Turn](http://codeforces.com/problemset/problem/630/M)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|7|
|<ul><li>- [ ] Done</li></ul>|509|[Simple Skewness](http://codeforces.com/problemset/problem/626/E)|Codeforces||8VC Venture Cup 2016 - Elimination Round|7|
|<ul><li>- [ ] Done</li></ul>|510|[Rat Kwesh and Cheese](http://codeforces.com/problemset/problem/621/D)|Codeforces||Codeforces Round #341 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|511|[Sum of Remainders](http://codeforces.com/problemset/problem/616/E)|Codeforces||Educational Codeforces Round 5|7|
|<ul><li>- [ ] Done</li></ul>|512|[Hexagons](http://codeforces.com/problemset/problem/615/E)|Codeforces||Codeforces Round #338 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|513|[Case of a Top Secret](http://codeforces.com/problemset/problem/555/D)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|514|[Idempotent functions](http://codeforces.com/problemset/problem/542/C)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|515|[Restoring Numbers](http://codeforces.com/problemset/problem/509/D)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|516|[Hack it!](http://codeforces.com/problemset/problem/468/C)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|517|[Devu and Birthday Celebration](http://codeforces.com/problemset/problem/439/E)|Codeforces||Codeforces Round #251 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|518|[Square Table](http://codeforces.com/problemset/problem/417/E)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|519|[Curious Array](http://codeforces.com/problemset/problem/407/C)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|520|[On Sum of Fractions](http://codeforces.com/problemset/problem/396/B)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|521|[Blocked Points](http://codeforces.com/problemset/problem/392/A)|Codeforces||Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|522|[Subway Innovation](http://codeforces.com/problemset/problem/371/E)|Codeforces||Codeforces Round #218 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|523|[Vasily the Bear and Beautiful Strings](http://codeforces.com/problemset/problem/336/D)|Codeforces||Codeforces Round #195 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|524|[Minimum Modular](http://codeforces.com/problemset/problem/303/C)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|525|[Empire Strikes Back](http://codeforces.com/problemset/problem/300/E)|Codeforces||Codeforces Round #181 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|526|[Playlist](http://codeforces.com/problemset/problem/268/E)|Codeforces||Codeforces Round #164 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|527|[Maxim and Matrix](http://codeforces.com/problemset/problem/261/C)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|528|[The Last Fight Between Human and AI](http://codeforces.com/problemset/problem/676/E)|Codeforces||Codeforces Round #354 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|529|[Powers](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1025)|Live Archive|2004|Africa/Middle East - South Africa|7|
|<ul><li>- [ ] Done</li></ul>|530|[Bamboo Partition](http://codeforces.com/problemset/problem/830/C)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|7|
|<ul><li>- [ ] Done</li></ul>|531|[String Mark](http://codeforces.com/problemset/problem/895/D)|Codeforces||Codeforces Round #448 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|532|[Bribes](http://codeforces.com/problemset/problem/575/B)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|533|[Little Elephant and Broken Sorting](http://codeforces.com/problemset/problem/258/D)|Codeforces||Codeforces Round #157 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|534|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|535|[Unsolvable](http://codeforces.com/problemset/problem/225/E)|Codeforces||Codeforces Round #139 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|536|[Martian Luck](http://codeforces.com/problemset/problem/216/E)|Codeforces||Codeforces Round #133 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|537|[Multicolored Marbles](http://codeforces.com/problemset/problem/209/A)|Codeforces||VK Cup 2012 Finals, Practice Session|8|
|<ul><li>- [ ] Done</li></ul>|538|[Hamming Distance](http://codeforces.com/problemset/problem/193/C)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|539|[Headquarters](http://codeforces.com/problemset/problem/183/A)|Codeforces||Croc Champ 2012 - Final|8|
|<ul><li>- [ ] Done</li></ul>|540|[Wizards and Numbers](http://codeforces.com/problemset/problem/167/C)|Codeforces||Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|541|[Smart Cheater](http://codeforces.com/problemset/problem/150/C)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|542|[Fibonacci Sums](http://codeforces.com/problemset/problem/126/D)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|543|[Plumber](http://codeforces.com/problemset/problem/115/C)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|544|[Vectors](http://codeforces.com/problemset/problem/101/C)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|545|[Numbers](http://codeforces.com/problemset/problem/83/D)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|546|[Capture Valerian](http://codeforces.com/problemset/problem/61/C)|Codeforces||Codeforces Beta Round #57 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|547|[The Race](http://codeforces.com/problemset/problem/48/C)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|548|[Hyperdrive](http://codeforces.com/problemset/problem/44/D)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|549|[Collisions](http://codeforces.com/problemset/problem/34/E)|Codeforces||Codeforces Beta Round #34 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|550|[Math Homework](p?ID=23)|A2 Online Judge|||8|
|<ul><li>- [ ] Done</li></ul>|551|[Lannion Visit](p?ID=415)|A2 Online Judge|||8|
|<ul><li>- [ ] Done</li></ul>|552|[Cowslip Collections](http://codeforces.com/problemset/problem/645/F)|Codeforces||CROC 2016 - Elimination Round|8|
|<ul><li>- [ ] Done</li></ul>|553|[The Sum of the k-th Powers](http://codeforces.com/problemset/problem/622/F)|Codeforces||Educational Codeforces Round 7|8|
|<ul><li>- [ ] Done</li></ul>|554|[Vasya and Polynomial](http://codeforces.com/problemset/problem/493/E)|Codeforces||Codeforces Round #281 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|555|[Strange Sorting](http://codeforces.com/problemset/problem/484/C)|Codeforces||Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|556|[Bear in the Field](http://codeforces.com/problemset/problem/385/E)|Codeforces||Codeforces Round #226 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|557|[Dima and Magic Guitar](http://codeforces.com/problemset/problem/366/E)|Codeforces||Codeforces Round #214 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|558|[Ghd](http://codeforces.com/problemset/problem/364/D)|Codeforces||Codeforces Round #213 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|559|[GCD Table](http://codeforces.com/problemset/problem/338/D)|Codeforces||Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|560|[Summer Homework](http://codeforces.com/problemset/problem/316/E3)|Codeforces||ABBYY Cup 3.0|8|
|<ul><li>- [ ] Done</li></ul>|561|[Interval Cubing](http://codeforces.com/problemset/problem/311/D)|Codeforces||Codeforces Round #185 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|562|[Morning run](http://codeforces.com/problemset/problem/309/A)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|563|[Olya and Graph](http://codeforces.com/problemset/problem/305/D)|Codeforces||Codeforces Round #184 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|564|[Cube Problem](http://codeforces.com/problemset/problem/293/C)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|565|[Ladies' Shop](http://codeforces.com/problemset/problem/286/E)|Codeforces||Codeforces Round #176 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|566|[Positions in Permutations](http://codeforces.com/problemset/problem/285/E)|Codeforces||Codeforces Round #175 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|567|[Cow Tennis Tournament](http://codeforces.com/problemset/problem/283/E)|Codeforces||Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|568|[Cows and Cool Sequences](http://codeforces.com/problemset/problem/283/D)|Codeforces||Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|569|[Three Horses](http://codeforces.com/problemset/problem/271/E)|Codeforces||Codeforces Round #166 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|570|[More Queries to Array...](http://codeforces.com/problemset/problem/266/E)|Codeforces||Codeforces Round #163 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|571|[BerDonalds](http://codeforces.com/problemset/problem/266/D)|Codeforces||Codeforces Round #163 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|572|[Misha and Palindrome Degree](http://codeforces.com/problemset/problem/501/E)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|573|[Mother of Dragons](http://codeforces.com/problemset/problem/839/E)|Codeforces||Codeforces Round #428 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|574|[Memory and Casinos](http://codeforces.com/problemset/problem/712/E)|Codeforces||Codeforces Round #370 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|575|[Two Sets](http://codeforces.com/problemset/problem/251/D)|Codeforces||Codeforces Round #153 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|576|[Endless Matrix](http://codeforces.com/problemset/problem/249/E)|Codeforces||Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|577|[Friends](http://codeforces.com/problemset/problem/241/B)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|578|[Little Elephant and Triangle](http://codeforces.com/problemset/problem/220/D)|Codeforces||Codeforces Round #136 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|579|[Bitonix' Patrol](http://codeforces.com/problemset/problem/217/D)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|580|[Pixels](http://codeforces.com/problemset/problem/209/B)|Codeforces||VK Cup 2012 Finals, Practice Session|9|
|<ul><li>- [ ] Done</li></ul>|581|[Tractor College](http://codeforces.com/problemset/problem/200/E)|Codeforces||Codeforces Round #126 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|582|[Fibonacci Number](http://codeforces.com/problemset/problem/193/E)|Codeforces||Codeforces Round #122 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|583|[LCM](http://codeforces.com/problemset/problem/188/C)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|584|[Visit of the Great](http://codeforces.com/problemset/problem/185/D)|Codeforces||Codeforces Round #118 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|585|[Divisibility Rules](http://codeforces.com/problemset/problem/180/B)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|586|[Wizards and Bets](http://codeforces.com/problemset/problem/167/E)|Codeforces||Codeforces Round #114 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|587|[Flatland Fencing](http://codeforces.com/problemset/problem/154/D)|Codeforces||Codeforces Round #109 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|588|[Not Quick Transformation](http://codeforces.com/problemset/problem/117/D)|Codeforces||Codeforces Beta Round #88|9|
|<ul><li>- [ ] Done</li></ul>|589|[Rotation](http://codeforces.com/problemset/problem/100/I)|Codeforces||Unknown Language Round #3|9|
|<ul><li>- [ ] Done</li></ul>|590|[Winning Strategy](http://codeforces.com/problemset/problem/97/C)|Codeforces||Yandex.Algorithm 2011 Finals|9|
|<ul><li>- [ ] Done</li></ul>|591|[Lostborn](http://codeforces.com/problemset/problem/93/E)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|592|[Flags](http://codeforces.com/problemset/problem/93/D)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|593|[Tetris revisited](http://codeforces.com/problemset/problem/86/B)|Codeforces||Yandex.Algorithm 2011 Round 2|9|
|<ul><li>- [ ] Done</li></ul>|594|[Archer's Shot](http://codeforces.com/problemset/problem/78/D)|Codeforces||Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|595|[Morrowindows](http://codeforces.com/problemset/problem/73/E)|Codeforces||Codeforces Beta Round #66|9|
|<ul><li>- [ ] Done</li></ul>|596|[Extraordinarily Nice Numbers](http://codeforces.com/problemset/problem/72/C)|Codeforces||Unknown Language Round #2|9|
|<ul><li>- [ ] Done</li></ul>|597|[Table](http://codeforces.com/problemset/problem/64/C)|Codeforces||Unknown Language Round #1|9|
|<ul><li>- [ ] Done</li></ul>|598|[Mushroom Gnomes](http://codeforces.com/problemset/problem/60/E)|Codeforces||Codeforces Beta Round #56|9|
|<ul><li>- [ ] Done</li></ul>|599|[Savior](http://codeforces.com/problemset/problem/60/D)|Codeforces||Codeforces Beta Round #56|9|
|<ul><li>- [ ] Done</li></ul>|600|[Journey](http://codeforces.com/problemset/problem/57/D)|Codeforces||Codeforces Beta Round #53|9|
|<ul><li>- [ ] Done</li></ul>|601|[Square Equation Roots](http://codeforces.com/problemset/problem/50/E)|Codeforces||Codeforces Beta Round #47|9|
|<ul><li>- [ ] Done</li></ul>|602|[Strange town](http://codeforces.com/problemset/problem/42/D)|Codeforces||Codeforces Beta Round #41|9|
|<ul><li>- [ ] Done</li></ul>|603|[Berland Square](http://codeforces.com/problemset/problem/40/C)|Codeforces||Codeforces Beta Round #39|9|
|<ul><li>- [ ] Done</li></ul>|604|[Lesson Timetable](http://codeforces.com/problemset/problem/37/D)|Codeforces||Codeforces Beta Round #37|9|
|<ul><li>- [ ] Done</li></ul>|605|[Tetragon](http://codeforces.com/problemset/problem/23/D)|Codeforces||Codeforces Beta Round #23|9|
|<ul><li>- [ ] Done</li></ul>|606|[Four Divisors](http://codeforces.com/problemset/problem/665/F)|Codeforces||Educational Codeforces Round 12|9|
|<ul><li>- [ ] Done</li></ul>|607|[Gambling Nim](http://codeforces.com/problemset/problem/662/A)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|9|
|<ul><li>- [ ] Done</li></ul>|608|[Bear and Paradox](http://codeforces.com/problemset/problem/639/E)|Codeforces||VK Cup 2016 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|609|[Ruminations on Ruminants](http://codeforces.com/problemset/problem/603/D)|Codeforces||Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|610|[Beautiful Function](http://codeforces.com/problemset/problem/593/C)|Codeforces||Codeforces Round #329 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|611|[Task processing](http://codeforces.com/problemset/problem/589/K)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|9|
|<ul><li>- [ ] Done</li></ul>|612|[Present for Vitalik the Philatelist ](http://codeforces.com/problemset/problem/585/E)|Codeforces||Codeforces Round #325 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|613|[Fibonotci](http://codeforces.com/problemset/problem/575/A)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|9|
|<ul><li>- [ ] Done</li></ul>|614|[Sign Posts](http://codeforces.com/problemset/problem/568/D)|Codeforces||Codeforces Round #315 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|615|[Superhero's Job](http://codeforces.com/problemset/problem/542/D)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|9|
|<ul><li>- [ ] Done</li></ul>|616|[New York Hotel](http://codeforces.com/problemset/problem/491/B)|Codeforces||Testing Round #11|9|
|<ul><li>- [ ] Done</li></ul>|617|[Design Tutorial: Change the Goal](http://codeforces.com/problemset/problem/472/F)|Codeforces||Codeforces Round #270|9|
|<ul><li>- [ ] Done</li></ul>|618|[Appleman and Complicated Task](http://codeforces.com/problemset/problem/461/D)|Codeforces||Codeforces Round #263 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|619|[Roland and Rose](http://codeforces.com/problemset/problem/460/E)|Codeforces||Codeforces Round #262 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|620|[Physical Education and Buns](http://codeforces.com/problemset/problem/394/D)|Codeforces||Codeforces Round #231 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|621|[Yet Another Number Sequence](http://codeforces.com/problemset/problem/392/C)|Codeforces||Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|622|[Fox and Perfect Sets](http://codeforces.com/problemset/problem/388/D)|Codeforces||Codeforces Round #228 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|623|[Sereja and Cinema](http://codeforces.com/problemset/problem/380/D)|Codeforces||Codeforces Round #223 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|624|[Red and Black Tree](http://codeforces.com/problemset/problem/375/E)|Codeforces||Codeforces Round #221 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|625|[Theft of Blueprints](http://codeforces.com/problemset/problem/332/D)|Codeforces||Codeforces Round #193 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|626|[Ciel and Flipboard](http://codeforces.com/problemset/problem/321/D)|Codeforces||Codeforces Round #190 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|627|[Summer Homework](http://codeforces.com/problemset/problem/316/E2)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|628|[PE Lesson](http://codeforces.com/problemset/problem/316/D3)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|629|[Rotatable Number](http://codeforces.com/problemset/problem/303/D)|Codeforces||Codeforces Round #183 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|630|[Ksusha and Square](http://codeforces.com/problemset/problem/293/D)|Codeforces||Croc Champ 2013 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|631|[Polo the Penguin and Lucky Numbers](http://codeforces.com/problemset/problem/288/E)|Codeforces||Codeforces Round #177 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|632|[Donkey and Stars](http://codeforces.com/problemset/problem/249/D)|Codeforces||Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|633|[Cowboys](http://codeforces.com/problemset/problem/212/C)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|634|[Horse Races](http://codeforces.com/problemset/problem/95/D)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|635|[Optimal Point](http://codeforces.com/problemset/problem/685/C)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|636|[Subarray Cuts](http://codeforces.com/problemset/problem/513/E1)|Codeforces||Rockethon 2015|9|
|<ul><li>- [ ] Done</li></ul>|637|[Lust](http://codeforces.com/problemset/problem/891/E)|Codeforces||Codeforces Round #446 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|638|[Surprise me!](http://codeforces.com/problemset/problem/809/E)|Codeforces||Codeforces Round #415 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|639|[Strange Radiation](http://codeforces.com/problemset/problem/832/C)|Codeforces||Codeforces Round #425 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|640|[Ivan the Fool VS Gorynych the Dragon](http://codeforces.com/problemset/problem/48/E)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|641|[Birthday](http://codeforces.com/problemset/problem/128/E)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|642|[Sleeping](http://codeforces.com/problemset/problem/113/E)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|643|[Lucky Interval](http://codeforces.com/problemset/problem/109/E)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|644|[Interval Coloring](http://codeforces.com/problemset/problem/100/J)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|645|[Lamps in a Line](http://codeforces.com/problemset/problem/100/E)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|646|[Help Shrek and Donkey](http://codeforces.com/problemset/problem/98/E)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|647|[Long sequence](http://codeforces.com/problemset/problem/86/E)|Codeforces||Yandex.Algorithm 2011 Round 2|10|
|<ul><li>- [ ] Done</li></ul>|648|[Security System](http://codeforces.com/problemset/problem/79/E)|Codeforces||Codeforces Beta Round #71|10|
|<ul><li>- [ ] Done</li></ul>|649|[Mutation](http://codeforces.com/problemset/problem/76/C)|Codeforces||All-Ukrainian School Olympiad in Informatics|10|
|<ul><li>- [ ] Done</li></ul>|650|[Oil](http://codeforces.com/problemset/problem/72/F)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|651|[Goshtasp, Vishtasp and Eidi](http://codeforces.com/problemset/problem/72/A)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|652|[Chess](http://codeforces.com/problemset/problem/57/E)|Codeforces||Codeforces Beta Round #53|10|
|<ul><li>- [ ] Done</li></ul>|653|[Interesting Sequence](http://codeforces.com/problemset/problem/40/D)|Codeforces||Codeforces Beta Round #39|10|
|<ul><li>- [ ] Done</li></ul>|654|[BigFibonacci](http://community.topcoder.com/stat?c=problem_statement&pm=6077)|TopCoder||TCO06 Sponsor 5 - Div1 hard] (9916)|10|
|<ul><li>- [ ] Done</li></ul>|655|[Ants on a Circle](http://codeforces.com/problemset/problem/652/F)|Codeforces||Educational Codeforces Round 10|10|
|<ul><li>- [ ] Done</li></ul>|656|[Agricultural Archaeology](http://codeforces.com/problemset/problem/589/L)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|10|
|<ul><li>- [ ] Done</li></ul>|657|[Geometric Progressions](http://codeforces.com/problemset/problem/571/E)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|658|[Sasha Circle](http://codeforces.com/problemset/problem/549/E)|Codeforces||Looksery Cup 2015|10|
|<ul><li>- [ ] Done</li></ul>|659|[Berserk Robot ](http://codeforces.com/problemset/problem/538/G)|Codeforces||Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|660|[Gears](http://codeforces.com/problemset/problem/497/D)|Codeforces||Codeforces Round #283 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|661|[Permanent](http://codeforces.com/problemset/problem/468/E)|Codeforces||Codeforces Round #268 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|662|[Flow Optimality](http://codeforces.com/problemset/problem/457/E)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|663|[Bingo!](http://codeforces.com/problemset/problem/457/D)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|664|[Jzzhu and Squares](http://codeforces.com/problemset/problem/449/E)|Codeforces||Codeforces Round #257 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|665|[DZY Loves Bridges](http://codeforces.com/problemset/problem/446/E)|Codeforces||Codeforces Round #255 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|666|[DZY Loves Games](http://codeforces.com/problemset/problem/446/D)|Codeforces||Codeforces Round #255 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|667|[Hamming Triples](http://codeforces.com/problemset/problem/406/E)|Codeforces||Codeforces Round #238 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|668|[Olympic Games](http://codeforces.com/problemset/problem/401/E)|Codeforces||Codeforces Round #235 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|669|[Doodle Jump](http://codeforces.com/problemset/problem/346/E)|Codeforces||Codeforces Round #201 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|670|[Counting Skyscrapers](http://codeforces.com/problemset/problem/335/E)|Codeforces||MemSQL start[c]up Round 2 - online version|10|
|<ul><li>- [ ] Done</li></ul>|671|[Evil](http://codeforces.com/problemset/problem/329/E)|Codeforces||Codeforces Round #192 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|672|[Sequence Transformation](http://codeforces.com/problemset/problem/280/E)|Codeforces||Codeforces Round #172 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|673|[Berland Traffic](http://codeforces.com/problemset/problem/267/C)|Codeforces||Codeforces Testing Round #5|10|
|<ul><li>- [ ] Done</li></ul>|674|[DravDe saves the world](http://codeforces.com/problemset/problem/28/E)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|10|
|<ul><li>- [ ] Done</li></ul>|675|[Wisdom](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1023)|Live Archive|2004|Africa/Middle East - South Africa|10|
|<ul><li>- [ ] Done</li></ul>|676|[Nephren Runs a Cinema](http://codeforces.com/problemset/problem/896/D)|Codeforces||Codeforces Round #449 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|677|[Mod Mod Mod](http://codeforces.com/problemset/problem/889/E)|Codeforces||Codeforces Round #445 (Div. 1, based on Technocup 2018 Elimination Round 3)|10|
|<ul><li>- [ ] Done</li></ul>|678|[Perpetual Motion Machine](http://codeforces.com/problemset/problem/830/E)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|10|
|<ul><li>- [ ] Done</li></ul>|679|[Days of Floral Colours](http://codeforces.com/problemset/problem/848/E)|Codeforces||Codeforces Round #431 (Div. 1)|10|
