# 077. Mobius_Function


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[LCM Sum](http://www.spoj.com/problems/LCMSUM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Panoramix's Prediction](http://codeforces.com/problemset/problem/80/A)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Coprime Triples](http://www.codechef.com/problems/COPRIME3)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|4|[GCD Extreme](http://www.spoj.com/problems/GCDEX/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Sky Code](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2185)|Live Archive|2008|Europe - Southeastern|2|
|<ul><li>- [ ] Done</li></ul>|6|[Expected Greatest Common Divisor](http://www.codechef.com/problems/EXGCD)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Adding Least Common Multiples](http://www.codechef.com/problems/LCM)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|8|[Unusual Sequences](http://codeforces.com/problemset/problem/900/D)|Codeforces||Codeforces Round #450 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|9|[Mobius Multiplications](http://www.codechef.com/problems/ENCODE07)|CodeChef|||7|
|<ul><li>- [ ] Done</li></ul>|10|[GCD Extreme (hard)](http://www.spoj.com/problems/GCDEX2/)|SPOJ|||7|
