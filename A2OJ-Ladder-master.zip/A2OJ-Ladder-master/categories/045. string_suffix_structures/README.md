# 045. string_suffix_structures


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|2|[Watto and Mechanism](http://codeforces.com/problemset/problem/514/C)|Codeforces|Codeforces Round #291 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|3|[Tavas and Malekas](http://codeforces.com/problemset/problem/535/D)|Codeforces|Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|4|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces|Codeforces Round #246 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|5|[MUH and Cube Walls](http://codeforces.com/problemset/problem/471/D)|Codeforces|Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|6|[Spy Syndrome 2](http://codeforces.com/problemset/problem/633/C)|Codeforces|Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|7|[Om Nom and Necklace](http://codeforces.com/problemset/problem/526/D)|Codeforces|ZeptoLab Code Rush 2015|6|
|<ul><li>- [ ] Done</li></ul>|8|[Match & Catch](http://codeforces.com/problemset/problem/427/D)|Codeforces|Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|9|[Martian Strings](http://codeforces.com/problemset/problem/149/E)|Codeforces|Codeforces Round #106 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|10|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces|Codeforces Round #344 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|11|[String](http://codeforces.com/problemset/problem/128/B)|Codeforces|Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|12|[Cyclical Quest](http://codeforces.com/problemset/problem/235/C)|Codeforces|Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|13|[Valera and Swaps](http://codeforces.com/problemset/problem/441/D)|Codeforces|Codeforces Round #252 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|14|[Encoding](http://codeforces.com/problemset/problem/533/F)|Codeforces|VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|15|[Votka and String](http://www.spoj.com/problems/VOTAS/)|SPOJ||7|
|<ul><li>- [ ] Done</li></ul>|16|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces|Codeforces Round #311 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|17|[Mike and Friends](http://codeforces.com/problemset/problem/547/E)|Codeforces|Codeforces Round #305 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|18|[Three strings](http://codeforces.com/problemset/problem/452/E)|Codeforces|MemSQL Start[c]UP 2.0 - Round 1|8|
|<ul><li>- [ ] Done</li></ul>|19|[Deletion of Repeats](http://codeforces.com/problemset/problem/19/C)|Codeforces|Codeforces Beta Round #19|8|
|<ul><li>- [ ] Done</li></ul>|20|[Paper task](http://codeforces.com/problemset/problem/653/F)|Codeforces|IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|21|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces|Codeforces Round #129 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|22|[String](http://codeforces.com/problemset/problem/123/D)|Codeforces|Codeforces Beta Round #92 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|23|[Good Substrings](http://codeforces.com/problemset/problem/316/G2)|Codeforces|ABBYY Cup 3.0|8|
|<ul><li>- [ ] Done</li></ul>|24|[Genetic engineering](http://codeforces.com/problemset/problem/86/C)|Codeforces|Yandex.Algorithm 2011 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|25|[Fence](http://codeforces.com/problemset/problem/232/D)|Codeforces|Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|26|[Forensic Examination](http://codeforces.com/problemset/problem/666/E)|Codeforces|Codeforces Round #349 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|27|[Cool Slogans](http://codeforces.com/problemset/problem/700/E)|Codeforces|Codeforces Round #364 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|28|[And Yet Another Bracket Sequence](http://codeforces.com/problemset/problem/524/F)|Codeforces|VK Cup 2015 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|29|[Xenia and String Problem](http://codeforces.com/problemset/problem/356/E)|Codeforces|Codeforces Round #207 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|30|[Expensive Strings](http://codeforces.com/problemset/problem/616/F)|Codeforces|Educational Codeforces Round 5|9|
|<ul><li>- [ ] Done</li></ul>|31|[Have You Ever Heard About the Word?](http://codeforces.com/problemset/problem/319/D)|Codeforces|Codeforces Round #189 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|32|[Good Substrings](http://codeforces.com/problemset/problem/316/G3)|Codeforces|ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|33|[Arpa’s abnormal DNA and Mehrdad’s deep interest](http://codeforces.com/problemset/problem/741/E)|Codeforces|Codeforces Round #383 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|34|[Cutting the Line](http://codeforces.com/problemset/problem/594/E)|Codeforces|Codeforces Round #330 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|35|[Misha and LCP on Tree](http://codeforces.com/problemset/problem/504/E)|Codeforces|Codeforces Round #285 (Div. 1)|10|
