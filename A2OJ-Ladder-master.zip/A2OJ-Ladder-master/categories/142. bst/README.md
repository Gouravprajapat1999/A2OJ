# 142. bst


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Playboy Chimp](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1552)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[Binary Search Tree](http://www.spoj.com/problems/BST/)|SPOJ|2|
