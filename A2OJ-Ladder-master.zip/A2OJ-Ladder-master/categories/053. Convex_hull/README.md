# 053. Convex_hull


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Build the Fence](http://www.spoj.com/problems/BSHEEP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Onion Layers](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1656)|Live Archive|2006|Latin America - South America|1|
|<ul><li>- [ ] Done</li></ul>|3|[Convex Hull of Lattice Points](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2559)|Live Archive|2009|North America - Greater NY|1|
|<ul><li>- [ ] Done</li></ul>|4|[SCUD Busters](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=45)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|5|[Land Acquisition](http://www.spoj.com/problems/ACQUIRE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|6|[Useless Tile Packers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1006)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|7|[Moth Eradication](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=154)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|8|[Convex Hull Finding](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=622)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|9|[The Fortified Forest](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=752)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|10|[Doors and Penguins](http://www.spoj.com/problems/DOORSPEN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|11|[Commando](http://www.spoj.com/problems/APIO10A/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|12|[Convex Hull](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2673)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|13|[Military Story](http://www.spoj.com/problems/VMILI/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|14|[Cops and Robbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=297)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|15|[Good Inflation](http://www.spoj.com/problems/GOODG/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|16|[Separate Points](http://www.spoj.com/problems/SPOINTS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|17|[Boundary Points](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3647)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|18|[Perfume](http://www.spoj.com/problems/PERFUME/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|19|[Two Ball Game](http://www.spoj.com/problems/TBGAME/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|20|[Buy Low Sell High](http://codeforces.com/problemset/problem/865/D)|Codeforces||MemSQL Start[c]UP 3.0 - Round 2 (onsite finalists)|6|
|<ul><li>- [ ] Done</li></ul>|21|[Counting Divisors](http://www.spoj.com/problems/DIVCNT1/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|22|[Amazing Factor Sequence (hard)](http://www.spoj.com/problems/AFS3/)|SPOJ|||10|
