# 054. TopologicalSort


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Topological Sorting](http://www.spoj.com/problems/TOPOSORT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Project File Dependencies](http://www.spoj.com/problems/PFDEP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Following Orders](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=60)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[The Dueling Philosophers Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4206)|Live Archive|2012|North America - Mid-Atlantic USA|1|
|<ul><li>- [ ] Done</li></ul>|5|[Rare Order](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=136)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Ordering Tasks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1246)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Beverages](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2001)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Answer the boss!](http://www.spoj.com/problems/RPLA/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|9|[Topological Sorting](http://acm.timus.ru/problem.aspx?space=1&num=1280)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|10|[All Discs Considered](http://www.spoj.com/problems/ALL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|11|[Hierarchy](http://www.spoj.com/problems/MAKETREE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|12|[Indiana Jones and the lost Soccer Cup](http://www.spoj.com/problems/GCPC11C/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|13|[Fox And Names](http://codeforces.com/problemset/problem/510/C)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|14|[Ordering](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=813)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|15|[Rare Order](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3140)|Live Archive|1990|World Finals - Washington|2|
|<ul><li>- [ ] Done</li></ul>|16|[Pick up sticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2733)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|17|[Orkut](http://br.spoj.com/problems/ORKUT/)|SPOJ Brazil|||3|
|<ul><li>- [ ] Done</li></ul>|18|[Multinomial Coefficients](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=852)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|19|[Tree Topology](http://www.spoj.com/problems/TTOP/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|20|[Online Courses In BSU](http://codeforces.com/problemset/problem/770/C)|Codeforces||VK Cup 2017 - Qualification 2|5|
|<ul><li>- [ ] Done</li></ul>|21|[Escalonamento ótimo](http://br.spoj.com/problems/ESCALO11/)|SPOJ Brazil|||6|
