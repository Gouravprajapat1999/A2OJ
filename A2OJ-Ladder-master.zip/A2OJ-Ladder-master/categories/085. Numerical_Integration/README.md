# 085. Numerical_Integration


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The area of the union of circles](http://www.spoj.com/problems/CIRU/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|2|[Bridge](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1486)|Live Archive|2005|Asia - Hangzhou|3|
|<ul><li>- [ ] Done</li></ul>|3|[Timer](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2331)|Live Archive|2008|Asia - Beijing|4|
|<ul><li>- [ ] Done</li></ul>|4|[Little Mammoth](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=2675)|ZOJ|||4|
|<ul><li>- [ ] Done</li></ul>|5|[GM-pineapple](http://acm.timus.ru/problem.aspx?space=1&num=1562)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|6|[Volume](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3097)|Live Archive|2010|Asia - Harbin|5|
|<ul><li>- [ ] Done</li></ul>|7|[Two Cylinders](http://acm.sgu.ru/problem.php?contest=0&problem=217)|SGU|||5|
|<ul><li>- [ ] Done</li></ul>|8|[Curvy Little Bottles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3893)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|9|[Environment Protection](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3973)|UVA|||6|
