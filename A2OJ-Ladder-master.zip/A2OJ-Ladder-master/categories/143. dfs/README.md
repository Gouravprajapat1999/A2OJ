# 143. dfs


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[A Bug&#8217;s Life](http://www.spoj.com/problems/BUGLIFE/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces|Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|1|
