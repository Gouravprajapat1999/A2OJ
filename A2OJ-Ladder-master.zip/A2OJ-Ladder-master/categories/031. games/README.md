# 031. games


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Little Girl and Game](http://codeforces.com/problemset/problem/276/B)|Codeforces|Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[WHAT A CO-ACCIDENT](http://www.spoj.com/problems/SYNC13C/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[M&M Game](http://www.spoj.com/problems/MMMGAME/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Sasha and Sticks](http://codeforces.com/problemset/problem/832/A)|Codeforces|Codeforces Round #425 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Spider Man](http://codeforces.com/problemset/problem/705/B)|Codeforces|Codeforces Round #366 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[A Game with Numbers](http://www.spoj.com/problems/NGM/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|7|[Hubulullu](http://www.spoj.com/problems/HUBULLU/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|8|[Godsend](http://codeforces.com/problemset/problem/841/B)|Codeforces|Codeforces Round #429 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Coins Game](http://www.spoj.com/problems/MCOINS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|10|[DOTA HEROES](http://www.spoj.com/problems/DOTAA/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|11|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|12|[The Game](http://www.spoj.com/problems/QCJ3/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|13|[Game](http://codeforces.com/problemset/problem/630/R)|Codeforces|Experimental Educational Round: VolBIT Formulas Blitz|2|
|<ul><li>- [ ] Done</li></ul>|14|[Dinner with Emma](http://codeforces.com/problemset/problem/616/B)|Codeforces|Educational Codeforces Round 5|2|
|<ul><li>- [ ] Done</li></ul>|15|[Vasya and Chess](http://codeforces.com/problemset/problem/493/D)|Codeforces|Codeforces Round #281 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|16|[Matrix Game](http://www.spoj.com/problems/MATGAME/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|17|[Integer Game](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2484)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|18|[Tic-tac-toe](http://codeforces.com/problemset/problem/3/C)|Codeforces|Codeforces Beta Round #3|3|
|<ul><li>- [ ] Done</li></ul>|19|[Playing Cubes](http://codeforces.com/problemset/problem/257/B)|Codeforces|Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|20|[The Stones Game](p?ID=8)|A2 Online Judge||3|
|<ul><li>- [ ] Done</li></ul>|21|[Moving Pebbles](http://www.spoj.com/problems/PEBBMOV/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|22|[Find the Winning Move](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1052)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|23|[Win or Freeze](http://codeforces.com/problemset/problem/150/A)|Codeforces|Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|24|[Exclusively Edible](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2286)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|25|[Special Nim Game](http://www.spoj.com/problems/NIMGAME/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|26|[TRIVIADOR](http://www.spoj.com/problems/TWOKINGS/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|27|[Stone Removing Game](http://www.spoj.com/problems/REMGAME/)|SPOJ||4|
|<ul><li>- [ ] Done</li></ul>|28|[Naming Company](http://codeforces.com/problemset/problem/794/C)|Codeforces|Tinkoff Challenge - Final Round (Codeforces Round #414, rated, Div. 1 + Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|29|[Chomp](http://www.spoj.com/problems/CLK/)|SPOJ||4|
|<ul><li>- [ ] Done</li></ul>|30|[Plate Game](http://codeforces.com/problemset/problem/197/A)|Codeforces|Codeforces Round #124 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|31|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces|Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|32|[Bag of mice](http://codeforces.com/problemset/problem/148/D)|Codeforces|Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|33|[Board Game](http://codeforces.com/problemset/problem/533/C)|Codeforces|VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|34|[TRIVIADOR](http://www.spoj.com/problems/QWERTY04/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|35|[Berzerk](http://codeforces.com/problemset/problem/786/A)|Codeforces|Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|36|[Put Knight!](http://codeforces.com/problemset/problem/120/E)|Codeforces|School Regional Team Contest, Saratov, 2011|5|
|<ul><li>- [ ] Done</li></ul>|37|[Team Nim](http://www.spoj.com/problems/TEAMNIM/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|38|[Weird Game](http://codeforces.com/problemset/problem/293/A)|Codeforces|Croc Champ 2013 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|39|[The Game Of Parity](http://codeforces.com/problemset/problem/549/C)|Codeforces|Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|40|[Fox and Card Game](http://codeforces.com/problemset/problem/388/C)|Codeforces|Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|41|[GAMING ARENA](http://www.spoj.com/problems/GAMARENA/)|SPOJ||6|
|<ul><li>- [ ] Done</li></ul>|42|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces|Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|43|[Zero-One](http://codeforces.com/problemset/problem/135/C)|Codeforces|Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|44|[Ithea Plays With Chtholly](http://codeforces.com/problemset/problem/896/B)|Codeforces|Codeforces Round #449 (Div. 1) & Codeforces Round #449 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|45|[Lieges of Legendre](http://codeforces.com/problemset/problem/603/C)|Codeforces|Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|46|[Baklawa](p?ID=424)|A2 Online Judge||6|
|<ul><li>- [ ] Done</li></ul>|47|[Interesting Game](http://codeforces.com/problemset/problem/87/C)|Codeforces|Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|48|[Warrior and Archer](http://codeforces.com/problemset/problem/594/A)|Codeforces|Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|49|[Yet Another Number Game](http://codeforces.com/problemset/problem/282/D)|Codeforces|Codeforces Round #173 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|50|[Beaver Game](http://codeforces.com/problemset/problem/78/C)|Codeforces|Codeforces Beta Round #70 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|51|[Beautiful Decomposition](http://codeforces.com/problemset/problem/279/E)|Codeforces|Codeforces Round #171 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|52|[Train](http://codeforces.com/problemset/problem/74/B)|Codeforces|Codeforces Beta Round #68|6|
|<ul><li>- [ ] Done</li></ul>|53|[Industrial Nim](http://codeforces.com/problemset/problem/15/C)|Codeforces|Codeforces Beta Round #15|6|
|<ul><li>- [ ] Done</li></ul>|54|[Dot](http://codeforces.com/problemset/problem/69/D)|Codeforces|Codeforces Beta Round #63 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|55|[Heroes of Might and Magic](http://acm.timus.ru/problem.aspx?space=1&num=1240)|Timus||7|
|<ul><li>- [ ] Done</li></ul>|56|[Furlo and Rublo and Game](http://codeforces.com/problemset/problem/255/E)|Codeforces|Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|57|[Pie or die](http://codeforces.com/problemset/problem/55/C)|Codeforces|Codeforces Beta Round #51|7|
|<ul><li>- [ ] Done</li></ul>|58|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces|Codeforces Round #188 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|59|[Sagheer and Apple Tree](http://codeforces.com/problemset/problem/812/E)|Codeforces|Codeforces Round #417 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|60|[Captains Mode](http://codeforces.com/problemset/problem/377/C)|Codeforces|Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|61|[Cactuses](http://acm.timus.ru/problem.aspx?space=1&num=1610)|Timus||8|
|<ul><li>- [ ] Done</li></ul>|62|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces|Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|63|[More Reclamation](http://codeforces.com/problemset/problem/335/C)|Codeforces|MemSQL start[c]up Round 2 - online version|8|
|<ul><li>- [ ] Done</li></ul>|64|[Two Pawns and One King](http://acm.timus.ru/problem.aspx?space=1&num=1216)|Timus||8|
|<ul><li>- [ ] Done</li></ul>|65|[Playing with String](http://codeforces.com/problemset/problem/305/E)|Codeforces|Codeforces Round #184 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|66|[Wizards and Numbers](http://codeforces.com/problemset/problem/167/C)|Codeforces|Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|67|[What Has Dirichlet Got to Do with That?](http://codeforces.com/problemset/problem/39/E)|Codeforces|School Team Contest #1 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|68|[New Game with a Chess Piece](http://codeforces.com/problemset/problem/36/D)|Codeforces|Codeforces Beta Round #36|8|
|<ul><li>- [ ] Done</li></ul>|69|[Game](http://codeforces.com/problemset/problem/277/C)|Codeforces|Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|70|[Chapaev](http://acm.timus.ru/problem.aspx?space=1&num=1163)|Timus||8|
|<ul><li>- [ ] Done</li></ul>|71|[Help Shrek and Donkey 2](http://codeforces.com/problemset/problem/142/D)|Codeforces|Codeforces Round #102 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|72|[Game with Strings](http://codeforces.com/problemset/problem/354/B)|Codeforces|Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|73|[World of Darkraft](http://codeforces.com/problemset/problem/138/D)|Codeforces|Codeforces Beta Round #99 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|74|[Dima and Game](http://codeforces.com/problemset/problem/273/E)|Codeforces|Codeforces Round #167 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|75|[Ivan the Fool VS Gorynych the Dragon](http://codeforces.com/problemset/problem/48/E)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|76|[Flatland Fencing](http://codeforces.com/problemset/problem/154/D)|Codeforces|Codeforces Round #109 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|77|[Smart Boy](http://codeforces.com/problemset/problem/38/F)|Codeforces|School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|78|[Tavas in Kansas](http://codeforces.com/problemset/problem/536/D)|Codeforces|Codeforces Round #299 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|79|[Sharti](http://codeforces.com/problemset/problem/494/E)|Codeforces|Codeforces Round #282 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|80|[Help Shrek and Donkey](http://codeforces.com/problemset/problem/98/E)|Codeforces|Codeforces Beta Round #78 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|81|[An easy problem about trees](http://codeforces.com/problemset/problem/457/F)|Codeforces|MemSQL Start[c]UP 2.0 - Round 2|10|
