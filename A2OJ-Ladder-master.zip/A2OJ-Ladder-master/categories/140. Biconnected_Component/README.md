# 140. Biconnected_Component


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[To inifinity and Beyond](http://www.spoj.com/problems/BUZZ/)|SPOJ|6|
|<ul><li>- [ ] Done</li></ul>|2|[Interesting Route](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3923)|UVA|9|
