# 147. big_mod


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Big Mod](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=310)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[Ones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1068)|UVA|1|
