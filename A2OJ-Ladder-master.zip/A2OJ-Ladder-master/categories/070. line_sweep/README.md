# 070. line_sweep


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Closest Pair Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1186)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Closest Point Pair](http://www.spoj.com/problems/CLOPPAIR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[The day of the competitors](http://www.spoj.com/problems/NICEDAY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Mummy Madness](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3137)|Live Archive|2011|World Finals - Orlando|2|
|<ul><li>- [ ] Done</li></ul>|5|[SkyScrapers](http://www.spoj.com/problems/CEPC08B/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|6|[November Rain](http://www.spoj.com/problems/RAIN1/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Water Falls](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=774)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Triangular Queries](http://www.codechef.com/problems/TRIQUERY)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|9|[Minion Circle](http://www.codechef.com/problems/CIRCLE)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|10|[Wireless](http://www.spoj.com/problems/WIRELESS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|11|[Wild West](http://www.spoj.com/problems/WILD/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|12|[Bishops](http://www.codechef.com/problems/TABISHOP)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|13|[Boundary Points](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3647)|UVA|||5|
