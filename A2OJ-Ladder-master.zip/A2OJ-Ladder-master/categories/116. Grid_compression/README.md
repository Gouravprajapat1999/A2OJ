# 116. Grid_compression


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Tracking Bio-bots](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2788)|Live Archive|2010|World Finals - Harbin|1|
|<ul><li>- [ ] Done</li></ul>|2|[Crossing Streets](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1275)|Live Archive|2005|World Finals - Shanghai|1|
|<ul><li>- [ ] Done</li></ul>|3|[Tin Cutter](http://www.spoj.com/problems/TCUTTER/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|4|[Bulb Inside a Grid](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2638)|UVA|||7|
