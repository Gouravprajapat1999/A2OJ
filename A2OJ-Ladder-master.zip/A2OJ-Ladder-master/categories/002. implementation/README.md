# 002. implementation


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Greg's Workout](http://codeforces.com/problemset/problem/255/A)|Codeforces||Codeforces Round #156 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Free Cash](http://codeforces.com/problemset/problem/237/A)|Codeforces||Codeforces Round #147 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Boy or Girl](http://codeforces.com/problemset/problem/236/A)|Codeforces||Codeforces Round #146 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Perfect Permutation](http://codeforces.com/problemset/problem/233/A)|Codeforces||Codeforces Round #144 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Team](http://codeforces.com/problemset/problem/231/A)|Codeforces||Codeforces Round #143 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Is your horseshoe on the other hoof?](http://codeforces.com/problemset/problem/228/A)|Codeforces||Codeforces Round #141 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[k-String](http://codeforces.com/problemset/problem/219/A)|Codeforces||Codeforces Round #135 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Dubstep](http://codeforces.com/problemset/problem/208/A)|Codeforces||Codeforces Round #130 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Drinks](http://codeforces.com/problemset/problem/200/B)|Codeforces||Codeforces Round #126 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Hexadecimal's theorem](http://codeforces.com/problemset/problem/199/A)|Codeforces||Codeforces Round #125 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Supercentral Point](http://codeforces.com/problemset/problem/165/A)|Codeforces||Codeforces Round #112 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|13|[Next Round](http://codeforces.com/problemset/problem/158/A)|Codeforces||VK Cup 2012 Qualification Round 1|1|
|<ul><li>- [ ] Done</li></ul>|14|[Marks](http://codeforces.com/problemset/problem/152/A)|Codeforces||Codeforces Round #108 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Soft Drinking](http://codeforces.com/problemset/problem/151/A)|Codeforces||Codeforces Round #107 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Business trip](http://codeforces.com/problemset/problem/149/A)|Codeforces||Codeforces Round #106 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Insomnia cure](http://codeforces.com/problemset/problem/148/A)|Codeforces||Codeforces Round #105 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Lucky Ticket](http://codeforces.com/problemset/problem/146/A)|Codeforces||Codeforces Round #104 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Arrival of the General](http://codeforces.com/problemset/problem/144/A)|Codeforces||Codeforces Round #103 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Amusing Joke](http://codeforces.com/problemset/problem/141/A)|Codeforces||Codeforces Round #101 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Petr and Book](http://codeforces.com/problemset/problem/139/A)|Codeforces||Codeforces Beta Round #99 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[Presents](http://codeforces.com/problemset/problem/136/A)|Codeforces||Codeforces Beta Round #97 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[HQ9+](http://codeforces.com/problemset/problem/133/A)|Codeforces||Codeforces Beta Round #96 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[cAPS lOCK](http://codeforces.com/problemset/problem/131/A)|Codeforces||Codeforces Beta Round #95 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Cookies](http://codeforces.com/problemset/problem/129/A)|Codeforces||Codeforces Beta Round #94 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Epic Game](http://codeforces.com/problemset/problem/119/A)|Codeforces||Codeforces Beta Round #90|1|
|<ul><li>- [ ] Done</li></ul>|27|[Present from Lena](http://codeforces.com/problemset/problem/118/B)|Codeforces||Codeforces Beta Round #89 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[String Task](http://codeforces.com/problemset/problem/118/A)|Codeforces||Codeforces Beta Round #89 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Tram](http://codeforces.com/problemset/problem/116/A)|Codeforces||Codeforces Beta Round #87 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Petya and Strings](http://codeforces.com/problemset/problem/112/A)|Codeforces||Codeforces Beta Round #85 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Nearly Lucky Number](http://codeforces.com/problemset/problem/110/A)|Codeforces||Codeforces Beta Round #84 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Football](http://codeforces.com/problemset/problem/96/A)|Codeforces||Codeforces Beta Round #77 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Chips](http://codeforces.com/problemset/problem/92/A)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Double Cola](http://codeforces.com/problemset/problem/82/A)|Codeforces||Yandex.Algorithm 2011 Qualification 2|1|
|<ul><li>- [ ] Done</li></ul>|35|[Life Without Zeros](http://codeforces.com/problemset/problem/75/A)|Codeforces||Codeforces Beta Round #67 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[Young Physicist](http://codeforces.com/problemset/problem/69/A)|Codeforces||Codeforces Beta Round #63 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|37|[Ultra-Fast Mathematician](http://codeforces.com/problemset/problem/61/A)|Codeforces||Codeforces Beta Round #57 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|38|[Word](http://codeforces.com/problemset/problem/59/A)|Codeforces||Codeforces Beta Round #55 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Translation](http://codeforces.com/problemset/problem/41/A)|Codeforces||Codeforces Beta Round #40 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Army](http://codeforces.com/problemset/problem/38/A)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|1|
|<ul><li>- [ ] Done</li></ul>|41|[Reconnaissance 2](http://codeforces.com/problemset/problem/34/A)|Codeforces||Codeforces Beta Round #34 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|42|[Borze](http://codeforces.com/problemset/problem/32/B)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|43|[Registration System](http://codeforces.com/problemset/problem/4/C)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|44|[Winner](http://codeforces.com/problemset/problem/2/A)|Codeforces||Codeforces Beta Round #2|1|
|<ul><li>- [ ] Done</li></ul>|45|[Spreadsheet](http://codeforces.com/problemset/problem/1/B)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|46|[Bytelandian gold coins](http://www.spoj.com/problems/COINS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|47|[Ws Cipher](http://www.spoj.com/problems/WSCIPHER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|48|[Arm Wrestling Tournament](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3061)|Live Archive|2010|Asia - Jakarta|1|
|<ul><li>- [ ] Done</li></ul>|49|[Magic Numbers](http://codeforces.com/problemset/problem/320/A)|Codeforces||Codeforces Round #189 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|50|[Hello, world!](http://acm.tju.edu.cn/toj/showp1001.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|51|[Fibonacci Numbers](http://acm.tju.edu.cn/toj/showp1208.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|52|[Meteoros](http://br.spoj.com/problems/METEORO/)|SPOJ Brazil|||1|
|<ul><li>- [ ] Done</li></ul>|53|[MODIFY SEQUENCE](http://www.spoj.com/problems/NITK06/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|54|[Adding Reversed Numbers](http://acm.tju.edu.cn/toj/showp2210.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|55|[Area of a Circle](https://www.urionlinejudge.com.br/judge/en/problems/view/1002)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|56|[Clock Hands](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=520)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|57|[Cheap Travel](http://codeforces.com/problemset/problem/466/A)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|58|[Balloons Colors](p?ID=6)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|59|[Appleman and Easy Task](http://codeforces.com/problemset/problem/462/A)|Codeforces||Codeforces Round #263 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|60|[FoxAndGame](http://community.topcoder.com/stat?c=problem_statement&pm=12438)|TopCoder||SRM 571 - Div2 easy] (15491)|1|
|<ul><li>- [ ] Done</li></ul>|61|[Treats for the Cows](http://www.spoj.com/problems/TRT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|62|[Wachovia Bank](http://www.spoj.com/problems/WACHOVIA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|63|[Fibonacci Freeze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=436)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|64|[What's Next?](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2965)|Live Archive|2010|Africa/Middle East - Arab Contest|1|
|<ul><li>- [ ] Done</li></ul>|65|[Tanya and Toys](http://codeforces.com/problemset/problem/659/C)|Codeforces||Codeforces Round #346 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|66|[Round House](http://codeforces.com/problemset/problem/659/A)|Codeforces||Codeforces Round #346 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|67|[Far Relative’s Birthday Cake](http://codeforces.com/problemset/problem/629/A)|Codeforces||Codeforces Round #343 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|68|[Wet Shark and Odd and Even](http://codeforces.com/problemset/problem/621/A)|Codeforces||Codeforces Round #341 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|69|[Professor GukiZ's Robot](http://codeforces.com/problemset/problem/620/A)|Codeforces||Educational Codeforces Round 6|1|
|<ul><li>- [ ] Done</li></ul>|70|[Bulbs](http://codeforces.com/problemset/problem/615/A)|Codeforces||Codeforces Round #338 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|71|[New Year and Days](http://codeforces.com/problemset/problem/611/A)|Codeforces||Good Bye 2015|1|
|<ul><li>- [ ] Done</li></ul>|72|[USB Flash Drives](http://codeforces.com/problemset/problem/609/A)|Codeforces||Educational Codeforces Round 3|1|
|<ul><li>- [ ] Done</li></ul>|73|[Uncowed Forces](http://codeforces.com/problemset/problem/604/A)|Codeforces||Codeforces Round #334 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|74|[Two Bases](http://codeforces.com/problemset/problem/602/A)|Codeforces||Codeforces Round #333 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|75|[Patrick and Shopping](http://codeforces.com/problemset/problem/599/A)|Codeforces||Codeforces Round #332 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|76|[Vitaly and Night](http://codeforces.com/problemset/problem/595/A)|Codeforces||Codeforces Round #330 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|77|[Alena's Schedule](http://codeforces.com/problemset/problem/586/A)|Codeforces||Codeforces Round #325 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|78|[Robot's Task](http://codeforces.com/problemset/problem/583/B)|Codeforces||Codeforces Round #323 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|79|[Asphalting Roads](http://codeforces.com/problemset/problem/583/A)|Codeforces||Codeforces Round #323 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|80|[Luxurious Houses](http://codeforces.com/problemset/problem/581/B)|Codeforces||Codeforces Round #322 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|81|[Vasya the Hipster](http://codeforces.com/problemset/problem/581/A)|Codeforces||Codeforces Round #322 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|82|[Kefa and First Steps](http://codeforces.com/problemset/problem/580/A)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|83|[Multiplication Table](http://codeforces.com/problemset/problem/577/A)|Codeforces||Codeforces Round #319 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|84|[Bear and Elections](http://codeforces.com/problemset/problem/574/A)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|85|[Bear and Poker](http://codeforces.com/problemset/problem/573/A)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|86|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces||Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|87|[Elections](http://codeforces.com/problemset/problem/570/A)|Codeforces||Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|88|[Berland National Library](http://codeforces.com/problemset/problem/567/B)|Codeforces||Codeforces Round #Pi (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|89|[Lineland Mail](http://codeforces.com/problemset/problem/567/A)|Codeforces||Codeforces Round #Pi (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|90|[Currency System in Geraldion](http://codeforces.com/problemset/problem/560/A)|Codeforces||Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|91|[Lala Land and Apple Trees](http://codeforces.com/problemset/problem/558/A)|Codeforces||Codeforces Round #312 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|92|[Ilya and Diplomas](http://codeforces.com/problemset/problem/557/A)|Codeforces||Codeforces Round #311 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|93|[Vanya and Books](http://codeforces.com/problemset/problem/552/B)|Codeforces||Codeforces Round #308 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|94|[Vanya and Table](http://codeforces.com/problemset/problem/552/A)|Codeforces||Codeforces Round #308 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|95|[GukiZ and Contest](http://codeforces.com/problemset/problem/551/A)|Codeforces||Codeforces Round #307 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|96|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|97|[Face Detection](http://codeforces.com/problemset/problem/549/A)|Codeforces||Looksery Cup 2015|1|
|<ul><li>- [ ] Done</li></ul>|98|[Mike and Fax](http://codeforces.com/problemset/problem/548/A)|Codeforces||Codeforces Round #305 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|99|[Soldier and Badges](http://codeforces.com/problemset/problem/546/B)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|100|[Soldier and Bananas](http://codeforces.com/problemset/problem/546/A)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|101|[Queue](http://codeforces.com/problemset/problem/545/D)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|102|[Toy Cars](http://codeforces.com/problemset/problem/545/A)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|103|[Combination Lock](http://codeforces.com/problemset/problem/540/A)|Codeforces||Codeforces Round #301 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|104|[Quasi Binary](http://codeforces.com/problemset/problem/538/B)|Codeforces||Codeforces Round #300|1|
|<ul><li>- [ ] Done</li></ul>|105|[Tavas and SaDDas](http://codeforces.com/problemset/problem/535/B)|Codeforces||Codeforces Round #299 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|106|[Tavas and Nafas](http://codeforces.com/problemset/problem/535/A)|Codeforces||Codeforces Round #299 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|107|[Exam](http://codeforces.com/problemset/problem/534/A)|Codeforces||Codeforces Round #298 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|108|[Playing with Paper](http://codeforces.com/problemset/problem/527/A)|Codeforces||Codeforces Round #296 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|109|[Two Buttons](http://codeforces.com/problemset/problem/520/B)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|110|[Pangram](http://codeforces.com/problemset/problem/520/A)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|111|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|112|[A and B and Compilation Errors](http://codeforces.com/problemset/problem/519/B)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|113|[A and B and Chess](http://codeforces.com/problemset/problem/519/A)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|114|[Chewba?ca and Number](http://codeforces.com/problemset/problem/514/A)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|115|[Fox And Snake](http://codeforces.com/problemset/problem/510/A)|Codeforces||Codeforces Round #290 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|116|[Maximum in Table](http://codeforces.com/problemset/problem/509/A)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|1|
|<ul><li>- [ ] Done</li></ul>|117|[Amr and Music](http://codeforces.com/problemset/problem/507/A)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|118|[Contest](http://codeforces.com/problemset/problem/501/A)|Codeforces||Codeforces Round #285 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|119|[New Year Transportation](http://codeforces.com/problemset/problem/500/A)|Codeforces||Good Bye 2014|1|
|<ul><li>- [ ] Done</li></ul>|120|[Watching a movie](http://codeforces.com/problemset/problem/499/A)|Codeforces||Codeforces Round #284 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|121|[Minimum Difficulty](http://codeforces.com/problemset/problem/496/A)|Codeforces||Codeforces Round #283 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|122|[Vanya and Cubes](http://codeforces.com/problemset/problem/492/A)|Codeforces||Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|123|[Team Olympiad](http://codeforces.com/problemset/problem/490/A)|Codeforces||Codeforces Round #279 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|124|[Given Length and Sum of Digits...](http://codeforces.com/problemset/problem/489/C)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|125|[OR in Matrix](http://codeforces.com/problemset/problem/486/B)|Codeforces||Codeforces Round #277 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|126|[Calculating Function](http://codeforces.com/problemset/problem/486/A)|Codeforces||Codeforces Round #277 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|127|[Counterexample ](http://codeforces.com/problemset/problem/483/A)|Codeforces||Codeforces Round #275 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|128|[Initial Bet](http://codeforces.com/problemset/problem/478/A)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|129|[Dreamoon and Stairs](http://codeforces.com/problemset/problem/476/A)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|130|[Worms](http://codeforces.com/problemset/problem/474/B)|Codeforces||Codeforces Round #271 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|131|[Keyboard](http://codeforces.com/problemset/problem/474/A)|Codeforces||Codeforces Round #271 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|132|[MUH and Sticks](http://codeforces.com/problemset/problem/471/A)|Codeforces||Codeforces Round #269 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|133|[I Wanna Be the Guy](http://codeforces.com/problemset/problem/469/A)|Codeforces||Codeforces Round #268 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|134|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces||Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|135|[George and Accommodation](http://codeforces.com/problemset/problem/467/A)|Codeforces||Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|136|[Inbox (100500)](http://codeforces.com/problemset/problem/465/B)|Codeforces||Codeforces Round #265 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|137|[inc ARG](http://codeforces.com/problemset/problem/465/A)|Codeforces||Codeforces Round #265 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|138|[Caisa and Sugar](http://codeforces.com/problemset/problem/463/A)|Codeforces||Codeforces Round #264 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|139|[Vasya and Socks](http://codeforces.com/problemset/problem/460/A)|Codeforces||Codeforces Round #262 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|140|[Pashmak and Flowers](http://codeforces.com/problemset/problem/459/B)|Codeforces||Codeforces Round #261 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|141|[Pashmak and Garden](http://codeforces.com/problemset/problem/459/A)|Codeforces||Codeforces Round #261 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|142|[Little Pony and Sort by Shift](http://codeforces.com/problemset/problem/454/B)|Codeforces||Codeforces Round #259 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|143|[Little Pony and Crystal Mine](http://codeforces.com/problemset/problem/454/A)|Codeforces||Codeforces Round #259 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|144|[Sort the Array](http://codeforces.com/problemset/problem/451/B)|Codeforces||Codeforces Round #258 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|145|[Game With Sticks](http://codeforces.com/problemset/problem/451/A)|Codeforces||Codeforces Round #258 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|146|[Jzzhu and Sequences](http://codeforces.com/problemset/problem/450/B)|Codeforces||Codeforces Round #257 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|147|[Jzzhu and Children](http://codeforces.com/problemset/problem/450/A)|Codeforces||Codeforces Round #257 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|148|[Suffix Structures](http://codeforces.com/problemset/problem/448/B)|Codeforces||Codeforces Round #256 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|149|[Rewards](http://codeforces.com/problemset/problem/448/A)|Codeforces||Codeforces Round #256 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|150|[DZY Loves Strings](http://codeforces.com/problemset/problem/447/B)|Codeforces||Codeforces Round #255 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|151|[DZY Loves Chessboard](http://codeforces.com/problemset/problem/445/A)|Codeforces||Codeforces Round #254 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|152|[Anton and Letters](http://codeforces.com/problemset/problem/443/A)|Codeforces||Codeforces Round #253 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|153|[Valera and Antique Items](http://codeforces.com/problemset/problem/441/A)|Codeforces||Codeforces Round #252 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|154|[Devu, the Dumb Guy](http://codeforces.com/problemset/problem/439/B)|Codeforces||Codeforces Round #251 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|155|[Devu, the Singer and Churu, the Joker](http://codeforces.com/problemset/problem/439/A)|Codeforces||Codeforces Round #251 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|156|[Queue on Bus Stop](http://codeforces.com/problemset/problem/435/A)|Codeforces||Codeforces Round #249 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|157|[Kuriyama Mirai's Stones](http://codeforces.com/problemset/problem/433/B)|Codeforces||Codeforces Round #248 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|158|[Choosing Teams](http://codeforces.com/problemset/problem/432/A)|Codeforces||Codeforces Round #246 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|159|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces||Codeforces Round #247 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|160|[Black Square](http://codeforces.com/problemset/problem/431/A)|Codeforces||Codeforces Round #247 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|161|[Prison Transfer](http://codeforces.com/problemset/problem/427/B)|Codeforces||Codeforces Round #244 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|162|[Police Recruits](http://codeforces.com/problemset/problem/427/A)|Codeforces||Codeforces Round #244 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|163|[Gravity Flip](http://codeforces.com/problemset/problem/405/A)|Codeforces||Codeforces Round #238 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|164|[Valera and X](http://codeforces.com/problemset/problem/404/A)|Codeforces||Codeforces Round #237 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|165|[Team](http://codeforces.com/problemset/problem/401/C)|Codeforces||Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|166|[Vanya and Cards](http://codeforces.com/problemset/problem/401/A)|Codeforces||Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|167|[Bear and Raspberry](http://codeforces.com/problemset/problem/385/A)|Codeforces||Codeforces Round #226 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|168|[Coder](http://codeforces.com/problemset/problem/384/A)|Codeforces||Codeforces Round #225 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|169|[Sereja and Dima](http://codeforces.com/problemset/problem/381/A)|Codeforces||Codeforces Round #223 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|170|[New Year Candles](http://codeforces.com/problemset/problem/379/A)|Codeforces||Good Bye 2013|1|
|<ul><li>- [ ] Done</li></ul>|171|[Valera and Plates](http://codeforces.com/problemset/problem/369/A)|Codeforces||Codeforces Round #216 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|172|[Domino](http://codeforces.com/problemset/problem/353/A)|Codeforces||Codeforces Round #205 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|173|[Jeff and Digits](http://codeforces.com/problemset/problem/352/A)|Codeforces||Codeforces Round #204 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|174|[TL](http://codeforces.com/problemset/problem/350/A)|Codeforces||Codeforces Round #203 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|175|[Cinema Line](http://codeforces.com/problemset/problem/349/A)|Codeforces||Codeforces Round #202 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|176|[Magnets](http://codeforces.com/problemset/problem/344/A)|Codeforces||Codeforces Round #200 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|177|[Xenia and Ringroad](http://codeforces.com/problemset/problem/339/B)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|178|[Helpful Maths](http://codeforces.com/problemset/problem/339/A)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|179|[Candy Bags](http://codeforces.com/problemset/problem/334/A)|Codeforces||Codeforces Round #194 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|180|[Cakeminator](http://codeforces.com/problemset/problem/330/A)|Codeforces||Codeforces Round #192 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|181|[Flipping Game](http://codeforces.com/problemset/problem/327/A)|Codeforces||Codeforces Round #191 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|182|[Ilya and Queries](http://codeforces.com/problemset/problem/313/B)|Codeforces||Codeforces Round #186 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|183|[Ilya and Bank Account](http://codeforces.com/problemset/problem/313/A)|Codeforces||Codeforces Round #186 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|184|[Array](http://codeforces.com/problemset/problem/300/A)|Codeforces||Codeforces Round #181 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|185|[Shaass and Oskols](http://codeforces.com/problemset/problem/294/A)|Codeforces||Codeforces Round #178 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|186|[Building Permutation](http://codeforces.com/problemset/problem/285/C)|Codeforces||Codeforces Round #175 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|187|[Slightly Decreasing Permutations](http://codeforces.com/problemset/problem/285/A)|Codeforces||Codeforces Round #175 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|188|[Bit++](http://codeforces.com/problemset/problem/282/A)|Codeforces||Codeforces Round #173 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|189|[Books](http://codeforces.com/problemset/problem/279/B)|Codeforces||Codeforces Round #171 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|190|[Circle Line](http://codeforces.com/problemset/problem/278/A)|Codeforces||Codeforces Round #170 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|191|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces||Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|192|[Lunch Rush](http://codeforces.com/problemset/problem/276/A)|Codeforces||Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|193|[Lights Out](http://codeforces.com/problemset/problem/275/A)|Codeforces||Codeforces Round #168 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|194|[Dima and Friends](http://codeforces.com/problemset/problem/272/A)|Codeforces||Codeforces Round #167 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|195|[Fancy Fence](http://codeforces.com/problemset/problem/270/A)|Codeforces||Codeforces Round #165 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|196|[Buttons](http://codeforces.com/problemset/problem/268/B)|Codeforces||Codeforces Round #164 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|197|[Queue at the School](http://codeforces.com/problemset/problem/266/B)|Codeforces||Codeforces Round #163 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|198|[Stones on the Table](http://codeforces.com/problemset/problem/266/A)|Codeforces||Codeforces Round #163 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|199|[Roadside Trees (Simplified Edition)](http://codeforces.com/problemset/problem/265/B)|Codeforces||Codeforces Round #162 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|200|[Colorful Stones (Simplified Edition)](http://codeforces.com/problemset/problem/265/A)|Codeforces||Codeforces Round #162 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|201|[Beautiful Matrix](http://codeforces.com/problemset/problem/263/A)|Codeforces||Codeforces Round #161 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|202|[Roma and Lucky Numbers](http://codeforces.com/problemset/problem/262/A)|Codeforces||Codeforces Round #160 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|203|[Taxi](http://codeforces.com/problemset/problem/158/B)|Codeforces||VK Cup 2012 Qualification Round 1|1|
|<ul><li>- [ ] Done</li></ul>|204|[Lucky Sum of Digits](http://codeforces.com/problemset/problem/109/A)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|205|[Drazil and Factorial](http://codeforces.com/problemset/problem/515/C)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|206|[Summer Camp](http://codeforces.com/problemset/problem/672/A)|Codeforces||Codeforces Round #352 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|207|[Different is Good](http://codeforces.com/problemset/problem/672/B)|Codeforces||Codeforces Round #352 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|208|[Vanya and Fence](http://codeforces.com/problemset/problem/677/A)|Codeforces||Codeforces Round #355 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|209|[Free Ice Cream](http://codeforces.com/problemset/problem/686/A)|Codeforces||Codeforces Round #359 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|210|[Bear and Five Cards](http://codeforces.com/problemset/problem/680/A)|Codeforces||Codeforces Round #356 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|211|[Nicholas and Permutation](http://codeforces.com/problemset/problem/676/A)|Codeforces||Codeforces Round #354 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|212|[Bear and Finding Criminals](http://codeforces.com/problemset/problem/680/B)|Codeforces||Codeforces Round #356 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|213|[Opponents](http://codeforces.com/problemset/problem/688/A)|Codeforces||Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|214|[Identifying tea](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=5223)|Live Archive|2015|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|215|[Watermelon](http://codeforces.com/problemset/problem/4/A)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|216|[Anastasia and pebbles](http://codeforces.com/problemset/problem/789/A)|Codeforces||Codeforces Round #407 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|217|[Karen and Morning](http://codeforces.com/problemset/problem/816/A)|Codeforces||Codeforces Round #419 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|218|[Anton and Polyhedrons](http://codeforces.com/problemset/problem/785/A)|Codeforces||Codeforces Round #404 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|219|[Bear and Big Brother](http://codeforces.com/problemset/problem/791/A)|Codeforces||Codeforces Round #405 (rated, Div. 2, based on VK Cup 2017 Round 1)|1|
|<ul><li>- [ ] Done</li></ul>|220|[Hulk](http://codeforces.com/problemset/problem/705/A)|Codeforces||Codeforces Round #366 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|221|[Mishka and Game](http://codeforces.com/problemset/problem/703/A)|Codeforces||Codeforces Round #365 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|222|[Scarborough Fair](http://codeforces.com/problemset/problem/897/A)|Codeforces||Codeforces Round #449 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|223|[Bachgold Problem](http://codeforces.com/problemset/problem/749/A)|Codeforces||Codeforces Round #388 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|224|[Bus to Udayland](http://codeforces.com/problemset/problem/711/A)|Codeforces||Codeforces Round #369 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|225|[One-dimensional Japanese Crossword](http://codeforces.com/problemset/problem/721/A)|Codeforces||Codeforces Round #374 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|226|[A Good Contest](http://codeforces.com/problemset/problem/681/A)|Codeforces||Codeforces Round #357 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|227|[Taymyr is calling you](http://codeforces.com/problemset/problem/764/A)|Codeforces||Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|228|[Memory and Crow](http://codeforces.com/problemset/problem/712/A)|Codeforces||Codeforces Round #370 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|229|[Crazy Computer](http://codeforces.com/problemset/problem/716/A)|Codeforces||Codeforces Round #372 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|230|[Vladik and Courtesy](http://codeforces.com/problemset/problem/811/A)|Codeforces||Codeforces Round #416 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|231|[Find Extra One](http://codeforces.com/problemset/problem/900/A)|Codeforces||Codeforces Round #450 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|232|[Hongcow Learns the Cyclic Shift](http://codeforces.com/problemset/problem/745/A)|Codeforces||Codeforces Round #385 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|233|[Generous Kefa](http://codeforces.com/problemset/problem/841/A)|Codeforces||Codeforces Round #429 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|234|[Greed](http://codeforces.com/problemset/problem/892/A)|Codeforces||Codeforces Round #446 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|235|[Brain's Photos](http://codeforces.com/problemset/problem/707/A)|Codeforces||Codeforces Round #368 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|236|[Ostap and Grasshopper](http://codeforces.com/problemset/problem/735/A)|Codeforces||Codeforces Round #382 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|237|[Arpa’s hard exam and Mehrdad’s naive cheat](http://codeforces.com/problemset/problem/742/A)|Codeforces||Codeforces Round #383 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|238|[Timofey and cubes](http://codeforces.com/problemset/problem/764/B)|Codeforces||Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|239|[Arya and Bran](http://codeforces.com/problemset/problem/839/A)|Codeforces||Codeforces Round #428 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|240|[An abandoned sentiment from past](http://codeforces.com/problemset/problem/814/A)|Codeforces||Codeforces Round #418 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|241|[The Useless Toy](http://codeforces.com/problemset/problem/834/A)|Codeforces||Codeforces Round #426 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|242|[Shell Game](http://codeforces.com/problemset/problem/777/A)|Codeforces||Codeforces Round #401 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|243|[Borya's Diagnosis](http://codeforces.com/problemset/problem/879/A)|Codeforces||Codeforces Round #443 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|244|[Beru-taxi](http://codeforces.com/problemset/problem/706/A)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|245|[Odds and Ends](http://codeforces.com/problemset/problem/849/A)|Codeforces||Codeforces Round #431 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|246|[Snacktower](http://codeforces.com/problemset/problem/767/A)|Codeforces||Codeforces Round #398 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|247|[Interesting drink](http://codeforces.com/problemset/problem/706/B)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|248|[Chloe and the sequence ](http://codeforces.com/problemset/problem/743/B)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|249|[Memory and Trident](http://codeforces.com/problemset/problem/712/B)|Codeforces||Codeforces Round #370 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|250|[Vladik and flights](http://codeforces.com/problemset/problem/743/A)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|251|[Filya and Homework](http://codeforces.com/problemset/problem/714/B)|Codeforces||Codeforces Round #371 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|252|[The Artful Expedient](http://codeforces.com/problemset/problem/869/A)|Codeforces||Codeforces Round #439 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|253|[1, 10, 100, 1000...](http://acm.timus.ru/problem.aspx?space=1&num=1209)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|254|[Simple Equations](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2612)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|255|[Normalized Form](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2967)|Live Archive|2010|Africa/Middle East - Arab Contest|1|
|<ul><li>- [ ] Done</li></ul>|256|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces||Codeforces Round #119 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|257|[Shortest path of the king](http://codeforces.com/problemset/problem/3/A)|Codeforces||Codeforces Beta Round #3|1|
|<ul><li>- [ ] Done</li></ul>|258|[Omar](p?ID=1)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|259|[Key races](http://codeforces.com/problemset/problem/835/A)|Codeforces||Codeforces Round #427 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|260|[Cupboards](http://codeforces.com/problemset/problem/248/A)|Codeforces||Codeforces Round #152 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|261|[Big Segment](http://codeforces.com/problemset/problem/242/B)|Codeforces||Codeforces Round #149 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|262|[Two Bags of Potatoes](http://codeforces.com/problemset/problem/239/A)|Codeforces||Codeforces Round #148 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|263|[Effective Approach](http://codeforces.com/problemset/problem/227/B)|Codeforces||Codeforces Round #140 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|264|[Shooshuns and Sequence ](http://codeforces.com/problemset/problem/222/A)|Codeforces||Codeforces Round #137 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|265|[Little Elephant and Function](http://codeforces.com/problemset/problem/221/A)|Codeforces||Codeforces Round #136 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|266|[Little Elephant and Problem](http://codeforces.com/problemset/problem/220/A)|Codeforces||Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|267|[Airport](http://codeforces.com/problemset/problem/218/B)|Codeforces||Codeforces Round #134 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|268|[Bicycle Chain](http://codeforces.com/problemset/problem/215/A)|Codeforces||Codeforces Round #132 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|269|[Prizes, Prizes, more Prizes](http://codeforces.com/problemset/problem/208/D)|Codeforces||Codeforces Round #130 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|270|[Little Elephant and Rozdil](http://codeforces.com/problemset/problem/205/A)|Codeforces||Codeforces Round #129 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|271|[Comparing Strings](http://codeforces.com/problemset/problem/186/A)|Codeforces||Codeforces Round #118 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|272|[Wizards and Demonstration](http://codeforces.com/problemset/problem/168/A)|Codeforces||Codeforces Round #114 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|273|[Rank List](http://codeforces.com/problemset/problem/166/A)|Codeforces||Codeforces Round #113 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|274|[Burning Midnight Oil](http://codeforces.com/problemset/problem/165/B)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|275|[Cd and pwd commands](http://codeforces.com/problemset/problem/158/C)|Codeforces||VK Cup 2012 Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|276|[Lucky Conversion](http://codeforces.com/problemset/problem/145/A)|Codeforces||Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|277|[Opposites Attract](http://codeforces.com/problemset/problem/131/B)|Codeforces||Codeforces Beta Round #95 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|278|[Little Pigs and Wolves](http://codeforces.com/problemset/problem/116/B)|Codeforces||Codeforces Beta Round #87 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|279|[Palindromic Times](http://codeforces.com/problemset/problem/108/A)|Codeforces||Codeforces Beta Round #83 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|280|[Blackjack](http://codeforces.com/problemset/problem/104/A)|Codeforces||Codeforces Beta Round #80 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|281|[Sum of Digits](http://codeforces.com/problemset/problem/102/B)|Codeforces||Codeforces Beta Round #79 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|282|[Restoring Password](http://codeforces.com/problemset/problem/94/A)|Codeforces||Codeforces Beta Round #76 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|283|[Petya and Countryside](http://codeforces.com/problemset/problem/66/B)|Codeforces||Codeforces Beta Round #61 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|284|[Sinking Ship](http://codeforces.com/problemset/problem/63/A)|Codeforces||Codeforces Beta Round #59 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|285|[Next Test](http://codeforces.com/problemset/problem/27/A)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|286|[Flag](http://codeforces.com/problemset/problem/16/A)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|287|[Chat Servers Outgoing Traffic](http://codeforces.com/problemset/problem/5/A)|Codeforces||Codeforces Beta Round #5|2|
|<ul><li>- [ ] Done</li></ul>|288|[Ciel and Dancing](http://codeforces.com/problemset/problem/322/A)|Codeforces||Codeforces Round #190 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|289|[Little Elephant and Magic Square](http://codeforces.com/problemset/problem/259/B)|Codeforces||Codeforces Round #157 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|290|[Roman Numerals](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|291|[Super Over](http://www.spoj.com/problems/SUPOVR/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|292|[Minimum Number](http://www.spoj.com/problems/MINNUM/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|293|[Find the Format String](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2201)|Live Archive|2008|Asia - Dhaka|2|
|<ul><li>- [ ] Done</li></ul>|294|[George and Sleep](http://codeforces.com/problemset/problem/387/A)|Codeforces||Codeforces Round #227 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|295|[SOLDIERS](http://www.spoj.com/problems/SOLDIERS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|296|[PATHS](http://www.spoj.com/problems/WAYS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|297|[Vasya and Digital Root](http://codeforces.com/problemset/problem/355/A)|Codeforces||Codeforces Round #206 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|298|[Handball](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|299|[The Alphabet Sticker](p?ID=2)|A2 Online Judge|||2|
|<ul><li>- [ ] Done</li></ul>|300|[The Child and Homework](http://codeforces.com/problemset/problem/437/A)|Codeforces||Codeforces Round #250 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|301|[Soroban](http://codeforces.com/problemset/problem/363/A)|Codeforces||Codeforces Round #211 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|302|[Line to Cashier](http://codeforces.com/problemset/problem/408/A)|Codeforces||Codeforces Round #239 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|303|[Lever](http://codeforces.com/problemset/problem/376/A)|Codeforces||Codeforces Round #221 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|304|[Eugeny and Array](http://codeforces.com/problemset/problem/302/A)|Codeforces||Codeforces Round #182 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|305|[Dima and Continuous Line](http://codeforces.com/problemset/problem/358/A)|Codeforces||Codeforces Round #208 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|306|[Bridge Hand Evaluator](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=403)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|307|[Bear and Three Balls](http://codeforces.com/problemset/problem/653/A)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|308|[Little Artem and Grasshopper](http://codeforces.com/problemset/problem/641/A)|Codeforces||VK Cup 2016 - Round 2|2|
|<ul><li>- [ ] Done</li></ul>|309|[Bear and Displayed Friends](http://codeforces.com/problemset/problem/639/A)|Codeforces||VK Cup 2016 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|310|[Print Check](http://codeforces.com/problemset/problem/631/B)|Codeforces||Codeforces Round #344 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|311|[Interview](http://codeforces.com/problemset/problem/631/A)|Codeforces||Codeforces Round #344 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|312|[Robot Sequence](http://codeforces.com/problemset/problem/626/A)|Codeforces||8VC Venture Cup 2016 - Elimination Round|2|
|<ul><li>- [ ] Done</li></ul>|313|[K-special Tables](http://codeforces.com/problemset/problem/625/C)|Codeforces||Codeforces Round #342 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|314|[The Time](http://codeforces.com/problemset/problem/622/B)|Codeforces||Educational Codeforces Round 7|2|
|<ul><li>- [ ] Done</li></ul>|315|[Infinite Sequence](http://codeforces.com/problemset/problem/622/A)|Codeforces||Educational Codeforces Round 7|2|
|<ul><li>- [ ] Done</li></ul>|316|[Grandfather Dovlet’s calculator](http://codeforces.com/problemset/problem/620/B)|Codeforces||Educational Codeforces Round 6|2|
|<ul><li>- [ ] Done</li></ul>|317|[Slime Combining](http://codeforces.com/problemset/problem/618/A)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|2|
|<ul><li>- [ ] Done</li></ul>|318|[Comparing Two Long Integers](http://codeforces.com/problemset/problem/616/A)|Codeforces||Educational Codeforces Round 5|2|
|<ul><li>- [ ] Done</li></ul>|319|[Gena's Code](http://codeforces.com/problemset/problem/614/B)|Codeforces||Codeforces Round #339 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|320|[New Year and Domino](http://codeforces.com/problemset/problem/611/C)|Codeforces||Good Bye 2015|2|
|<ul><li>- [ ] Done</li></ul>|321|[New Year and Old Property](http://codeforces.com/problemset/problem/611/B)|Codeforces||Good Bye 2015|2|
|<ul><li>- [ ] Done</li></ul>|322|[Vika and Squares](http://codeforces.com/problemset/problem/610/B)|Codeforces||Codeforces Round #337 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|323|[The Best Gift](http://codeforces.com/problemset/problem/609/B)|Codeforces||Educational Codeforces Round 3|2|
|<ul><li>- [ ] Done</li></ul>|324|[Saitama Destroys Hotel](http://codeforces.com/problemset/problem/608/A)|Codeforces||Codeforces Round #336 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|325|[Magic Spheres](http://codeforces.com/problemset/problem/606/A)|Codeforces||Codeforces Round #335 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|326|[Queries on a String](http://codeforces.com/problemset/problem/598/B)|Codeforces||Educational Codeforces Round 1|2|
|<ul><li>- [ ] Done</li></ul>|327|[Wilbur and Swimming Pool](http://codeforces.com/problemset/problem/596/A)|Codeforces||Codeforces Round #331 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|328|[PawnChess](http://codeforces.com/problemset/problem/592/A)|Codeforces||Codeforces Round #328 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|329|[Rebranding](http://codeforces.com/problemset/problem/591/B)|Codeforces||Codeforces Round #327 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|330|[Lottery](http://codeforces.com/problemset/problem/589/I)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|2|
|<ul><li>- [ ] Done</li></ul>|331|[Laurenty and Shop](http://codeforces.com/problemset/problem/586/B)|Codeforces||Codeforces Round #325 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|332|[Developing Skills](http://codeforces.com/problemset/problem/581/C)|Codeforces||Codeforces Round #322 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|333|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces||Codeforces Round #316 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|334|[Gerald is into Art](http://codeforces.com/problemset/problem/560/B)|Codeforces||Codeforces Round #313 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|335|[Amr and The Large Array](http://codeforces.com/problemset/problem/558/B)|Codeforces||Codeforces Round #312 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|336|[Pasha and Tea](http://codeforces.com/problemset/problem/557/B)|Codeforces||Codeforces Round #311 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|337|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces||Codeforces Round #310 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|338|[Case of Matryoshkas](http://codeforces.com/problemset/problem/555/A)|Codeforces||Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|339|[Mike and Fun](http://codeforces.com/problemset/problem/548/B)|Codeforces||Codeforces Round #305 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|340|[Sea and Islands](http://codeforces.com/problemset/problem/544/B)|Codeforces||Codeforces Round #302 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|341|[Set of Strings](http://codeforces.com/problemset/problem/544/A)|Codeforces||Codeforces Round #302 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|342|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|343|[Cutting Banner](http://codeforces.com/problemset/problem/538/A)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|344|[Photo to Remember](http://codeforces.com/problemset/problem/522/B)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|345|[Anya and Smartphone](http://codeforces.com/problemset/problem/518/C)|Codeforces||Codeforces Round #293 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|346|[Tanya and Postcard](http://codeforces.com/problemset/problem/518/B)|Codeforces||Codeforces Round #293 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|347|[Painting Pebbles](http://codeforces.com/problemset/problem/509/B)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|2|
|<ul><li>- [ ] Done</li></ul>|348|[Mr. Kitayuta's Gift](http://codeforces.com/problemset/problem/505/A)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|349|[New Year Book Reading](http://codeforces.com/problemset/problem/500/C)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|350|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|351|[Digital Counter](http://codeforces.com/problemset/problem/495/A)|Codeforces||Codeforces Round #282 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|352|[Vasya and Wrestling](http://codeforces.com/problemset/problem/493/B)|Codeforces||Codeforces Round #281 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|353|[Vasya and Football](http://codeforces.com/problemset/problem/493/A)|Codeforces||Codeforces Round #281 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|354|[SwapSort](http://codeforces.com/problemset/problem/489/A)|Codeforces||Codeforces Round #277.5 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|355|[Palindrome Transformation](http://codeforces.com/problemset/problem/486/C)|Codeforces||Codeforces Round #277 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|356|[Factory](http://codeforces.com/problemset/problem/485/A)|Codeforces||Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|357|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces||Codeforces Round #274 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|358|[Strongly Connected City](http://codeforces.com/problemset/problem/475/B)|Codeforces||Bayan 2015 Contest Warm Up|2|
|<ul><li>- [ ] Done</li></ul>|359|[Chat Online](http://codeforces.com/problemset/problem/469/B)|Codeforces||Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|360|[George and Job](http://codeforces.com/problemset/problem/467/C)|Codeforces||Codeforces Round #267 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|361|[Little Dima and Equation](http://codeforces.com/problemset/problem/460/B)|Codeforces||Codeforces Round #262 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|362|[Eevee](http://codeforces.com/problemset/problem/452/A)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|363|[DZY Loves Hash](http://codeforces.com/problemset/problem/447/A)|Codeforces||Codeforces Round #255 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|364|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|365|[Valera and Tubes ](http://codeforces.com/problemset/problem/441/C)|Codeforces||Codeforces Round #252 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|366|[Kitahara Haruki's Gift](http://codeforces.com/problemset/problem/433/A)|Codeforces||Codeforces Round #248 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|367|[Football Kit](http://codeforces.com/problemset/problem/432/B)|Codeforces||Codeforces Round #246 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|368|[Shower Line](http://codeforces.com/problemset/problem/431/B)|Codeforces||Codeforces Round #247 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|369|[Sereja and Mugs](http://codeforces.com/problemset/problem/426/A)|Codeforces||Codeforces Round #243 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|370|[Squats](http://codeforces.com/problemset/problem/424/A)|Codeforces||Codeforces Round #242 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|371|[Mashmokh and Lights](http://codeforces.com/problemset/problem/415/A)|Codeforces||Codeforces Round #240 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|372|[Inna and Choose Options](http://codeforces.com/problemset/problem/400/A)|Codeforces||Codeforces Round #234 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|373|[Fox and Cross](http://codeforces.com/problemset/problem/389/B)|Codeforces||Codeforces Round #228 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|374|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces||Codeforces Round #226 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|375|[Ksenia and Pan Scales](http://codeforces.com/problemset/problem/382/A)|Codeforces||Codeforces Round #224 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|376|[New Year Present](http://codeforces.com/problemset/problem/379/B)|Codeforces||Good Bye 2013|2|
|<ul><li>- [ ] Done</li></ul>|377|[Collecting Beats is Fun](http://codeforces.com/problemset/problem/373/A)|Codeforces||Codeforces Round #219 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|378|[Sereja and Coat Rack](http://codeforces.com/problemset/problem/368/A)|Codeforces||Codeforces Round #215 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|379|[The Fibonacci Segment](http://codeforces.com/problemset/problem/365/B)|Codeforces||Codeforces Round #213 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|380|[Good Number](http://codeforces.com/problemset/problem/365/A)|Codeforces||Codeforces Round #213 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|381|[Fixing Typos](http://codeforces.com/problemset/problem/363/C)|Codeforces||Codeforces Round #211 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|382|[Petya and Staircases](http://codeforces.com/problemset/problem/362/B)|Codeforces||Codeforces Round #212 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|383|[Levko and Table](http://codeforces.com/problemset/problem/361/A)|Codeforces||Codeforces Round #210 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|384|[Table](http://codeforces.com/problemset/problem/359/A)|Codeforces||Codeforces Round #209 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|385|[Group of Students](http://codeforces.com/problemset/problem/357/A)|Codeforces||Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|386|[Jeff and Periods](http://codeforces.com/problemset/problem/352/B)|Codeforces||Codeforces Round #204 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|387|[Fixed Points](http://codeforces.com/problemset/problem/347/B)|Codeforces||Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|388|[Difference Row](http://codeforces.com/problemset/problem/347/A)|Codeforces||Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|389|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|390|[Xenia and Divisors](http://codeforces.com/problemset/problem/342/A)|Codeforces||Codeforces Round #199 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|391|[Vasily the Bear and Triangle](http://codeforces.com/problemset/problem/336/A)|Codeforces||Codeforces Round #195 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|392|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces||Codeforces Round #188 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|393|[Sail](http://codeforces.com/problemset/problem/298/B)|Codeforces||Codeforces Round #180 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|394|[Greg and Array](http://codeforces.com/problemset/problem/295/A)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|395|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces||Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|396|[IQ Test](http://codeforces.com/problemset/problem/287/A)|Codeforces||Codeforces Round #176 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|397|[Find Marble](http://codeforces.com/problemset/problem/285/B)|Codeforces||Codeforces Round #175 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|398|[Beautiful Sets of Points](http://codeforces.com/problemset/problem/268/C)|Codeforces||Codeforces Round #164 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|399|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces||Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|400|[Squares](http://codeforces.com/problemset/problem/263/B)|Codeforces||Codeforces Round #161 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|401|[Adding Digits](http://codeforces.com/problemset/problem/260/A)|Codeforces||Codeforces Round #158 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|402|[Lucky Substring](http://codeforces.com/problemset/problem/122/B)|Codeforces||Codeforces Beta Round #91 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|403|[Hexadecimal's Numbers](http://codeforces.com/problemset/problem/9/C)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|404|[Little Robber Girl's Zoo](http://codeforces.com/problemset/problem/686/B)|Codeforces||Codeforces Round #359 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|405|[Vanya and Food Processor](http://codeforces.com/problemset/problem/677/B)|Codeforces||Codeforces Round #355 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|406|[Meta-Loopless Sorts](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=46)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|407|[Thor](http://codeforces.com/problemset/problem/704/A)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|408|[Arpa and a research in Mexican wave](http://codeforces.com/problemset/problem/851/A)|Codeforces||Codeforces Round #432 (Div. 2, based on IndiaHacks Final Round 2017)|2|
|<ul><li>- [ ] Done</li></ul>|409|[Okabe and Future Gadget Laboratory](http://codeforces.com/problemset/problem/821/A)|Codeforces||Codeforces Round #420 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|410|[Mister B and Book Reading](http://codeforces.com/problemset/problem/820/A)|Codeforces||Codeforces Round #421 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|411|[Straight <<A>>](http://codeforces.com/problemset/problem/810/A)|Codeforces||Codeforces Round #415 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|412|[The Festive Evening](http://codeforces.com/problemset/problem/834/B)|Codeforces||Codeforces Round #426 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|413|[Ilya and tic-tac-toe game](http://codeforces.com/problemset/problem/754/B)|Codeforces||Codeforces Round #390 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|414|[Alyona and copybooks](http://codeforces.com/problemset/problem/740/A)|Codeforces||Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|415|[Sagheer and Crossroads](http://codeforces.com/problemset/problem/812/A)|Codeforces||Codeforces Round #417 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|416|[Wrath](http://codeforces.com/problemset/problem/892/B)|Codeforces||Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|417|[Vladik and Complicated Book](http://codeforces.com/problemset/problem/811/B)|Codeforces||Codeforces Round #416 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|418|[Not Afraid](http://codeforces.com/problemset/problem/787/B)|Codeforces||Codeforces Round #406 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|419|[Mishka and trip](http://codeforces.com/problemset/problem/703/B)|Codeforces||Codeforces Round #365 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|420|[Table Tennis](http://codeforces.com/problemset/problem/879/B)|Codeforces||Codeforces Round #443 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|421|[The Child and Toy](http://codeforces.com/problemset/problem/437/C)|Codeforces||Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|422|[Code Parsing](http://codeforces.com/problemset/problem/255/B)|Codeforces||Codeforces Round #156 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|423|[Internet Address](http://codeforces.com/problemset/problem/245/B)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|3|
|<ul><li>- [ ] Done</li></ul>|424|[System Administrator](http://codeforces.com/problemset/problem/245/A)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|3|
|<ul><li>- [ ] Done</li></ul>|425|[Dividing Orange](http://codeforces.com/problemset/problem/244/A)|Codeforces||Codeforces Round #150 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|426|[Heads or Tails](http://codeforces.com/problemset/problem/242/A)|Codeforces||Codeforces Round #149 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|427|[Dice Tower](http://codeforces.com/problemset/problem/225/A)|Codeforces||Codeforces Round #139 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|428|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces||Codeforces Round #138 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|429|[Cosmic Tables](http://codeforces.com/problemset/problem/222/B)|Codeforces||Codeforces Round #137 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|430|[Little Elephant and Numbers](http://codeforces.com/problemset/problem/221/B)|Codeforces||Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|431|[Tiling with Hexagons](http://codeforces.com/problemset/problem/216/A)|Codeforces||Codeforces Round #133 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|432|[Two Problems](http://codeforces.com/problemset/problem/203/A)|Codeforces||Codeforces Round #128 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|433|[Exams](http://codeforces.com/problemset/problem/194/A)|Codeforces||Codeforces Round #122 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|434|[Funky Numbers](http://codeforces.com/problemset/problem/192/A)|Codeforces||Codeforces Round #121 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|435|[Vasya's Calendar](http://codeforces.com/problemset/problem/182/B)|Codeforces||Codeforces Round #117 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|436|[Phone Code](http://codeforces.com/problemset/problem/172/A)|Codeforces||Croc Champ 2012 - Qualification Round|3|
|<ul><li>- [ ] Done</li></ul>|437|[Phone Numbers](http://codeforces.com/problemset/problem/151/B)|Codeforces||Codeforces Round #107 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|438|[Postcards and photos](http://codeforces.com/problemset/problem/137/A)|Codeforces||Codeforces Beta Round #98 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|439|[Replacement](http://codeforces.com/problemset/problem/135/A)|Codeforces||Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|440|[Unary](http://codeforces.com/problemset/problem/133/B)|Codeforces||Codeforces Beta Round #96 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|441|[Canvas Frames](http://codeforces.com/problemset/problem/127/B)|Codeforces||Codeforces Beta Round #93 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|442|[Lucky Sum](http://codeforces.com/problemset/problem/121/A)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only) & Codeforces Beta Round #91 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|443|[Card Game](http://codeforces.com/problemset/problem/106/A)|Codeforces||Codeforces Beta Round #82 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|444|[Testing Pants for Sadness](http://codeforces.com/problemset/problem/103/A)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|445|[Powerful array](http://codeforces.com/problemset/problem/86/D)|Codeforces||Yandex.Algorithm 2011 Round 2|3|
|<ul><li>- [ ] Done</li></ul>|446|[Plug-in](http://codeforces.com/problemset/problem/81/A)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|3|
|<ul><li>- [ ] Done</li></ul>|447|[Easter Eggs](http://codeforces.com/problemset/problem/78/B)|Codeforces||Codeforces Beta Round #70 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|448|[Haiku](http://codeforces.com/problemset/problem/78/A)|Codeforces||Codeforces Beta Round #70 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|449|[Room Leader](http://codeforces.com/problemset/problem/74/A)|Codeforces||Codeforces Beta Round #68|3|
|<ul><li>- [ ] Done</li></ul>|450|[Petya and Java](http://codeforces.com/problemset/problem/66/A)|Codeforces||Codeforces Beta Round #61 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|451|[Bar](http://codeforces.com/problemset/problem/56/A)|Codeforces||Codeforces Beta Round #52 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|452|[Sleuth](http://codeforces.com/problemset/problem/49/A)|Codeforces||Codeforces Beta Round #46 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|453|[Ball Game](http://codeforces.com/problemset/problem/46/A)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|3|
|<ul><li>- [ ] Done</li></ul>|454|[Letter](http://codeforces.com/problemset/problem/43/B)|Codeforces||Codeforces Beta Round #42 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|455|[Worms Evolution](http://codeforces.com/problemset/problem/31/A)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|3|
|<ul><li>- [ ] Done</li></ul>|456|[Phone numbers](http://codeforces.com/problemset/problem/25/B)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|457|[Stripe](http://codeforces.com/problemset/problem/18/C)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|458|[Burglar and Matches](http://codeforces.com/problemset/problem/16/B)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|459|[Letter](http://codeforces.com/problemset/problem/14/A)|Codeforces||Codeforces Beta Round #14 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|460|[Numbers](http://codeforces.com/problemset/problem/13/A)|Codeforces||Codeforces Beta Round #13|3|
|<ul><li>- [ ] Done</li></ul>|461|[Correct Solution?](http://codeforces.com/problemset/problem/12/B)|Codeforces||Codeforces Beta Round #12 (Div 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|462|[Super Agent](http://codeforces.com/problemset/problem/12/A)|Codeforces||Codeforces Beta Round #12 (Div 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|463|[Increasing Sequence](http://codeforces.com/problemset/problem/11/A)|Codeforces||Codeforces Beta Round #11|3|
|<ul><li>- [ ] Done</li></ul>|464|[President's Office](http://codeforces.com/problemset/problem/6/B)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|465|[Tic-tac-toe](http://codeforces.com/problemset/problem/3/C)|Codeforces||Codeforces Beta Round #3|3|
|<ul><li>- [ ] Done</li></ul>|466|[Can you play carrom !!!](http://www.spoj.com/problems/CARRHIM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|467|[Blackjack](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1051)|Live Archive|2004|North America - Rocky Mountain|3|
|<ul><li>- [ ] Done</li></ul>|468|[Sockets](http://codeforces.com/problemset/problem/257/A)|Codeforces||Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|469|[Snow Footprints](http://codeforces.com/problemset/problem/298/A)|Codeforces||Codeforces Round #180 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|470|[Point on Spiral](http://codeforces.com/problemset/problem/279/A)|Codeforces||Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|471|[Cows and Primitive Roots](http://codeforces.com/problemset/problem/284/A)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|472|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces||Codeforces Round #143 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|473|[ZigZag](http://community.topcoder.com/stat?c=problem_statement&pm=1259)|TopCoder||TCCC '03 Semifinals 3 - Div1 easy] (4493)|3|
|<ul><li>- [ ] Done</li></ul>|474|[Seating On Bus](http://codeforces.com/problemset/problem/660/B)|Codeforces||Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|475|[Co-prime Array](http://codeforces.com/problemset/problem/660/A)|Codeforces||Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|476|[Bicycle Race](http://codeforces.com/problemset/problem/659/D)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|477|[Bear and Reverse Radewoosh](http://codeforces.com/problemset/problem/658/A)|Codeforces||VK Cup 2016 - Round 1 (Div. 2 Edition)|3|
|<ul><li>- [ ] Done</li></ul>|478|[Little Artem and Matrix](http://codeforces.com/problemset/problem/641/B)|Codeforces||VK Cup 2016 - Round 2|3|
|<ul><li>- [ ] Done</li></ul>|479|[Voting for Photos](http://codeforces.com/problemset/problem/637/A)|Codeforces||VK Cup 2016 - Qualification Round 1|3|
|<ul><li>- [ ] Done</li></ul>|480|[Tennis Tournament](http://codeforces.com/problemset/problem/628/A)|Codeforces||Educational Codeforces Round 8|3|
|<ul><li>- [ ] Done</li></ul>|481|[Guest From the Past](http://codeforces.com/problemset/problem/625/A)|Codeforces||Codeforces Round #342 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|482|[Not Equal on a Segment](http://codeforces.com/problemset/problem/622/C)|Codeforces||Educational Codeforces Round 7|3|
|<ul><li>- [ ] Done</li></ul>|483|[Constellation](http://codeforces.com/problemset/problem/618/C)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|3|
|<ul><li>- [ ] Done</li></ul>|484|[Watering Flowers](http://codeforces.com/problemset/problem/617/C)|Codeforces||Codeforces Round #340 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|485|[HDD is Outdated Technology](http://codeforces.com/problemset/problem/612/B)|Codeforces||Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|486|[The Text Splitting](http://codeforces.com/problemset/problem/612/A)|Codeforces||Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|487|[Load Balancing](http://codeforces.com/problemset/problem/609/C)|Codeforces||Educational Codeforces Round 3|3|
|<ul><li>- [ ] Done</li></ul>|488|[Spongebob and Joke](http://codeforces.com/problemset/problem/599/B)|Codeforces||Codeforces Round #332 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|489|[Cleaner Robot](http://codeforces.com/problemset/problem/589/J)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|3|
|<ul><li>- [ ] Done</li></ul>|490|[Gennady the Dentist](http://codeforces.com/problemset/problem/585/A)|Codeforces||Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|491|[Finding Team Member](http://codeforces.com/problemset/problem/579/B)|Codeforces||Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|492|[Order Book](http://codeforces.com/problemset/problem/572/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|493|[Music](http://codeforces.com/problemset/problem/569/A)|Codeforces||Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|494|[Primes or Palindromes?](http://codeforces.com/problemset/problem/568/A)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|495|[School Marks](http://codeforces.com/problemset/problem/540/B)|Codeforces||Codeforces Round #301 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|496|[Glass Carving](http://codeforces.com/problemset/problem/527/C)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|497|[Om Nom and Dark Park](http://codeforces.com/problemset/problem/526/B)|Codeforces||ZeptoLab Code Rush 2015|3|
|<ul><li>- [ ] Done</li></ul>|498|[King of Thieves](http://codeforces.com/problemset/problem/526/A)|Codeforces||ZeptoLab Code Rush 2015|3|
|<ul><li>- [ ] Done</li></ul>|499|[Guess Your Way Out!](http://codeforces.com/problemset/problem/507/C)|Codeforces||Codeforces Round #287 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|500|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces||Codeforces Round #283 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|501|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces||Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|502|[Queue](http://codeforces.com/problemset/problem/490/B)|Codeforces||Codeforces Round #279 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|503|[Long Jumps](http://codeforces.com/problemset/problem/479/D)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|504|[Bayan Bus](http://codeforces.com/problemset/problem/475/A)|Codeforces||Bayan 2015 Contest Warm Up|3|
|<ul><li>- [ ] Done</li></ul>|505|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces||Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|506|[Valera and Fruits](http://codeforces.com/problemset/problem/441/B)|Codeforces||Codeforces Round #252 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|507|[The Child and Set](http://codeforces.com/problemset/problem/437/B)|Codeforces||Codeforces Round #250 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|508|[Megacity](http://codeforces.com/problemset/problem/424/B)|Codeforces||Codeforces Round #242 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|509|[Start Up](http://codeforces.com/problemset/problem/420/A)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|510|[Football](http://codeforces.com/problemset/problem/417/C)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|511|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|512|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|513|[Guess a number!](http://codeforces.com/problemset/problem/416/A)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|514|[Password Check](http://codeforces.com/problemset/problem/411/A)|Codeforces||Coder-Strike 2014 - Qualification Round|3|
|<ul><li>- [ ] Done</li></ul>|515|[A + B Strikes Back](http://codeforces.com/problemset/problem/409/H)|Codeforces||April Fools Day Contest 2014|3|
|<ul><li>- [ ] Done</li></ul>|516|[Garland](http://codeforces.com/problemset/problem/408/B)|Codeforces||Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|517|[Long Path](http://codeforces.com/problemset/problem/407/B)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|518|[Triangle](http://codeforces.com/problemset/problem/407/A)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|519|[Unusual Product](http://codeforces.com/problemset/problem/405/C)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|520|[Sereja and Contests](http://codeforces.com/problemset/problem/401/B)|Codeforces||Codeforces Round #235 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|521|[Inna and New Matrix of Candies](http://codeforces.com/problemset/problem/400/B)|Codeforces||Codeforces Round #234 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|522|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|523|[Arithmetic Progression](http://codeforces.com/problemset/problem/382/C)|Codeforces||Codeforces Round #224 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|524|[Sereja and Stairs](http://codeforces.com/problemset/problem/381/B)|Codeforces||Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|525|[K-Periodic Array](http://codeforces.com/problemset/problem/371/A)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|526|[Valera and Contest](http://codeforces.com/problemset/problem/369/B)|Codeforces||Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|527|[Sereja and Algorithm ](http://codeforces.com/problemset/problem/367/A)|Codeforces||Codeforces Round #215 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|528|[Dima and To-do List](http://codeforces.com/problemset/problem/366/B)|Codeforces||Codeforces Round #214 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|529|[Dima and Guards](http://codeforces.com/problemset/problem/366/A)|Codeforces||Codeforces Round #214 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|530|[Flag Day](http://codeforces.com/problemset/problem/357/B)|Codeforces||Codeforces Round #207 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|531|[Vasya and Public Transport](http://codeforces.com/problemset/problem/355/B)|Codeforces||Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|532|[Bombs](http://codeforces.com/problemset/problem/350/C)|Codeforces||Codeforces Round #203 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|533|[Maximum Absurdity](http://codeforces.com/problemset/problem/332/B)|Codeforces||Codeforces Round #193 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|534|[Down the Hatch!](http://codeforces.com/problemset/problem/332/A)|Codeforces||Codeforces Round #193 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|535|[Sereja and Array](http://codeforces.com/problemset/problem/315/B)|Codeforces||Codeforces Round #187 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|536|[Ilya and Matrix](http://codeforces.com/problemset/problem/313/C)|Codeforces||Codeforces Round #186 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|537|[Whose sentence is it?](http://codeforces.com/problemset/problem/312/A)|Codeforces||Codeforces Round #185 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|538|[Lucky Permutation Triple](http://codeforces.com/problemset/problem/303/A)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|539|[Eugeny and Play List](http://codeforces.com/problemset/problem/302/B)|Codeforces||Codeforces Round #182 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|540|[Network Topology](http://codeforces.com/problemset/problem/292/B)|Codeforces||Croc Champ 2013 - Round 1|3|
|<ul><li>- [ ] Done</li></ul>|541|[Spyke Talks](http://codeforces.com/problemset/problem/291/A)|Codeforces||Croc Champ 2013 - Qualification Round|3|
|<ul><li>- [ ] Done</li></ul>|542|[Polo the Penguin and Segments ](http://codeforces.com/problemset/problem/289/A)|Codeforces||Codeforces Round #177 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|543|[Cows and Poker Game](http://codeforces.com/problemset/problem/284/B)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|544|[Cows and Sequence](http://codeforces.com/problemset/problem/283/A)|Codeforces||Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|545|[XOR and OR](http://codeforces.com/problemset/problem/282/C)|Codeforces||Codeforces Round #173 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|546|[Ladder](http://codeforces.com/problemset/problem/279/C)|Codeforces||Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|547|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces||Codeforces Round #169 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|548|[Dima and Staircase](http://codeforces.com/problemset/problem/272/C)|Codeforces||Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|549|[Multithreading](http://codeforces.com/problemset/problem/270/B)|Codeforces||Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|550|[Playing Cubes](http://codeforces.com/problemset/problem/257/B)|Codeforces||Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|551|[Little Xor](http://codeforces.com/problemset/problem/252/A)|Codeforces||Codeforces Round #153 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|552|[Easy Number Challenge](http://codeforces.com/problemset/problem/236/B)|Codeforces||Codeforces Round #146 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|553|[LLPS](http://codeforces.com/problemset/problem/202/A)|Codeforces||Codeforces Round #127 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|554|[Common Divisors](http://codeforces.com/problemset/problem/182/D)|Codeforces||Codeforces Round #117 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|555|[Ternary Logic](http://codeforces.com/problemset/problem/136/B)|Codeforces||Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|556|[Pyramid of Glasses](http://codeforces.com/problemset/problem/676/B)|Codeforces||Codeforces Round #354 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|557|[Vanya and Label](http://codeforces.com/problemset/problem/677/C)|Codeforces||Codeforces Round #355 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|558|[Petya and Exam](http://codeforces.com/problemset/problem/832/B)|Codeforces||Codeforces Round #425 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|559|[Karen and Game](http://codeforces.com/problemset/problem/815/A)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|560|[Mike and Cellphone](http://codeforces.com/problemset/problem/689/A)|Codeforces||Codeforces Round #361 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|561|[Hongcow Solves A Puzzle](http://codeforces.com/problemset/problem/745/B)|Codeforces||Codeforces Round #385 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|562|[Alyona and Spreadsheet](http://codeforces.com/problemset/problem/777/C)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|563|[Voting](http://codeforces.com/problemset/problem/749/C)|Codeforces||Codeforces Round #388 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|564|[Cloud of Hashtags](http://codeforces.com/problemset/problem/777/D)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|565|[Masha and geometric depression](http://codeforces.com/problemset/problem/789/B)|Codeforces||Codeforces Round #407 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|566|[Chilly Willy](http://codeforces.com/problemset/problem/248/B)|Codeforces||Codeforces Round #152 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|567|[Mishap in Club](http://codeforces.com/problemset/problem/245/E)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|4|
|<ul><li>- [ ] Done</li></ul>|568|[Weather](http://codeforces.com/problemset/problem/234/C)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|569|[Lefthanders and Righthanders ](http://codeforces.com/problemset/problem/234/A)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|570|[Two Tables](http://codeforces.com/problemset/problem/228/B)|Codeforces||Codeforces Round #141 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|571|[Special Offer! Super Price 999 Bourles!](http://codeforces.com/problemset/problem/219/B)|Codeforces||Codeforces Round #135 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|572|[Mountain Scenery](http://codeforces.com/problemset/problem/218/A)|Codeforces||Codeforces Round #134 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|573|[About Bacteria](http://codeforces.com/problemset/problem/198/A)|Codeforces||Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|574|[After Training](http://codeforces.com/problemset/problem/195/B)|Codeforces||Codeforces Round #123 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|575|[Good Matrix Elements](http://codeforces.com/problemset/problem/177/A2)|Codeforces||ABBYY Cup 2.0 - Easy|4|
|<ul><li>- [ ] Done</li></ul>|576|[Good Matrix Elements](http://codeforces.com/problemset/problem/177/A1)|Codeforces||ABBYY Cup 2.0 - Easy|4|
|<ul><li>- [ ] Done</li></ul>|577|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces||Codeforces Round #111 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|578|[Friends or Not](http://codeforces.com/problemset/problem/159/A)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|579|[Steps](http://codeforces.com/problemset/problem/152/B)|Codeforces||Codeforces Round #108 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|580|[Escape](http://codeforces.com/problemset/problem/148/B)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|581|[Lucky Mask](http://codeforces.com/problemset/problem/146/B)|Codeforces||Codeforces Round #104 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|582|[Meeting](http://codeforces.com/problemset/problem/144/B)|Codeforces||Codeforces Round #103 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|583|[Help Kingdom of Far Far Away 2](http://codeforces.com/problemset/problem/143/B)|Codeforces||Codeforces Round #102 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|584|[Turing Tape](http://codeforces.com/problemset/problem/132/A)|Codeforces||Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|585|[Winnie-the-Pooh and honey](http://codeforces.com/problemset/problem/120/C)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|586|[Quiz League](http://codeforces.com/problemset/problem/120/B)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|587|[Elevator](http://codeforces.com/problemset/problem/120/A)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|588|[Petya and Square](http://codeforces.com/problemset/problem/112/B)|Codeforces||Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|589|[Choosing Laptop](http://codeforces.com/problemset/problem/106/B)|Codeforces||Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|590|[African Crossword](http://codeforces.com/problemset/problem/90/B)|Codeforces||Codeforces Beta Round #74 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|591|[Chord](http://codeforces.com/problemset/problem/88/A)|Codeforces||Codeforces Beta Round #73 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|592|[Progress Bar](http://codeforces.com/problemset/problem/71/B)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|593|[Irrational problem](http://codeforces.com/problemset/problem/68/A)|Codeforces||Codeforces Beta Round #62|4|
|<ul><li>- [ ] Done</li></ul>|594|[Settlers' Training](http://codeforces.com/problemset/problem/63/B)|Codeforces||Codeforces Beta Round #59 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|595|[Where Are My Flakes?](http://codeforces.com/problemset/problem/60/A)|Codeforces||Codeforces Beta Round #56|4|
|<ul><li>- [ ] Done</li></ul>|596|[Fortune Telling](http://codeforces.com/problemset/problem/59/B)|Codeforces||Codeforces Beta Round #55 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|597|[Autocomplete](http://codeforces.com/problemset/problem/53/A)|Codeforces||Codeforces Beta Round #49 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|598|[123-sequence](http://codeforces.com/problemset/problem/52/A)|Codeforces||Codeforces Testing Round #1|4|
|<ul><li>- [ ] Done</li></ul>|599|[Coins](http://codeforces.com/problemset/problem/47/B)|Codeforces||Codeforces Beta Round #44 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|600|[Indian Summer](http://codeforces.com/problemset/problem/44/A)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|4|
|<ul><li>- [ ] Done</li></ul>|601|[Shell Game](http://codeforces.com/problemset/problem/35/A)|Codeforces||Codeforces Beta Round #35 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|602|[Page Numbers](http://codeforces.com/problemset/problem/34/C)|Codeforces||Codeforces Beta Round #34 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|603|[BerOS file system](http://codeforces.com/problemset/problem/20/A)|Codeforces||Codeforces Alpha Round #20 (Codeforces format)|4|
|<ul><li>- [ ] Done</li></ul>|604|[Young Photographer](http://codeforces.com/problemset/problem/14/B)|Codeforces||Codeforces Beta Round #14 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|605|[Power Consumption Calculation](http://codeforces.com/problemset/problem/10/A)|Codeforces||Codeforces Beta Round #10|4|
|<ul><li>- [ ] Done</li></ul>|606|[Running Student](http://codeforces.com/problemset/problem/9/B)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|607|[Center Alignment](http://codeforces.com/problemset/problem/5/B)|Codeforces||Codeforces Beta Round #5|4|
|<ul><li>- [ ] Done</li></ul>|608|[Troops of Sand Monsters](http://www.spoj.com/problems/TROOPS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|609|[Magic, Wizardry and Wonders](http://codeforces.com/problemset/problem/231/B)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|610|[Magic Box](http://codeforces.com/problemset/problem/231/D)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|611|[Gabriel and Caterpillar](http://codeforces.com/problemset/problem/652/A)|Codeforces||Educational Codeforces Round 10|4|
|<ul><li>- [ ] Done</li></ul>|612|[Amity Assessment](http://codeforces.com/problemset/problem/645/A)|Codeforces||CROC 2016 - Elimination Round|4|
|<ul><li>- [ ] Done</li></ul>|613|[Little Artem and Dance](http://codeforces.com/problemset/problem/641/C)|Codeforces||VK Cup 2016 - Round 2|4|
|<ul><li>- [ ] Done</li></ul>|614|[Promocodes with Mistakes](http://codeforces.com/problemset/problem/637/C)|Codeforces||VK Cup 2016 - Qualification Round 1|4|
|<ul><li>- [ ] Done</li></ul>|615|[Orchestra](http://codeforces.com/problemset/problem/635/A)|Codeforces||8VC Venture Cup 2016 - Final Round (Div. 2 Edition) & 8VC Venture Cup 2016 - Final Round (Div. 1 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|616|[Island Puzzle](http://codeforces.com/problemset/problem/634/A)|Codeforces||8VC Venture Cup 2016 - Final Round (Div. 1 Edition) & 8VC Venture Cup 2016 - Final Round (Div. 2 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|617|[Cracking the Code](http://codeforces.com/problemset/problem/630/L)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|4|
|<ul><li>- [ ] Done</li></ul>|618|[Testing Robots](http://codeforces.com/problemset/problem/606/B)|Codeforces||Codeforces Round #335 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|619|[Extract Numbers](http://codeforces.com/problemset/problem/600/A)|Codeforces||Educational Codeforces Round 2|4|
|<ul><li>- [ ] Done</li></ul>|620|[Email Aliases](http://codeforces.com/problemset/problem/589/A)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|4|
|<ul><li>- [ ] Done</li></ul>|621|[Three Logos](http://codeforces.com/problemset/problem/581/D)|Codeforces||Codeforces Round #322 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|622|[ZgukistringZ](http://codeforces.com/problemset/problem/551/B)|Codeforces||Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|623|[Regular Bridge](http://codeforces.com/problemset/problem/550/D)|Codeforces||Codeforces Round #306 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|624|[Weird Chess](http://codeforces.com/problemset/problem/538/D)|Codeforces||Codeforces Round #300|4|
|<ul><li>- [ ] Done</li></ul>|625|[Clique Problem](http://codeforces.com/problemset/problem/527/D)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|626|[Rotate, Flip and Zoom](http://codeforces.com/problemset/problem/523/A)|Codeforces||VK Cup 2015 - Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|627|[Vanya and Computer Game](http://codeforces.com/problemset/problem/492/D)|Codeforces||Codeforces Round #280 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|628|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|629|[Predict Outcome of the Game](http://codeforces.com/problemset/problem/451/C)|Codeforces||Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|630|[Forgotten Episode](http://codeforces.com/problemset/problem/440/A)|Codeforces||Testing Round #10|4|
|<ul><li>- [ ] Done</li></ul>|631|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces||Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|632|[Om Nom and Spiders](http://codeforces.com/problemset/problem/436/B)|Codeforces||Zepto Code Rush 2014|4|
|<ul><li>- [ ] Done</li></ul>|633|[Cardiogram](http://codeforces.com/problemset/problem/435/C)|Codeforces||Codeforces Round #249 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|634|[Sereja and Mirroring](http://codeforces.com/problemset/problem/426/B)|Codeforces||Codeforces Round #243 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|635|[Pasha and Hamsters](http://codeforces.com/problemset/problem/421/A)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|636|[Pattern](http://codeforces.com/problemset/problem/412/C)|Codeforces||Coder-Strike 2014 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|637|[Poster](http://codeforces.com/problemset/problem/412/A)|Codeforces||Coder-Strike 2014 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|638|[Toy Sum](http://codeforces.com/problemset/problem/405/D)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|639|[Marathon](http://codeforces.com/problemset/problem/404/B)|Codeforces||Codeforces Round #237 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|640|[Inna and Huge Candy Matrix](http://codeforces.com/problemset/problem/400/C)|Codeforces||Codeforces Round #234 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|641|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces||Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|642|[Semifinals](http://codeforces.com/problemset/problem/378/B)|Codeforces||Codeforces Round #222 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|643|[I.O.U.](http://codeforces.com/problemset/problem/376/B)|Codeforces||Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|644|[Maximum Submatrix 2](http://codeforces.com/problemset/problem/375/B)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|645|[Vessels](http://codeforces.com/problemset/problem/371/D)|Codeforces||Codeforces Round #218 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|646|[Matrix](http://codeforces.com/problemset/problem/364/A)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|647|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces||Codeforces Round #205 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|648|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|649|[Xenia and Spies](http://codeforces.com/problemset/problem/342/B)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|650|[Tourist Problem](http://codeforces.com/problemset/problem/340/C)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|651|[Ciel and Robot](http://codeforces.com/problemset/problem/321/A)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|652|[Psychos in a Line](http://codeforces.com/problemset/problem/319/B)|Codeforces||Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|653|[The Closest Pair](http://codeforces.com/problemset/problem/311/A)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|654|[Command Line Arguments](http://codeforces.com/problemset/problem/291/B)|Codeforces||Croc Champ 2013 - Qualification Round|4|
|<ul><li>- [ ] Done</li></ul>|655|[Mysterious strings](http://codeforces.com/problemset/problem/290/A)|Codeforces||April Fools Day Contest 2013|4|
|<ul><li>- [ ] Done</li></ul>|656|[Dima and Sequence](http://codeforces.com/problemset/problem/272/B)|Codeforces||Codeforces Round #167 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|657|[Secret](http://codeforces.com/problemset/problem/271/C)|Codeforces||Codeforces Round #166 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|658|[Ancient Prophesy](http://codeforces.com/problemset/problem/260/B)|Codeforces||Codeforces Round #158 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|659|[Forming Teams](http://codeforces.com/problemset/problem/216/B)|Codeforces||Codeforces Round #133 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|660|[Walking in the Rain](http://codeforces.com/problemset/problem/192/B)|Codeforces||Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|661|[Anagram Search](http://codeforces.com/problemset/problem/144/C)|Codeforces||Codeforces Round #103 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|662|[Fruits](http://codeforces.com/problemset/problem/12/C)|Codeforces||Codeforces Beta Round #12 (Div 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|663|[Reberland Linguistics](http://codeforces.com/problemset/problem/666/A)|Codeforces||Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|664|[Tennis Game](http://codeforces.com/problemset/problem/496/D)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|665|[Riding in a Lift](http://codeforces.com/problemset/problem/479/E)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|666|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|667|[Vladik and Memorable Trip](http://codeforces.com/problemset/problem/811/C)|Codeforces||Codeforces Round #416 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|668|[Game of the Rows](http://codeforces.com/problemset/problem/839/B)|Codeforces||Codeforces Round #428 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|669|[Array Division](http://codeforces.com/problemset/problem/808/D)|Codeforces||Educational Codeforces Round 21|4|
|<ul><li>- [ ] Done</li></ul>|670|[Road Map](http://codeforces.com/problemset/problem/34/D)|Codeforces||Codeforces Beta Round #34 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|671|[Jury Size](http://codeforces.com/problemset/problem/254/B)|Codeforces||Codeforces Round #155 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|672|[Young Table](http://codeforces.com/problemset/problem/237/B)|Codeforces||Codeforces Round #147 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|673|[Game on Paper](http://codeforces.com/problemset/problem/203/B)|Codeforces||Codeforces Round #128 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|674|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|675|[Series of Crimes](http://codeforces.com/problemset/problem/181/A)|Codeforces||Croc Champ 2012 - Round 2 (Unofficial Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|676|[Robot Bicorn Attack](http://codeforces.com/problemset/problem/175/A)|Codeforces||Codeforces Round #115|5|
|<ul><li>- [ ] Done</li></ul>|677|[Pseudorandom Sequence Period](http://codeforces.com/problemset/problem/172/B)|Codeforces||Croc Champ 2012 - Qualification Round|5|
|<ul><li>- [ ] Done</li></ul>|678|[Wizards and Trolleybuses](http://codeforces.com/problemset/problem/167/A)|Codeforces||Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|679|[Suspects](http://codeforces.com/problemset/problem/156/B)|Codeforces||Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|680|[Martian Clock](http://codeforces.com/problemset/problem/149/B)|Codeforces||Codeforces Round #106 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|681|[Punctuation](http://codeforces.com/problemset/problem/147/A)|Codeforces||Codeforces Testing Round #4|5|
|<ul><li>- [ ] Done</li></ul>|682|[Help General](http://codeforces.com/problemset/problem/142/B)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|683|[Literature Lesson](http://codeforces.com/problemset/problem/138/A)|Codeforces||Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|684|[Average Numbers](http://codeforces.com/problemset/problem/134/A)|Codeforces||Codeforces Testing Round #3|5|
|<ul><li>- [ ] Done</li></ul>|685|[Permutations](http://codeforces.com/problemset/problem/124/B)|Codeforces||Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|686|[Prime Permutation](http://codeforces.com/problemset/problem/123/A)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|687|[Elevator](http://codeforces.com/problemset/problem/117/A)|Codeforces||Codeforces Beta Round #88|5|
|<ul><li>- [ ] Done</li></ul>|688|[Grammar Lessons](http://codeforces.com/problemset/problem/113/A)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|689|[Help Chef Gerasim](http://codeforces.com/problemset/problem/99/B)|Codeforces||Codeforces Beta Round #78 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|690|[Friends](http://codeforces.com/problemset/problem/94/B)|Codeforces||Codeforces Beta Round #76 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|691|[Frames](http://codeforces.com/problemset/problem/93/A)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|692|[Sets](http://codeforces.com/problemset/problem/82/B)|Codeforces||Yandex.Algorithm 2011 Qualification 2|5|
|<ul><li>- [ ] Done</li></ul>|693|[Sequence Formatting](http://codeforces.com/problemset/problem/81/B)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|5|
|<ul><li>- [ ] Done</li></ul>|694|[Facetook Priority Wall](http://codeforces.com/problemset/problem/75/B)|Codeforces||Codeforces Beta Round #67 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|695|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces||Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|696|[Bets](http://codeforces.com/problemset/problem/69/B)|Codeforces||Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|697|[Square Earth?](http://codeforces.com/problemset/problem/57/A)|Codeforces||Codeforces Beta Round #53|5|
|<ul><li>- [ ] Done</li></ul>|698|[Spoilt Permutation](http://codeforces.com/problemset/problem/56/B)|Codeforces||Codeforces Beta Round #52 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|699|[Flea travel](http://codeforces.com/problemset/problem/55/A)|Codeforces||Codeforces Beta Round #51|5|
|<ul><li>- [ ] Done</li></ul>|700|[Rock-paper-scissors](http://codeforces.com/problemset/problem/48/A)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|701|[T-shirts from Sponsor](http://codeforces.com/problemset/problem/46/B)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|702|[Codecraft III](http://codeforces.com/problemset/problem/45/A)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|5|
|<ul><li>- [ ] Done</li></ul>|703|[Guilty --- to the kitchen!](http://codeforces.com/problemset/problem/42/A)|Codeforces||Codeforces Beta Round #41|5|
|<ul><li>- [ ] Done</li></ul>|704|[Email address](http://codeforces.com/problemset/problem/41/C)|Codeforces||Codeforces Beta Round #40 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|705|[Find Color](http://codeforces.com/problemset/problem/40/A)|Codeforces||Codeforces Beta Round #39|5|
|<ul><li>- [ ] Done</li></ul>|706|[Chess](http://codeforces.com/problemset/problem/38/B)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|707|[Extra-terrestrial Intelligence](http://codeforces.com/problemset/problem/36/A)|Codeforces||Codeforces Beta Round #36|5|
|<ul><li>- [ ] Done</li></ul>|708|[What is for dinner?](http://codeforces.com/problemset/problem/33/A)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|709|[Mail Stamps](http://codeforces.com/problemset/problem/29/C)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|710|[World Football Cup](http://codeforces.com/problemset/problem/19/A)|Codeforces||Codeforces Beta Round #19|5|
|<ul><li>- [ ] Done</li></ul>|711|[Cottage Village](http://codeforces.com/problemset/problem/15/A)|Codeforces||Codeforces Beta Round #15|5|
|<ul><li>- [ ] Done</li></ul>|712|[Obsession with Robots](http://codeforces.com/problemset/problem/8/B)|Codeforces||Codeforces Beta Round #8|5|
|<ul><li>- [ ] Done</li></ul>|713|[Memory Manager](http://codeforces.com/problemset/problem/7/B)|Codeforces||Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|714|[Bombing](http://www.spoj.com/problems/BOMB2/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|715|[Domino](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1677)|Live Archive|2006|Asia - Hanoi|5|
|<ul><li>- [ ] Done</li></ul>|716|[On the Road to LCPC](p?ID=79)|A2 Online Judge|||5|
|<ul><li>- [ ] Done</li></ul>|717|[Buses Between Cities](http://codeforces.com/problemset/problem/665/A)|Codeforces||Educational Codeforces Round 12|5|
|<ul><li>- [ ] Done</li></ul>|718|[Scrambled](http://codeforces.com/problemset/problem/656/B)|Codeforces||April Fools Day Contest 2016|5|
|<ul><li>- [ ] Done</li></ul>|719|[Fibonacci-ish](http://codeforces.com/problemset/problem/633/D)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|720|[Spy Syndrome 2](http://codeforces.com/problemset/problem/633/C)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|721|[Boulevard](http://codeforces.com/problemset/problem/589/D)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|5|
|<ul><li>- [ ] Done</li></ul>|722|[Lengthening Sticks](http://codeforces.com/problemset/problem/571/A)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|723|[Kyoya and Permutation](http://codeforces.com/problemset/problem/553/B)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|724|[Haar Features](http://codeforces.com/problemset/problem/549/D)|Codeforces||Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|725|[Mike and Frog](http://codeforces.com/problemset/problem/547/A)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|726|[Board Game](http://codeforces.com/problemset/problem/533/C)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|727|[Statistics of Recompressing Videos](http://codeforces.com/problemset/problem/523/D)|Codeforces||VK Cup 2015 - Qualification Round 2|5|
|<ul><li>- [ ] Done</li></ul>|728|[Sums of Digits](http://codeforces.com/problemset/problem/509/C)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|729|[Borya and Hanabi](http://codeforces.com/problemset/problem/442/A)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|730|[Balancer](http://codeforces.com/problemset/problem/440/B)|Codeforces||Testing Round #10|5|
|<ul><li>- [ ] Done</li></ul>|731|[Ryouko's Memory Note](http://codeforces.com/problemset/problem/433/C)|Codeforces||Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|732|[Elimination](http://codeforces.com/problemset/problem/417/A)|Codeforces||RCC 2014 Warmup (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|733|[Data Recovery](http://codeforces.com/problemset/problem/413/A)|Codeforces||Coder-Strike 2014 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|734|[Pages](http://codeforces.com/problemset/problem/399/A)|Codeforces||Codeforces Round #233 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|735|[Counting Sticks](http://codeforces.com/problemset/problem/394/A)|Codeforces||Codeforces Round #231 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|736|[Inna and Alarm Clock](http://codeforces.com/problemset/problem/390/A)|Codeforces||Codeforces Round #229 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|737|[Fox and Minimal path](http://codeforces.com/problemset/problem/388/B)|Codeforces||Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|738|[George and Number](http://codeforces.com/problemset/problem/387/C)|Codeforces||Codeforces Round #227 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|739|[Second-Price Auction](http://codeforces.com/problemset/problem/386/A)|Codeforces||Testing Round #9|5|
|<ul><li>- [ ] Done</li></ul>|740|[Inna and Dima](http://codeforces.com/problemset/problem/374/C)|Codeforces||Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|741|[Inna and Pink Pony](http://codeforces.com/problemset/problem/374/A)|Codeforces||Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|742|[Making Sequences is Fun](http://codeforces.com/problemset/problem/373/B)|Codeforces||Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|743|[Berland Bingo](http://codeforces.com/problemset/problem/370/B)|Codeforces||Codeforces Round #217 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|744|[Levko and Array Recovery](http://codeforces.com/problemset/problem/360/A)|Codeforces||Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|745|[Xenia and Hamming](http://codeforces.com/problemset/problem/356/B)|Codeforces||Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|746|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces||Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|747|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces||Codeforces Round #195 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|748|[Square and Rectangles](http://codeforces.com/problemset/problem/325/A)|Codeforces||MemSQL start[c]up Round 1|5|
|<ul><li>- [ ] Done</li></ul>|749|[Sereja and Contest](http://codeforces.com/problemset/problem/314/A)|Codeforces||Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|750|[Calendar](http://codeforces.com/problemset/problem/304/B)|Codeforces||Codeforces Round #183 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|751|[Ksusha the Squirrel](http://codeforces.com/problemset/problem/299/B)|Codeforces||Croc Champ 2013 - Round 2 (Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|752|[SMSC](http://codeforces.com/problemset/problem/292/A)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|753|[Network Mask](http://codeforces.com/problemset/problem/291/C)|Codeforces||Croc Champ 2013 - Qualification Round|5|
|<ul><li>- [ ] Done</li></ul>|754|[Orange](http://codeforces.com/problemset/problem/290/D)|Codeforces||April Fools Day Contest 2013|5|
|<ul><li>- [ ] Done</li></ul>|755|[QR code](http://codeforces.com/problemset/problem/290/B)|Codeforces||April Fools Day Contest 2013|5|
|<ul><li>- [ ] Done</li></ul>|756|[Polo the Penguin and XOR operation](http://codeforces.com/problemset/problem/288/C)|Codeforces||Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|757|[Nearest Fraction](http://codeforces.com/problemset/problem/281/B)|Codeforces||Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|758|[Maximum Xor Secondary](http://codeforces.com/problemset/problem/280/B)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|759|[Convex Shape](http://codeforces.com/problemset/problem/275/B)|Codeforces||Codeforces Round #168 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|760|[Balls and Boxes](http://codeforces.com/problemset/problem/260/C)|Codeforces||Codeforces Round #158 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|761|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces||Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|762|[Rock-Paper-Scissors](http://codeforces.com/problemset/problem/173/A)|Codeforces||Croc Champ 2012 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|763|[Domino](http://codeforces.com/problemset/problem/85/A)|Codeforces||Yandex.Algorithm 2011 Round 1|5|
|<ul><li>- [ ] Done</li></ul>|764|[Colorful Field](http://codeforces.com/problemset/problem/79/B)|Codeforces||Codeforces Beta Round #71|5|
|<ul><li>- [ ] Done</li></ul>|765|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|766|[Theseus and labyrinth](http://codeforces.com/problemset/problem/676/D)|Codeforces||Codeforces Round #354 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|767|[Cards Sorting](http://codeforces.com/problemset/problem/830/B)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|5|
|<ul><li>- [ ] Done</li></ul>|768|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|769|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces||Codeforces Round #368 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|770|[Mr. Bender and Square](http://codeforces.com/problemset/problem/255/D)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|771|[Playing with Permutations](http://codeforces.com/problemset/problem/251/B)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|772|[Restoring IPv6](http://codeforces.com/problemset/problem/250/B)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|773|[Easy Tape Programming](http://codeforces.com/problemset/problem/239/B)|Codeforces||Codeforces Round #148 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|774|[Practice](http://codeforces.com/problemset/problem/234/G)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|775|[Cinema](http://codeforces.com/problemset/problem/234/D)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|776|[Reducing Fractions](http://codeforces.com/problemset/problem/222/C)|Codeforces||Codeforces Round #137 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|777|[Hit Ball](http://codeforces.com/problemset/problem/203/D)|Codeforces||Codeforces Round #128 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|778|[Mathematical Analysis Rocks!](http://codeforces.com/problemset/problem/180/F)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|779|[Plane of Tanks: Pro](http://codeforces.com/problemset/problem/175/B)|Codeforces||Codeforces Round #115|6|
|<ul><li>- [ ] Done</li></ul>|780|[File List](http://codeforces.com/problemset/problem/174/B)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|781|[Bus](http://codeforces.com/problemset/problem/172/C)|Codeforces||Croc Champ 2012 - Qualification Round|6|
|<ul><li>- [ ] Done</li></ul>|782|[Wizards and Minimal Spell](http://codeforces.com/problemset/problem/168/B)|Codeforces||Codeforces Round #114 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|783|[New Year Cards](http://codeforces.com/problemset/problem/140/B)|Codeforces||Codeforces Round #100|6|
|<ul><li>- [ ] Done</li></ul>|784|[Wallpaper](http://codeforces.com/problemset/problem/139/B)|Codeforces||Codeforces Beta Round #99 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|785|[Simple XML](http://codeforces.com/problemset/problem/125/B)|Codeforces||Codeforces Testing Round #2|6|
|<ul><li>- [ ] Done</li></ul>|786|[Transmigration](http://codeforces.com/problemset/problem/105/A)|Codeforces||Codeforces Beta Round #81|6|
|<ul><li>- [ ] Done</li></ul>|787|[Hockey](http://codeforces.com/problemset/problem/95/A)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|788|[Keyboard](http://codeforces.com/problemset/problem/88/B)|Codeforces||Codeforces Beta Round #73 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|789|[Heroes](http://codeforces.com/problemset/problem/77/A)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|790|[Points](http://codeforces.com/problemset/problem/76/E)|Codeforces||All-Ukrainian School Olympiad in Informatics|6|
|<ul><li>- [ ] Done</li></ul>|791|[Partial Teacher](http://codeforces.com/problemset/problem/67/A)|Codeforces||Manthan 2011|6|
|<ul><li>- [ ] Done</li></ul>|792|[Harry Potter and the History of Magic](http://codeforces.com/problemset/problem/65/B)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|793|[Harry Potter and Three Spells](http://codeforces.com/problemset/problem/65/A)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|794|[Bulls and Cows](http://codeforces.com/problemset/problem/63/C)|Codeforces||Codeforces Beta Round #59 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|795|[Tyndex.Brome](http://codeforces.com/problemset/problem/62/B)|Codeforces||Codeforces Beta Round #58|6|
|<ul><li>- [ ] Done</li></ul>|796|[Presents](http://codeforces.com/problemset/problem/54/A)|Codeforces||Codeforces Beta Round #50|6|
|<ul><li>- [ ] Done</li></ul>|797|[Cheaterius's Problem](http://codeforces.com/problemset/problem/51/A)|Codeforces||Codeforces Beta Round #48|6|
|<ul><li>- [ ] Done</li></ul>|798|[Land Lot](http://codeforces.com/problemset/problem/48/B)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|799|[Holidays](http://codeforces.com/problemset/problem/44/C)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|800|[Cola](http://codeforces.com/problemset/problem/44/B)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|801|[Spelling Check](http://codeforces.com/problemset/problem/39/J)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|802|[Multiplication Table](http://codeforces.com/problemset/problem/39/H)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|803|[Schedule](http://codeforces.com/problemset/problem/31/C)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|804|[Traffic Lights](http://codeforces.com/problemset/problem/29/B)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|805|[F1 Champions](http://codeforces.com/problemset/problem/24/B)|Codeforces||Codeforces Beta Round #24|6|
|<ul><li>- [ ] Done</li></ul>|806|[Cinema Cashier](http://codeforces.com/problemset/problem/10/B)|Codeforces||Codeforces Beta Round #10|6|
|<ul><li>- [ ] Done</li></ul>|807|[PLAHTE](http://www.spoj.com/problems/PLAHTE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|808|[FLING1](http://www.spoj.com/problems/FLING1/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|809|[CUBE ROOT](http://www.spoj.com/problems/CUBEROO2/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|810|[International Olympiad](http://codeforces.com/problemset/problem/662/D)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|811|[Bear and Up-Down](http://codeforces.com/problemset/problem/653/C)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|812|[Bear and Polynomials](http://codeforces.com/problemset/problem/639/C)|Codeforces||VK Cup 2016 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|813|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces||Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|814|[Brackets in Implications](http://codeforces.com/problemset/problem/550/E)|Codeforces||Codeforces Round #306 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|815|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces||Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|816|[????????, ?? ?????? ???? ??????](http://codeforces.com/problemset/problem/524/A)|Codeforces||VK Cup 2015 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|817|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|818|[The Maths Lecture](http://codeforces.com/problemset/problem/507/D)|Codeforces||Codeforces Round #287 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|819|[Up the hill](http://codeforces.com/problemset/problem/491/A)|Codeforces||Testing Round #11|6|
|<ul><li>- [ ] Done</li></ul>|820|[Restoring Increasing Sequence](http://codeforces.com/problemset/problem/490/E)|Codeforces||Codeforces Round #279 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|821|[Appleman and a Sheet of Paper](http://codeforces.com/problemset/problem/461/C)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|822|[Washer, Dryer, Folder](http://codeforces.com/problemset/problem/452/D)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|823|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces||Codeforces Round #256 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|824|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces||Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|825|[Crash](http://codeforces.com/problemset/problem/417/B)|Codeforces||RCC 2014 Warmup (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|826|[Spyke Chatting](http://codeforces.com/problemset/problem/413/B)|Codeforces||Coder-Strike 2014 - Round 2|6|
|<ul><li>- [ ] Done</li></ul>|827|[Multi-core Processor](http://codeforces.com/problemset/problem/411/B)|Codeforces||Coder-Strike 2014 - Qualification Round|6|
|<ul><li>- [ ] Done</li></ul>|828|[Minesweeper 1D](http://codeforces.com/problemset/problem/404/D)|Codeforces||Codeforces Round #237 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|829|[Fly, freebies, fly!](http://codeforces.com/problemset/problem/386/B)|Codeforces||Testing Round #9|6|
|<ul><li>- [ ] Done</li></ul>|830|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces||Codeforces Round #212 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|831|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces||Codeforces Round #208 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|832|[Compartments](http://codeforces.com/problemset/problem/356/C)|Codeforces||Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|833|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces||Codeforces Round #194 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|834|[Oh Sweet Beaverette](http://codeforces.com/problemset/problem/331/A1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|6|
|<ul><li>- [ ] Done</li></ul>|835|[Ants](http://codeforces.com/problemset/problem/317/B)|Codeforces||Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|836|[Candies](http://codeforces.com/problemset/problem/306/A)|Codeforces||Testing Round #6|6|
|<ul><li>- [ ] Done</li></ul>|837|[Rectangle Puzzle II](http://codeforces.com/problemset/problem/303/B)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|838|[WTF?](http://codeforces.com/problemset/problem/290/C)|Codeforces||April Fools Day Contest 2013|6|
|<ul><li>- [ ] Done</li></ul>|839|[Main Sequence](http://codeforces.com/problemset/problem/286/C)|Codeforces||Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|840|[Permutation Sum](http://codeforces.com/problemset/problem/285/D)|Codeforces||Codeforces Round #175 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|841|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|842|[Sum of Medians](http://codeforces.com/problemset/problem/85/D)|Codeforces||Yandex.Algorithm 2011 Round 1|6|
|<ul><li>- [ ] Done</li></ul>|843|[Polygon](p?ID=258)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|844|[Mister B and PR Shifts](http://codeforces.com/problemset/problem/819/B)|Codeforces||Codeforces Round #421 (Div. 1) & Codeforces Round #421 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|845|[Rooter's Song](http://codeforces.com/problemset/problem/848/B)|Codeforces||Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|846|[Chris and Road](http://codeforces.com/problemset/problem/703/C)|Codeforces||Codeforces Round #365 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|847|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces||Codeforces Round #361 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|848|[Furlo and Rublo and Game](http://codeforces.com/problemset/problem/255/E)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|849|[Log Stream Analysis](http://codeforces.com/problemset/problem/245/F)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|7|
|<ul><li>- [ ] Done</li></ul>|850|[Champions' League](http://codeforces.com/problemset/problem/234/E)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|851|[Snake](http://codeforces.com/problemset/problem/225/D)|Codeforces||Codeforces Round #139 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|852|[Programming Language](http://codeforces.com/problemset/problem/200/D)|Codeforces||Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|853|[Football Championship](http://codeforces.com/problemset/problem/200/C)|Codeforces||Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|854|[Try and Catch](http://codeforces.com/problemset/problem/195/C)|Codeforces||Codeforces Round #123 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|855|[Geometry Horse](http://codeforces.com/problemset/problem/175/C)|Codeforces||Codeforces Round #115|7|
|<ul><li>- [ ] Done</li></ul>|856|[Pentagonal numbers](http://codeforces.com/problemset/problem/162/A)|Codeforces||VK Cup 2012 Wild-card Round 1|7|
|<ul><li>- [ ] Done</li></ul>|857|[Last Chance](http://codeforces.com/problemset/problem/137/E)|Codeforces||Codeforces Beta Round #98 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|858|[Hexagonal numbers](http://codeforces.com/problemset/problem/130/A)|Codeforces||Unknown Language Round #4|7|
|<ul><li>- [ ] Done</li></ul>|859|[Boom](http://codeforces.com/problemset/problem/120/G)|Codeforces||School Regional Team Contest, Saratov, 2011|7|
|<ul><li>- [ ] Done</li></ul>|860|[Before Exam](http://codeforces.com/problemset/problem/119/B)|Codeforces||Codeforces Beta Round #90|7|
|<ul><li>- [ ] Done</li></ul>|861|[Treasure Island](http://codeforces.com/problemset/problem/106/D)|Codeforces||Codeforces Beta Round #82 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|862|[Help Victoria the Wise](http://codeforces.com/problemset/problem/98/A)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|863|[Vasya and Types](http://codeforces.com/problemset/problem/87/B)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|864|[Biathlon](http://codeforces.com/problemset/problem/84/C)|Codeforces||Codeforces Beta Round #72 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|865|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|866|[Petya and File System](http://codeforces.com/problemset/problem/66/C)|Codeforces||Codeforces Beta Round #61 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|867|[Martian Architecture](http://codeforces.com/problemset/problem/57/B)|Codeforces||Codeforces Beta Round #53|7|
|<ul><li>- [ ] Done</li></ul>|868|[Corporation Mail](http://codeforces.com/problemset/problem/56/C)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|869|[Blog Photo](http://codeforces.com/problemset/problem/53/B)|Codeforces||Codeforces Beta Round #49 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|870|[Game](http://codeforces.com/problemset/problem/49/D)|Codeforces||Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|871|[Parking Lot](http://codeforces.com/problemset/problem/46/D)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|872|[Journey](http://codeforces.com/problemset/problem/43/D)|Codeforces||Codeforces Beta Round #42 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|873|[Game of chess unfinished](http://codeforces.com/problemset/problem/42/B)|Codeforces||Codeforces Beta Round #41|7|
|<ul><li>- [ ] Done</li></ul>|874|[Pacifist frogs](http://codeforces.com/problemset/problem/39/F)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|875|[Computer Game](http://codeforces.com/problemset/problem/37/B)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|876|[Fractal](http://codeforces.com/problemset/problem/36/B)|Codeforces||Codeforces Beta Round #36|7|
|<ul><li>- [ ] Done</li></ul>|877|[Warehouse](http://codeforces.com/problemset/problem/35/B)|Codeforces||Codeforces Beta Round #35 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|878|[Constellation](http://codeforces.com/problemset/problem/32/D)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|879|[Chocolate](http://codeforces.com/problemset/problem/31/D)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|880|[Codeforces World Finals](http://codeforces.com/problemset/problem/30/B)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|881|[Bender Problem](http://codeforces.com/problemset/problem/28/A)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|882|[Sequence of points](http://codeforces.com/problemset/problem/24/C)|Codeforces||Codeforces Beta Round #24|7|
|<ul><li>- [ ] Done</li></ul>|883|[Intersection](http://codeforces.com/problemset/problem/21/B)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|884|[Jabber ID](http://codeforces.com/problemset/problem/21/A)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|885|[Logging](http://codeforces.com/problemset/problem/16/D)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|886|[Follow Traffic Rules](http://codeforces.com/problemset/problem/5/D)|Codeforces||Codeforces Beta Round #5|7|
|<ul><li>- [ ] Done</li></ul>|887|[ucyhf](http://codeforces.com/problemset/problem/171/F)|Codeforces||April Fools Day Contest|7|
|<ul><li>- [ ] Done</li></ul>|888|[THE N WITTY FRIENDS](http://www.spoj.com/problems/WITTY/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|889|[Little Artem and Random Variable](http://codeforces.com/problemset/problem/641/D)|Codeforces||VK Cup 2016 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|890|[Sum of Remainders](http://codeforces.com/problemset/problem/616/E)|Codeforces||Educational Codeforces Round 5|7|
|<ul><li>- [ ] Done</li></ul>|891|[Hexagons](http://codeforces.com/problemset/problem/615/E)|Codeforces||Codeforces Round #338 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|892|[Guess Your Way Out! II](http://codeforces.com/problemset/problem/558/D)|Codeforces||Codeforces Round #312 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|893|[Case of a Top Secret](http://codeforces.com/problemset/problem/555/D)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|894|[Transmitting Levels](http://codeforces.com/problemset/problem/526/E)|Codeforces||ZeptoLab Code Rush 2015|7|
|<ul><li>- [ ] Done</li></ul>|895|[Mean Requests](http://codeforces.com/problemset/problem/523/B)|Codeforces||VK Cup 2015 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|896|[Arthur and Questions](http://codeforces.com/problemset/problem/518/E)|Codeforces||Codeforces Round #293 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|897|[Valera and Swaps](http://codeforces.com/problemset/problem/441/D)|Codeforces||Codeforces Round #252 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|898|[Nanami's Digital Board](http://codeforces.com/problemset/problem/433/D)|Codeforces||Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|899|[Bug in Code](http://codeforces.com/problemset/problem/420/C)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|900|[Online Meeting](http://codeforces.com/problemset/problem/420/B)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|901|[Population Size](http://codeforces.com/problemset/problem/416/D)|Codeforces||Codeforces Round #241 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|902|[E-mail Addresses](http://codeforces.com/problemset/problem/412/E)|Codeforces||Coder-Strike 2014 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|903|[Kicker](http://codeforces.com/problemset/problem/411/C)|Codeforces||Coder-Strike 2014 - Qualification Round|7|
|<ul><li>- [ ] Done</li></ul>|904|[Curious Array](http://codeforces.com/problemset/problem/407/C)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|905|[Cards](http://codeforces.com/problemset/problem/398/A)|Codeforces||Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|906|[On Corruption and Numbers](http://codeforces.com/problemset/problem/397/B)|Codeforces||Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|907|[Genetic Engineering](http://codeforces.com/problemset/problem/391/A)|Codeforces||Rockethon 2014|7|
|<ul><li>- [ ] Done</li></ul>|908|[Inna, Dima and Song](http://codeforces.com/problemset/problem/390/B)|Codeforces||Codeforces Round #229 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|909|[Ksenia and Pawns](http://codeforces.com/problemset/problem/382/D)|Codeforces||Codeforces Round #224 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|910|[Shave Beaver!](http://codeforces.com/problemset/problem/331/B1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|7|
|<ul><li>- [ ] Done</li></ul>|911|[IQ Test](http://codeforces.com/problemset/problem/328/A)|Codeforces||Testing Round #8|7|
|<ul><li>- [ ] Done</li></ul>|912|[Shifting](http://codeforces.com/problemset/problem/286/B)|Codeforces||Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|913|[Circle of Numbers](http://codeforces.com/problemset/problem/263/C)|Codeforces||Codeforces Round #161 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|914|[Bear and Square Grid](http://codeforces.com/problemset/problem/679/C)|Codeforces||Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|915|[Crunching Numbers Just for You](http://codeforces.com/problemset/problem/784/F)|Codeforces||April Fools Contest 2017|7|
|<ul><li>- [ ] Done</li></ul>|916|[HTML](http://acm.timus.ru/problem.aspx?space=1&num=1345)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|917|[Blog](http://acm.timus.ru/problem.aspx?space=1&num=1347)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|918|[Teams Formation](http://codeforces.com/problemset/problem/878/B)|Codeforces||Codeforces Round #443 (Div. 1) & Codeforces Round #443 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|919|[Vladik and chat](http://codeforces.com/problemset/problem/754/C)|Codeforces||Codeforces Round #390 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|920|[Working routine](http://codeforces.com/problemset/problem/706/E)|Codeforces||Codeforces Round #367 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|921|[Printer](http://codeforces.com/problemset/problem/253/E)|Codeforces||Codeforces Round #154 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|922|[Mad Joe](http://codeforces.com/problemset/problem/250/E)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|923|[Sweets for Everyone!](http://codeforces.com/problemset/problem/248/D)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|924|[Colorado Potato Beetle](http://codeforces.com/problemset/problem/243/C)|Codeforces||Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|925|[Mirror Box](http://codeforces.com/problemset/problem/241/C)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|8|
|<ul><li>- [ ] Done</li></ul>|926|[Number Challenge](http://codeforces.com/problemset/problem/235/E)|Codeforces||Codeforces Round #146 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|927|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|928|[Crosses](http://codeforces.com/problemset/problem/215/C)|Codeforces||Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|929|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces||Codeforces Round #129 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|930|[Hexagonal Numbers](http://codeforces.com/problemset/problem/188/A)|Codeforces||Surprise Language Round #6|8|
|<ul><li>- [ ] Done</li></ul>|931|[Defragmentation](http://codeforces.com/problemset/problem/180/A)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|932|[A Piece of Cake](http://codeforces.com/problemset/problem/171/C)|Codeforces||April Fools Day Contest|8|
|<ul><li>- [ ] Done</li></ul>|933|[Piet](http://codeforces.com/problemset/problem/132/B)|Codeforces||Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|934|[Gnikool Ssalg](http://codeforces.com/problemset/problem/130/B)|Codeforces||Unknown Language Round #4|8|
|<ul><li>- [ ] Done</li></ul>|935|[Vectors](http://codeforces.com/problemset/problem/101/C)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|936|[Chip Play](http://codeforces.com/problemset/problem/89/C)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|937|[Widget Library](http://codeforces.com/problemset/problem/89/B)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|938|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|939|[Game](http://codeforces.com/problemset/problem/69/C)|Codeforces||Codeforces Beta Round #63 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|940|[Factorial](http://codeforces.com/problemset/problem/64/A)|Codeforces||Unknown Language Round #1|8|
|<ul><li>- [ ] Done</li></ul>|941|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces||Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|942|[Team Arrangement](http://codeforces.com/problemset/problem/59/D)|Codeforces||Codeforces Beta Round #55 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|943|[Cutting Jigsaw Puzzle](http://codeforces.com/problemset/problem/54/B)|Codeforces||Codeforces Beta Round #50|8|
|<ul><li>- [ ] Done</li></ul>|944|[Crossword](http://codeforces.com/problemset/problem/47/C)|Codeforces||Codeforces Beta Round #44 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|945|[Vasya the Architect](http://codeforces.com/problemset/problem/38/D)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|946|[Collisions](http://codeforces.com/problemset/problem/34/E)|Codeforces||Codeforces Beta Round #34 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|947|[How Many Squares?](http://codeforces.com/problemset/problem/11/C)|Codeforces||Codeforces Beta Round #11|8|
|<ul><li>- [ ] Done</li></ul>|948|[Defining Macros](http://codeforces.com/problemset/problem/7/E)|Codeforces||Codeforces Beta Round #7|8|
|<ul><li>- [ ] Done</li></ul>|949|[Zbazi in Zeydabad](http://codeforces.com/problemset/problem/628/E)|Codeforces||Educational Codeforces Round 8|8|
|<ul><li>- [ ] Done</li></ul>|950|[Finals in arithmetic](http://codeforces.com/problemset/problem/625/D)|Codeforces||Codeforces Round #342 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|951|[New Year and Cleaning](http://codeforces.com/problemset/problem/611/F)|Codeforces||Good Bye 2015|8|
|<ul><li>- [ ] Done</li></ul>|952|[Misha and Palindrome Degree](http://codeforces.com/problemset/problem/501/E)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|953|[Strange Sorting](http://codeforces.com/problemset/problem/484/C)|Codeforces||Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|954|[Crystal Ball Sequence](http://codeforces.com/problemset/problem/470/A)|Codeforces||Surprise Language Round #7|8|
|<ul><li>- [ ] Done</li></ul>|955|[Maze 1D](http://codeforces.com/problemset/problem/404/E)|Codeforces||Codeforces Round #237 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|956|[Volcanoes](http://codeforces.com/problemset/problem/383/B)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|957|[Sereja and Tree](http://codeforces.com/problemset/problem/380/B)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|958|[Broken Monitor](http://codeforces.com/problemset/problem/370/D)|Codeforces||Codeforces Round #217 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|959|[Dima and Magic Guitar](http://codeforces.com/problemset/problem/366/E)|Codeforces||Codeforces Round #214 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|960|[Game](http://codeforces.com/problemset/problem/277/C)|Codeforces||Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|961|[Letter A](http://codeforces.com/problemset/problem/13/B)|Codeforces||Codeforces Beta Round #13|8|
|<ul><li>- [ ] Done</li></ul>|962|[Vanya and Balloons](http://codeforces.com/problemset/problem/677/E)|Codeforces||Codeforces Round #355 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|963|[Dance Revolution](http://acm.timus.ru/problem.aspx?space=1&num=1543)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|964|[Dormitory](http://codeforces.com/problemset/problem/254/E)|Codeforces||Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|965|[Rats](http://codeforces.com/problemset/problem/254/D)|Codeforces||Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|966|[Race](http://codeforces.com/problemset/problem/241/F)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|967|[Polycarpus is Looking for Good Substrings](http://codeforces.com/problemset/problem/212/B)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|968|[Tractor College](http://codeforces.com/problemset/problem/200/E)|Codeforces||Codeforces Round #126 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|969|[Array Sorting](http://codeforces.com/problemset/problem/188/G)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|970|[Binary Notation](http://codeforces.com/problemset/problem/188/F)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|971|[HQ9+](http://codeforces.com/problemset/problem/188/E)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|972|[Asterisks](http://codeforces.com/problemset/problem/188/D)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|973|[LCM](http://codeforces.com/problemset/problem/188/C)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|974|[A + Reverse B](http://codeforces.com/problemset/problem/188/B)|Codeforces||Surprise Language Round #6|9|
|<ul><li>- [ ] Done</li></ul>|975|[Battlefield](http://codeforces.com/problemset/problem/182/A)|Codeforces||Codeforces Round #117 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|976|[Deputies](http://codeforces.com/problemset/problem/173/D)|Codeforces||Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|977|[Lucky Pair](http://codeforces.com/problemset/problem/145/D)|Codeforces||Codeforces Round #104 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|978|[Cycle](http://codeforces.com/problemset/problem/135/D)|Codeforces||Codeforces Beta Round #97 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|979|[Lucky Segments](http://codeforces.com/problemset/problem/121/D)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|980|[Item World](http://codeforces.com/problemset/problem/105/C)|Codeforces||Codeforces Beta Round #81|9|
|<ul><li>- [ ] Done</li></ul>|981|[Candies and Stones](http://codeforces.com/problemset/problem/101/E)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|982|[A+B](http://codeforces.com/problemset/problem/100/C)|Codeforces||Unknown Language Round #3|9|
|<ul><li>- [ ] Done</li></ul>|983|[Friendly Numbers](http://codeforces.com/problemset/problem/100/B)|Codeforces||Unknown Language Round #3|9|
|<ul><li>- [ ] Done</li></ul>|984|[Carpeting the Room](http://codeforces.com/problemset/problem/100/A)|Codeforces||Unknown Language Round #3|9|
|<ul><li>- [ ] Done</li></ul>|985|[Domino](http://codeforces.com/problemset/problem/97/A)|Codeforces||Yandex.Algorithm 2011 Finals|9|
|<ul><li>- [ ] Done</li></ul>|986|[Azembler](http://codeforces.com/problemset/problem/93/C)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|987|[Domino Carpet](http://codeforces.com/problemset/problem/77/D)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|988|[Goofy Numbers](http://codeforces.com/problemset/problem/72/I)|Codeforces||Unknown Language Round #2|9|
|<ul><li>- [ ] Done</li></ul>|989|[Reverse It!](http://codeforces.com/problemset/problem/72/H)|Codeforces||Unknown Language Round #2|9|
|<ul><li>- [ ] Done</li></ul>|990|[Solitaire](http://codeforces.com/problemset/problem/71/D)|Codeforces||Codeforces Beta Round #65 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|991|[Information Reform](http://codeforces.com/problemset/problem/70/E)|Codeforces||Codeforces Beta Round #64|9|
|<ul><li>- [ ] Done</li></ul>|992|[Table](http://codeforces.com/problemset/problem/64/C)|Codeforces||Unknown Language Round #1|9|
|<ul><li>- [ ] Done</li></ul>|993|[Inquisition](http://codeforces.com/problemset/problem/62/C)|Codeforces||Codeforces Beta Round #58|9|
|<ul><li>- [ ] Done</li></ul>|994|[Geometrical problem](http://codeforces.com/problemset/problem/51/D)|Codeforces||Codeforces Beta Round #48|9|
|<ul><li>- [ ] Done</li></ul>|995|[Race](http://codeforces.com/problemset/problem/43/E)|Codeforces||Codeforces Beta Round #42 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|996|[Two Paths](http://codeforces.com/problemset/problem/36/E)|Codeforces||Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|997|[Bowls](http://codeforces.com/problemset/problem/36/C)|Codeforces||Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|998|[Hide-and-Seek](http://codeforces.com/problemset/problem/32/E)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|999|[Map](http://codeforces.com/problemset/problem/15/D)|Codeforces||Codeforces Beta Round #15|9|
|<ul><li>- [ ] Done</li></ul>|1000|[O Problema do Sapateiro Viajante](http://br.spoj.com/problems/SAPATEIR/)|SPOJ Brazil|||9|
|<ul><li>- [ ] Done</li></ul>|1001|[BLOCK_D SOLVER](http://www.spoj.com/problems/BLOCK_D/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|1002|[BF_MODULUS](http://www.spoj.com/problems/MODULUS2/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|1003|[Fibonacci-ish II](http://codeforces.com/problemset/problem/633/H)|Codeforces||Manthan, Codefest 16|9|
|<ul><li>- [ ] Done</li></ul>|1004|[Berland Local Positioning System](http://codeforces.com/problemset/problem/534/E)|Codeforces||Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1005|[Pasha and Pipe](http://codeforces.com/problemset/problem/518/F)|Codeforces||Codeforces Round #293 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1006|[Physical Education and Buns](http://codeforces.com/problemset/problem/394/D)|Codeforces||Codeforces Round #231 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1007|[Game with Points](http://codeforces.com/problemset/problem/386/D)|Codeforces||Testing Round #9|9|
|<ul><li>- [ ] Done</li></ul>|1008|[Red and Black Tree](http://codeforces.com/problemset/problem/375/E)|Codeforces||Codeforces Round #221 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1009|[Dima and Kicks](http://codeforces.com/problemset/problem/358/E)|Codeforces||Codeforces Round #208 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1010|[Xenia and String Problem](http://codeforces.com/problemset/problem/356/E)|Codeforces||Codeforces Round #207 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1011|[Binary Key](http://codeforces.com/problemset/problem/332/E)|Codeforces||Codeforces Round #193 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1012|[Shaass and Painter Robot](http://codeforces.com/problemset/problem/294/D)|Codeforces||Codeforces Round #178 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1013|[Polo the Penguin and Lucky Numbers](http://codeforces.com/problemset/problem/288/E)|Codeforces||Codeforces Round #177 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1014|[Mirror Room](http://codeforces.com/problemset/problem/274/E)|Codeforces||Codeforces Round #168 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1015|[Greedy Elevator](http://codeforces.com/problemset/problem/257/E)|Codeforces||Codeforces Round #159 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1016|[Pairs](http://codeforces.com/problemset/problem/81/E)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|9|
|<ul><li>- [ ] Done</li></ul>|1017|[Bear and Chase](http://codeforces.com/problemset/problem/679/D)|Codeforces||Codeforces Round #356 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1018|[Black Widow](http://codeforces.com/problemset/problem/704/C)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1019|[Sagheer and Kindergarten](http://codeforces.com/problemset/problem/812/D)|Codeforces||Codeforces Round #417 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1020|[Strange Radiation](http://codeforces.com/problemset/problem/832/C)|Codeforces||Codeforces Round #425 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1021|[Tree and Table](http://codeforces.com/problemset/problem/251/E)|Codeforces||Codeforces Round #153 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1022|[Tape Programming](http://codeforces.com/problemset/problem/238/D)|Codeforces||Codeforces Round #148 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1023|[Stack](http://codeforces.com/problemset/problem/188/H)|Codeforces||Surprise Language Round #6|10|
|<ul><li>- [ ] Done</li></ul>|1024|[Gnomes of Might and Magic](http://codeforces.com/problemset/problem/175/F)|Codeforces||Codeforces Round #115|10|
|<ul><li>- [ ] Done</li></ul>|1025|[A polyline](http://codeforces.com/problemset/problem/171/H)|Codeforces||April Fools Day Contest|10|
|<ul><li>- [ ] Done</li></ul>|1026|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces||Codeforces Beta Round #88|10|
|<ul><li>- [ ] Done</li></ul>|1027|[Sleeping](http://codeforces.com/problemset/problem/113/E)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|1028|[Entertaining Geodetics](http://codeforces.com/problemset/problem/105/D)|Codeforces||Codeforces Beta Round #81|10|
|<ul><li>- [ ] Done</li></ul>|1029|[Battleship](http://codeforces.com/problemset/problem/100/H)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|1030|[Name the album](http://codeforces.com/problemset/problem/100/G)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|1031|[Polynom](http://codeforces.com/problemset/problem/100/F)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|1032|[Help King](http://codeforces.com/problemset/problem/98/B)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|10|
|<ul><li>- [ ] Done</li></ul>|1033|[Robot in Basement](http://codeforces.com/problemset/problem/97/D)|Codeforces||Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|1034|[INI-file](http://codeforces.com/problemset/problem/72/B)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|1035|[Harry Potter and Moving Staircases](http://codeforces.com/problemset/problem/65/E)|Codeforces||Codeforces Beta Round #60|10|
|<ul><li>- [ ] Done</li></ul>|1036|[Shooting Gallery](http://codeforces.com/problemset/problem/44/G)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|1037|[Inverse Function](http://codeforces.com/problemset/problem/39/G)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|1038|[ALIGNSUBTRACT](http://www.spoj.com/problems/PROBLEM5/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|1039|[Digits of Number Pi](http://codeforces.com/problemset/problem/585/F)|Codeforces||Codeforces Round #325 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1040|[Design Tutorial: Learn from a Game](http://codeforces.com/problemset/problem/472/E)|Codeforces||Codeforces Round #270|10|
|<ul><li>- [ ] Done</li></ul>|1041|[Hamming Triples](http://codeforces.com/problemset/problem/406/E)|Codeforces||Codeforces Round #238 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1042|[Two Rooted Trees](http://codeforces.com/problemset/problem/403/E)|Codeforces||Codeforces Round #236 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1043|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces||Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1044|[Two Circles](http://codeforces.com/problemset/problem/363/E)|Codeforces||Codeforces Round #211 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1045|[Vasily the Bear and Painting Square](http://codeforces.com/problemset/problem/336/E)|Codeforces||Codeforces Round #195 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1046|[Deja Vu](http://codeforces.com/problemset/problem/331/E1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|1047|[Escaping on Beaveractor](http://codeforces.com/problemset/problem/331/D3)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|1048|[Escaping on Beaveractor](http://codeforces.com/problemset/problem/331/D1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|1049|[Suns and Rays](http://codeforces.com/problemset/problem/316/F3)|Codeforces||ABBYY Cup 3.0|10|
|<ul><li>- [ ] Done</li></ul>|1050|[Suns and Rays](http://codeforces.com/problemset/problem/316/F1)|Codeforces||ABBYY Cup 3.0|10|
|<ul><li>- [ ] Done</li></ul>|1051|[Sequence Transformation](http://codeforces.com/problemset/problem/280/E)|Codeforces||Codeforces Round #172 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1052|[A Kleene Implementation](http://www.spoj.com/problems/BFREGEX1/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|1053|[Red-Black Cobweb](http://codeforces.com/problemset/problem/833/D)|Codeforces||Codeforces Round #426 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1054|[Perpetual Motion Machine](http://codeforces.com/problemset/problem/830/E)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|10|
