# 009. Codeforces_Div._2_-_C_Problems


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Registration System](http://codeforces.com/problemset/problem/4/C)|Codeforces|Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Dijkstra?](http://codeforces.com/problemset/problem/20/C)|Codeforces|Codeforces Alpha Round #20 (Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Lucky Sum of Digits](http://codeforces.com/problemset/problem/109/A)|Codeforces|Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces|Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces|Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Little Elephant and Bits](http://codeforces.com/problemset/problem/258/A)|Codeforces|Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces|Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Learning Languages](http://codeforces.com/problemset/problem/277/A)|Codeforces|Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Building Permutation](http://codeforces.com/problemset/problem/285/C)|Codeforces|Codeforces Round #175 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Maze](http://codeforces.com/problemset/problem/377/A)|Codeforces|Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Team](http://codeforces.com/problemset/problem/401/C)|Codeforces|Codeforces Round #235 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces|Codeforces Round #247 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|13|[Boredom](http://codeforces.com/problemset/problem/455/A)|Codeforces|Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|14|[Appleman and Toastman](http://codeforces.com/problemset/problem/461/A)|Codeforces|Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces|Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Table Decorations](http://codeforces.com/problemset/problem/478/C)|Codeforces|Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Exams](http://codeforces.com/problemset/problem/479/C)|Codeforces|Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Diverse Permutation](http://codeforces.com/problemset/problem/482/A)|Codeforces|Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Given Length and Sum of Digits...](http://codeforces.com/problemset/problem/489/C)|Codeforces|Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Drazil and Factorial](http://codeforces.com/problemset/problem/515/C)|Codeforces|Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|21|[A and B and Team Training](http://codeforces.com/problemset/problem/519/C)|Codeforces|Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[Woodcutters](http://codeforces.com/problemset/problem/545/C)|Codeforces|Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[Soldier and Cards](http://codeforces.com/problemset/problem/546/C)|Codeforces|Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[Divisibility by Eight](http://codeforces.com/problemset/problem/550/C)|Codeforces|Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Gerald's Hexagon](http://codeforces.com/problemset/problem/559/A)|Codeforces|Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Bear and Poker](http://codeforces.com/problemset/problem/573/A)|Codeforces|Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|27|[Vasya and Petya's Game](http://codeforces.com/problemset/problem/576/A)|Codeforces|Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Kefa and Park](http://codeforces.com/problemset/problem/580/C)|Codeforces|Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Watchmen](http://codeforces.com/problemset/problem/650/A)|Codeforces|Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Tanya and Toys](http://codeforces.com/problemset/problem/659/C)|Codeforces|Codeforces Round #346 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|31|[NP-Hard Problem](http://codeforces.com/problemset/problem/687/A)|Codeforces|Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Vacations](http://codeforces.com/problemset/problem/698/A)|Codeforces|Codeforces Round #363 (Div. 1) & Codeforces Round #363 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Sanatorium](http://codeforces.com/problemset/problem/732/C)|Codeforces|Codeforces Round #377 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces|Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|35|[Dishonest Sellers](http://codeforces.com/problemset/problem/779/C)|Codeforces|Codeforces Round #402 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[Find Amir](http://codeforces.com/problemset/problem/804/A)|Codeforces|Codeforces Round #411 (Div. 1) & Codeforces Round #411 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|37|[The Closest Pair Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1186)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|38|[Classroom Watch](http://codeforces.com/problemset/problem/875/A)|Codeforces|Codeforces Round #441 (Div. 1, by Moscow Team Olympiad) & Codeforces Round #441 (Div. 2, by Moscow Team Olympiad)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Cards](http://codeforces.com/problemset/problem/701/A)|Codeforces|Codeforces Round #364 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Alice, Bob and Chocolate](http://codeforces.com/problemset/problem/6/C)|Codeforces|Codeforces Beta Round #6 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|41|[Hexadecimal's Numbers](http://codeforces.com/problemset/problem/9/C)|Codeforces|Codeforces Beta Round #9 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|42|[The World is a Theatre](http://codeforces.com/problemset/problem/131/C)|Codeforces|Codeforces Beta Round #95 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|43|[Lucky Conversion](http://codeforces.com/problemset/problem/145/A)|Codeforces|Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|44|[Pocket Book](http://codeforces.com/problemset/problem/152/C)|Codeforces|Codeforces Round #108 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|45|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces|Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|46|[Little Elephant and Problem](http://codeforces.com/problemset/problem/220/A)|Codeforces|Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|47|[LCM Challenge](http://codeforces.com/problemset/problem/235/A)|Codeforces|Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|48|[Points on Line](http://codeforces.com/problemset/problem/251/A)|Codeforces|Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|49|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces|Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|50|[Beautiful Sets of Points](http://codeforces.com/problemset/problem/268/C)|Codeforces|Codeforces Round #164 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|51|[k-Multiple Free Set](http://codeforces.com/problemset/problem/274/A)|Codeforces|Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|52|[Polo the Penguin and Strings](http://codeforces.com/problemset/problem/288/A)|Codeforces|Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|53|[Greg and Array](http://codeforces.com/problemset/problem/295/A)|Codeforces|Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|54|[Rational Resistance](http://codeforces.com/problemset/problem/343/A)|Codeforces|Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|55|[Alice and Bob](http://codeforces.com/problemset/problem/346/A)|Codeforces|Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|56|[Mafia](http://codeforces.com/problemset/problem/348/A)|Codeforces|Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|57|[Knight Tournament](http://codeforces.com/problemset/problem/356/A)|Codeforces|Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|58|[Fixing Typos](http://codeforces.com/problemset/problem/363/C)|Codeforces|Codeforces Round #211 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|59|[Hamburgers](http://codeforces.com/problemset/problem/371/C)|Codeforces|Codeforces Round #218 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|60|[Counting Kangaroos is Fun](http://codeforces.com/problemset/problem/372/A)|Codeforces|Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|61|[Fox and Box Accumulation](http://codeforces.com/problemset/problem/388/A)|Codeforces|Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|62|[Mashmokh and Numbers](http://codeforces.com/problemset/problem/414/A)|Codeforces|Codeforces Round #240 (Div. 1) & Codeforces Round #240 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|63|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces|Codeforces Round #244 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|64|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces|Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|65|[The Child and Toy](http://codeforces.com/problemset/problem/437/C)|Codeforces|Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|66|[Valera and Tubes ](http://codeforces.com/problemset/problem/441/C)|Codeforces|Codeforces Round #252 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|67|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces|Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|68|[Little Pony and Expected Maximum](http://codeforces.com/problemset/problem/453/A)|Codeforces|Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|69|[George and Job](http://codeforces.com/problemset/problem/467/C)|Codeforces|Codeforces Round #267 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|70|[24 Game](http://codeforces.com/problemset/problem/468/A)|Codeforces|Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|71|[Design Tutorial: Make It Nondeterministic](http://codeforces.com/problemset/problem/472/C)|Codeforces|Codeforces Round #270|2|
|<ul><li>- [ ] Done</li></ul>|72|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces|Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|73|[Palindrome Transformation](http://codeforces.com/problemset/problem/486/C)|Codeforces|Codeforces Round #277 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|74|[Hacking Cypher](http://codeforces.com/problemset/problem/490/C)|Codeforces|Codeforces Round #279 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|75|[Vanya and Exams](http://codeforces.com/problemset/problem/492/C)|Codeforces|Codeforces Round #280 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|76|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces|Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|77|[Crazy Town](http://codeforces.com/problemset/problem/498/A)|Codeforces|Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|78|[Fox And Names](http://codeforces.com/problemset/problem/510/C)|Codeforces|Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|79|[Anya and Smartphone](http://codeforces.com/problemset/problem/518/C)|Codeforces|Codeforces Round #293 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|80|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces|Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|81|[Kyoya and Colored Balls](http://codeforces.com/problemset/problem/553/A)|Codeforces|Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|82|[Case of Matryoshkas](http://codeforces.com/problemset/problem/555/A)|Codeforces|Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|83|[Geometric Progression](http://codeforces.com/problemset/problem/567/C)|Codeforces|Codeforces Round #Pi (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|84|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces|Codeforces Round #316 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|85|[Developing Skills](http://codeforces.com/problemset/problem/581/C)|Codeforces|Codeforces Round #322 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|86|[GCD Table](http://codeforces.com/problemset/problem/582/A)|Codeforces|Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|87|[Duff and Weight Lifting](http://codeforces.com/problemset/problem/587/A)|Codeforces|Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|88|[The Two Routes](http://codeforces.com/problemset/problem/601/A)|Codeforces|Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|89|[Alternative Thinking](http://codeforces.com/problemset/problem/603/A)|Codeforces|Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|90|[Sorting Railway Cars](http://codeforces.com/problemset/problem/605/A)|Codeforces|Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|91|[Chain Reaction](http://codeforces.com/problemset/problem/607/A)|Codeforces|Codeforces Round #336 (Div. 1) & Codeforces Round #336 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|92|[K-special Tables](http://codeforces.com/problemset/problem/625/C)|Codeforces|Codeforces Round #342 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|93|[Cinema](http://codeforces.com/problemset/problem/670/C)|Codeforces|Codeforces Round #350 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|94|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces|Codeforces Round #354 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|95|[Bear and Prime 100](http://codeforces.com/problemset/problem/679/A)|Codeforces|Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|96|[They Are Everywhere](http://codeforces.com/problemset/problem/701/C)|Codeforces|Codeforces Round #364 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|97|[Thor](http://codeforces.com/problemset/problem/704/A)|Codeforces|Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|98|[Hard problem](http://codeforces.com/problemset/problem/706/C)|Codeforces|Codeforces Round #367 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|99|[Pythagorean Triples](http://codeforces.com/problemset/problem/707/C)|Codeforces|Codeforces Round #368 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|100|[Sonya and Queries](http://codeforces.com/problemset/problem/713/A)|Codeforces|Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|101|[Plus and Square Root](http://codeforces.com/problemset/problem/715/A)|Codeforces|Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|102|[Alyona and mex](http://codeforces.com/problemset/problem/739/A)|Codeforces|Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|103|[Tennis Championship](http://codeforces.com/problemset/problem/735/C)|Codeforces|Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|104|[Vladik and fractions](http://codeforces.com/problemset/problem/743/C)|Codeforces|Codeforces Round #384 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|105|[PolandBall and Forest](http://codeforces.com/problemset/problem/755/C)|Codeforces|8VC Venture Cup 2017 - Elimination Round|2|
|<ul><li>- [ ] Done</li></ul>|106|[Timofey and a tree](http://codeforces.com/problemset/problem/763/A)|Codeforces|Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|107|[Table Tennis Game 2](http://codeforces.com/problemset/problem/765/C)|Codeforces|Codeforces Round #397 by Kaspersky Lab and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|2|
|<ul><li>- [ ] Done</li></ul>|108|[Andryusha and Colored Balloons](http://codeforces.com/problemset/problem/780/C)|Codeforces|?????????? 2017 - ????? (?????? ??? ??????-??????????)|2|
|<ul><li>- [ ] Done</li></ul>|109|[Anton and Fairy Tale](http://codeforces.com/problemset/problem/785/C)|Codeforces|Codeforces Round #404 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|110|[Bear and Different Names](http://codeforces.com/problemset/problem/771/B)|Codeforces|VK Cup 2017 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|111|[Functions again](http://codeforces.com/problemset/problem/788/A)|Codeforces|Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|112|[Sagheer and Nubian Market](http://codeforces.com/problemset/problem/812/C)|Codeforces|Codeforces Round #417 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|113|[Leha and Function](http://codeforces.com/problemset/problem/840/A)|Codeforces|Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|114|[Journey](http://codeforces.com/problemset/problem/839/C)|Codeforces|Codeforces Round #428 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|115|[Bear and Forgotten Tree 3](http://codeforces.com/problemset/problem/639/B)|Codeforces|VK Cup 2016 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|116|[Bus](http://codeforces.com/problemset/problem/864/C)|Codeforces|Codeforces Round #436 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|117|[Maximum splitting](http://codeforces.com/problemset/problem/870/C)|Codeforces|Technocup 2018 - Elimination Round 2|2|
|<ul><li>- [ ] Done</li></ul>|118|[Rumor](http://codeforces.com/problemset/problem/893/C)|Codeforces|Educational Codeforces Round 33 (Rated for Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|119|[Seat Arrangements](http://codeforces.com/problemset/problem/919/C)|Codeforces|Codeforces Round #460 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|120|[Tic-tac-toe](http://codeforces.com/problemset/problem/3/C)|Codeforces|Codeforces Beta Round #3|3|
|<ul><li>- [ ] Done</li></ul>|121|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces|Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|122|[Stripe](http://codeforces.com/problemset/problem/18/C)|Codeforces|Codeforces Beta Round #18 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|123|[Modified GCD](http://codeforces.com/problemset/problem/75/C)|Codeforces|Codeforces Beta Round #67 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|124|[Cthulhu](http://codeforces.com/problemset/problem/103/B)|Codeforces|Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|125|[Petya and Inequiations](http://codeforces.com/problemset/problem/111/A)|Codeforces|Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|126|[Lucky Sum](http://codeforces.com/problemset/problem/121/A)|Codeforces|Codeforces Beta Round #91 (Div. 1 Only) & Codeforces Beta Round #91 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|127|[Replacement](http://codeforces.com/problemset/problem/135/A)|Codeforces|Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|128|[History](http://codeforces.com/problemset/problem/137/C)|Codeforces|Codeforces Beta Round #98 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|129|[Win or Freeze](http://codeforces.com/problemset/problem/150/A)|Codeforces|Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|130|[Median](http://codeforces.com/problemset/problem/166/C)|Codeforces|Codeforces Round #113 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|131|[Plant](http://codeforces.com/problemset/problem/185/A)|Codeforces|Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|132|[Lexicographically Maximum Subsequence](http://codeforces.com/problemset/problem/196/A)|Codeforces|Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|133|[Photographer](http://codeforces.com/problemset/problem/203/C)|Codeforces|Codeforces Round #128 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|134|[Little Elephant and Interval](http://codeforces.com/problemset/problem/204/A)|Codeforces|Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|135|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces|Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|136|[Barcode](http://codeforces.com/problemset/problem/225/C)|Codeforces|Codeforces Round #139 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|137|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces|Codeforces Round #143 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|138|[Primes on Interval](http://codeforces.com/problemset/problem/237/C)|Codeforces|Codeforces Round #147 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|139|[Maxim and Discounts](http://codeforces.com/problemset/problem/261/A)|Codeforces|Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|140|[Dima and Staircase](http://codeforces.com/problemset/problem/272/C)|Codeforces|Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|141|[Ladder](http://codeforces.com/problemset/problem/279/C)|Codeforces|Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|142|[XOR and OR](http://codeforces.com/problemset/problem/282/C)|Codeforces|Codeforces Round #173 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|143|[Cows and Sequence](http://codeforces.com/problemset/problem/283/A)|Codeforces|Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|144|[Lucky Permutation Triple](http://codeforces.com/problemset/problem/303/A)|Codeforces|Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|145|[Ilya and Matrix](http://codeforces.com/problemset/problem/313/C)|Codeforces|Codeforces Round #186 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|146|[Perfect Pair](http://codeforces.com/problemset/problem/317/A)|Codeforces|Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|147|[Purification](http://codeforces.com/problemset/problem/329/A)|Codeforces|Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|148|[Secrets](http://codeforces.com/problemset/problem/333/A)|Codeforces|Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|149|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces|Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|150|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces|Codeforces Round #197 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|151|[Bombs](http://codeforces.com/problemset/problem/350/C)|Codeforces|Codeforces Round #203 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|152|[Vasya and Robot](http://codeforces.com/problemset/problem/354/A)|Codeforces|Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|153|[Sereja and Algorithm ](http://codeforces.com/problemset/problem/367/A)|Codeforces|Codeforces Round #215 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|154|[Valera and Elections](http://codeforces.com/problemset/problem/369/C)|Codeforces|Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|155|[Arithmetic Progression](http://codeforces.com/problemset/problem/382/C)|Codeforces|Codeforces Round #224 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|156|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces|Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|157|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces|Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|158|[Searching for Graph](http://codeforces.com/problemset/problem/402/C)|Codeforces|Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|159|[Unusual Product](http://codeforces.com/problemset/problem/405/C)|Codeforces|Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|160|[Triangle](http://codeforces.com/problemset/problem/407/A)|Codeforces|Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|161|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces|Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|162|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces|Codeforces Round #256 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|163|[Jzzhu and Chocolate](http://codeforces.com/problemset/problem/449/A)|Codeforces|Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|164|[Pashmak and Buses](http://codeforces.com/problemset/problem/459/C)|Codeforces|Codeforces Round #261 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|165|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces|Codeforces Round #262 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|166|[Gargari and Bishops](http://codeforces.com/problemset/problem/463/C)|Codeforces|Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|167|[No to Palindromes!](http://codeforces.com/problemset/problem/464/A)|Codeforces|Codeforces Round #265 (Div. 1) & Codeforces Round #265 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|168|[Dreamoon and Sums](http://codeforces.com/problemset/problem/476/C)|Codeforces|Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|169|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces|Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|170|[Treasure](http://codeforces.com/problemset/problem/494/A)|Codeforces|Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|171|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces|Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|172|[Mr. Kitayuta, the Treasure Hunter](http://codeforces.com/problemset/problem/505/C)|Codeforces|Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|173|[Guess Your Way Out!](http://codeforces.com/problemset/problem/507/C)|Codeforces|Codeforces Round #287 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|174|[Anya and Ghosts](http://codeforces.com/problemset/problem/508/C)|Codeforces|Codeforces Round #288 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|175|[Watto and Mechanism](http://codeforces.com/problemset/problem/514/C)|Codeforces|Codeforces Round #291 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|176|[DNA Alignment](http://codeforces.com/problemset/problem/520/C)|Codeforces|Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|177|[Glass Carving](http://codeforces.com/problemset/problem/527/C)|Codeforces|Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|178|[Ilya and Sticks](http://codeforces.com/problemset/problem/525/C)|Codeforces|Codeforces Round #297 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|179|[Polycarpus' Dice](http://codeforces.com/problemset/problem/534/C)|Codeforces|Codeforces Round #298 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|180|[Ice Cave](http://codeforces.com/problemset/problem/540/C)|Codeforces|Codeforces Round #301 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|181|[Writing Code](http://codeforces.com/problemset/problem/543/A)|Codeforces|Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|182|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces|Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|183|[Primes or Palindromes?](http://codeforces.com/problemset/problem/568/A)|Codeforces|Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|184|[A Problem about Polyline](http://codeforces.com/problemset/problem/578/A)|Codeforces|Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|185|[Marina and Vasya](http://codeforces.com/problemset/problem/584/C)|Codeforces|Codeforces Round #324 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|186|[Gennady the Dentist](http://codeforces.com/problemset/problem/585/A)|Codeforces|Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|187|[Median Smoothing](http://codeforces.com/problemset/problem/590/A)|Codeforces|Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|188|[Day at the Beach](http://codeforces.com/problemset/problem/599/C)|Codeforces|Codeforces Round #332 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|189|[Watering Flowers](http://codeforces.com/problemset/problem/617/C)|Codeforces|Codeforces Round #340 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|190|[Wet Shark and Flowers](http://codeforces.com/problemset/problem/621/C)|Codeforces|Codeforces Round #341 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|191|[Little Artem and Matrix](http://codeforces.com/problemset/problem/641/B)|Codeforces|VK Cup 2016 - Round 2|3|
|<ul><li>- [ ] Done</li></ul>|192|[Bear and Colors](http://codeforces.com/problemset/problem/643/A)|Codeforces|VK Cup 2016 - Round 3|3|
|<ul><li>- [ ] Done</li></ul>|193|[Recycling Bottles](http://codeforces.com/problemset/problem/671/A)|Codeforces|Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|194|[Vanya and Label](http://codeforces.com/problemset/problem/677/C)|Codeforces|Codeforces Round #355 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|195|[Heap Operations](http://codeforces.com/problemset/problem/681/C)|Codeforces|Codeforces Round #357 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|196|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces|Codeforces Round #358 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|197|[Robbers' watch](http://codeforces.com/problemset/problem/685/A)|Codeforces|Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|198|[Lorenzo Von Matterhorn](http://codeforces.com/problemset/problem/696/A)|Codeforces|Codeforces Round #362 (Div. 1) & Codeforces Round #362 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|199|[Coloring Trees](http://codeforces.com/problemset/problem/711/C)|Codeforces|Codeforces Round #369 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|200|[Joty and Chocolate](http://codeforces.com/problemset/problem/678/C)|Codeforces|Educational Codeforces Round 13|3|
|<ul><li>- [ ] Done</li></ul>|201|[Memory and De-Evolution](http://codeforces.com/problemset/problem/712/C)|Codeforces|Codeforces Round #370 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|202|[Efim and Strange Grade](http://codeforces.com/problemset/problem/718/A)|Codeforces|Codeforces Round #373 (Div. 1) & Codeforces Round #373 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|203|[Journey](http://codeforces.com/problemset/problem/721/C)|Codeforces|Codeforces Round #374 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|204|[Polycarp at the Radio](http://codeforces.com/problemset/problem/723/C)|Codeforces|Codeforces Round #375 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|205|[Socks](http://codeforces.com/problemset/problem/731/C)|Codeforces|Codeforces Round #376 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|206|[Anton and Making Potions](http://codeforces.com/problemset/problem/734/C)|Codeforces|Codeforces Round #379 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|207|[Arpa's loud Owf and Mehrdad's evil plan](http://codeforces.com/problemset/problem/741/A)|Codeforces|Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|208|[Voting](http://codeforces.com/problemset/problem/749/C)|Codeforces|Codeforces Round #388 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|209|[Servers](http://codeforces.com/problemset/problem/747/C)|Codeforces|Codeforces Round #387 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|210|[Hongcow Builds A Nation](http://codeforces.com/problemset/problem/744/A)|Codeforces|Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|211|[Santa Claus and Robot](http://codeforces.com/problemset/problem/748/C)|Codeforces|Technocup 2017 - Elimination Round 3|3|
|<ul><li>- [ ] Done</li></ul>|212|[Dasha and Password](http://codeforces.com/problemset/problem/761/C)|Codeforces|Codeforces Round #394 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|213|[Mahmoud and a Message](http://codeforces.com/problemset/problem/766/C)|Codeforces|Codeforces Round #396 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|214|[Molly's Chemicals](http://codeforces.com/problemset/problem/776/C)|Codeforces|ICM Technex 2017 and Codeforces Round #400 (Div. 1 + Div. 2, combined)|3|
|<ul><li>- [ ] Done</li></ul>|215|[Alyona and Spreadsheet](http://codeforces.com/problemset/problem/777/C)|Codeforces|Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|216|[Do you want a date?](http://codeforces.com/problemset/problem/809/A)|Codeforces|Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|217|[Success Rate](http://codeforces.com/problemset/problem/773/A)|Codeforces|VK Cup 2017 - Round 3|3|
|<ul><li>- [ ] Done</li></ul>|218|[Mike and gcd problem](http://codeforces.com/problemset/problem/798/C)|Codeforces|Codeforces Round #410 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|219|[Voltage Keepsake](http://codeforces.com/problemset/problem/772/A)|Codeforces|VK Cup 2017 - Round 2|3|
|<ul><li>- [ ] Done</li></ul>|220|[Karen and Game](http://codeforces.com/problemset/problem/815/A)|Codeforces|Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|221|[Star sky](http://codeforces.com/problemset/problem/835/C)|Codeforces|Codeforces Round #427 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|222|[The Meaningless Game](http://codeforces.com/problemset/problem/833/A)|Codeforces|Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|223|[Hacker, pack your bags!](http://codeforces.com/problemset/problem/822/C)|Codeforces|Codeforces Round #422 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|224|[Okabe and Boxes](http://codeforces.com/problemset/problem/821/C)|Codeforces|Codeforces Round #420 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|225|[An impassioned circulation of affection](http://codeforces.com/problemset/problem/814/C)|Codeforces|Codeforces Round #418 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|226|[Sorting by Subsequences](http://codeforces.com/problemset/problem/843/A)|Codeforces|AIM Tech Round 4 (Div. 1) & AIM Tech Round 4 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|227|[Two TVs](http://codeforces.com/problemset/problem/845/C)|Codeforces|Educational Codeforces Round 27|3|
|<ul><li>- [ ] Done</li></ul>|228|[Phone Numbers](http://codeforces.com/problemset/problem/898/C)|Codeforces|Codeforces Round #451 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|229|[Hashing Trees](http://codeforces.com/problemset/problem/901/A)|Codeforces|Codeforces Round #453 (Div. 1) & Codeforces Round #453 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|230|[Party Lemonade](http://codeforces.com/problemset/problem/913/C)|Codeforces|Hello 2018|3|
|<ul><li>- [ ] Done</li></ul>|231|[Jamie and Interesting Graph](http://codeforces.com/problemset/problem/916/C)|Codeforces|Codeforces Round #457 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|232|[Swap Adjacent Elements](http://codeforces.com/problemset/problem/920/C)|Codeforces|Educational Codeforces Round 37 (Rated for Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|233|[Cave Painting](http://codeforces.com/problemset/problem/922/C)|Codeforces|Codeforces Round #461 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|234|[Convenient For Everybody](http://codeforces.com/problemset/problem/939/C)|Codeforces|Codeforces Round #464 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|235|[Fifa and Fafa](http://codeforces.com/problemset/problem/935/C)|Codeforces|Codeforces Round #465 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|236|[K-Multiple Free set ](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2203)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|237|[Ancient Berland Circus](http://codeforces.com/problemset/problem/1/C)|Codeforces|Codeforces Beta Round #1|4|
|<ul><li>- [ ] Done</li></ul>|238|[Fruits](http://codeforces.com/problemset/problem/12/C)|Codeforces|Codeforces Beta Round #12 (Div 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|239|[Roads in Berland](http://codeforces.com/problemset/problem/25/C)|Codeforces|Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|240|[Page Numbers](http://codeforces.com/problemset/problem/34/C)|Codeforces|Codeforces Beta Round #34 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|241|[Fire Again](http://codeforces.com/problemset/problem/35/C)|Codeforces|Codeforces Beta Round #35 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|242|[Lucky Tickets](http://codeforces.com/problemset/problem/43/C)|Codeforces|Codeforces Beta Round #42 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|243|[Little Frog](http://codeforces.com/problemset/problem/53/C)|Codeforces|Codeforces Beta Round #49 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|244|[Round Table Knights](http://codeforces.com/problemset/problem/71/C)|Codeforces|Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|245|[Trains](http://codeforces.com/problemset/problem/87/A)|Codeforces|Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|246|[Homework](http://codeforces.com/problemset/problem/101/A)|Codeforces|Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|247|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces|Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|248|[Dorm Water Supply](http://codeforces.com/problemset/problem/107/A)|Codeforces|Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|249|[Statues](http://codeforces.com/problemset/problem/128/A)|Codeforces|Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|250|[Turing Tape](http://codeforces.com/problemset/problem/132/A)|Codeforces|Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|251|[New Year Snowmen](http://codeforces.com/problemset/problem/140/C)|Codeforces|Codeforces Round #100|4|
|<ul><li>- [ ] Done</li></ul>|252|[Anagram Search](http://codeforces.com/problemset/problem/144/C)|Codeforces|Codeforces Round #103 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|253|[Division into Teams](http://codeforces.com/problemset/problem/149/C)|Codeforces|Codeforces Round #106 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|254|[Hometask](http://codeforces.com/problemset/problem/154/A)|Codeforces|Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|255|[Message](http://codeforces.com/problemset/problem/156/A)|Codeforces|Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|256|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces|Codeforces Round #111 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|257|[Letter](http://codeforces.com/problemset/problem/180/C)|Codeforces|Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|258|[About Bacteria](http://codeforces.com/problemset/problem/198/A)|Codeforces|Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|259|[Flying Saucer Segments](http://codeforces.com/problemset/problem/226/A)|Codeforces|Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|260|[Shifts](http://codeforces.com/problemset/problem/229/A)|Codeforces|Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|261|[Weather](http://codeforces.com/problemset/problem/234/C)|Codeforces|Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|262|[King's Path](http://codeforces.com/problemset/problem/242/C)|Codeforces|Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|263|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces|Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|264|[View Angle](http://codeforces.com/problemset/problem/257/C)|Codeforces|Codeforces Round #159 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|265|[The Brand New Function](http://codeforces.com/problemset/problem/243/A)|Codeforces|Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|266|[Magical Boxes](http://codeforces.com/problemset/problem/269/A)|Codeforces|Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|267|[Secret](http://codeforces.com/problemset/problem/271/C)|Codeforces|Codeforces Round #166 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|268|[Lucky Permutation](http://codeforces.com/problemset/problem/286/A)|Codeforces|Codeforces Round #176 (Div. 1) & Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|269|[Parity Game](http://codeforces.com/problemset/problem/297/A)|Codeforces|Codeforces Round #180 (Div. 1) & Codeforces Round #180 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|270|[Beautiful Numbers](http://codeforces.com/problemset/problem/300/C)|Codeforces|Codeforces Round #181 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|271|[Yaroslav and Sequence](http://codeforces.com/problemset/problem/301/A)|Codeforces|Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|272|[The Closest Pair](http://codeforces.com/problemset/problem/311/A)|Codeforces|Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|273|[Ciel and Robot](http://codeforces.com/problemset/problem/321/A)|Codeforces|Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|274|[Magic Five](http://codeforces.com/problemset/problem/327/C)|Codeforces|Codeforces Round #191 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|275|[Tourist Problem](http://codeforces.com/problemset/problem/340/C)|Codeforces|Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|276|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces|Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|277|[Find Maximum](http://codeforces.com/problemset/problem/353/C)|Codeforces|Codeforces Round #205 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|278|[Matrix](http://codeforces.com/problemset/problem/364/A)|Codeforces|Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|279|[Dima and Salad](http://codeforces.com/problemset/problem/366/C)|Codeforces|Codeforces Round #214 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|280|[Divisible by Seven](http://codeforces.com/problemset/problem/375/A)|Codeforces|Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|281|[Sereja and Prefixes](http://codeforces.com/problemset/problem/380/A)|Codeforces|Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|282|[Inna and Huge Candy Matrix](http://codeforces.com/problemset/problem/400/C)|Codeforces|Codeforces Round #234 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|283|[Restore Graph](http://codeforces.com/problemset/problem/404/C)|Codeforces|Codeforces Round #237 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|284|[Magic Formulas](http://codeforces.com/problemset/problem/424/C)|Codeforces|Codeforces Round #242 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|285|[Sereja and Swaps](http://codeforces.com/problemset/problem/425/A)|Codeforces|Codeforces Round #243 (Div. 1) & Codeforces Round #243 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|286|[Cardiogram](http://codeforces.com/problemset/problem/435/C)|Codeforces|Codeforces Round #249 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|287|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces|Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|288|[DZY Loves Physics](http://codeforces.com/problemset/problem/444/A)|Codeforces|Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|289|[Predict Outcome of the Game](http://codeforces.com/problemset/problem/451/C)|Codeforces|Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|290|[MUH and House of Cards](http://codeforces.com/problemset/problem/471/C)|Codeforces|Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|291|[Captain Marmot](http://codeforces.com/problemset/problem/474/C)|Codeforces|Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|292|[Fight the Monster](http://codeforces.com/problemset/problem/488/C)|Codeforces|Codeforces Round #278 (Div. 2) & Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2) & Codeforces Round #278 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|293|[Tavas and Karafs](http://codeforces.com/problemset/problem/535/C)|Codeforces|Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|294|[GukiZ hates Boxes](http://codeforces.com/problemset/problem/551/C)|Codeforces|Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|295|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces|Codeforces Round #311 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|296|[Amr and Chemistry](http://codeforces.com/problemset/problem/558/C)|Codeforces|Codeforces Round #312 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|297|[The Big Race](http://codeforces.com/problemset/problem/592/C)|Codeforces|Codeforces Round #328 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|298|[Harmony Analysis](http://codeforces.com/problemset/problem/610/C)|Codeforces|Codeforces Round #337 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|299|[Peter and Snow Blower](http://codeforces.com/problemset/problem/613/A)|Codeforces|Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|300|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces|Codeforces Round #344 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|301|[Reberland Linguistics](http://codeforces.com/problemset/problem/666/A)|Codeforces|Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|302|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces|Codeforces Round #353 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|303|[Mike and Chocolate Thieves](http://codeforces.com/problemset/problem/689/C)|Codeforces|Codeforces Round #361 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|304|[Epidemic in Monstropolis](http://codeforces.com/problemset/problem/733/C)|Codeforces|Codeforces Round #378 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|305|[Road to Cinema](http://codeforces.com/problemset/problem/729/C)|Codeforces|Technocup 2017 - Elimination Round 2|4|
|<ul><li>- [ ] Done</li></ul>|306|[Tram](http://codeforces.com/problemset/problem/746/C)|Codeforces|Codeforces Round #386 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|307|[Unfair Poll](http://codeforces.com/problemset/problem/758/C)|Codeforces|Codeforces Round #392 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|308|[Pavel and barbecue](http://codeforces.com/problemset/problem/756/A)|Codeforces|8VC Venture Cup 2017 - Final Round|4|
|<ul><li>- [ ] Done</li></ul>|309|[Garland](http://codeforces.com/problemset/problem/767/C)|Codeforces|Codeforces Round #398 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|310|[Jon Snow and his Favourite Number](http://codeforces.com/problemset/problem/768/C)|Codeforces|Divide by Zero 2017 and Codeforces Round #399 (Div. 1 + Div. 2, combined)|4|
|<ul><li>- [ ] Done</li></ul>|311|[Vladik and Memorable Trip](http://codeforces.com/problemset/problem/811/C)|Codeforces|Codeforces Round #416 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|312|[Naming Company](http://codeforces.com/problemset/problem/794/C)|Codeforces|Tinkoff Challenge - Final Round (Codeforces Round #414, rated, Div. 1 + Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|313|[Fountains](http://codeforces.com/problemset/problem/799/C)|Codeforces|Playrix Codescapes Cup (Codeforces Round #413, rated, Div. 1 + Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|314|[Jury Marks](http://codeforces.com/problemset/problem/831/C)|Codeforces|Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|315|[String Reconstruction](http://codeforces.com/problemset/problem/827/A)|Codeforces|Codeforces Round #423 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #423 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|316|[Queue](http://codeforces.com/problemset/problem/91/B)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|317|[The Intriguing Obsession](http://codeforces.com/problemset/problem/869/C)|Codeforces|Codeforces Round #439 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|318|[Qualification Rounds](http://codeforces.com/problemset/problem/868/C)|Codeforces|Codeforces Round #438 by Sberbank and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|4|
|<ul><li>- [ ] Done</li></ul>|319|[Travelling Salesman and Special Numbers](http://codeforces.com/problemset/problem/914/C)|Codeforces|Codecraft-18 and Codeforces Round #458 (Div. 1 + Div. 2, combined)|4|
|<ul><li>- [ ] Done</li></ul>|320|[Line](http://codeforces.com/problemset/problem/7/C)|Codeforces|Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|321|[Sequence](http://codeforces.com/problemset/problem/13/C)|Codeforces|Codeforces Beta Round #13|5|
|<ul><li>- [ ] Done</li></ul>|322|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces|Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|323|[Monitor](http://codeforces.com/problemset/problem/16/C)|Codeforces|Codeforces Beta Round #16 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|324|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces|Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|325|[Mail Stamps](http://codeforces.com/problemset/problem/29/C)|Codeforces|Codeforces Beta Round #29 (Div. 2, Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|326|[Email address](http://codeforces.com/problemset/problem/41/C)|Codeforces|Codeforces Beta Round #40 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|327|[Newspaper Headline](http://codeforces.com/problemset/problem/91/A)|Codeforces|Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|328|[Frames](http://codeforces.com/problemset/problem/93/A)|Codeforces|Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|329|[Grammar Lessons](http://codeforces.com/problemset/problem/113/A)|Codeforces|Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|330|[Cycle](http://codeforces.com/problemset/problem/117/C)|Codeforces|Codeforces Beta Round #88|5|
|<ul><li>- [ ] Done</li></ul>|331|[Fancy Number](http://codeforces.com/problemset/problem/118/C)|Codeforces|Codeforces Beta Round #89 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|332|[Prime Permutation](http://codeforces.com/problemset/problem/123/A)|Codeforces|Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|333|[Literature Lesson](http://codeforces.com/problemset/problem/138/A)|Codeforces|Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|334|[Queue](http://codeforces.com/problemset/problem/141/C)|Codeforces|Codeforces Round #101 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|335|[Help Farmer](http://codeforces.com/problemset/problem/142/A)|Codeforces|Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|336|[Terse princess](http://codeforces.com/problemset/problem/148/C)|Codeforces|Codeforces Round #105 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|337|[Wizards and Trolleybuses](http://codeforces.com/problemset/problem/167/A)|Codeforces|Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|338|[Permutations](http://codeforces.com/problemset/problem/187/A)|Codeforces|Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|339|[STL](http://codeforces.com/problemset/problem/190/C)|Codeforces|Codeforces Round #120 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|340|[Dynasty Puzzles](http://codeforces.com/problemset/problem/191/A)|Codeforces|Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|341|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces|Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|342|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces|Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|343|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces|Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|344|[Cycles](http://codeforces.com/problemset/problem/232/A)|Codeforces|Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|345|[Not Wool Sequences](http://codeforces.com/problemset/problem/238/A)|Codeforces|Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|346|[Beauty Pageant](http://codeforces.com/problemset/problem/246/C)|Codeforces|Codeforces Round #151 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|347|[Text Editor](http://codeforces.com/problemset/problem/253/C)|Codeforces|Codeforces Round #154 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|348|[Balls and Boxes](http://codeforces.com/problemset/problem/260/C)|Codeforces|Codeforces Round #158 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|349|[Shaass and Lights](http://codeforces.com/problemset/problem/294/C)|Codeforces|Codeforces Round #178 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|350|[Ivan and Powers of Two](http://codeforces.com/problemset/problem/305/C)|Codeforces|Codeforces Round #184 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|351|[Sereja and Contest](http://codeforces.com/problemset/problem/314/A)|Codeforces|Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|352|[Malek Dance Club](http://codeforces.com/problemset/problem/319/A)|Codeforces|Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|353|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces|Codeforces Round #195 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|354|[Cupboard and Balloons](http://codeforces.com/problemset/problem/342/C)|Codeforces|Codeforces Round #199 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|355|[Prime Number](http://codeforces.com/problemset/problem/359/C)|Codeforces|Codeforces Round #209 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|356|[Levko and Array Recovery](http://codeforces.com/problemset/problem/360/A)|Codeforces|Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|357|[Inna and Dima](http://codeforces.com/problemset/problem/374/C)|Codeforces|Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|358|[George and Number](http://codeforces.com/problemset/problem/387/C)|Codeforces|Codeforces Round #227 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|359|[Prime Swaps](http://codeforces.com/problemset/problem/432/C)|Codeforces|Codeforces Round #246 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|360|[Ryouko's Memory Note](http://codeforces.com/problemset/problem/433/C)|Codeforces|Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|361|[Borya and Hanabi](http://codeforces.com/problemset/problem/442/A)|Codeforces|Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|362|[Sums of Digits](http://codeforces.com/problemset/problem/509/C)|Codeforces|Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|363|[Mike and Frog](http://codeforces.com/problemset/problem/547/A)|Codeforces|Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|364|[Lengthening Sticks](http://codeforces.com/problemset/problem/571/A)|Codeforces|Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|365|[Wilbur and Points](http://codeforces.com/problemset/problem/596/C)|Codeforces|Codeforces Round #331 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|366|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces|Codeforces Round #338 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|367|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces|Codeforces Round #343 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|368|[Felicity is Coming!](http://codeforces.com/problemset/problem/757/C)|Codeforces|Codecraft-17 and Codeforces Round #391 (Div. 1 + Div. 2, combined)|5|
|<ul><li>- [ ] Done</li></ul>|369|[Two strings](http://codeforces.com/problemset/problem/762/C)|Codeforces|Educational Codeforces Round 17|5|
|<ul><li>- [ ] Done</li></ul>|370|[Berzerk](http://codeforces.com/problemset/problem/786/A)|Codeforces|Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|371|[Bank Hacking](http://codeforces.com/problemset/problem/796/C)|Codeforces|Codeforces Round #408 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|372|[Strange Game On Matrix](http://codeforces.com/problemset/problem/873/C)|Codeforces|Educational Codeforces Round 30|5|
|<ul><li>- [ ] Done</li></ul>|373|[Looking for Order](http://codeforces.com/problemset/problem/8/C)|Codeforces|Codeforces Beta Round #8|6|
|<ul><li>- [ ] Done</li></ul>|374|[Industrial Nim](http://codeforces.com/problemset/problem/15/C)|Codeforces|Codeforces Beta Round #15|6|
|<ul><li>- [ ] Done</li></ul>|375|[Stripe 2](http://codeforces.com/problemset/problem/21/C)|Codeforces|Codeforces Alpha Round #21 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|376|[System Administrator](http://codeforces.com/problemset/problem/22/C)|Codeforces|Codeforces Beta Round #22 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|377|[Shooting Gallery](http://codeforces.com/problemset/problem/30/C)|Codeforces|Codeforces Beta Round #30 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|378|[Schedule](http://codeforces.com/problemset/problem/31/C)|Codeforces|Codeforces Beta Round #31 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|379|[Flea](http://codeforces.com/problemset/problem/32/C)|Codeforces|Codeforces Beta Round #32 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|380|[Wonderful Randomized Sum](http://codeforces.com/problemset/problem/33/C)|Codeforces|Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|381|[Blinds](http://codeforces.com/problemset/problem/38/C)|Codeforces|School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|382|[Hamsters and Tigers](http://codeforces.com/problemset/problem/46/C)|Codeforces|School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|383|[Array](http://codeforces.com/problemset/problem/57/C)|Codeforces|Codeforces Beta Round #53|6|
|<ul><li>- [ ] Done</li></ul>|384|[Trees](http://codeforces.com/problemset/problem/58/C)|Codeforces|Codeforces Beta Round #54 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|385|[Title](http://codeforces.com/problemset/problem/59/C)|Codeforces|Codeforces Beta Round #55 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|386|[Bulls and Cows](http://codeforces.com/problemset/problem/63/C)|Codeforces|Codeforces Beta Round #59 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|387|[Heroes](http://codeforces.com/problemset/problem/77/A)|Codeforces|Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|388|[Beaver Game](http://codeforces.com/problemset/problem/78/C)|Codeforces|Codeforces Beta Round #70 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|389|[Beaver](http://codeforces.com/problemset/problem/79/C)|Codeforces|Codeforces Beta Round #71|6|
|<ul><li>- [ ] Done</li></ul>|390|[Robbery](http://codeforces.com/problemset/problem/89/A)|Codeforces|Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|391|[Hockey](http://codeforces.com/problemset/problem/95/A)|Codeforces|Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|392|[Hot Bath](http://codeforces.com/problemset/problem/126/A)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|393|[Police Station](http://codeforces.com/problemset/problem/208/C)|Codeforces|Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|394|[Game](http://codeforces.com/problemset/problem/213/A)|Codeforces|Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|395|[Hiring Staff](http://codeforces.com/problemset/problem/216/C)|Codeforces|Codeforces Round #133 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|396|[Reducing Fractions](http://codeforces.com/problemset/problem/222/C)|Codeforces|Codeforces Round #137 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|397|[Anagram](http://codeforces.com/problemset/problem/254/C)|Codeforces|Codeforces Round #155 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|398|[Below the Diagonal](http://codeforces.com/problemset/problem/266/C)|Codeforces|Codeforces Round #163 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|399|[Rectangle Puzzle](http://codeforces.com/problemset/problem/280/A)|Codeforces|Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|400|[Dima and Containers](http://codeforces.com/problemset/problem/358/C)|Codeforces|Codeforces Round #208 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|401|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces|Codeforces Round #212 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|402|[Mittens](http://codeforces.com/problemset/problem/370/C)|Codeforces|Codeforces Round #217 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|403|[Warrior and Archer](http://codeforces.com/problemset/problem/594/A)|Codeforces|Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|404|[International Olympiad](http://codeforces.com/problemset/problem/662/D)|Codeforces|CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|405|[Chris and Road](http://codeforces.com/problemset/problem/703/C)|Codeforces|Codeforces Round #365 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|406|[Commentator problem](http://codeforces.com/problemset/problem/2/C)|Codeforces|Codeforces Beta Round #2|7|
|<ul><li>- [ ] Done</li></ul>|407|[Digital Root](http://codeforces.com/problemset/problem/10/C)|Codeforces|Codeforces Beta Round #10|7|
|<ul><li>- [ ] Done</li></ul>|408|[Sequence of points](http://codeforces.com/problemset/problem/24/C)|Codeforces|Codeforces Beta Round #24|7|
|<ul><li>- [ ] Done</li></ul>|409|[Old Berland Language](http://codeforces.com/problemset/problem/37/C)|Codeforces|Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|410|[Disposition](http://codeforces.com/problemset/problem/49/C)|Codeforces|Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|411|[Three Base Stations](http://codeforces.com/problemset/problem/51/C)|Codeforces|Codeforces Beta Round #48|7|
|<ul><li>- [ ] Done</li></ul>|412|[First Digit Law](http://codeforces.com/problemset/problem/54/C)|Codeforces|Codeforces Beta Round #50|7|
|<ul><li>- [ ] Done</li></ul>|413|[Pie or die](http://codeforces.com/problemset/problem/55/C)|Codeforces|Codeforces Beta Round #51|7|
|<ul><li>- [ ] Done</li></ul>|414|[Corporation Mail](http://codeforces.com/problemset/problem/56/C)|Codeforces|Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|415|[Harry Potter and the Golden Snitch](http://codeforces.com/problemset/problem/65/C)|Codeforces|Codeforces Beta Round #60|7|
|<ul><li>- [ ] Done</li></ul>|416|[Petya and File System](http://codeforces.com/problemset/problem/66/C)|Codeforces|Codeforces Beta Round #61 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|417|[LionAge II](http://codeforces.com/problemset/problem/73/C)|Codeforces|Codeforces Beta Round #66|7|
|<ul><li>- [ ] Done</li></ul>|418|[Chessboard Billiard](http://codeforces.com/problemset/problem/74/C)|Codeforces|Codeforces Beta Round #68|7|
|<ul><li>- [ ] Done</li></ul>|419|[Biathlon](http://codeforces.com/problemset/problem/84/C)|Codeforces|Codeforces Beta Round #72 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|420|[Help Victoria the Wise](http://codeforces.com/problemset/problem/98/A)|Codeforces|Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|421|[Education Reform](http://codeforces.com/problemset/problem/119/C)|Codeforces|Codeforces Beta Round #90|7|
|<ul><li>- [ ] Done</li></ul>|422|[Geometry Horse](http://codeforces.com/problemset/problem/175/C)|Codeforces|Codeforces Round #115|7|
|<ul><li>- [ ] Done</li></ul>|423|[Try and Catch](http://codeforces.com/problemset/problem/195/C)|Codeforces|Codeforces Round #123 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|424|[Football Championship](http://codeforces.com/problemset/problem/200/C)|Codeforces|Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|425|[Robo-Footballer](http://codeforces.com/problemset/problem/248/C)|Codeforces|Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|426|[Circle of Numbers](http://codeforces.com/problemset/problem/263/C)|Codeforces|Codeforces Round #161 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|427|[Students' Revenge](http://codeforces.com/problemset/problem/332/C)|Codeforces|Codeforces Round #193 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|428|[Blocked Points](http://codeforces.com/problemset/problem/392/A)|Codeforces|Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|429|[On Number of Decompositions into Multipliers](http://codeforces.com/problemset/problem/396/A)|Codeforces|Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|430|[Cards](http://codeforces.com/problemset/problem/398/A)|Codeforces|Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|431|[Vladik and chat](http://codeforces.com/problemset/problem/754/C)|Codeforces|Codeforces Round #390 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|432|[How Many Squares?](http://codeforces.com/problemset/problem/11/C)|Codeforces|Codeforces Beta Round #11|8|
|<ul><li>- [ ] Done</li></ul>|433|[Balance](http://codeforces.com/problemset/problem/17/C)|Codeforces|Codeforces Beta Round #17|8|
|<ul><li>- [ ] Done</li></ul>|434|[Deletion of Repeats](http://codeforces.com/problemset/problem/19/C)|Codeforces|Codeforces Beta Round #19|8|
|<ul><li>- [ ] Done</li></ul>|435|[Oranges and Apples](http://codeforces.com/problemset/problem/23/C)|Codeforces|Codeforces Beta Round #23|8|
|<ul><li>- [ ] Done</li></ul>|436|[Parquet](http://codeforces.com/problemset/problem/26/C)|Codeforces|Codeforces Beta Round #26 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|437|[Bath Queue](http://codeforces.com/problemset/problem/28/C)|Codeforces|Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|438|[Safe cracking](http://codeforces.com/problemset/problem/42/C)|Codeforces|Codeforces Beta Round #41|8|
|<ul><li>- [ ] Done</li></ul>|439|[Crossword](http://codeforces.com/problemset/problem/47/C)|Codeforces|Codeforces Beta Round #44 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|440|[The Race](http://codeforces.com/problemset/problem/48/C)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|441|[Happy Farm 5](http://codeforces.com/problemset/problem/50/C)|Codeforces|Codeforces Beta Round #47|8|
|<ul><li>- [ ] Done</li></ul>|442|[Mushroom Strife](http://codeforces.com/problemset/problem/60/C)|Codeforces|Codeforces Beta Round #56|8|
|<ul><li>- [ ] Done</li></ul>|443|[Capture Valerian](http://codeforces.com/problemset/problem/61/C)|Codeforces|Codeforces Beta Round #57 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|444|[Game](http://codeforces.com/problemset/problem/69/C)|Codeforces|Codeforces Beta Round #63 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|445|[Lucky Tickets](http://codeforces.com/problemset/problem/70/C)|Codeforces|Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|446|[Optimal Sum](http://codeforces.com/problemset/problem/182/C)|Codeforces|Codeforces Round #117 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|447|[Crosses](http://codeforces.com/problemset/problem/215/C)|Codeforces|Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|448|[Fractal Detector](http://codeforces.com/problemset/problem/228/C)|Codeforces|Codeforces Round #141 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|449|[Inna and Candy Boxes](http://codeforces.com/problemset/problem/390/C)|Codeforces|Codeforces Round #229 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|450|[Dominoes](http://codeforces.com/problemset/problem/394/C)|Codeforces|Codeforces Round #231 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|451|[Bowls](http://codeforces.com/problemset/problem/36/C)|Codeforces|Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|452|[Berland Square](http://codeforces.com/problemset/problem/40/C)|Codeforces|Codeforces Beta Round #39|9|
|<ul><li>- [ ] Done</li></ul>|453|[Inquisition](http://codeforces.com/problemset/problem/62/C)|Codeforces|Codeforces Beta Round #58|9|
|<ul><li>- [ ] Done</li></ul>|454|[Synchrophasotron](http://codeforces.com/problemset/problem/68/C)|Codeforces|Codeforces Beta Round #62|9|
|<ul><li>- [ ] Done</li></ul>|455|[Item World](http://codeforces.com/problemset/problem/105/C)|Codeforces|Codeforces Beta Round #81|9|
|<ul><li>- [ ] Done</li></ul>|456|[Beautiful Function](http://codeforces.com/problemset/problem/593/C)|Codeforces|Codeforces Round #329 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|457|[Fire in the City](http://codeforces.com/problemset/problem/845/E)|Codeforces|Educational Codeforces Round 27|9|
|<ul><li>- [ ] Done</li></ul>|458|[Strange Radiation](http://codeforces.com/problemset/problem/832/C)|Codeforces|Codeforces Round #425 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|459|[Mister B and Boring Game](http://codeforces.com/problemset/problem/819/A)|Codeforces|Codeforces Round #421 (Div. 1) & Codeforces Round #421 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|460|[Maze 2D](http://codeforces.com/problemset/problem/413/E)|Codeforces|Coder-Strike 2014 - Round 2|9|
