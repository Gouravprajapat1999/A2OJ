# 145. maxflow


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Omar](p?ID=1)|A2 Online Judge|1|
|<ul><li>- [ ] Done</li></ul>|2|[The 3n + 1 problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=36)|UVA|1|
