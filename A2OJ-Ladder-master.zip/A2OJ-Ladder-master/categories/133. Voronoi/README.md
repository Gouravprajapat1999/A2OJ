# 133. Voronoi


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Run Away](http://www.spoj.com/problems/RUNAWAY/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|2|[Bacterial](http://www.spoj.com/problems/BAC/)|SPOJ|5|
