# 046. expresison_and_parsing


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Borze](http://codeforces.com/problemset/problem/32/B)|Codeforces|Codeforces Beta Round #32 (Div. 2, Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Transform the Expression](http://www.spoj.com/problems/ONP/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Complicated Expressions](http://www.spoj.com/problems/CMEXPR/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|4|[Any fool can do it](http://www.spoj.com/problems/FOOL/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|5|[Going to school](http://www.spoj.com/problems/GS/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|6|[Replace To Make Regular Bracket Sequence](http://codeforces.com/problemset/problem/612/C)|Codeforces|Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|7|[Page Numbers](http://codeforces.com/problemset/problem/34/C)|Codeforces|Codeforces Beta Round #34 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|8|[Rebus](http://codeforces.com/problemset/problem/663/A)|Codeforces|Codeforces Round #347 (Div. 1) & Codeforces Round #347 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|9|[Facetook Priority Wall](http://codeforces.com/problemset/problem/75/B)|Codeforces|Codeforces Beta Round #67 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|10|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces|Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|11|[Email address](http://codeforces.com/problemset/problem/41/C)|Codeforces|Codeforces Beta Round #40 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|12|[Boolean Logic](http://www.spoj.com/problems/BOOLE/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|13|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces|Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|14|[Cells](http://www.spoj.com/problems/IPCELLS/)|SPOJ||5|
|<ul><li>- [ ] Done</li></ul>|15|[Text Messaging](http://codeforces.com/problemset/problem/70/B)|Codeforces|Codeforces Beta Round #64|6|
|<ul><li>- [ ] Done</li></ul>|16|[Title](http://codeforces.com/problemset/problem/59/C)|Codeforces|Codeforces Beta Round #55 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|17|[A - Comparison Expressions](http://www.spoj.com/problems/BOCOMP/)|SPOJ||6|
|<ul><li>- [ ] Done</li></ul>|18|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces|Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|19|[Programming Language](http://codeforces.com/problemset/problem/200/D)|Codeforces|Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|20|[Try and Catch](http://codeforces.com/problemset/problem/195/C)|Codeforces|Codeforces Round #123 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|21|[Corporation Mail](http://codeforces.com/problemset/problem/56/C)|Codeforces|Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|22|[bHTML Tables Analisys](http://codeforces.com/problemset/problem/51/B)|Codeforces|Codeforces Beta Round #48|7|
|<ul><li>- [ ] Done</li></ul>|23|[C*++ Calculations](http://codeforces.com/problemset/problem/39/A)|Codeforces|School Team Contest #1 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|24|[Defining Macros](http://codeforces.com/problemset/problem/7/E)|Codeforces|Codeforces Beta Round #7|8|
|<ul><li>- [ ] Done</li></ul>|25|[Expression](http://codeforces.com/problemset/problem/64/B)|Codeforces|Unknown Language Round #1|8|
|<ul><li>- [ ] Done</li></ul>|26|[Widget Library](http://codeforces.com/problemset/problem/89/B)|Codeforces|Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|27|[BHTML+BCSS](http://codeforces.com/problemset/problem/172/E)|Codeforces|Croc Champ 2012 - Qualification Round|9|
|<ul><li>- [ ] Done</li></ul>|28|[Formurosa](http://codeforces.com/problemset/problem/217/C)|Codeforces|Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|29|[Unambiguous Arithmetic Expression](http://codeforces.com/problemset/problem/115/D)|Codeforces|Codeforces Beta Round #87 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|30|[Perse-script](http://codeforces.com/problemset/problem/72/D)|Codeforces|Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|31|[Domain](http://codeforces.com/problemset/problem/64/F)|Codeforces|Unknown Language Round #1|10|
|<ul><li>- [ ] Done</li></ul>|32|[Stack](http://codeforces.com/problemset/problem/188/H)|Codeforces|Surprise Language Round #6|10|
|<ul><li>- [ ] Done</li></ul>|33|[Boolean Function](http://codeforces.com/problemset/problem/582/E)|Codeforces|Codeforces Round #323 (Div. 1)|10|
