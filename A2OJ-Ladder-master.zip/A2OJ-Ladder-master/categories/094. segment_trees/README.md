# 094. segment_trees


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Light Switching](http://www.spoj.com/problems/LITE/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Can you answer these queries I](http://www.spoj.com/problems/GSS1/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|3|[Can you answer these queries II](http://www.spoj.com/problems/GSS2/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|4|[Can you answer these queries III](http://www.spoj.com/problems/GSS3/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|5|[Maximum Sum](http://www.spoj.com/problems/KGSS/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|6|[Building Bridges(HARD)](http://www.spoj.com/problems/BRDGHRD/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|7|[Brackets](http://www.spoj.com/problems/BRKTS/)|SPOJ|3|
