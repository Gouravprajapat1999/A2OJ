# 025. probabilities


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Die Roll](http://codeforces.com/problemset/problem/9/A)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|2|[To the Max](http://poj.org/problem?id=1050)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Cows and Cars](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1432)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Yanu in Movie theatre](http://www.spoj.com/problems/FUNPROB/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[What is the Probability ?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=997)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Probability One](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2737)|Live Archive|2009|Africa/Middle East - Africa and Arab|1|
|<ul><li>- [ ] Done</li></ul>|8|[Counting Extra Stars](p?ID=356)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Archer](http://codeforces.com/problemset/problem/312/B)|Codeforces||Codeforces Round #185 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|10|[Collecting Bugs](http://poj.org/problem?id=2096)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|11|[Football](http://poj.org/problem?id=3071)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|12|[Check the difficulty of problems](http://poj.org/problem?id=2151)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|13|[One Person Game](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=3329)|ZOJ|||2|
|<ul><li>- [ ] Done</li></ul>|14|[Help Me Escape](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=3640)|ZOJ|||2|
|<ul><li>- [ ] Done</li></ul>|15|[Little Pony and Expected Maximum](http://codeforces.com/problemset/problem/453/A)|Codeforces||Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|16|[Dice Throwing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1700)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|17|[France '98](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=483)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|18|[Journey](http://codeforces.com/problemset/problem/839/C)|Codeforces||Codeforces Round #428 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|19|[BirthdayOdds](http://community.topcoder.com/stat?c=problem_statement&pm=1848)|TopCoder||SRM 174 - Div1 easy - Div2 medium] (4675)|3|
|<ul><li>- [ ] Done</li></ul>|20|[PipeCuts](http://community.topcoder.com/stat?c=problem_statement&pm=3994)|TopCoder||SRM 233 - Div1 easy - Div2 medium] (6532)|3|
|<ul><li>- [ ] Done</li></ul>|21|[Coupons](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1229)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|22|[Burger](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=498)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|23|[Scout YYF I](http://poj.org/problem?id=3744)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|24|[Chocolate](http://poj.org/problem?id=1322)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|25|[?????](http://poj.org/problem?id=1189)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|26|[Hats](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3175)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|27|[Wet Shark and Flowers](http://codeforces.com/problemset/problem/621/C)|Codeforces||Codeforces Round #341 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|28|[Ilya and Escalator](http://codeforces.com/problemset/problem/518/D)|Codeforces||Codeforces Round #293 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|29|[Andrey and Problem](http://codeforces.com/problemset/problem/442/B)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|30|[Another lottery](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2675)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|31|[So you want to be a 2n-aire?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1841)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|32|[PrimeSoccer](http://community.topcoder.com/stat?c=problem_statement&pm=10033)|TopCoder||SRM 422 - Div1 easy - Div2 medium] (13513)|3|
|<ul><li>- [ ] Done</li></ul>|33|[FixedDiceGameDiv1](http://community.topcoder.com/stat?c=problem_statement&pm=13239)|TopCoder||SRM 626 - Div1 easy] (15859)|3|
|<ul><li>- [ ] Done</li></ul>|34|[PalindromicSubstringsDiv1](http://community.topcoder.com/stat?c=problem_statement&pm=12964)|TopCoder||Unknown ()|3|
|<ul><li>- [ ] Done</li></ul>|35|[Bag of mice](http://codeforces.com/problemset/problem/148/D)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|36|[Vampires](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2495)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|37|[God! Save me](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1718)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|38|[Expect the Expected](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2422)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|39|[Dumb Bones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1470)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|40|[Panda's Birthday Present](http://poj.org/problem?id=3716)|PKU|||4|
|<ul><li>- [ ] Done</li></ul>|41|[Patchouli's Spell Cards](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=3380)|ZOJ|||4|
|<ul><li>- [ ] Done</li></ul>|42|[Bad Luck Island](http://codeforces.com/problemset/problem/540/D)|Codeforces||Codeforces Round #301 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|43|[Race to 1](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2862)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|44|[Probability](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2321)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|45|[Winning Streak](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2117)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|46|[Chocolate Box](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1589)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|47|[Boastin' Red Socks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1218)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|48|[Urn-ball Probabilities!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1110)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|49|[MonstersAndBunnies](http://community.topcoder.com/stat?c=problem_statement&pm=8595)|TopCoder||TCO08 Qual 1 - Div1 easy] (12007)|4|
|<ul><li>- [ ] Done</li></ul>|50|[Basketball Team](http://codeforces.com/problemset/problem/107/B)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|51|[Falling Anvils](http://codeforces.com/problemset/problem/77/B)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|52|[ProbabilityTree](http://community.topcoder.com/stat?c=problem_statement&pm=2234)|TopCoder||SRM 174 - Div2 hard] (4675)|5|
|<ul><li>- [ ] Done</li></ul>|53|[ChessKnight](http://community.topcoder.com/stat?c=problem_statement&pm=3509)|TopCoder||TCCC05 Round 1 - Div1 medium] (6528)|5|
|<ul><li>- [ ] Done</li></ul>|54|[Collision](http://community.topcoder.com/stat?c=problem_statement&pm=1771)|TopCoder||SRM 153 - Div1 medium] (4570)|5|
|<ul><li>- [ ] Done</li></ul>|55|[Jerry's Protest](http://codeforces.com/problemset/problem/626/D)|Codeforces||8VC Venture Cup 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|56|[Jeff and Furik](http://codeforces.com/problemset/problem/351/B)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|57|[Joining with Friend](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2769)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|58|[Dragster](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2727)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|59|[Lights inside a 3d Grid](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2652)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|60|[Masud Rana](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2647)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|61|[RandomSwaps](http://community.topcoder.com/stat?c=problem_statement&pm=7289)|TopCoder||SRM 338 - Div1 medium] (10662)|5|
|<ul><li>- [ ] Done</li></ul>|62|[KthProbableElement](http://community.topcoder.com/stat?c=problem_statement&pm=10335)|TopCoder||TCO09 Round 1 - Div1 medium] (13759)|5|
|<ul><li>- [ ] Done</li></ul>|63|[LotteryPyaterochka](http://community.topcoder.com/stat?c=problem_statement&pm=10863)|TopCoder||SRM 466 - Div1 medium] (14150)|5|
|<ul><li>- [ ] Done</li></ul>|64|[RandomSort](http://community.topcoder.com/stat?c=problem_statement&pm=8590)|TopCoder||SRM 402 - Div1 easy - Div2 hard] (12174)|5|
|<ul><li>- [ ] Done</li></ul>|65|[QuickSort](http://community.topcoder.com/stat?c=problem_statement&pm=10996)|TopCoder||SRM 486 - Div1 medium] (14239)|5|
|<ul><li>- [ ] Done</li></ul>|66|[RedIsGood](http://community.topcoder.com/stat?c=problem_statement&pm=9915)|TopCoder||SRM 420 - Div1 medium] (13511)|5|
|<ul><li>- [ ] Done</li></ul>|67|[TestBettingStrategy](http://community.topcoder.com/stat?c=problem_statement&pm=7422)|TopCoder||SRM 339 - Div1 medium] (10663)|5|
|<ul><li>- [ ] Done</li></ul>|68|[CampaignTrail](http://community.topcoder.com/stat?c=problem_statement&pm=10188)|TopCoder||TCO09 Round 3 - Div1 medium] (13761)|5|
|<ul><li>- [ ] Done</li></ul>|69|[PerfectMemory](http://community.topcoder.com/stat?c=problem_statement&pm=11500)|TopCoder||SRM 513 - Div1 medium] (14538)|5|
|<ul><li>- [ ] Done</li></ul>|70|[CandyBox](http://community.topcoder.com/stat?c=problem_statement&pm=10744)|TopCoder||SRM 462 - Div1 medium] (14147)|5|
|<ul><li>- [ ] Done</li></ul>|71|[TheFansAndMeetingsDivOne](http://community.topcoder.com/stat?c=problem_statement&pm=10771)|TopCoder||SRM 460 - Div1 medium] (14146)|5|
|<ul><li>- [ ] Done</li></ul>|72|[DrawingLines](http://community.topcoder.com/stat?c=problem_statement&pm=10735)|TopCoder||SRM 470 - Div1 medium] (14153)|5|
|<ul><li>- [ ] Done</li></ul>|73|[Let's Play Osu!](http://codeforces.com/problemset/problem/235/B)|Codeforces||Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|74|[Wizards and Huge Prize](http://codeforces.com/problemset/problem/167/B)|Codeforces||Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|75|[Lucky Probability](http://codeforces.com/problemset/problem/109/B)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|76|[Shooting Gallery](http://codeforces.com/problemset/problem/30/C)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|77|[Fish](http://codeforces.com/problemset/problem/16/E)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|78|[Join two kingdoms](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4415)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|79|[ETS Problem setting](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2425)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|80|[Magic Trick](http://codeforces.com/problemset/problem/452/C)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|81|[Map Generator](http://poj.org/problem?id=3557)|PKU|||6|
|<ul><li>- [ ] Done</li></ul>|82|[Chess Game](http://poj.org/problem?id=3756)|PKU|||6|
|<ul><li>- [ ] Done</li></ul>|83|[Second price auction](http://codeforces.com/problemset/problem/513/C)|Codeforces||Rockethon 2015|6|
|<ul><li>- [ ] Done</li></ul>|84|[Game on Tree](http://codeforces.com/problemset/problem/280/C)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|85|[Maxim and Restaurant](http://codeforces.com/problemset/problem/261/B)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|86|[Prisoners, Boxes and Pieces of Paper](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2059)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|87|[AlternatingLane](http://community.topcoder.com/stat?c=problem_statement&pm=11309)|TopCoder||Member SRM 494 - Div1 medium - Div2 hard] (14423)|6|
|<ul><li>- [ ] Done</li></ul>|88|[ZS and The Birthday Paradox](http://codeforces.com/problemset/problem/711/E)|Codeforces||Codeforces Round #369 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|89|[Ada and Island](http://www.spoj.com/problems/ADASEA/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|90|[Little Elephant and Furik and Rubik](http://codeforces.com/problemset/problem/204/C)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|91|[Mushroom Gnomes - 2](http://codeforces.com/problemset/problem/138/C)|Codeforces||Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|92|[Dark Assembly](http://codeforces.com/problemset/problem/105/B)|Codeforces||Codeforces Beta Round #81|7|
|<ul><li>- [ ] Done</li></ul>|93|[First Digit Law](http://codeforces.com/problemset/problem/54/C)|Codeforces||Codeforces Beta Round #50|7|
|<ul><li>- [ ] Done</li></ul>|94|[Playing War](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2002)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|95|[Little Artem and Random Variable](http://codeforces.com/problemset/problem/641/D)|Codeforces||VK Cup 2016 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|96|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces||Codeforces Round #343 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|97|[Kleofáš and the n-thlon](http://codeforces.com/problemset/problem/601/C)|Codeforces||Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|98|[Name That Tune](http://codeforces.com/problemset/problem/498/B)|Codeforces||Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|99|[DZY Loves FFT](http://codeforces.com/problemset/problem/444/B)|Codeforces||Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|100|[Square Table](http://codeforces.com/problemset/problem/417/E)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|101|[Painting The Wall](http://codeforces.com/problemset/problem/398/B)|Codeforces||Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|102|[Playlist](http://codeforces.com/problemset/problem/268/E)|Codeforces||Codeforces Round #164 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|103|[Dexterina’s Lab](http://codeforces.com/problemset/problem/717/D)|Codeforces||Bubble Cup 9 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|104|[Table Tennis](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2855)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|105|[Garbage Remembering Exam](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2684)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|106|[Gifts](http://codeforces.com/problemset/problem/229/E)|Codeforces||Codeforces Round #142 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|107|[Smart Cheater](http://codeforces.com/problemset/problem/150/C)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|108|[Castle](http://codeforces.com/problemset/problem/101/D)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|109|[Petya and Tree](http://codeforces.com/problemset/problem/85/C)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|110|[Bombing](http://codeforces.com/problemset/problem/50/D)|Codeforces||Codeforces Beta Round #47|8|
|<ul><li>- [ ] Done</li></ul>|111|[Bath Queue](http://codeforces.com/problemset/problem/28/C)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|112|[Tickets](http://codeforces.com/problemset/problem/26/D)|Codeforces||Codeforces Beta Round #26 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|113|[Broken robot](http://codeforces.com/problemset/problem/24/D)|Codeforces||Codeforces Beta Round #24|8|
|<ul><li>- [ ] Done</li></ul>|114|[World of Darkraft - 2](http://codeforces.com/problemset/problem/464/D)|Codeforces||Codeforces Round #265 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|115|[Startup Funding](http://codeforces.com/problemset/problem/633/E)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|116|[Intergalaxy Trips](http://codeforces.com/problemset/problem/605/E)|Codeforces||Codeforces Round #335 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|117|[Wilbur and Trees](http://codeforces.com/problemset/problem/596/D)|Codeforces||Codeforces Round #331 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|118|[Inversions problem](http://codeforces.com/problemset/problem/513/G2)|Codeforces||Rockethon 2015|8|
|<ul><li>- [ ] Done</li></ul>|119|[Helping People](http://codeforces.com/problemset/problem/494/C)|Codeforces||Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|120|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|121|[Ghd](http://codeforces.com/problemset/problem/364/D)|Codeforces||Codeforces Round #213 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|122|[Expecting Trouble](http://codeforces.com/problemset/problem/345/A)|Codeforces||Friday the 13th, Programmers Day|8|
|<ul><li>- [ ] Done</li></ul>|123|[Little Elephant and Broken Sorting](http://codeforces.com/problemset/problem/258/D)|Codeforces||Codeforces Round #157 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|124|[SPAM! (or not)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2666)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|125|[Fixing the Bugs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2596)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|126|[Destiny](http://codeforces.com/problemset/problem/840/D)|Codeforces||Codeforces Round #429 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|127|[Willem, Chtholly and Seniorious](http://codeforces.com/problemset/problem/896/C)|Codeforces||Codeforces Round #449 (Div. 1) & Codeforces Round #449 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|128|[Inversions After Shuffle](http://codeforces.com/problemset/problem/749/E)|Codeforces||Codeforces Round #388 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|129|[Eyes Closed](http://codeforces.com/problemset/problem/895/E)|Codeforces||Codeforces Round #448 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|130|[Memory and Casinos](http://codeforces.com/problemset/problem/712/E)|Codeforces||Codeforces Round #370 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|131|[Piglet's Birthday](http://codeforces.com/problemset/problem/248/E)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|132|[T-shirt](http://codeforces.com/problemset/problem/183/D)|Codeforces||Croc Champ 2012 - Final|9|
|<ul><li>- [ ] Done</li></ul>|133|[Plane of Tanks: Duel](http://codeforces.com/problemset/problem/175/D)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|134|[Maze](http://codeforces.com/problemset/problem/123/E)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|135|[Museum](http://codeforces.com/problemset/problem/113/D)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|136|[Half-decay tree](http://codeforces.com/problemset/problem/68/D)|Codeforces||Codeforces Beta Round #62|9|
|<ul><li>- [ ] Done</li></ul>|137|[NestedRandomness](http://community.topcoder.com/stat?c=problem_statement&pm=3510)|TopCoder||TCCC05 Qual 5 - Div1 hard] (6527)|9|
|<ul><li>- [ ] Done</li></ul>|138|[World of Darkraft](http://codeforces.com/problemset/problem/138/D)|Codeforces||Codeforces Beta Round #99 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|139|[Gambling Nim](http://codeforces.com/problemset/problem/662/A)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|9|
|<ul><li>- [ ] Done</li></ul>|140|[Birthday](http://codeforces.com/problemset/problem/623/D)|Codeforces||AIM Tech Round (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|141|[Randomizer](http://codeforces.com/problemset/problem/559/D)|Codeforces||Codeforces Round #313 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|142|[Ksusha and Square](http://codeforces.com/problemset/problem/293/D)|Codeforces||Croc Champ 2013 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|143|[Google Code Jam](http://codeforces.com/problemset/problem/277/D)|Codeforces||Codeforces Round #170 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|144|[Darts](http://codeforces.com/problemset/problem/107/E)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|145|[Help Shrek and Donkey](http://codeforces.com/problemset/problem/98/E)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|146|[Help King](http://codeforces.com/problemset/problem/98/B)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|10|
|<ul><li>- [ ] Done</li></ul>|147|[Rubik's Cube: 0-1 Version](http://poj.org/problem?id=3701)|PKU|||10|
|<ul><li>- [ ] Done</li></ul>|148|[Combining Slimes](http://codeforces.com/problemset/problem/618/G)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|10|
|<ul><li>- [ ] Done</li></ul>|149|[Kyoya and Train](http://codeforces.com/problemset/problem/553/E)|Codeforces||Codeforces Round #309 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|150|[Bingo!](http://codeforces.com/problemset/problem/457/D)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|151|[DZY Loves Games](http://codeforces.com/problemset/problem/446/D)|Codeforces||Codeforces Round #255 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|152|[Colored Jenga](http://codeforces.com/problemset/problem/424/E)|Codeforces||Codeforces Round #242 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|153|[Counting Skyscrapers](http://codeforces.com/problemset/problem/335/E)|Codeforces||MemSQL start[c]up Round 2 - online version|10|
