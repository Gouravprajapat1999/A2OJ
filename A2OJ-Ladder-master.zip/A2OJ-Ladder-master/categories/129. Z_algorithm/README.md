# 129. Z_algorithm


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Query Problem](http://www.spoj.com/problems/QUERYSTR/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|2|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces|Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|3|[Ancient Prophesy](http://codeforces.com/problemset/problem/260/B)|Codeforces|Codeforces Round #158 (Div. 2)|4|
