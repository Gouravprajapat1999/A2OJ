# 006. brute_force


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Team](http://codeforces.com/problemset/problem/231/A)|Codeforces||Codeforces Round #143 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[System of Equations](http://codeforces.com/problemset/problem/214/A)|Codeforces||Codeforces Round #131 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Hexadecimal's theorem](http://codeforces.com/problemset/problem/199/A)|Codeforces||Codeforces Round #125 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces||Codeforces Round #119 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[I_love_\%username\%](http://codeforces.com/problemset/problem/155/A)|Codeforces||Codeforces Round #109 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Lucky Division](http://codeforces.com/problemset/problem/122/A)|Codeforces||Codeforces Beta Round #91 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Lucky Sum of Digits](http://codeforces.com/problemset/problem/109/A)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|8|[IQ test](http://codeforces.com/problemset/problem/25/A)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Triangle](http://codeforces.com/problemset/problem/6/A)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Candy](http://www.spoj.com/problems/SAMER08C/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Candy I](http://www.spoj.com/problems/CANDY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Grouping Problem](http://acm.tju.edu.cn/toj/showp2821.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Play with Dates](http://www.spoj.com/problems/CODEIT03/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[Pangram](http://codeforces.com/problemset/problem/520/A)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Burger Time?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2708)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Far Relative’s Birthday Cake](http://codeforces.com/problemset/problem/629/A)|Codeforces||Codeforces Round #343 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Kefa and First Steps](http://codeforces.com/problemset/problem/580/A)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Gerald's Hexagon](http://codeforces.com/problemset/problem/559/A)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Lala Land and Apple Trees](http://codeforces.com/problemset/problem/558/A)|Codeforces||Codeforces Round #312 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Kyoya and Photobooks](http://codeforces.com/problemset/problem/554/A)|Codeforces||Codeforces Round #309 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[Divisibility by Eight](http://codeforces.com/problemset/problem/550/C)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[Preparing Olympiad](http://codeforces.com/problemset/problem/550/B)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Mike and Fax](http://codeforces.com/problemset/problem/548/A)|Codeforces||Codeforces Round #305 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Soldier and Cards](http://codeforces.com/problemset/problem/546/C)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|27|[Soldier and Badges](http://codeforces.com/problemset/problem/546/B)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Tavas and SaDDas](http://codeforces.com/problemset/problem/535/B)|Codeforces||Codeforces Round #299 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Maximum in Table](http://codeforces.com/problemset/problem/509/A)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Minimum Difficulty](http://codeforces.com/problemset/problem/496/A)|Codeforces||Codeforces Round #283 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Giga Tower](http://codeforces.com/problemset/problem/488/A)|Codeforces||Codeforces Round #278 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Counterexample ](http://codeforces.com/problemset/problem/483/A)|Codeforces||Codeforces Round #275 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Expression](http://codeforces.com/problemset/problem/479/A)|Codeforces||Codeforces Round #274 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|35|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces||Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|37|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|38|[Appleman and Easy Task](http://codeforces.com/problemset/problem/462/A)|Codeforces||Codeforces Round #263 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Vasya and Socks](http://codeforces.com/problemset/problem/460/A)|Codeforces||Codeforces Round #262 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Bear and Raspberry](http://codeforces.com/problemset/problem/385/A)|Codeforces||Codeforces Round #226 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|41|[Playing with Dice](http://codeforces.com/problemset/problem/378/A)|Codeforces||Codeforces Round #222 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|42|[Fence](http://codeforces.com/problemset/problem/363/B)|Codeforces||Codeforces Round #211 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|43|[Jeff and Digits](http://codeforces.com/problemset/problem/352/A)|Codeforces||Codeforces Round #204 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|44|[TL](http://codeforces.com/problemset/problem/350/A)|Codeforces||Codeforces Round #203 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|45|[Cakeminator](http://codeforces.com/problemset/problem/330/A)|Codeforces||Codeforces Round #192 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|46|[Flipping Game](http://codeforces.com/problemset/problem/327/A)|Codeforces||Codeforces Round #191 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|47|[Magic Numbers](http://codeforces.com/problemset/problem/320/A)|Codeforces||Codeforces Round #189 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|48|[Array](http://codeforces.com/problemset/problem/300/A)|Codeforces||Codeforces Round #181 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|49|[Books](http://codeforces.com/problemset/problem/279/B)|Codeforces||Codeforces Round #171 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|50|[Beautiful Year](http://codeforces.com/problemset/problem/271/A)|Codeforces||Codeforces Round #166 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|51|[Games](http://codeforces.com/problemset/problem/268/A)|Codeforces||Codeforces Round #164 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|52|[Parallelepiped](http://codeforces.com/problemset/problem/224/A)|Codeforces||Codeforces Round #138 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|53|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces||Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|54|[Panoramix's Prediction](http://codeforces.com/problemset/problem/80/A)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|55|[Watermelon](http://codeforces.com/problemset/problem/4/A)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|56|[Bus to Udayland](http://codeforces.com/problemset/problem/711/A)|Codeforces||Codeforces Round #369 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|57|[Taymyr is calling you](http://codeforces.com/problemset/problem/764/A)|Codeforces||Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|58|[Fraction](http://codeforces.com/problemset/problem/854/A)|Codeforces||Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|1|
|<ul><li>- [ ] Done</li></ul>|59|[QAQ](http://codeforces.com/problemset/problem/894/A)|Codeforces||Codeforces Round #447 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|60|[Vladik and Courtesy](http://codeforces.com/problemset/problem/811/A)|Codeforces||Codeforces Round #416 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|61|[Generous Kefa](http://codeforces.com/problemset/problem/841/A)|Codeforces||Codeforces Round #429 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|62|[Mike and palindrome](http://codeforces.com/problemset/problem/798/A)|Codeforces||Codeforces Round #410 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|63|[Beru-taxi](http://codeforces.com/problemset/problem/706/A)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|64|[Karen and Morning](http://codeforces.com/problemset/problem/816/A)|Codeforces||Codeforces Round #419 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|65|[The Artful Expedient](http://codeforces.com/problemset/problem/869/A)|Codeforces||Codeforces Round #439 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|66|[The Monster](http://codeforces.com/problemset/problem/787/A)|Codeforces||Codeforces Round #406 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|67|[Arpa’s hard exam and Mehrdad’s naive cheat](http://codeforces.com/problemset/problem/742/A)|Codeforces||Codeforces Round #383 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|68|[Little Elephant and Magic Square](http://codeforces.com/problemset/problem/259/B)|Codeforces||Codeforces Round #157 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|69|[Shooshuns and Sequence ](http://codeforces.com/problemset/problem/222/A)|Codeforces||Codeforces Round #137 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|70|[Bicycle Chain](http://codeforces.com/problemset/problem/215/A)|Codeforces||Codeforces Round #132 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|71|[Prizes, Prizes, more Prizes](http://codeforces.com/problemset/problem/208/D)|Codeforces||Codeforces Round #130 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|72|[Little Elephant and Rozdil](http://codeforces.com/problemset/problem/205/A)|Codeforces||Codeforces Round #129 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|73|[Ice Sculptures](http://codeforces.com/problemset/problem/158/D)|Codeforces||VK Cup 2012 Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|74|[Game Outcome](http://codeforces.com/problemset/problem/157/A)|Codeforces||Codeforces Round #110 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|75|[Help Vasilisa the Wise 2](http://codeforces.com/problemset/problem/143/A)|Codeforces||Codeforces Round #102 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|76|[Lucky Substring](http://codeforces.com/problemset/problem/122/B)|Codeforces||Codeforces Beta Round #91 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|77|[Lucky Numbers (easy)](http://codeforces.com/problemset/problem/96/B)|Codeforces||Codeforces Beta Round #77 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|78|[Petya and Countryside](http://codeforces.com/problemset/problem/66/B)|Codeforces||Codeforces Beta Round #61 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|79|[Triangular numbers](http://codeforces.com/problemset/problem/47/A)|Codeforces||Codeforces Beta Round #44 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|80|[Second Order Statistics](http://codeforces.com/problemset/problem/22/A)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|81|[Hexadecimal's Numbers](http://codeforces.com/problemset/problem/9/C)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|82|[GRADE POINT AVERAGE](http://www.spoj.com/problems/GPA1/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|83|[Dima and Continuous Line](http://codeforces.com/problemset/problem/358/A)|Codeforces||Codeforces Round #208 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|84|[Bear and Three Balls](http://codeforces.com/problemset/problem/653/A)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|85|[Ebony and Ivory](http://codeforces.com/problemset/problem/633/A)|Codeforces||Manthan, Codefest 16|2|
|<ul><li>- [ ] Done</li></ul>|86|[Interview](http://codeforces.com/problemset/problem/631/A)|Codeforces||Codeforces Round #344 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|87|[Far Relative’s Problem](http://codeforces.com/problemset/problem/629/B)|Codeforces||Codeforces Round #343 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|88|[Robot Sequence](http://codeforces.com/problemset/problem/626/A)|Codeforces||8VC Venture Cup 2016 - Elimination Round|2|
|<ul><li>- [ ] Done</li></ul>|89|[Link/Cut Tree](http://codeforces.com/problemset/problem/614/A)|Codeforces||Codeforces Round #339 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|90|[New Year and Old Property](http://codeforces.com/problemset/problem/611/B)|Codeforces||Good Bye 2015|2|
|<ul><li>- [ ] Done</li></ul>|91|[2Char](http://codeforces.com/problemset/problem/593/A)|Codeforces||Codeforces Round #329 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|92|[Bear and Three Musketeers](http://codeforces.com/problemset/problem/574/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|93|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces||Codeforces Round #310 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|94|[Ohana Cleans Up](http://codeforces.com/problemset/problem/554/B)|Codeforces||Codeforces Round #309 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|95|[Mike and Fun](http://codeforces.com/problemset/problem/548/B)|Codeforces||Codeforces Round #305 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|96|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|97|[Cutting Banner](http://codeforces.com/problemset/problem/538/A)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|98|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces||Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|99|[Pasha and Pixels](http://codeforces.com/problemset/problem/508/A)|Codeforces||Codeforces Round #288 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|100|[Mr. Kitayuta's Gift](http://codeforces.com/problemset/problem/505/A)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|101|[Removing Columns](http://codeforces.com/problemset/problem/496/C)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|102|[Hacking Cypher](http://codeforces.com/problemset/problem/490/C)|Codeforces||Codeforces Round #279 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|103|[Valuable Resources](http://codeforces.com/problemset/problem/485/B)|Codeforces||Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|104|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces||Codeforces Round #274 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|105|[Strongly Connected City](http://codeforces.com/problemset/problem/475/B)|Codeforces||Bayan 2015 Contest Warm Up|2|
|<ul><li>- [ ] Done</li></ul>|106|[Little Dima and Equation](http://codeforces.com/problemset/problem/460/B)|Codeforces||Codeforces Round #262 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|107|[Multiplication Table](http://codeforces.com/problemset/problem/448/D)|Codeforces||Codeforces Round #256 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|108|[Kitahara Haruki's Gift](http://codeforces.com/problemset/problem/433/A)|Codeforces||Codeforces Round #248 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|109|[Football Kit](http://codeforces.com/problemset/problem/432/B)|Codeforces||Codeforces Round #246 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|110|[Shower Line](http://codeforces.com/problemset/problem/431/B)|Codeforces||Codeforces Round #247 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|111|[George and Round](http://codeforces.com/problemset/problem/387/B)|Codeforces||Codeforces Round #227 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|112|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces||Codeforces Round #226 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|113|[Hamburgers](http://codeforces.com/problemset/problem/371/C)|Codeforces||Codeforces Round #218 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|114|[Group of Students](http://codeforces.com/problemset/problem/357/A)|Codeforces||Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|115|[Simple Molecules](http://codeforces.com/problemset/problem/344/B)|Codeforces||Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|116|[Sail](http://codeforces.com/problemset/problem/298/B)|Codeforces||Codeforces Round #180 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|117|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces||Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|118|[IQ Test](http://codeforces.com/problemset/problem/287/A)|Codeforces||Codeforces Round #176 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|119|[Prime Matrix](http://codeforces.com/problemset/problem/271/B)|Codeforces||Codeforces Round #166 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|120|[Little Elephant and Chess](http://codeforces.com/problemset/problem/259/A)|Codeforces||Codeforces Round #157 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|121|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|122|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|123|[Economy Game](http://codeforces.com/problemset/problem/681/B)|Codeforces||Codeforces Round #357 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|124|[Restoring Painting](http://codeforces.com/problemset/problem/675/B)|Codeforces||Codeforces Round #353 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|125|[Thor](http://codeforces.com/problemset/problem/704/A)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|126|[Pride](http://codeforces.com/problemset/problem/891/A)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|127|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/505/B)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|128|[Vicious Keyboard](http://codeforces.com/problemset/problem/801/A)|Codeforces||Codeforces Round #409 (rated, Div. 2, based on VK Cup 2017 Round 2)|2|
|<ul><li>- [ ] Done</li></ul>|129|[Ilya and tic-tac-toe game](http://codeforces.com/problemset/problem/754/B)|Codeforces||Codeforces Round #390 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|130|[Parallelogram is Back](http://codeforces.com/problemset/problem/749/B)|Codeforces||Codeforces Round #388 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|131|[Alyona and copybooks](http://codeforces.com/problemset/problem/740/A)|Codeforces||Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|132|[Okabe and Banana Trees](http://codeforces.com/problemset/problem/821/B)|Codeforces||Codeforces Round #420 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|133|[Chtholly's request](http://codeforces.com/problemset/problem/897/B)|Codeforces||Codeforces Round #449 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|134|[Pizza Separation](http://codeforces.com/problemset/problem/895/A)|Codeforces||Codeforces Round #448 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|135|[Kirill And The Game](http://codeforces.com/problemset/problem/842/A)|Codeforces||Codeforces Round #430 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|136|[Mike and strings](http://codeforces.com/problemset/problem/798/B)|Codeforces||Codeforces Round #410 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|137|[Vladik and fractions](http://codeforces.com/problemset/problem/743/C)|Codeforces||Codeforces Round #384 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|138|[Letters](http://codeforces.com/problemset/problem/978/C)|Codeforces||Codeforces Round #481 (Div. 3)|2|
|<ul><li>- [ ] Done</li></ul>|139|[Little Xor](http://codeforces.com/problemset/problem/252/A)|Codeforces||Codeforces Round #153 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|140|[Colorful Graph](http://codeforces.com/problemset/problem/246/D)|Codeforces||Codeforces Round #151 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|141|[Heads or Tails](http://codeforces.com/problemset/problem/242/A)|Codeforces||Codeforces Round #149 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|142|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|143|[Two Problems](http://codeforces.com/problemset/problem/203/A)|Codeforces||Codeforces Round #128 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|144|[LLPS](http://codeforces.com/problemset/problem/202/A)|Codeforces||Codeforces Round #127 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|145|[Let's Watch Football](http://codeforces.com/problemset/problem/195/A)|Codeforces||Codeforces Round #123 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|146|[Funky Numbers](http://codeforces.com/problemset/problem/192/A)|Codeforces||Codeforces Round #121 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|147|[Common Divisors](http://codeforces.com/problemset/problem/182/D)|Codeforces||Codeforces Round #117 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|148|[Phone Code](http://codeforces.com/problemset/problem/172/A)|Codeforces||Croc Champ 2012 - Qualification Round|3|
|<ul><li>- [ ] Done</li></ul>|149|[Dress'em in Vests!](http://codeforces.com/problemset/problem/161/A)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|150|[Students and Shoelaces](http://codeforces.com/problemset/problem/129/B)|Codeforces||Codeforces Beta Round #94 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|151|[Ball Game](http://codeforces.com/problemset/problem/46/A)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|3|
|<ul><li>- [ ] Done</li></ul>|152|[Reconnaissance](http://codeforces.com/problemset/problem/32/A)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|3|
|<ul><li>- [ ] Done</li></ul>|153|[Noldbach problem](http://codeforces.com/problemset/problem/17/A)|Codeforces||Codeforces Beta Round #17|3|
|<ul><li>- [ ] Done</li></ul>|154|[Kalevitch and Chess](http://codeforces.com/problemset/problem/7/A)|Codeforces||Codeforces Beta Round #7|3|
|<ul><li>- [ ] Done</li></ul>|155|[Tic-tac-toe](http://codeforces.com/problemset/problem/3/C)|Codeforces||Codeforces Beta Round #3|3|
|<ul><li>- [ ] Done</li></ul>|156|[Catch Me If You Can ](http://www.spoj.com/problems/CMIYC/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|157|[Polo the Penguin and Segments ](http://codeforces.com/problemset/problem/289/A)|Codeforces||Codeforces Round #177 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|158|[Point on Spiral](http://codeforces.com/problemset/problem/279/A)|Codeforces||Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|159|[Bear and Compressing](http://codeforces.com/problemset/problem/653/B)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|160|[A Trivial Problem](http://codeforces.com/problemset/problem/633/B)|Codeforces||Manthan, Codefest 16|3|
|<ul><li>- [ ] Done</li></ul>|161|[Block Towers](http://codeforces.com/problemset/problem/626/C)|Codeforces||8VC Venture Cup 2016 - Elimination Round|3|
|<ul><li>- [ ] Done</li></ul>|162|[The Text Splitting](http://codeforces.com/problemset/problem/612/A)|Codeforces||Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|163|[Gennady the Dentist](http://codeforces.com/problemset/problem/585/A)|Codeforces||Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|164|[Finding Team Member](http://codeforces.com/problemset/problem/579/B)|Codeforces||Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|165|["Or" Game](http://codeforces.com/problemset/problem/578/B)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|166|[Primes or Palindromes?](http://codeforces.com/problemset/problem/568/A)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|167|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces||Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|168|[King of Thieves](http://codeforces.com/problemset/problem/526/A)|Codeforces||ZeptoLab Code Rush 2015|3|
|<ul><li>- [ ] Done</li></ul>|169|[Permutations](http://codeforces.com/problemset/problem/513/B1)|Codeforces||Rockethon 2015|3|
|<ul><li>- [ ] Done</li></ul>|170|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces||Codeforces Round #283 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|171|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces||Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|172|[Unbearable Controversy of Being](http://codeforces.com/problemset/problem/489/D)|Codeforces||Codeforces Round #277.5 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|173|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|174|[A + B Strikes Back](http://codeforces.com/problemset/problem/409/H)|Codeforces||April Fools Day Contest 2014|3|
|<ul><li>- [ ] Done</li></ul>|175|[Triangle](http://codeforces.com/problemset/problem/407/A)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|176|[Searching for Graph](http://codeforces.com/problemset/problem/402/C)|Codeforces||Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|177|[Inna and New Matrix of Candies](http://codeforces.com/problemset/problem/400/B)|Codeforces||Codeforces Round #234 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|178|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|179|[Dima and To-do List](http://codeforces.com/problemset/problem/366/B)|Codeforces||Codeforces Round #214 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|180|[Vasya and Robot](http://codeforces.com/problemset/problem/354/A)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|181|[Perfect Pair](http://codeforces.com/problemset/problem/317/A)|Codeforces||Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|182|[Sereja and Bottles](http://codeforces.com/problemset/problem/315/A)|Codeforces||Codeforces Round #187 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|183|[Pythagorean Theorem II](http://codeforces.com/problemset/problem/304/A)|Codeforces||Codeforces Round #183 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|184|[Coach](http://codeforces.com/problemset/problem/300/B)|Codeforces||Codeforces Round #181 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|185|[Cows and Poker Game](http://codeforces.com/problemset/problem/284/B)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|186|[Non-square Equation](http://codeforces.com/problemset/problem/233/B)|Codeforces||Codeforces Round #144 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|187|[Robbers' watch](http://codeforces.com/problemset/problem/685/A)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|188|[Sagheer, the Hausmeister](http://codeforces.com/problemset/problem/812/B)|Codeforces||Codeforces Round #417 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|189|[Karen and Game](http://codeforces.com/problemset/problem/815/A)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|190|[Mike and Cellphone](http://codeforces.com/problemset/problem/689/A)|Codeforces||Codeforces Round #361 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|191|[An impassioned circulation of affection](http://codeforces.com/problemset/problem/814/C)|Codeforces||Codeforces Round #418 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|192|[Masha and geometric depression](http://codeforces.com/problemset/problem/789/B)|Codeforces||Codeforces Round #407 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|193|[Mahmoud and a Message](http://codeforces.com/problemset/problem/766/C)|Codeforces||Codeforces Round #396 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|194|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|195|[Undoubtedly Lucky Numbers](http://codeforces.com/problemset/problem/244/B)|Codeforces||Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|196|[Magic Box](http://codeforces.com/problemset/problem/231/D)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|197|[Shifts](http://codeforces.com/problemset/problem/229/A)|Codeforces||Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|198|[Two Tables](http://codeforces.com/problemset/problem/228/B)|Codeforces||Codeforces Round #141 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|199|[Mountain Scenery](http://codeforces.com/problemset/problem/218/A)|Codeforces||Codeforces Round #134 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|200|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces||Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|201|[Little Elephant and Sorting](http://codeforces.com/problemset/problem/205/B)|Codeforces||Codeforces Round #129 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|202|[Walking in the Rain](http://codeforces.com/problemset/problem/192/B)|Codeforces||Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|203|[Counting Rhombi](http://codeforces.com/problemset/problem/189/B)|Codeforces||Codeforces Round #119 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|204|[Letter](http://codeforces.com/problemset/problem/180/C)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|205|[String Manipulation 1.0](http://codeforces.com/problemset/problem/159/C)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|206|[Message](http://codeforces.com/problemset/problem/156/A)|Codeforces||Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|207|[Lucky Mask](http://codeforces.com/problemset/problem/146/B)|Codeforces||Codeforces Round #104 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|208|[Elevator](http://codeforces.com/problemset/problem/120/A)|Codeforces||School Regional Team Contest, Saratov, 2011|4|
|<ul><li>- [ ] Done</li></ul>|209|[Choosing Laptop](http://codeforces.com/problemset/problem/106/B)|Codeforces||Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|210|[Chord](http://codeforces.com/problemset/problem/88/A)|Codeforces||Codeforces Beta Round #73 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|211|[Fire Again](http://codeforces.com/problemset/problem/35/C)|Codeforces||Codeforces Beta Round #35 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|212|[Spit Problem](http://codeforces.com/problemset/problem/29/A)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|4|
|<ul><li>- [ ] Done</li></ul>|213|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|214|[Roads not only in Berland](http://codeforces.com/problemset/problem/25/D)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|215|[You're Given a String...](http://codeforces.com/problemset/problem/23/A)|Codeforces||Codeforces Beta Round #23|4|
|<ul><li>- [ ] Done</li></ul>|216|[Triangle](http://codeforces.com/problemset/problem/18/A)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|217|[Running Student](http://codeforces.com/problemset/problem/9/B)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|218|[TWO BISHOPS](http://www.spoj.com/problems/TWOBISOP/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|219|[Minion Circle](http://www.codechef.com/problems/CIRCLE)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|220|[Brute-force Algorithm](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2745)|Live Archive|2009|Asia - Shanghai|4|
|<ul><li>- [ ] Done</li></ul>|221|[Strange Addition](http://codeforces.com/problemset/problem/305/A)|Codeforces||Codeforces Round #184 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|222|[Amity Assessment](http://codeforces.com/problemset/problem/645/A)|Codeforces||CROC 2016 - Elimination Round|4|
|<ul><li>- [ ] Done</li></ul>|223|[Promocodes with Mistakes](http://codeforces.com/problemset/problem/637/C)|Codeforces||VK Cup 2016 - Qualification Round 1|4|
|<ul><li>- [ ] Done</li></ul>|224|[Orchestra](http://codeforces.com/problemset/problem/635/A)|Codeforces||8VC Venture Cup 2016 - Final Round (Div. 2 Edition) & 8VC Venture Cup 2016 - Final Round (Div. 1 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|225|[Alice, Bob, Two Teams](http://codeforces.com/problemset/problem/632/B)|Codeforces||Educational Codeforces Round 9|4|
|<ul><li>- [ ] Done</li></ul>|226|[Spongebob and Squares](http://codeforces.com/problemset/problem/599/D)|Codeforces||Codeforces Round #332 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|227|[Three Logos](http://codeforces.com/problemset/problem/581/D)|Codeforces||Codeforces Round #322 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|228|[Amr and Chemistry](http://codeforces.com/problemset/problem/558/C)|Codeforces||Codeforces Round #312 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|229|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces||Codeforces Round #311 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|230|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces||Codeforces Round #308 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|231|[ZgukistringZ](http://codeforces.com/problemset/problem/551/B)|Codeforces||Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|232|[Weird Chess](http://codeforces.com/problemset/problem/538/D)|Codeforces||Codeforces Round #300|4|
|<ul><li>- [ ] Done</li></ul>|233|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|234|[Fight the Monster](http://codeforces.com/problemset/problem/487/A)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|235|[Captain Marmot](http://codeforces.com/problemset/problem/474/C)|Codeforces||Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|236|[MUH and House of Cards](http://codeforces.com/problemset/problem/471/C)|Codeforces||Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|237|[Wonder Room](http://codeforces.com/problemset/problem/466/B)|Codeforces||Codeforces Round #266 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|238|[Little Pony and Harmony Chest](http://codeforces.com/problemset/problem/453/B)|Codeforces||Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|239|[Predict Outcome of the Game](http://codeforces.com/problemset/problem/451/C)|Codeforces||Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|240|[DZY Loves Modification](http://codeforces.com/problemset/problem/446/B)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|241|[Kolya and Tandem Repeat](http://codeforces.com/problemset/problem/443/B)|Codeforces||Codeforces Round #253 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|242|[Devu and Partitioning of the Array](http://codeforces.com/problemset/problem/439/C)|Codeforces||Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|243|[Balls Game](http://codeforces.com/problemset/problem/430/B)|Codeforces||Codeforces Round #245 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|244|[Sereja and Swaps](http://codeforces.com/problemset/problem/425/A)|Codeforces||Codeforces Round #243 (Div. 1) & Codeforces Round #243 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|245|[Trees in a Row](http://codeforces.com/problemset/problem/402/B)|Codeforces||Codeforces Round #236 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|246|[Sereja and Prefixes](http://codeforces.com/problemset/problem/380/A)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|247|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces||Codeforces Round #209 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|248|[Dima and Text Messages](http://codeforces.com/problemset/problem/358/B)|Codeforces||Codeforces Round #208 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|249|[Resort](http://codeforces.com/problemset/problem/350/B)|Codeforces||Codeforces Round #203 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|250|[Xenia and Spies](http://codeforces.com/problemset/problem/342/B)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|251|[Beautiful Numbers](http://codeforces.com/problemset/problem/300/C)|Codeforces||Codeforces Round #181 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|252|[Ksusha and Array](http://codeforces.com/problemset/problem/299/A)|Codeforces||Croc Champ 2013 - Round 2 (Div. 2 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|253|[New Problem](http://codeforces.com/problemset/problem/278/B)|Codeforces||Codeforces Round #170 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|254|[Ancient Prophesy](http://codeforces.com/problemset/problem/260/B)|Codeforces||Codeforces Round #158 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|255|[View Angle](http://codeforces.com/problemset/problem/257/C)|Codeforces||Codeforces Round #159 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|256|[Palindrome pairs](http://codeforces.com/problemset/problem/159/D)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|257|[Tennis Game](http://codeforces.com/problemset/problem/496/D)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|258|[Office Keys](http://codeforces.com/problemset/problem/830/A)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|259|[Tell Your World](http://codeforces.com/problemset/problem/849/B)|Codeforces||Codeforces Round #431 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|260|[Remove Extra One](http://codeforces.com/problemset/problem/900/C)|Codeforces||Codeforces Round #450 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|261|[Game of the Rows](http://codeforces.com/problemset/problem/839/B)|Codeforces||Codeforces Round #428 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|262|[Jury Size](http://codeforces.com/problemset/problem/254/B)|Codeforces||Codeforces Round #155 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|263|[Beauty Pageant](http://codeforces.com/problemset/problem/246/C)|Codeforces||Codeforces Round #151 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|264|[Game on Paper](http://codeforces.com/problemset/problem/203/B)|Codeforces||Codeforces Round #128 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|265|[Series of Crimes](http://codeforces.com/problemset/problem/181/A)|Codeforces||Croc Champ 2012 - Round 2 (Unofficial Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|266|[Robot Bicorn Attack](http://codeforces.com/problemset/problem/175/A)|Codeforces||Codeforces Round #115|5|
|<ul><li>- [ ] Done</li></ul>|267|[Broken checker](http://codeforces.com/problemset/problem/171/D)|Codeforces||April Fools Day Contest|5|
|<ul><li>- [ ] Done</li></ul>|268|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces||Codeforces Round #112 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|269|[Help Farmer](http://codeforces.com/problemset/problem/142/A)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|270|[Rectangle and Square](http://codeforces.com/problemset/problem/135/B)|Codeforces||Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|271|[Permutations](http://codeforces.com/problemset/problem/124/B)|Codeforces||Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|272|[Three Sons](http://codeforces.com/problemset/problem/120/D)|Codeforces||School Regional Team Contest, Saratov, 2011|5|
|<ul><li>- [ ] Done</li></ul>|273|[Fancy Number](http://codeforces.com/problemset/problem/118/C)|Codeforces||Codeforces Beta Round #89 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|274|[PFAST Inc.](http://codeforces.com/problemset/problem/114/B)|Codeforces||Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|275|[Clothes](http://codeforces.com/problemset/problem/102/A)|Codeforces||Codeforces Beta Round #79 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|276|[Petya and His Friends](http://codeforces.com/problemset/problem/66/D)|Codeforces||Codeforces Beta Round #61 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|277|[Martian Dollar](http://codeforces.com/problemset/problem/41/B)|Codeforces||Codeforces Beta Round #40 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|278|[Chess](http://codeforces.com/problemset/problem/38/B)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|279|[Accounting](http://codeforces.com/problemset/problem/30/A)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|280|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|281|[Bargaining Table](http://codeforces.com/problemset/problem/22/B)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|282|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|283|[Brute-force Algorithm EXTREME](http://www.spoj.com/problems/BFALG/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|284|[4-point polyline](http://codeforces.com/problemset/problem/452/B)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|285|[Restore Cube ](http://codeforces.com/problemset/problem/464/B)|Codeforces||Codeforces Round #265 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|286|[Shopping](http://codeforces.com/problemset/problem/665/B)|Codeforces||Educational Codeforces Round 12|5|
|<ul><li>- [ ] Done</li></ul>|287|[Fibonacci-ish](http://codeforces.com/problemset/problem/633/D)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|288|[Jerry's Protest](http://codeforces.com/problemset/problem/626/D)|Codeforces||8VC Venture Cup 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|289|[Skills](http://codeforces.com/problemset/problem/613/B)|Codeforces||Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|290|[Chocolate Bar](http://codeforces.com/problemset/problem/598/E)|Codeforces||Educational Codeforces Round 1|5|
|<ul><li>- [ ] Done</li></ul>|291|[Boulevard](http://codeforces.com/problemset/problem/589/D)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|5|
|<ul><li>- [ ] Done</li></ul>|292|[Mike and Frog](http://codeforces.com/problemset/problem/547/A)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|293|[Om Nom and Candies](http://codeforces.com/problemset/problem/526/C)|Codeforces||ZeptoLab Code Rush 2015|5|
|<ul><li>- [ ] Done</li></ul>|294|[Inversions problem](http://codeforces.com/problemset/problem/513/G1)|Codeforces||Rockethon 2015|5|
|<ul><li>- [ ] Done</li></ul>|295|[Chocolate](http://codeforces.com/problemset/problem/490/D)|Codeforces||Codeforces Round #279 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|296|[Candy Boxes](http://codeforces.com/problemset/problem/488/B)|Codeforces||Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|297|[CGCDSSQ](http://codeforces.com/problemset/problem/475/D)|Codeforces||Bayan 2015 Contest Warm Up|5|
|<ul><li>- [ ] Done</li></ul>|298|[Borya and Hanabi](http://codeforces.com/problemset/problem/442/A)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|299|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces||Codeforces Round #235 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|300|[Counting Rectangles is Fun](http://codeforces.com/problemset/problem/372/B)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|301|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|302|[Vasily the Bear and Sequence](http://codeforces.com/problemset/problem/336/C)|Codeforces||Codeforces Round #195 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|303|[Continued Fractions](http://codeforces.com/problemset/problem/305/B)|Codeforces||Codeforces Round #184 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|304|[Calendar](http://codeforces.com/problemset/problem/304/B)|Codeforces||Codeforces Round #183 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|305|[Ksusha the Squirrel](http://codeforces.com/problemset/problem/299/B)|Codeforces||Croc Champ 2013 - Round 2 (Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|306|[Network Mask](http://codeforces.com/problemset/problem/291/C)|Codeforces||Croc Champ 2013 - Qualification Round|5|
|<ul><li>- [ ] Done</li></ul>|307|[Nearest Fraction](http://codeforces.com/problemset/problem/281/B)|Codeforces||Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|308|[Average Numbers](http://codeforces.com/problemset/problem/134/A)|Codeforces||Codeforces Testing Round #3|5|
|<ul><li>- [ ] Done</li></ul>|309|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|310|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|311|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces||Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|312|[The Queue](http://codeforces.com/problemset/problem/767/B)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|313|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|314|[Little Elephant and Elections](http://codeforces.com/problemset/problem/258/B)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|315|[Mr. Bender and Square](http://codeforces.com/problemset/problem/255/D)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|316|[Unsorting Array](http://codeforces.com/problemset/problem/252/B)|Codeforces||Codeforces Round #153 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|317|[Easy Tape Programming](http://codeforces.com/problemset/problem/239/B)|Codeforces||Codeforces Round #148 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|318|[Number of Triplets](http://codeforces.com/problemset/problem/181/B)|Codeforces||Croc Champ 2012 - Round 2 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|319|[Party](http://codeforces.com/problemset/problem/177/C2)|Codeforces||ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|320|[New Year Cards](http://codeforces.com/problemset/problem/140/B)|Codeforces||Codeforces Round #100|6|
|<ul><li>- [ ] Done</li></ul>|321|[String](http://codeforces.com/problemset/problem/128/B)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|322|[Hot Bath](http://codeforces.com/problemset/problem/126/A)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|323|[Lucky Permutation](http://codeforces.com/problemset/problem/121/C)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only) & Codeforces Beta Round #91 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|324|[Very Interesting Game](http://codeforces.com/problemset/problem/117/B)|Codeforces||Codeforces Beta Round #88|6|
|<ul><li>- [ ] Done</li></ul>|325|[Lucky Probability](http://codeforces.com/problemset/problem/109/B)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|326|[Time to Raid Cowavans](http://codeforces.com/problemset/problem/103/D)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|327|[Sum of Medians](http://codeforces.com/problemset/problem/85/D)|Codeforces||Yandex.Algorithm 2011 Round 1|6|
|<ul><li>- [ ] Done</li></ul>|328|[Heroes](http://codeforces.com/problemset/problem/77/A)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|329|[Harry Potter and the History of Magic](http://codeforces.com/problemset/problem/65/B)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|330|[Trees](http://codeforces.com/problemset/problem/58/C)|Codeforces||Codeforces Beta Round #54 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|331|[Smallest number](http://codeforces.com/problemset/problem/55/B)|Codeforces||Codeforces Beta Round #51|6|
|<ul><li>- [ ] Done</li></ul>|332|[Land Lot](http://codeforces.com/problemset/problem/48/B)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|333|[Blinds](http://codeforces.com/problemset/problem/38/C)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|334|[Wonderful Randomized Sum](http://codeforces.com/problemset/problem/33/C)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|335|[Lizards and Basements 2](http://codeforces.com/problemset/problem/6/D)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|336|[Kingdoms](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3951)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|337|[FLING1](http://www.spoj.com/problems/FLING1/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|338|[Bear and Up-Down](http://codeforces.com/problemset/problem/653/C)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|339|[Longest Subsequence](http://codeforces.com/problemset/problem/632/D)|Codeforces||Educational Codeforces Round 9|6|
|<ul><li>- [ ] Done</li></ul>|340|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces||Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|341|[A Heap of Heaps](http://codeforces.com/problemset/problem/538/F)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|342|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|343|[Restoring Increasing Sequence](http://codeforces.com/problemset/problem/490/E)|Codeforces||Codeforces Round #279 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|344|[Caisa and Tree](http://codeforces.com/problemset/problem/463/E)|Codeforces||Codeforces Round #264 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|345|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces||Codeforces Round #256 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|346|[Fly, freebies, fly!](http://codeforces.com/problemset/problem/386/B)|Codeforces||Testing Round #9|6|
|<ul><li>- [ ] Done</li></ul>|347|[New Year Letter](http://codeforces.com/problemset/problem/379/D)|Codeforces||Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|348|[Maximal Area Quadrilateral](http://codeforces.com/problemset/problem/340/B)|Codeforces||Codeforces Round #198 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|349|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces||Codeforces Round #194 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|350|[Oh Sweet Beaverette](http://codeforces.com/problemset/problem/331/A1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|6|
|<ul><li>- [ ] Done</li></ul>|351|[Ants](http://codeforces.com/problemset/problem/317/B)|Codeforces||Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|352|[Summer Homework](http://codeforces.com/problemset/problem/316/E1)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|353|[EKG](http://codeforces.com/problemset/problem/316/B1)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|354|[Encrypting Messages](http://codeforces.com/problemset/problem/177/D1)|Codeforces||ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|355|[Bulls and Cows](http://codeforces.com/problemset/problem/63/C)|Codeforces||Codeforces Beta Round #59 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|356|[Platforms](http://codeforces.com/problemset/problem/18/B)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|357|[Karen and Test](http://codeforces.com/problemset/problem/815/B)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|358|[Karen and Supermarket](http://codeforces.com/problemset/problem/815/C)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|359|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces||Codeforces Round #384 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|360|[Table with Letters - 2](http://codeforces.com/problemset/problem/253/D)|Codeforces||Codeforces Round #154 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|361|[Blackboard Fibonacci](http://codeforces.com/problemset/problem/217/B)|Codeforces||Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|362|[Brand New Easy Problem](http://codeforces.com/problemset/problem/202/B)|Codeforces||Codeforces Round #127 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|363|[Football Championship](http://codeforces.com/problemset/problem/200/C)|Codeforces||Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|364|[Xor](http://codeforces.com/problemset/problem/193/B)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|365|[Spiral Maximum](http://codeforces.com/problemset/problem/173/C)|Codeforces||Croc Champ 2012 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|366|[Pairs of Numbers](http://codeforces.com/problemset/problem/134/B)|Codeforces||Codeforces Testing Round #3|7|
|<ul><li>- [ ] Done</li></ul>|367|[Double Happiness](http://codeforces.com/problemset/problem/113/C)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|368|[Treasure Island](http://codeforces.com/problemset/problem/106/D)|Codeforces||Codeforces Beta Round #82 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|369|[Dark Assembly](http://codeforces.com/problemset/problem/105/B)|Codeforces||Codeforces Beta Round #81|7|
|<ul><li>- [ ] Done</li></ul>|370|[Help Victoria the Wise](http://codeforces.com/problemset/problem/98/A)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|371|[Journey](http://codeforces.com/problemset/problem/43/D)|Codeforces||Codeforces Beta Round #42 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|372|[THE N WITTY FRIENDS](http://www.spoj.com/problems/WITTY/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|373|[Binary Table](http://codeforces.com/problemset/problem/662/C)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|7|
|<ul><li>- [ ] Done</li></ul>|374|[Three-dimensional Turtle Super Computer ](http://codeforces.com/problemset/problem/638/D)|Codeforces||VK Cup 2016 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|375|[Rat Kwesh and Cheese](http://codeforces.com/problemset/problem/621/D)|Codeforces||Codeforces Round #341 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|376|[Edo and Magnets](http://codeforces.com/problemset/problem/594/C)|Codeforces||Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|377|[Group Photo 2 (online mirror version)](http://codeforces.com/problemset/problem/529/B)|Codeforces||VK Cup 2015 - Round 1 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|378|[Fuzzy Search](http://codeforces.com/problemset/problem/528/D)|Codeforces||Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|379|[Kamal-ol-molk's Painting](http://codeforces.com/problemset/problem/475/C)|Codeforces||Bayan 2015 Contest Warm Up|7|
|<ul><li>- [ ] Done</li></ul>|380|[Little Victor and Set](http://codeforces.com/problemset/problem/460/D)|Codeforces||Codeforces Round #262 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|381|[Elections](http://codeforces.com/problemset/problem/457/C)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|382|[Special Grid](http://codeforces.com/problemset/problem/435/D)|Codeforces||Codeforces Round #249 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|383|[Curious Array](http://codeforces.com/problemset/problem/407/C)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|384|[Wrong Floyd](http://codeforces.com/problemset/problem/350/E)|Codeforces||Codeforces Round #203 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|385|[Subset Sums](http://codeforces.com/problemset/problem/348/C)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|386|[Divisor Tree](http://codeforces.com/problemset/problem/337/E)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|387|[Minimum Modular](http://codeforces.com/problemset/problem/303/C)|Codeforces||Codeforces Round #183 (Div. 1) & Codeforces Round #183 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|388|[Beautiful IP Addresses](http://codeforces.com/problemset/problem/292/C)|Codeforces||Croc Champ 2013 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|389|[Log Stream Analysis](http://codeforces.com/problemset/problem/245/F)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|7|
|<ul><li>- [ ] Done</li></ul>|390|[Programming Language](http://codeforces.com/problemset/problem/200/D)|Codeforces||Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|391|[ucyhf](http://codeforces.com/problemset/problem/171/F)|Codeforces||April Fools Day Contest|7|
|<ul><li>- [ ] Done</li></ul>|392|[Game](http://codeforces.com/problemset/problem/49/D)|Codeforces||Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|393|[Seller Bob](http://codeforces.com/problemset/problem/18/D)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|394|[Hongcow Buys a Deck of Cards](http://codeforces.com/problemset/problem/744/C)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|395|[Bamboo Partition](http://codeforces.com/problemset/problem/830/C)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|7|
|<ul><li>- [ ] Done</li></ul>|396|[Peterson Polyglot](http://codeforces.com/problemset/problem/778/C)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|397|[Vladik and chat](http://codeforces.com/problemset/problem/754/C)|Codeforces||Codeforces Round #390 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|398|[Anton and Permutation](http://codeforces.com/problemset/problem/785/E)|Codeforces||Codeforces Round #404 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|399|[Mad Joe](http://codeforces.com/problemset/problem/250/E)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|400|[Suggested Friends](http://codeforces.com/problemset/problem/245/G)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|8|
|<ul><li>- [ ] Done</li></ul>|401|[Crosses](http://codeforces.com/problemset/problem/215/C)|Codeforces||Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|402|[Cinema](http://codeforces.com/problemset/problem/200/A)|Codeforces||Codeforces Round #126 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|403|[Zoo](http://codeforces.com/problemset/problem/183/B)|Codeforces||Croc Champ 2012 - Final|8|
|<ul><li>- [ ] Done</li></ul>|404|[Polycarpus the Safecracker](http://codeforces.com/problemset/problem/161/E)|Codeforces||VK Cup 2012 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|405|[Help Caretaker](http://codeforces.com/problemset/problem/142/C)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|406|[Chip Play](http://codeforces.com/problemset/problem/89/C)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|407|[Mushroom Strife](http://codeforces.com/problemset/problem/60/C)|Codeforces||Codeforces Beta Round #56|8|
|<ul><li>- [ ] Done</li></ul>|408|[Safe](http://codeforces.com/problemset/problem/47/D)|Codeforces||Codeforces Beta Round #44 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|409|[Safe cracking](http://codeforces.com/problemset/problem/42/C)|Codeforces||Codeforces Beta Round #41|8|
|<ul><li>- [ ] Done</li></ul>|410|[Collisions](http://codeforces.com/problemset/problem/34/E)|Codeforces||Codeforces Beta Round #34 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|411|[Sereja and Tree](http://codeforces.com/problemset/problem/380/B)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|412|[The Diameter of Tree](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=5050)|Live Archive|2014|Asia - Xian|8|
|<ul><li>- [ ] Done</li></ul>|413|[Magic Matrix](http://codeforces.com/problemset/problem/632/F)|Codeforces||Educational Codeforces Round 9|8|
|<ul><li>- [ ] Done</li></ul>|414|[Biathlon Track](http://codeforces.com/problemset/problem/424/D)|Codeforces||Codeforces Round #242 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|415|[Broken Monitor](http://codeforces.com/problemset/problem/370/D)|Codeforces||Codeforces Round #217 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|416|[Dima and Magic Guitar](http://codeforces.com/problemset/problem/366/E)|Codeforces||Codeforces Round #214 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|417|[Ghd](http://codeforces.com/problemset/problem/364/D)|Codeforces||Codeforces Round #213 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|418|[Beautiful Set](http://codeforces.com/problemset/problem/364/C)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|419|[Summer Earnings](http://codeforces.com/problemset/problem/333/E)|Codeforces||Codeforces Round #194 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|420|[Cube Problem](http://codeforces.com/problemset/problem/293/C)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|421|[Distinct Paths](http://codeforces.com/problemset/problem/293/B)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|422|[Vanya and Balloons](http://codeforces.com/problemset/problem/677/E)|Codeforces||Codeforces Round #355 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|423|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces||Codeforces Round #360 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|424|[Kay and Eternity](http://codeforces.com/problemset/problem/685/D)|Codeforces||Codeforces Round #359 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|425|[Timofey and remoduling](http://codeforces.com/problemset/problem/763/C)|Codeforces||Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|426|[Gosha is hunting](http://codeforces.com/problemset/problem/739/E)|Codeforces||Codeforces Round #381 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|427|[Mother of Dragons](http://codeforces.com/problemset/problem/839/E)|Codeforces||Codeforces Round #428 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|428|[Rats](http://codeforces.com/problemset/problem/254/D)|Codeforces||Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|429|[Race](http://codeforces.com/problemset/problem/241/F)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|430|[Bitonix' Patrol](http://codeforces.com/problemset/problem/217/D)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|431|[Brand New Problem](http://codeforces.com/problemset/problem/201/D)|Codeforces||Codeforces Round #127 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|432|[Gripping Story](http://codeforces.com/problemset/problem/198/E)|Codeforces||Codeforces Round #125 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|433|[Fibonacci Number](http://codeforces.com/problemset/problem/193/E)|Codeforces||Codeforces Round #122 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|434|[Power Defence](http://codeforces.com/problemset/problem/175/E)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|435|[Plane of Tanks: Duel](http://codeforces.com/problemset/problem/175/D)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|436|[Minimum Diameter](http://codeforces.com/problemset/problem/164/D)|Codeforces||VK Cup 2012 Round 3|9|
|<ul><li>- [ ] Done</li></ul>|437|[Large Refrigerator](http://codeforces.com/problemset/problem/163/D)|Codeforces||VK Cup 2012 Round 2|9|
|<ul><li>- [ ] Done</li></ul>|438|[Frames](http://codeforces.com/problemset/problem/152/D)|Codeforces||Codeforces Round #108 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|439|[Cycle](http://codeforces.com/problemset/problem/135/D)|Codeforces||Codeforces Beta Round #97 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|440|[Item World](http://codeforces.com/problemset/problem/105/C)|Codeforces||Codeforces Beta Round #81|9|
|<ul><li>- [ ] Done</li></ul>|441|[Domino](http://codeforces.com/problemset/problem/97/A)|Codeforces||Yandex.Algorithm 2011 Finals|9|
|<ul><li>- [ ] Done</li></ul>|442|[Azembler](http://codeforces.com/problemset/problem/93/C)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only) & Codeforces Beta Round #76 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|443|[Solitaire](http://codeforces.com/problemset/problem/71/D)|Codeforces||Codeforces Beta Round #65 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|444|[Synchrophasotron](http://codeforces.com/problemset/problem/68/C)|Codeforces||Codeforces Beta Round #62|9|
|<ul><li>- [ ] Done</li></ul>|445|[Harry Potter and the Sorting Hat](http://codeforces.com/problemset/problem/65/D)|Codeforces||Codeforces Beta Round #60|9|
|<ul><li>- [ ] Done</li></ul>|446|[Prime Segment](http://codeforces.com/problemset/problem/64/E)|Codeforces||Unknown Language Round #1|9|
|<ul><li>- [ ] Done</li></ul>|447|[Savior](http://codeforces.com/problemset/problem/60/D)|Codeforces||Codeforces Beta Round #56|9|
|<ul><li>- [ ] Done</li></ul>|448|[Writing a Song](http://codeforces.com/problemset/problem/54/D)|Codeforces||Codeforces Beta Round #50|9|
|<ul><li>- [ ] Done</li></ul>|449|[Race](http://codeforces.com/problemset/problem/43/E)|Codeforces||Codeforces Beta Round #42 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|450|[Walls](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4234)|Live Archive|2012|North America - Southeast USA|9|
|<ul><li>- [ ] Done</li></ul>|451|[BLOCK_D SOLVER](http://www.spoj.com/problems/BLOCK_D/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|452|[Task processing](http://codeforces.com/problemset/problem/589/K)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|9|
|<ul><li>- [ ] Done</li></ul>|453|[Sign Posts](http://codeforces.com/problemset/problem/568/D)|Codeforces||Codeforces Round #315 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|454|[Pasha and Pipe](http://codeforces.com/problemset/problem/518/F)|Codeforces||Codeforces Round #293 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|455|[Roland and Rose](http://codeforces.com/problemset/problem/460/E)|Codeforces||Codeforces Round #262 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|456|[Physical Education and Buns](http://codeforces.com/problemset/problem/394/D)|Codeforces||Codeforces Round #231 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|457|[Supercollider](http://codeforces.com/problemset/problem/391/D1)|Codeforces||Rockethon 2014|9|
|<ul><li>- [ ] Done</li></ul>|458|[The Tournament](http://codeforces.com/problemset/problem/391/C1)|Codeforces||Rockethon 2014|9|
|<ul><li>- [ ] Done</li></ul>|459|[Word Folding](http://codeforces.com/problemset/problem/391/B)|Codeforces||Rockethon 2014|9|
|<ul><li>- [ ] Done</li></ul>|460|[Dima and Kicks](http://codeforces.com/problemset/problem/358/E)|Codeforces||Codeforces Round #208 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|461|[Pumping Stations](http://codeforces.com/problemset/problem/343/E)|Codeforces||Codeforces Round #200 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|462|[Rectangles and Square](http://codeforces.com/problemset/problem/335/D)|Codeforces||MemSQL start[c]up Round 2 - online version|9|
|<ul><li>- [ ] Done</li></ul>|463|[Lucky Tickets](http://codeforces.com/problemset/problem/333/C)|Codeforces||Codeforces Round #194 (Div. 1) & Codeforces Round #194 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|464|[PE Lesson](http://codeforces.com/problemset/problem/316/D1)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|465|[Fetch the Treasure](http://codeforces.com/problemset/problem/311/C)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|466|[Shaass and Painter Robot](http://codeforces.com/problemset/problem/294/D)|Codeforces||Codeforces Round #178 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|467|[The Last Hole!](http://codeforces.com/problemset/problem/274/C)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|468|[Rhombus](http://codeforces.com/problemset/problem/263/E)|Codeforces||Codeforces Round #161 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|469|[Maxim and Calculator](http://codeforces.com/problemset/problem/261/E)|Codeforces||Codeforces Round #160 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|470|[Dividing Kingdom](http://codeforces.com/problemset/problem/260/E)|Codeforces||Codeforces Round #158 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|471|[Travelling Through the Snow Queen's Kingdom](http://codeforces.com/problemset/problem/685/E)|Codeforces||Codeforces Round #359 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|472|[Bear and Chase](http://codeforces.com/problemset/problem/679/D)|Codeforces||Codeforces Round #356 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|473|[Ever-Hungry Krakozyabra](http://codeforces.com/problemset/problem/833/C)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|474|[Dasha and cyclic table](http://codeforces.com/problemset/problem/754/E)|Codeforces||Codeforces Round #390 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|475|[Hellish Constraints](http://codeforces.com/problemset/problem/138/E)|Codeforces||Codeforces Beta Round #99 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|476|[Pills](http://codeforces.com/problemset/problem/126/E)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|477|[Lucky Interval](http://codeforces.com/problemset/problem/109/E)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|478|[Lift and Throw](http://codeforces.com/problemset/problem/105/E)|Codeforces||Codeforces Beta Round #81|10|
|<ul><li>- [ ] Done</li></ul>|479|[Robot in Basement](http://codeforces.com/problemset/problem/97/D)|Codeforces||Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|480|[Long sequence](http://codeforces.com/problemset/problem/86/E)|Codeforces||Yandex.Algorithm 2011 Round 2|10|
|<ul><li>- [ ] Done</li></ul>|481|[Plane of Tanks](http://codeforces.com/problemset/problem/73/F)|Codeforces||Codeforces Beta Round #66|10|
|<ul><li>- [ ] Done</li></ul>|482|[Ali goes shopping](http://codeforces.com/problemset/problem/72/E)|Codeforces||Unknown Language Round #2|10|
|<ul><li>- [ ] Done</li></ul>|483|[Toys](http://codeforces.com/problemset/problem/44/I)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|484|[To Hack or not to Hack](http://codeforces.com/problemset/problem/662/E)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|10|
|<ul><li>- [ ] Done</li></ul>|485|[Party](http://codeforces.com/problemset/problem/575/C)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|10|
|<ul><li>- [ ] Done</li></ul>|486|[Gears](http://codeforces.com/problemset/problem/497/D)|Codeforces||Codeforces Round #283 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|487|[Wavy numbers](http://codeforces.com/problemset/problem/478/E)|Codeforces||Codeforces Round #273 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|488|[Banners](http://codeforces.com/problemset/problem/436/F)|Codeforces||Zepto Code Rush 2014|10|
|<ul><li>- [ ] Done</li></ul>|489|[Two Circles](http://codeforces.com/problemset/problem/363/E)|Codeforces||Codeforces Round #211 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|490|[Tennis Rackets](http://codeforces.com/problemset/problem/309/D)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|491|[Mrs. Hudson's Pancakes](http://codeforces.com/problemset/problem/156/E)|Codeforces||Codeforces Round #110 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|492|[Entertaining Geodetics](http://codeforces.com/problemset/problem/105/D)|Codeforces||Codeforces Beta Round #81|10|
|<ul><li>- [ ] Done</li></ul>|493|[Chain Reaction](http://codeforces.com/problemset/problem/666/D)|Codeforces||Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|494|[The Overdosing Ubiquity](http://codeforces.com/problemset/problem/869/D)|Codeforces||Codeforces Round #439 (Div. 2)|10|
