# 081. STL


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Department of Redundancy Department](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=425)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[CD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=565)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Babelfish](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1223)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|4|[Hay Points](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1236)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|5|[FIGUREFUL](http://www.spoj.com/problems/ACMCEG2B/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|6|[Pick the candies](http://www.spoj.com/problems/ACMCEG2C/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|7|[2D-SORT](http://www.spoj.com/problems/SORT2D/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|8|[HELP NERUBAN](http://www.spoj.com/problems/DOTAA2/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|9|[STL](http://codeforces.com/problemset/problem/190/C)|Codeforces|Codeforces Round #120 (Div. 2)|5|
