# 109. Treap


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Order statistic set](http://www.spoj.com/problems/ORDERSET/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Can you answer these queries VI](http://www.spoj.com/problems/GSS6/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|3|[Matrix](http://www.spoj.com/problems/KPMATRIX/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|4|[Robotic Sort](http://www.spoj.com/problems/CERC07S/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|5|[Genetics](http://www.codechef.com/problems/GENETICS)|CodeChef|5|
