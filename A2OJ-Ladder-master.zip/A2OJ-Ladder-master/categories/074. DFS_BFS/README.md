# 074. DFS_BFS


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lucius Dungeon](http://www.spoj.com/problems/BYTESE1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Graph Connectivity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=400)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Bitmap](http://www.spoj.com/problems/BITMAP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Tic-Tac-Toe ( II )](http://www.spoj.com/problems/TOE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[ALL IZZ WELL](http://www.spoj.com/problems/ALLIZWEL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[VALIDATE THE MAZE](http://www.spoj.com/problems/MAKEMAZE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Fix the Pond](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4147)|Live Archive|2012|Latin America|2|
|<ul><li>- [ ] Done</li></ul>|8|[THE WEIRD STAIRCASE](http://www.spoj.com/problems/STAR3CAS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|9|[GRAVITY](http://www.spoj.com/problems/GRAVITY/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|10|[Fix the Pond](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3974)|UVA|||5|
