# 132. Algorithm_X


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Yet Another N-Queen Problem](http://www.spoj.com/problems/NQUEEN/)|SPOJ|2|
|<ul><li>- [ ] Done</li></ul>|2|[Sudoku](http://www.spoj.com/problems/SUDOKU/)|SPOJ|4|
