# 138. Factoradic_Index


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Permalex](http://www.spoj.com/problems/PRMLX/)|SPOJ|3|
|<ul><li>- [ ] Done</li></ul>|2|[Spelling Lists](http://www.spoj.com/problems/MIB/)|SPOJ|4|
