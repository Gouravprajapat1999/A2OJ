# 127. binary_search


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Stern-Brocot Number System](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1018)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[Enumerating Rational Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2302)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|3|[Binary Search Heap Construction](http://poj.org/problem?id=1785)|PKU|3|
