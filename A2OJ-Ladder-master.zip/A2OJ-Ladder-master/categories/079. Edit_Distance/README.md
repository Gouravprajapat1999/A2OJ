# 079. Edit_Distance


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Minimum Cost](http://www.spoj.com/problems/MC/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Edit distance](http://www.spoj.com/problems/EDIST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Edit Distance Again](http://www.spoj.com/problems/EDIT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[String Computer](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=100)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|5|[String Distance and Transform Process](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=467)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|6|[AGTC](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3648)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Edit Distance](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2899)|Live Archive|2010|North America - North Central NA|5|
|<ul><li>- [ ] Done</li></ul>|8|[Edit Distance](http://www.spoj.com/problems/EDDIST/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|9|[I Like Uppercase Palindrome](http://www.spoj.com/problems/PLNDRM1/)|SPOJ|||8|
