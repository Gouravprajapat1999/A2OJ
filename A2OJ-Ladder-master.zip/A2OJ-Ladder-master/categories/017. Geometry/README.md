# 017. Geometry


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Equipment Box](http://www.spoj.com/problems/EQBOX/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Triangle From Centroid](http://www.spoj.com/problems/TRICENTR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[One Geometry Problem](http://www.spoj.com/problems/GEOPROB/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Maximal Quadrilateral Area](http://www.spoj.com/problems/QUADAREA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Sphere in a tetrahedron](http://www.spoj.com/problems/TETRA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Lifting the Stone](http://www.spoj.com/problems/STONE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Triangle](http://codeforces.com/problemset/problem/6/A)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Fancy Fence](http://codeforces.com/problemset/problem/270/A)|Codeforces||Codeforces Round #165 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Currency System in Geraldion](http://codeforces.com/problemset/problem/560/A)|Codeforces||Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Colourful Flowers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2093)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Is This Integration ?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1150)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|14|[The Grazing Cow](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1619)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Carmichael Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=947)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Gerald's Hexagon](http://codeforces.com/problemset/problem/559/A)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Julka](http://www.spoj.com/problems/JULKA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Beru-taxi](http://codeforces.com/problemset/problem/706/A)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Gleb And Pizza](http://codeforces.com/problemset/problem/842/B)|Codeforces||Codeforces Round #430 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Mahmoud and a Triangle](http://codeforces.com/problemset/problem/766/B)|Codeforces||Codeforces Round #396 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Trace](http://codeforces.com/problemset/problem/157/B)|Codeforces||Codeforces Round #110 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|22|[Wasted Time](http://codeforces.com/problemset/problem/127/A)|Codeforces||Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|23|[The Ant](http://www.spoj.com/problems/ANTTT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|24|[Goal for Raúl](http://www.spoj.com/problems/GOALFR/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|25|[Doors and Penguins](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1582)|Live Archive|2006|North America - Mid-Atlantic USA & North America - Rocky Mountain|2|
|<ul><li>- [ ] Done</li></ul>|26|[Area](http://acm.tju.edu.cn/toj/showp1011.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|27|[Land Acquisition](http://www.spoj.com/problems/ACQUIRE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|28|[Pipe](http://poj.org/problem?id=1039)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|29|[Handball](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|30|[Sunny Mountains](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=861)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|31|[Area](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1530)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|32|[Beavergnaw](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1238)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|33|[Convex Hull Finding](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=622)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|34|[Railway](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1204)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|35|[Packing polygons](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=946)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|36|[Colourful Flowers](https://www.urionlinejudge.com.br/judge/en/problems/view/1219)|URI|||2|
|<ul><li>- [ ] Done</li></ul>|37|[Soya Milk](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3060)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|38|[Overlapping Rectangles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=401)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|39|[The easiest way](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2148)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|40|[Elevator](https://www.urionlinejudge.com.br/judge/en/problems/view/1124)|URI|||2|
|<ul><li>- [ ] Done</li></ul>|41|[Crazy Town](http://codeforces.com/problemset/problem/498/A)|Codeforces||Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[Pouring Rain](http://codeforces.com/problemset/problem/667/A)|Codeforces||Codeforces Round #349 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|43|[Parallelogram is Back](http://codeforces.com/problemset/problem/749/B)|Codeforces||Codeforces Round #388 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|44|[Rings and Glue](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1242)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|45|[Gleaming the Cubes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=678)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|46|[I Conduit](http://www.spoj.com/problems/CONDUIT/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|47|[Geometry and a Square](http://www.spoj.com/problems/GEOM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|48|[Area of circles](http://www.spoj.com/problems/VCIRCLES/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|49|[Air Strike](http://www.spoj.com/problems/ANARC09F/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|50|[New Year Table](http://codeforces.com/problemset/problem/140/A)|Codeforces||Codeforces Round #100|3|
|<ul><li>- [ ] Done</li></ul>|51|[Calculate the Area](http://www.spoj.com/problems/CALCAREA/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|52|[Treasure Hunt](http://poj.org/problem?id=1066)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|53|[Point on Spiral](http://codeforces.com/problemset/problem/279/A)|Codeforces||Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|54|[Athletics Track](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2693)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|55|[Convex Hull](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2673)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|56|[Gifts in a Hexagonal Box](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1228)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|57|[Bright Lights](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1868)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|58|[Bounding box](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1518)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|59|[SPIRAL RUN](http://www.spoj.com/problems/SPIRAL2/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|60|[Bicycle Race](http://codeforces.com/problemset/problem/659/D)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|61|[Constellation](http://codeforces.com/problemset/problem/618/C)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|3|
|<ul><li>- [ ] Done</li></ul>|62|[Anton and Lines](http://codeforces.com/problemset/problem/593/B)|Codeforces||Codeforces Round #329 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|63|[A Problem about Polyline](http://codeforces.com/problemset/problem/578/A)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|64|[Coat of Anticubism](http://codeforces.com/problemset/problem/667/B)|Codeforces||Codeforces Round #349 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|65|[Mister B and Angle in Polygon](http://codeforces.com/problemset/problem/820/B)|Codeforces||Codeforces Round #421 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|66|[Arpa and an exam about geometry](http://codeforces.com/problemset/problem/851/B)|Codeforces||Codeforces Round #432 (Div. 2, based on IndiaHacks Final Round 2017)|3|
|<ul><li>- [ ] Done</li></ul>|67|[Geometry Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2677)|Live Archive|2009|Asia - Amritapuri|3|
|<ul><li>- [ ] Done</li></ul>|68|[Magic Box](http://codeforces.com/problemset/problem/231/D)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|69|[Where do I Turn?](http://codeforces.com/problemset/problem/227/A)|Codeforces||Codeforces Round #140 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|70|[Hopscotch](http://codeforces.com/problemset/problem/141/B)|Codeforces||Codeforces Round #101 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|71|[Depression](http://codeforces.com/problemset/problem/80/B)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|72|[Triangle](http://codeforces.com/problemset/problem/18/A)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|73|[Running Student](http://codeforces.com/problemset/problem/9/B)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|74|[Ancient Berland Circus](http://codeforces.com/problemset/problem/1/C)|Codeforces||Codeforces Beta Round #1|4|
|<ul><li>- [ ] Done</li></ul>|75|[Will Indiana Jones Get There](http://www.spoj.com/problems/WIJGT/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|76|[Face the mate](http://www.spoj.com/problems/FACENEMY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|77|[Fence](http://poj.org/problem?id=1031)|PKU|||4|
|<ul><li>- [ ] Done</li></ul>|78|[Captain Marmot](http://codeforces.com/problemset/problem/474/C)|Codeforces||Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|79|[Peter and Snow Blower](http://codeforces.com/problemset/problem/613/A)|Codeforces||Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|80|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces||Codeforces Round #308 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|81|[View Angle](http://codeforces.com/problemset/problem/257/C)|Codeforces||Codeforces Round #159 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|82|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces||Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|83|[Tell Your World](http://codeforces.com/problemset/problem/849/B)|Codeforces||Codeforces Round #431 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|84|[The Sultan's Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2232)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|85|[Chocolate Chip Cookies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1077)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|86|[The Teacher's Side of Math](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1892)|Live Archive|2007|Asia - Tokyo|4|
|<ul><li>- [ ] Done</li></ul>|87|[Intersection of Two Prisms](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3076)|Live Archive|2010|Asia - Tokyo|4|
|<ul><li>- [ ] Done</li></ul>|88|[Frontier](http://acm.timus.ru/problem.aspx?space=1&num=1065)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|89|[Dog Distance](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2896)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|90|[Surrounded](http://codeforces.com/problemset/problem/190/B)|Codeforces||Codeforces Round #120 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|91|[Series of Crimes](http://codeforces.com/problemset/problem/181/A)|Codeforces||Croc Champ 2012 - Round 2 (Unofficial Div. 2 Edition)|5|
|<ul><li>- [ ] Done</li></ul>|92|[Rectangle and Square](http://codeforces.com/problemset/problem/135/B)|Codeforces||Codeforces Beta Round #97 (Div. 1) & Codeforces Beta Round #97 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|93|[Four Segments](http://codeforces.com/problemset/problem/14/C)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|94|[Area in Triangle](http://poj.org/problem?id=1927)|PKU|||5|
|<ul><li>- [ ] Done</li></ul>|95|[4-point polyline](http://codeforces.com/problemset/problem/452/B)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|96|[Equilateral Triangle in a Triangle Grid](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4355)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|97|[Number of Parallelograms](http://codeforces.com/problemset/problem/660/D)|Codeforces||Educational Codeforces Round 11|5|
|<ul><li>- [ ] Done</li></ul>|98|[Nearest vectors](http://codeforces.com/problemset/problem/598/C)|Codeforces||Educational Codeforces Round 1|5|
|<ul><li>- [ ] Done</li></ul>|99|[Chip 'n Dale Rescue Rangers](http://codeforces.com/problemset/problem/590/B)|Codeforces||Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|100|[Points on Plane](http://codeforces.com/problemset/problem/576/C)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|101|[Restore Cube ](http://codeforces.com/problemset/problem/464/B)|Codeforces||Codeforces Round #265 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|102|[Tricky Function](http://codeforces.com/problemset/problem/429/D)|Codeforces||Codeforces Round #245 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|103|[Cupboard and Balloons](http://codeforces.com/problemset/problem/342/C)|Codeforces||Codeforces Round #199 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|104|[Kalila and Dimna in the Logging Industry](http://codeforces.com/problemset/problem/319/C)|Codeforces||Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|105|[An overnight dance in discotheque](http://codeforces.com/problemset/problem/814/D)|Codeforces||Codeforces Round #418 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|106|[Nature Reserve](http://codeforces.com/problemset/problem/1059/D)|Codeforces||Codeforces Round #514 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|107|[All Souls Night](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2869)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|108|[Hit Ball](http://codeforces.com/problemset/problem/203/D)|Codeforces||Codeforces Round #128 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|109|[Polygons](http://codeforces.com/problemset/problem/166/B)|Codeforces||Codeforces Round #113 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|110|[Shooting Gallery](http://codeforces.com/problemset/problem/30/C)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|111|[Maximal Area Quadrilateral](http://codeforces.com/problemset/problem/340/B)|Codeforces||Codeforces Round #198 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|112|[Heavy Disc](http://acm.sgu.ru/problem.php?contest=0&problem=417)|SGU|||6|
|<ul><li>- [ ] Done</li></ul>|113|[Area of Two Circles' Intersection](http://codeforces.com/problemset/problem/600/D)|Codeforces||Educational Codeforces Round 2|6|
|<ul><li>- [ ] Done</li></ul>|114|[Rectangle Puzzle](http://codeforces.com/problemset/problem/280/A)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|115|[Ada and Cucumber](http://www.spoj.com/problems/ADAPICK/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|116|[Rooter's Song](http://codeforces.com/problemset/problem/848/B)|Codeforces||Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|117|[Chris and Road](http://codeforces.com/problemset/problem/703/C)|Codeforces||Codeforces Round #365 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|118|[Fighting Against a Polygonal Monster](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2118)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|119|[Tower for Cellular Telephony](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2728)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|120|[Hail](http://acm.timus.ru/problem.aspx?space=1&num=1317)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|121|[Cutting a Polygon](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1808)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|122|[Device](http://acm.timus.ru/problem.aspx?space=1&num=1341)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|123|[Building Bridge](http://codeforces.com/problemset/problem/250/D)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|124|[Robo-Footballer](http://codeforces.com/problemset/problem/248/C)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|125|[Paint Tree](http://codeforces.com/problemset/problem/196/C)|Codeforces||Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|126|[Minimum Sum](http://codeforces.com/problemset/problem/120/J)|Codeforces||School Regional Team Contest, Saratov, 2011|7|
|<ul><li>- [ ] Done</li></ul>|127|[Harry Potter and the Golden Snitch](http://codeforces.com/problemset/problem/65/C)|Codeforces||Codeforces Beta Round #60|7|
|<ul><li>- [ ] Done</li></ul>|128|[Knights](http://codeforces.com/problemset/problem/33/D)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|129|[Sequence of points](http://codeforces.com/problemset/problem/24/C)|Codeforces||Codeforces Beta Round #24|7|
|<ul><li>- [ ] Done</li></ul>|130|[Commentator problem](http://codeforces.com/problemset/problem/2/C)|Codeforces||Codeforces Beta Round #2|7|
|<ul><li>- [ ] Done</li></ul>|131|[A Square and Equilateral Triangles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1230)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|132|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces||Codeforces Round #344 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|133|[Pyramids](http://codeforces.com/problemset/problem/630/Q)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|7|
|<ul><li>- [ ] Done</li></ul>|134|[Turn](http://codeforces.com/problemset/problem/630/M)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|7|
|<ul><li>- [ ] Done</li></ul>|135|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces||Codeforces Round #337 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|136|[Freelancer's Dreams](http://codeforces.com/problemset/problem/605/C)|Codeforces||Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|137|[Tavas and Pashmaks](http://codeforces.com/problemset/problem/535/E)|Codeforces||Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|138|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces||Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|139|[Set of Points](http://codeforces.com/problemset/problem/277/B)|Codeforces||Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|140|[Mirror](http://acm.timus.ru/problem.aspx?space=1&num=1265)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|141|[Fireball](http://acm.timus.ru/problem.aspx?space=1&num=1328)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|142|[Special Olympics](http://codeforces.com/problemset/problem/199/B)|Codeforces||Codeforces Round #125 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|143|[Zoo](http://codeforces.com/problemset/problem/183/B)|Codeforces||Croc Champ 2012 - Final|8|
|<ul><li>- [ ] Done</li></ul>|144|[Space Rescuers](http://codeforces.com/problemset/problem/106/E)|Codeforces||Codeforces Beta Round #82 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|145|[Igloo Skyscraper](http://codeforces.com/problemset/problem/91/E)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|146|[Guard Towers](http://codeforces.com/problemset/problem/85/E)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|147|[Professor's task](http://codeforces.com/problemset/problem/70/D)|Codeforces||Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|148|[Very simple problem](http://codeforces.com/problemset/problem/55/E)|Codeforces||Codeforces Beta Round #51|8|
|<ul><li>- [ ] Done</li></ul>|149|[Happy Farm 5](http://codeforces.com/problemset/problem/50/C)|Codeforces||Codeforces Beta Round #47|8|
|<ul><li>- [ ] Done</li></ul>|150|[Triangles](http://codeforces.com/problemset/problem/13/D)|Codeforces||Codeforces Beta Round #13|8|
|<ul><li>- [ ] Done</li></ul>|151|[Letter A](http://codeforces.com/problemset/problem/13/B)|Codeforces||Codeforces Beta Round #13|8|
|<ul><li>- [ ] Done</li></ul>|152|[Two Friends](http://codeforces.com/problemset/problem/8/D)|Codeforces||Codeforces Beta Round #8|8|
|<ul><li>- [ ] Done</li></ul>|153|[Cookie](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3959)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|154|[Hide and seek](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4413)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|155|[Deformed Wheel](http://poj.org/problem?id=1070)|PKU|||8|
|<ul><li>- [ ] Done</li></ul>|156|[Mirror Box](http://codeforces.com/problemset/problem/241/C)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|8|
|<ul><li>- [ ] Done</li></ul>|157|[Bear and Bowling 4](http://codeforces.com/problemset/problem/660/F)|Codeforces||Educational Codeforces Round 11|8|
|<ul><li>- [ ] Done</li></ul>|158|[Area of a Star](http://codeforces.com/problemset/problem/630/P)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|8|
|<ul><li>- [ ] Done</li></ul>|159|[Arrow](http://codeforces.com/problemset/problem/630/O)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|8|
|<ul><li>- [ ] Done</li></ul>|160|[Max and Bike](http://codeforces.com/problemset/problem/594/B)|Codeforces||Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|161|[Bear and Floodlight](http://codeforces.com/problemset/problem/385/D)|Codeforces||Codeforces Round #226 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|162|[Summer Earnings](http://codeforces.com/problemset/problem/333/E)|Codeforces||Codeforces Round #194 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|163|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces||Codeforces Round #187 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|164|[The Child and Polygon](http://codeforces.com/problemset/problem/437/E)|Codeforces||Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|165|[Alyona and Triangles](http://codeforces.com/problemset/problem/682/E)|Codeforces||Codeforces Round #358 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|166|[Cheese](http://acm.timus.ru/problem.aspx?space=1&num=1583)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|167|[Chapaev](http://acm.timus.ru/problem.aspx?space=1&num=1163)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|168|[Good Manners](http://acm.timus.ru/problem.aspx?space=1&num=1504)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|169|[National Park](http://acm.timus.ru/problem.aspx?space=1&num=1514)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|170|[Kill the Shaitan-Boss](http://acm.timus.ru/problem.aspx?space=1&num=1719)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|171|[Stars](http://codeforces.com/problemset/problem/213/D)|Codeforces||Codeforces Round #131 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|172|[Delivering Carcinogen](http://codeforces.com/problemset/problem/198/C)|Codeforces||Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|173|[Battlefield](http://codeforces.com/problemset/problem/182/A)|Codeforces||Codeforces Round #117 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|174|[New Year Snowflake](http://codeforces.com/problemset/problem/140/F)|Codeforces||Codeforces Round #100|9|
|<ul><li>- [ ] Done</li></ul>|175|[Rotation](http://codeforces.com/problemset/problem/100/I)|Codeforces||Unknown Language Round #3|9|
|<ul><li>- [ ] Done</li></ul>|176|[Help Greg the Dwarf](http://codeforces.com/problemset/problem/98/C)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|177|[Space mines](http://codeforces.com/problemset/problem/89/D)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|178|[Corridor](http://codeforces.com/problemset/problem/82/E)|Codeforces||Yandex.Algorithm 2011 Qualification 2|9|
|<ul><li>- [ ] Done</li></ul>|179|[Archer's Shot](http://codeforces.com/problemset/problem/78/D)|Codeforces||Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|180|[Martian Food](http://codeforces.com/problemset/problem/77/E)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|181|[Ship's Shortest Path](http://codeforces.com/problemset/problem/75/E)|Codeforces||Codeforces Beta Round #67 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|182|[Save the City!](http://codeforces.com/problemset/problem/67/E)|Codeforces||Manthan 2011|9|
|<ul><li>- [ ] Done</li></ul>|183|[Inquisition](http://codeforces.com/problemset/problem/62/C)|Codeforces||Codeforces Beta Round #58|9|
|<ul><li>- [ ] Done</li></ul>|184|[Cannon](http://codeforces.com/problemset/problem/47/E)|Codeforces||Codeforces Beta Round #44 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|185|[Bowls](http://codeforces.com/problemset/problem/36/C)|Codeforces||Codeforces Beta Round #36|9|
|<ul><li>- [ ] Done</li></ul>|186|[Hide-and-Seek](http://codeforces.com/problemset/problem/32/E)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|187|[King's Problem?](http://codeforces.com/problemset/problem/30/D)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|9|
|<ul><li>- [ ] Done</li></ul>|188|[Tetragon](http://codeforces.com/problemset/problem/23/D)|Codeforces||Codeforces Beta Round #23|9|
|<ul><li>- [ ] Done</li></ul>|189|[3D Geometry](p?ID=406)|A2 Online Judge|||9|
|<ul><li>- [ ] Done</li></ul>|190|[Ruminations on Ruminants](http://codeforces.com/problemset/problem/603/D)|Codeforces||Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|191|[Max and Min](http://codeforces.com/problemset/problem/566/G)|Codeforces||VK Cup 2015 - Finals, online mirror|9|
|<ul><li>- [ ] Done</li></ul>|192|[Randomizer](http://codeforces.com/problemset/problem/559/D)|Codeforces||Codeforces Round #313 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|193|[Roland and Rose](http://codeforces.com/problemset/problem/460/E)|Codeforces||Codeforces Round #262 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|194|[New Year Tree Decorations](http://codeforces.com/problemset/problem/379/E)|Codeforces||Good Bye 2013|9|
|<ul><li>- [ ] Done</li></ul>|195|[Ksusha and Square](http://codeforces.com/problemset/problem/293/D)|Codeforces||Croc Champ 2013 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|196|[The Last Hole!](http://codeforces.com/problemset/problem/274/C)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|197|[Little Elephant and Triangle](http://codeforces.com/problemset/problem/220/D)|Codeforces||Codeforces Round #136 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|198|[Runaway to a Shadow](http://codeforces.com/problemset/problem/681/E)|Codeforces||Codeforces Round #357 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|199|[Mouse](http://acm.timus.ru/problem.aspx?space=1&num=1199)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|200|[Intersect Until You're Sick of It](http://acm.timus.ru/problem.aspx?space=1&num=2036)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|201|[Light](http://acm.timus.ru/problem.aspx?space=1&num=1464)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|202|[Karen and Cards](http://codeforces.com/problemset/problem/815/D)|Codeforces||Codeforces Round #419 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|203|[Goat in the Garden 4](http://acm.timus.ru/problem.aspx?space=1&num=1384)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|204|[Wires](http://acm.timus.ru/problem.aspx?space=1&num=1460)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|205|[Triangle Game 2](http://acm.timus.ru/problem.aspx?space=1&num=1637)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|206|[Triangle Game](http://acm.timus.ru/problem.aspx?space=1&num=1482)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|207|[Biscuits](http://acm.timus.ru/problem.aspx?space=1&num=1429)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|208|[Empire Strikes Back](http://acm.timus.ru/problem.aspx?space=1&num=1520)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|209|[The Mentaculus](http://acm.timus.ru/problem.aspx?space=1&num=1839)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|210|[Fire Signals](http://acm.timus.ru/problem.aspx?space=1&num=1956)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|211|[Non-Flying Weather](http://acm.timus.ru/problem.aspx?space=1&num=1894)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|212|[Cubes](http://codeforces.com/problemset/problem/243/D)|Codeforces||Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|213|[Planar Graph](http://codeforces.com/problemset/problem/223/E)|Codeforces||Codeforces Round #138 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|214|[Spider](http://codeforces.com/problemset/problem/223/D)|Codeforces||Codeforces Round #138 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|215|[Martian Colony](http://codeforces.com/problemset/problem/154/E)|Codeforces||Codeforces Round #109 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|216|[Help Greg the Dwarf 2](http://codeforces.com/problemset/problem/142/E)|Codeforces||Codeforces Round #102 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|217|[Birthday](http://codeforces.com/problemset/problem/128/E)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|218|[Alternative Reality](http://codeforces.com/problemset/problem/119/E)|Codeforces||Codeforces Beta Round #90|10|
|<ul><li>- [ ] Done</li></ul>|219|[Darts](http://codeforces.com/problemset/problem/107/E)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|220|[Mogohu-Rea Idol](http://codeforces.com/problemset/problem/87/E)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|221|[Plane of Tanks](http://codeforces.com/problemset/problem/73/F)|Codeforces||Codeforces Beta Round #66|10|
|<ul><li>- [ ] Done</li></ul>|222|[Contact](http://codeforces.com/problemset/problem/68/E)|Codeforces||Codeforces Beta Round #62|10|
|<ul><li>- [ ] Done</li></ul>|223|[Vacuum ?leaner](http://codeforces.com/problemset/problem/54/E)|Codeforces||Codeforces Beta Round #50|10|
|<ul><li>- [ ] Done</li></ul>|224|[BerPaint](http://codeforces.com/problemset/problem/44/F)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|225|[Armistice Area Apportionment](http://codeforces.com/problemset/problem/645/G)|Codeforces||CROC 2016 - Elimination Round|10|
|<ul><li>- [ ] Done</li></ul>|226|[New Year and Cake](http://codeforces.com/problemset/problem/611/G)|Codeforces||Good Bye 2015|10|
|<ul><li>- [ ] Done</li></ul>|227|[Cross Sum](http://codeforces.com/problemset/problem/607/E)|Codeforces||Codeforces Round #336 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|228|[Cut Length](http://codeforces.com/problemset/problem/598/F)|Codeforces||Educational Codeforces Round 1|10|
|<ul><li>- [ ] Done</li></ul>|229|[BCPC](http://codeforces.com/problemset/problem/592/E)|Codeforces||Codeforces Round #328 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|230|[Spectator Riots](http://codeforces.com/problemset/problem/575/E)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|10|
|<ul><li>- [ ] Done</li></ul>|231|[Points in triangle](http://codeforces.com/problemset/problem/530/H)|Codeforces||VK Cup 2015 - Wild Card Round 1|10|
|<ul><li>- [ ] Done</li></ul>|232|[Triangles 3000](http://codeforces.com/problemset/problem/528/E)|Codeforces||Codeforces Round #296 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|233|[Gears](http://codeforces.com/problemset/problem/497/D)|Codeforces||Codeforces Round #283 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|234|[Gena and Second Distance](http://codeforces.com/problemset/problem/442/E)|Codeforces||Codeforces Round #253 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|235|[Playing the ball](http://codeforces.com/problemset/problem/420/E)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|236|[Lightbulb for Minister](http://codeforces.com/problemset/problem/394/E)|Codeforces||Codeforces Round #231 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|237|[Fox and Meteor Shower](http://codeforces.com/problemset/problem/388/E)|Codeforces||Codeforces Round #228 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|238|[Cookie Clicker](http://codeforces.com/problemset/problem/377/E)|Codeforces||Codeforces Round #222 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|239|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces||Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|240|[Drawing Circles is Fun](http://codeforces.com/problemset/problem/372/E)|Codeforces||Codeforces Round #219 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|241|[Looking for Owls](http://codeforces.com/problemset/problem/350/D)|Codeforces||Codeforces Round #203 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|242|[Tennis Rackets](http://codeforces.com/problemset/problem/309/D)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|243|[Polygon](http://codeforces.com/problemset/problem/306/D)|Codeforces||Testing Round #6|10|
|<ul><li>- [ ] Done</li></ul>|244|[Emperor's Problem](http://codeforces.com/problemset/problem/46/G)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|245|[DravDe saves the world](http://codeforces.com/problemset/problem/28/E)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|10|
|<ul><li>- [ ] Done</li></ul>|246|[Hongcow Draws a Circle](http://codeforces.com/problemset/problem/744/D)|Codeforces||Codeforces Round #385 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|247|[Lada Malina](http://codeforces.com/problemset/problem/853/E)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises)|10|
|<ul><li>- [ ] Done</li></ul>|248|[Iron Man](http://codeforces.com/problemset/problem/704/E)|Codeforces||Codeforces Round #366 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|249|[Mobile Life](http://acm.timus.ru/problem.aspx?space=1&num=1415)|Timus|||10|
|<ul><li>- [ ] Done</li></ul>|250|[Multishot in the Secret Cow Level](http://acm.timus.ru/problem.aspx?space=1&num=1556)|Timus|||10|
|<ul><li>- [ ] Done</li></ul>|251|[Winding Number](http://acm.timus.ru/problem.aspx?space=1&num=1599)|Timus|||10|
|<ul><li>- [ ] Done</li></ul>|252|[Interfering Segment](http://acm.timus.ru/problem.aspx?space=1&num=1626)|Timus|||10|
|<ul><li>- [ ] Done</li></ul>|253|[Goat in the Garden 6](http://acm.timus.ru/problem.aspx?space=1&num=1662)|Timus|||10|
|<ul><li>- [ ] Done</li></ul>|254|[Boss, I Can See You!](http://acm.timus.ru/problem.aspx?space=1&num=1955)|Timus|||10|
