# 013. Binary_Search_Ternary_Search


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Aggressive cows](http://www.spoj.com/problems/AGGRCOW/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Copying Books](http://www.spoj.com/problems/BOOKS1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Fill the Cisterns](http://www.spoj.com/problems/CISTFILL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Pie](http://www.spoj.com/problems/PIE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Pyramids](http://www.spoj.com/problems/PIR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Sphere in a tetrahedron](http://www.spoj.com/problems/TETRA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[4 values whose sum is 0](http://www.spoj.com/problems/SUMFOUR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[ABCDEF](http://www.spoj.com/problems/ABCDEF/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Help the soldier](http://www.spoj.com/problems/SOLDIER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Rent your airplane and make money](http://www.spoj.com/problems/RENT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[K12 - Building Construction](http://www.spoj.com/problems/KOPC12A/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Hamster flight](http://www.spoj.com/problems/HAMSTER1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Eko](http://www.spoj.com/problems/EKO/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[String it out](http://www.spoj.com/problems/SUBS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Not a Triangle](http://www.spoj.com/problems/NOTATRI/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Shake Shake Shaky](http://www.spoj.com/problems/MAIN8_C/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|17|[Exact Sum](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1998)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|18|[4 Values whose Sum is 0](http://acm.tju.edu.cn/toj/showp2407.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Solve It](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1282)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Touch of Venom](http://www.spoj.com/problems/VENOM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[The Playboy Chimp](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1552)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Where is the Marble?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1415)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Books](http://codeforces.com/problemset/problem/279/B)|Codeforces||Codeforces Round #171 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[Cable master](http://poj.org/problem?id=1064)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Aggressive cows](http://poj.org/problem?id=2456)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|26|[River Hopscotch](http://poj.org/problem?id=3258)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Monthly Expense](http://poj.org/problem?id=3273)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Queries about less or equal elements](http://codeforces.com/problemset/problem/600/B)|Codeforces||Educational Codeforces Round 2|1|
|<ul><li>- [ ] Done</li></ul>|29|[Kefa and Company](http://codeforces.com/problemset/problem/580/B)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Vanya and Lanterns](http://codeforces.com/problemset/problem/492/B)|Codeforces||Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Worms](http://codeforces.com/problemset/problem/474/B)|Codeforces||Codeforces Round #271 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Binary Search Tree](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2848)|Live Archive|2010|Asia - Daejeon|1|
|<ul><li>- [ ] Done</li></ul>|34|[Interesting drink](http://codeforces.com/problemset/problem/706/B)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|35|[Chloe and the sequence ](http://codeforces.com/problemset/problem/743/B)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[GCD LCM](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2383)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|37|[Prime Frequency](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1730)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Ternary](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2126)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|39|[DZY Loves Chessboard](http://codeforces.com/problemset/problem/445/A)|Codeforces||Codeforces Round #254 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Crossed Ladders](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1507)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|41|[Burning Midnight Oil](http://codeforces.com/problemset/problem/165/B)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[Mummy Madness](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3137)|Live Archive|2011|World Finals - Orlando|2|
|<ul><li>- [ ] Done</li></ul>|43|[Copying Books](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=655)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|44|[Points on Line](http://codeforces.com/problemset/problem/251/A)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|45|[Rank List](http://codeforces.com/problemset/problem/166/A)|Codeforces||Codeforces Round #113 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|46|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|47|[Lucky Numbers (easy)](http://codeforces.com/problemset/problem/96/B)|Codeforces||Codeforces Beta Round #77 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|48|[Distributing Ballot Boxes](http://www.spoj.com/problems/BALLOT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|49|[Fill the Containers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2408)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|50|[Popes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=898)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|51|[Multiplication Table](http://codeforces.com/problemset/problem/448/D)|Codeforces||Codeforces Round #256 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|52|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces||Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|53|[Drying](http://poj.org/problem?id=3104)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|54|[Dropping tests](http://poj.org/problem?id=2976)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|55|[K Best](http://poj.org/problem?id=3111)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|56|[Median](http://poj.org/problem?id=3579)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|57|[Moo University - Financial Aid](http://poj.org/problem?id=2010)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|58|[Chat Order](http://codeforces.com/problemset/problem/637/B)|Codeforces||VK Cup 2016 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|59|[Chain Reaction](http://codeforces.com/problemset/problem/607/A)|Codeforces||Codeforces Round #336 (Div. 1) & Codeforces Round #336 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|60|[Geometric Progression](http://codeforces.com/problemset/problem/567/C)|Codeforces||Codeforces Round #Pi (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|61|[Tourist's Notes](http://codeforces.com/problemset/problem/538/C)|Codeforces||Codeforces Round #300|2|
|<ul><li>- [ ] Done</li></ul>|62|[Counting Kangaroos is Fun](http://codeforces.com/problemset/problem/372/A)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|63|[Hamburgers](http://codeforces.com/problemset/problem/371/C)|Codeforces||Codeforces Round #218 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|64|[Mafia](http://codeforces.com/problemset/problem/348/A)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|65|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces||Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|66|[k-Multiple Free Set](http://codeforces.com/problemset/problem/274/A)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|67|[Prime Matrix](http://codeforces.com/problemset/problem/271/B)|Codeforces||Codeforces Round #166 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|68|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|69|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces||Codeforces Round #354 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|70|[New Year and Rating](http://codeforces.com/problemset/problem/750/C)|Codeforces||Good Bye 2016|2|
|<ul><li>- [ ] Done</li></ul>|71|[String Game](http://codeforces.com/problemset/problem/778/A)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|72|[Karen and Coffee](http://codeforces.com/problemset/problem/816/B)|Codeforces||Codeforces Round #419 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|73|[Sagheer and Nubian Market](http://codeforces.com/problemset/problem/812/C)|Codeforces||Codeforces Round #417 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|74|[Anton and Fairy Tale](http://codeforces.com/problemset/problem/785/C)|Codeforces||Codeforces Round #404 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|75|[Binary Search Tree](http://www.spoj.com/problems/BST/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|76|[ICPC Scoreboard](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1936)|Live Archive|2007|Latin America - South America|2|
|<ul><li>- [ ] Done</li></ul>|77|[Meteors](http://www.spoj.com/problems/METEORS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|78|[Funny scales](http://www.spoj.com/problems/SCALE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|79|[ICPC Scoreboard](http://www.spoj.com/problems/ICPCS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|80|[Physics Practical](http://codeforces.com/problemset/problem/253/B)|Codeforces||Codeforces Round #154 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|81|[Primes on Interval](http://codeforces.com/problemset/problem/237/C)|Codeforces||Codeforces Round #147 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|82|[Non-square Equation](http://codeforces.com/problemset/problem/233/B)|Codeforces||Codeforces Round #144 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|83|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces||Codeforces Round #143 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|84|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces||Codeforces Round #138 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|85|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces||Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|86|[Little Elephant and Interval](http://codeforces.com/problemset/problem/204/A)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|87|[Let's Watch Football](http://codeforces.com/problemset/problem/195/A)|Codeforces||Codeforces Round #123 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|88|[Funky Numbers](http://codeforces.com/problemset/problem/192/A)|Codeforces||Codeforces Round #121 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|89|[Roads Repair](http://www.spoj.com/problems/MROADS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|90|[grace marks](http://www.spoj.com/problems/MTHUR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|91|[Trick or Treat](http://www.spoj.com/problems/TRICKTRT/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|92|[Glasnici](http://www.spoj.com/problems/GLASNICI/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|93|[Towers of Hanoi](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=190)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|94|[Through the Desert](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3086)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|95|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces||Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|96|[Fantastic Discovery](http://www.spoj.com/problems/IMMERSED/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|97|[Cow Acrobats](http://poj.org/problem?id=3045)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|98|[Matrix](http://poj.org/problem?id=3685)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|99|[Telephone Lines](http://poj.org/problem?id=3662)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|100|[Hard Process](http://codeforces.com/problemset/problem/660/C)|Codeforces||Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|101|[Bear and Blocks](http://codeforces.com/problemset/problem/573/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|102|[Mike and Feet](http://codeforces.com/problemset/problem/547/B)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|103|[Glass Carving](http://codeforces.com/problemset/problem/527/C)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|104|[Watto and Mechanism](http://codeforces.com/problemset/problem/514/C)|Codeforces||Codeforces Round #291 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|105|[Maximum Value](http://codeforces.com/problemset/problem/484/B)|Codeforces||Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|106|[Long Jumps](http://codeforces.com/problemset/problem/479/D)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|107|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces||Codeforces Round #262 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|108|[Megacity](http://codeforces.com/problemset/problem/424/B)|Codeforces||Codeforces Round #242 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|109|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|110|[Mashmokh and Tokens](http://codeforces.com/problemset/problem/415/B)|Codeforces||Codeforces Round #240 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|111|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|112|[Bubble Sort Graph](http://codeforces.com/problemset/problem/340/D)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|113|[Quiz](http://codeforces.com/problemset/problem/337/C)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|114|[Eugeny and Play List](http://codeforces.com/problemset/problem/302/B)|Codeforces||Codeforces Round #182 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|115|[LLPS](http://codeforces.com/problemset/problem/202/A)|Codeforces||Codeforces Round #127 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|116|[Dress'em in Vests!](http://codeforces.com/problemset/problem/161/A)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|117|[Modified GCD](http://codeforces.com/problemset/problem/75/C)|Codeforces||Codeforces Beta Round #67 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|118|[Grapevine](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3344)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|119|[Exams](http://codeforces.com/problemset/problem/732/D)|Codeforces||Codeforces Round #377 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|120|[Alyona and Spreadsheet](http://codeforces.com/problemset/problem/777/C)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|121|[Cloud of Hashtags](http://codeforces.com/problemset/problem/777/D)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|122|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces||Codeforces Round #367 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|123|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces||Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|124|[Well-known Numbers](http://codeforces.com/problemset/problem/225/B)|Codeforces||Codeforces Round #139 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|125|[Little Elephant and Cards](http://codeforces.com/problemset/problem/204/B)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|126|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces||Codeforces Round #111 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|127|[String Manipulation 1.0](http://codeforces.com/problemset/problem/159/C)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|128|[Matchmaker](http://codeforces.com/problemset/problem/159/B)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|129|[Steps](http://codeforces.com/problemset/problem/152/B)|Codeforces||Codeforces Round #108 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|130|[Escape](http://codeforces.com/problemset/problem/148/B)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|131|[New Year Snowmen](http://codeforces.com/problemset/problem/140/C)|Codeforces||Codeforces Round #100|4|
|<ul><li>- [ ] Done</li></ul>|132|[Queue](http://codeforces.com/problemset/problem/91/B)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|133|[Binary Number](http://codeforces.com/problemset/problem/92/B)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|134|[Garland](http://poj.org/problem?id=1759)|PKU|||4|
|<ul><li>- [ ] Done</li></ul>|135|[Image Preview](http://codeforces.com/problemset/problem/650/B)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|136|[Longest k-Good Segment](http://codeforces.com/problemset/problem/616/D)|Codeforces||Educational Codeforces Round 5|4|
|<ul><li>- [ ] Done</li></ul>|137|[Peter and Snow Blower](http://codeforces.com/problemset/problem/613/A)|Codeforces||Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|138|[Pasha and Phone](http://codeforces.com/problemset/problem/595/B)|Codeforces||Codeforces Round #330 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|139|[Weakness and Poorness](http://codeforces.com/problemset/problem/578/C)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|4|
|<ul><li>- [ ] Done</li></ul>|140|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces||Codeforces Round #316 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|141|[One-Dimensional Battle Ships](http://codeforces.com/problemset/problem/567/D)|Codeforces||Codeforces Round #Pi (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|142|[GukiZ hates Boxes](http://codeforces.com/problemset/problem/551/C)|Codeforces||Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|143|[Tavas and Karafs](http://codeforces.com/problemset/problem/535/C)|Codeforces||Codeforces Round #299 (Div. 2) & Codeforces Round #299 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|144|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|145|[Tennis Game](http://codeforces.com/problemset/problem/496/D)|Codeforces||Codeforces Round #283 (Div. 2) & Codeforces Round #283 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|146|[Vanya and Computer Game](http://codeforces.com/problemset/problem/492/D)|Codeforces||Codeforces Round #280 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|147|[Fight the Monster](http://codeforces.com/problemset/problem/487/A)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|148|[Friends and Presents](http://codeforces.com/problemset/problem/483/B)|Codeforces||Codeforces Round #275 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|149|[MUH and House of Cards](http://codeforces.com/problemset/problem/471/C)|Codeforces||Codeforces Round #269 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|150|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|151|[Devu and his Brother](http://codeforces.com/problemset/problem/439/D)|Codeforces||Codeforces Round #251 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|152|[Sereja and Prefixes](http://codeforces.com/problemset/problem/380/A)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|153|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces||Codeforces Round #209 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|154|[Ciel and Robot](http://codeforces.com/problemset/problem/321/A)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|155|[Pipeline](http://codeforces.com/problemset/problem/287/B)|Codeforces||Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|156|[Petya and Divisors](http://codeforces.com/problemset/problem/111/B)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|157|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|158|[Robin Hood](http://codeforces.com/problemset/problem/671/B)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|159|[As Fast As Possible](http://codeforces.com/problemset/problem/700/A)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|160|[Office Keys](http://codeforces.com/problemset/problem/830/A)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|161|[Alyona and a tree](http://codeforces.com/problemset/problem/739/B)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|162|[Mike and Chocolate Thieves](http://codeforces.com/problemset/problem/689/C)|Codeforces||Codeforces Round #361 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|163|[XK Segments](http://codeforces.com/problemset/problem/895/B)|Codeforces||Codeforces Round #448 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|164|[Showstopper](http://www.spoj.com/problems/MSE07E/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|165|[Energy exchange](http://codeforces.com/problemset/problem/68/B)|Codeforces||Codeforces Beta Round #62|5|
|<ul><li>- [ ] Done</li></ul>|166|[Guilty --- to the kitchen!](http://codeforces.com/problemset/problem/42/A)|Codeforces||Codeforces Beta Round #41|5|
|<ul><li>- [ ] Done</li></ul>|167|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|168|[Monitor](http://codeforces.com/problemset/problem/16/C)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|169|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|170|[Showstopper](http://poj.org/problem?id=3484)|PKU|||5|
|<ul><li>- [ ] Done</li></ul>|171|[Robot Rapping Results Report](http://codeforces.com/problemset/problem/645/D)|Codeforces||CROC 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|172|[Enduring Exodus](http://codeforces.com/problemset/problem/645/C)|Codeforces||CROC 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|173|[Skills](http://codeforces.com/problemset/problem/613/B)|Codeforces||Codeforces Round #339 (Div. 1) & Codeforces Round #339 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|174|[Chip 'n Dale Rescue Rangers](http://codeforces.com/problemset/problem/590/B)|Codeforces||Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|175|[Gourmet and Banquet](http://codeforces.com/problemset/problem/589/F)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|5|
|<ul><li>- [ ] Done</li></ul>|176|[Kyoya and Permutation](http://codeforces.com/problemset/problem/553/B)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|177|[Degenerate Matrix](http://codeforces.com/problemset/problem/549/H)|Codeforces||Looksery Cup 2015|5|
|<ul><li>- [ ] Done</li></ul>|178|[Handshakes](http://codeforces.com/problemset/problem/534/D)|Codeforces||Codeforces Round #298 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|179|[The Art of Dealing with ATM](http://codeforces.com/problemset/problem/524/C)|Codeforces||VK Cup 2015 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|180|[R2D2 and Droid Army](http://codeforces.com/problemset/problem/514/D)|Codeforces||Codeforces Round #291 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|181|[Strip](http://codeforces.com/problemset/problem/487/B)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|182|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces||Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|183|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|184|[Making Sequences is Fun](http://codeforces.com/problemset/problem/373/B)|Codeforces||Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|185|[Sereja ans Anagrams](http://codeforces.com/problemset/problem/367/B)|Codeforces||Codeforces Round #215 (Div. 1) & Codeforces Round #215 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|186|[Renting Bikes](http://codeforces.com/problemset/problem/363/D)|Codeforces||Codeforces Round #211 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|187|[Levko and Array](http://codeforces.com/problemset/problem/360/B)|Codeforces||Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|188|[Read Time](http://codeforces.com/problemset/problem/343/C)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|189|[Yaroslav and Time](http://codeforces.com/problemset/problem/301/B)|Codeforces||Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|190|[Cycles](http://codeforces.com/problemset/problem/232/A)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|191|[Olympiad](http://codeforces.com/problemset/problem/222/D)|Codeforces||Codeforces Round #137 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|192|[Blood Cousins](http://codeforces.com/problemset/problem/208/E)|Codeforces||Codeforces Round #130 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|193|[Misha and Permutations Summation](http://codeforces.com/problemset/problem/501/D)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|194|[Road to Post Office](http://codeforces.com/problemset/problem/702/D)|Codeforces||Educational Codeforces Round 15|5|
|<ul><li>- [ ] Done</li></ul>|195|[Copying Data](http://codeforces.com/problemset/problem/292/E)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|196|[The Bakery](http://codeforces.com/problemset/problem/833/B)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|197|[Complete The Graph](http://codeforces.com/problemset/problem/715/B)|Codeforces||Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|198|[Leaving Auction](http://codeforces.com/problemset/problem/749/D)|Codeforces||Codeforces Round #388 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|199|[Cartons of milk](http://codeforces.com/problemset/problem/767/D)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|200|[Fedor and coupons](http://codeforces.com/problemset/problem/754/D)|Codeforces||Codeforces Round #390 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|201|[Vitya and Strange Lesson](http://codeforces.com/problemset/problem/842/D)|Codeforces||Codeforces Round #430 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|202|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces||Codeforces Round #361 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|203|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|204|[Mr. Bender and Square](http://codeforces.com/problemset/problem/255/D)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|205|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces||Codeforces Round #142 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|206|[Guess That Car!](http://codeforces.com/problemset/problem/201/B)|Codeforces||Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|207|[Mushroom Scientists](http://codeforces.com/problemset/problem/185/B)|Codeforces||Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|208|[Number of Triplets](http://codeforces.com/problemset/problem/181/B)|Codeforces||Croc Champ 2012 - Round 2 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|209|[Hot Bath](http://codeforces.com/problemset/problem/126/A)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|210|[Buses](http://codeforces.com/problemset/problem/101/B)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|211|[Sum of Medians](http://codeforces.com/problemset/problem/85/D)|Codeforces||Yandex.Algorithm 2011 Round 1|6|
|<ul><li>- [ ] Done</li></ul>|212|[Doctor](http://codeforces.com/problemset/problem/83/B)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|213|[Tyndex.Brome](http://codeforces.com/problemset/problem/62/B)|Codeforces||Codeforces Beta Round #58|6|
|<ul><li>- [ ] Done</li></ul>|214|[Stripe 2](http://codeforces.com/problemset/problem/21/C)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|215|[Array](http://codeforces.com/problemset/problem/57/C)|Codeforces||Codeforces Beta Round #53|6|
|<ul><li>- [ ] Done</li></ul>|216|[Boxes of Chocolate](http://www.spoj.com/problems/BOXSCHOC/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|217|[CUBE ROOT](http://www.spoj.com/problems/CUBEROO2/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|218|[Delivery Bears](http://codeforces.com/problemset/problem/653/D)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|219|[Gadgets for dollars and pounds](http://codeforces.com/problemset/problem/609/D)|Codeforces||Educational Codeforces Round 3|6|
|<ul><li>- [ ] Done</li></ul>|220|[Hiring](http://codeforces.com/problemset/problem/589/G)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|6|
|<ul><li>- [ ] Done</li></ul>|221|[GukiZ and GukiZiana](http://codeforces.com/problemset/problem/551/E)|Codeforces||Codeforces Round #307 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|222|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces||Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|223|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|224|[Restoring Increasing Sequence](http://codeforces.com/problemset/problem/490/E)|Codeforces||Codeforces Round #279 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|225|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces||Codeforces Round #247 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|226|[Police Patrol](http://codeforces.com/problemset/problem/427/E)|Codeforces||Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|227|[Fly, freebies, fly!](http://codeforces.com/problemset/problem/386/B)|Codeforces||Testing Round #9|6|
|<ul><li>- [ ] Done</li></ul>|228|[Number Busters](http://codeforces.com/problemset/problem/382/B)|Codeforces||Codeforces Round #224 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|229|[Valera and Queries](http://codeforces.com/problemset/problem/369/E)|Codeforces||Codeforces Round #216 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|230|[Banana](http://codeforces.com/problemset/problem/335/A)|Codeforces||MemSQL start[c]up Round 2 - online version|6|
|<ul><li>- [ ] Done</li></ul>|231|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces||Codeforces Round #194 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|232|[Stadium and Games](http://codeforces.com/problemset/problem/325/B)|Codeforces||MemSQL start[c]up Round 1|6|
|<ul><li>- [ ] Done</li></ul>|233|[Sereja and Periods](http://codeforces.com/problemset/problem/314/B)|Codeforces||Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|234|[Santa Claus and Tangerines](http://codeforces.com/problemset/problem/748/E)|Codeforces||Technocup 2017 - Elimination Round 3|6|
|<ul><li>- [ ] Done</li></ul>|235|[Searching Rectangles](http://codeforces.com/problemset/problem/713/B)|Codeforces||Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|236|[Glad to see you!](http://codeforces.com/problemset/problem/809/B)|Codeforces||Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|237|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces||Codeforces Round #384 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|238|[Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3705)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|239|[Building Bridge](http://codeforces.com/problemset/problem/250/D)|Codeforces||CROC-MBTU 2012, Final Round (Online version, Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|240|[Robo-Footballer](http://codeforces.com/problemset/problem/248/C)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|241|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces||Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|242|[Log Stream Analysis](http://codeforces.com/problemset/problem/245/F)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|7|
|<ul><li>- [ ] Done</li></ul>|243|[Spider's Web](http://codeforces.com/problemset/problem/216/D)|Codeforces||Codeforces Round #133 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|244|[Programming Language](http://codeforces.com/problemset/problem/200/D)|Codeforces||Codeforces Round #126 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|245|[Cubes](http://codeforces.com/problemset/problem/180/E)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|246|[Lemmings](http://codeforces.com/problemset/problem/163/B)|Codeforces||VK Cup 2012 Round 2|7|
|<ul><li>- [ ] Done</li></ul>|247|[Mushroom Gnomes - 2](http://codeforces.com/problemset/problem/138/C)|Codeforces||Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|248|[Biathlon](http://codeforces.com/problemset/problem/84/C)|Codeforces||Codeforces Beta Round #72 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|249|[Optical Experiment](http://codeforces.com/problemset/problem/67/D)|Codeforces||Manthan 2011|7|
|<ul><li>- [ ] Done</li></ul>|250|[Harry Potter and the Golden Snitch](http://codeforces.com/problemset/problem/65/C)|Codeforces||Codeforces Beta Round #60|7|
|<ul><li>- [ ] Done</li></ul>|251|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|252|[Blog Photo](http://codeforces.com/problemset/problem/53/B)|Codeforces||Codeforces Beta Round #49 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|253|[Three Base Stations](http://codeforces.com/problemset/problem/51/C)|Codeforces||Codeforces Beta Round #48|7|
|<ul><li>- [ ] Done</li></ul>|254|[Zip-line](http://codeforces.com/problemset/problem/650/D)|Codeforces||Codeforces Round #345 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|255|[Hostname Aliases](http://codeforces.com/problemset/problem/644/C)|Codeforces||CROC 2016 - Qualification|7|
|<ul><li>- [ ] Done</li></ul>|256|[Simple Skewness](http://codeforces.com/problemset/problem/626/E)|Codeforces||8VC Venture Cup 2016 - Elimination Round|7|
|<ul><li>- [ ] Done</li></ul>|257|[Professor GukiZ and Two Arrays](http://codeforces.com/problemset/problem/620/D)|Codeforces||Educational Codeforces Round 6|7|
|<ul><li>- [ ] Done</li></ul>|258|[Hexagons](http://codeforces.com/problemset/problem/615/E)|Codeforces||Codeforces Round #338 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|259|[Case of a Top Secret](http://codeforces.com/problemset/problem/555/D)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|260|[Nudist Beach](http://codeforces.com/problemset/problem/553/D)|Codeforces||Codeforces Round #309 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|261|[Arthur and Questions](http://codeforces.com/problemset/problem/518/E)|Codeforces||Codeforces Round #293 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|262|[Hiking](http://codeforces.com/problemset/problem/489/E)|Codeforces||Codeforces Round #277.5 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|263|[Sign on Fence](http://codeforces.com/problemset/problem/484/E)|Codeforces||Codeforces Round #276 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|264|[Hack it!](http://codeforces.com/problemset/problem/468/C)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|265|[Sereja and Squares](http://codeforces.com/problemset/problem/425/D)|Codeforces||Codeforces Round #243 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|266|[Bug in Code](http://codeforces.com/problemset/problem/421/D)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|267|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces||Codeforces Round #234 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|268|[George and Cards](http://codeforces.com/problemset/problem/387/E)|Codeforces||Codeforces Round #227 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|269|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces||Codeforces Round #220 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|270|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces||Codeforces Round #214 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|271|[Empire Strikes Back](http://codeforces.com/problemset/problem/300/E)|Codeforces||Codeforces Round #181 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|272|[Printer](http://codeforces.com/problemset/problem/253/E)|Codeforces||Codeforces Round #154 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|273|[Sweets for Everyone!](http://codeforces.com/problemset/problem/248/D)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|274|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces||Codeforces Round #121 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|275|[Space Voyage](http://codeforces.com/problemset/problem/177/E1)|Codeforces||ABBYY Cup 2.0 - Easy|8|
|<ul><li>- [ ] Done</li></ul>|276|[Smile House](http://codeforces.com/problemset/problem/147/B)|Codeforces||Codeforces Testing Round #4|8|
|<ul><li>- [ ] Done</li></ul>|277|[Present to Mom](http://codeforces.com/problemset/problem/131/F)|Codeforces||Codeforces Beta Round #95 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|278|[MST Company](http://codeforces.com/problemset/problem/125/E)|Codeforces||Codeforces Testing Round #2|8|
|<ul><li>- [ ] Done</li></ul>|279|[Space Rescuers](http://codeforces.com/problemset/problem/106/E)|Codeforces||Codeforces Beta Round #82 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|280|[Guard Towers](http://codeforces.com/problemset/problem/85/E)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|281|[Petya and Tree](http://codeforces.com/problemset/problem/85/C)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|282|[Tourist](http://codeforces.com/problemset/problem/76/F)|Codeforces||All-Ukrainian School Olympiad in Informatics|8|
|<ul><li>- [ ] Done</li></ul>|283|[Need For Brake](http://codeforces.com/problemset/problem/73/B)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|284|[Lucky Tickets](http://codeforces.com/problemset/problem/70/C)|Codeforces||Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|285|[Bombing](http://codeforces.com/problemset/problem/50/D)|Codeforces||Codeforces Beta Round #47|8|
|<ul><li>- [ ] Done</li></ul>|286|[Tricky and Clever Password](http://codeforces.com/problemset/problem/30/E)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|287|[Don't fear, DravDe is kind](http://codeforces.com/problemset/problem/28/D)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|288|[Berland collider](http://codeforces.com/problemset/problem/24/E)|Codeforces||Codeforces Beta Round #24|8|
|<ul><li>- [ ] Done</li></ul>|289|[Two Friends](http://codeforces.com/problemset/problem/8/D)|Codeforces||Codeforces Beta Round #8|8|
|<ul><li>- [ ] Done</li></ul>|290|[Bear and Bowling 4](http://codeforces.com/problemset/problem/660/F)|Codeforces||Educational Codeforces Round 11|8|
|<ul><li>- [ ] Done</li></ul>|291|[Startup Funding](http://codeforces.com/problemset/problem/633/E)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|292|[Preorder Test](http://codeforces.com/problemset/problem/627/D)|Codeforces||8VC Venture Cup 2016 - Final Round|8|
|<ul><li>- [ ] Done</li></ul>|293|[Electric Charges](http://codeforces.com/problemset/problem/623/C)|Codeforces||AIM Tech Round (Div. 1) & AIM Tech Round (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|294|[New Year and Cleaning](http://codeforces.com/problemset/problem/611/F)|Codeforces||Good Bye 2015|8|
|<ul><li>- [ ] Done</li></ul>|295|[Max and Bike](http://codeforces.com/problemset/problem/594/B)|Codeforces||Codeforces Round #330 (Div. 1) & Codeforces Round #330 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|296|[Misha and Palindrome Degree](http://codeforces.com/problemset/problem/501/E)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|297|[DZY Loves Planting](http://codeforces.com/problemset/problem/444/E)|Codeforces||Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|298|[DZY Loves Strings](http://codeforces.com/problemset/problem/444/D)|Codeforces||Codeforces Round #254 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|299|[Biathlon Track](http://codeforces.com/problemset/problem/424/D)|Codeforces||Codeforces Round #242 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|300|[Mashmokh and Water Tanks](http://codeforces.com/problemset/problem/414/D)|Codeforces||Codeforces Round #240 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|301|[Maze 1D](http://codeforces.com/problemset/problem/404/E)|Codeforces||Codeforces Round #237 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|302|[Volcanoes](http://codeforces.com/problemset/problem/383/B)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|303|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces||Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|304|[Summer Earnings](http://codeforces.com/problemset/problem/333/E)|Codeforces||Codeforces Round #194 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|305|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces||Codeforces Round #187 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|306|[Memory for Arrays](http://codeforces.com/problemset/problem/309/C)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|307|[Morning run](http://codeforces.com/problemset/problem/309/A)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|308|[Vanya and Balloons](http://codeforces.com/problemset/problem/677/E)|Codeforces||Codeforces Round #355 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|309|[Michael and Charging Stations](http://codeforces.com/problemset/problem/853/D)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises)|8|
|<ul><li>- [ ] Done</li></ul>|310|[Animals and Puzzle](http://codeforces.com/problemset/problem/713/D)|Codeforces||Codeforces Round #371 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|311|[Friends](http://codeforces.com/problemset/problem/241/B)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|312|[Fence](http://codeforces.com/problemset/problem/232/D)|Codeforces||Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|313|[Cutting a Fence](http://codeforces.com/problemset/problem/212/D)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|314|[Thoroughly Bureaucratic Organization](http://codeforces.com/problemset/problem/201/E)|Codeforces||Codeforces Round #127 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|315|[Tractor College](http://codeforces.com/problemset/problem/200/E)|Codeforces||Codeforces Round #126 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|316|[Gripping Story](http://codeforces.com/problemset/problem/198/E)|Codeforces||Codeforces Round #125 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|317|[Delivering Carcinogen](http://codeforces.com/problemset/problem/198/C)|Codeforces||Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|318|[Space Voyage](http://codeforces.com/problemset/problem/177/E2)|Codeforces||ABBYY Cup 2.0 - Easy|9|
|<ul><li>- [ ] Done</li></ul>|319|[Minimum Diameter](http://codeforces.com/problemset/problem/164/D)|Codeforces||VK Cup 2012 Round 3|9|
|<ul><li>- [ ] Done</li></ul>|320|[Buses and People](http://codeforces.com/problemset/problem/160/E)|Codeforces||Codeforces Round #111 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|321|[Freezing with Style](http://codeforces.com/problemset/problem/150/E)|Codeforces||Codeforces Round #107 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|322|[Lucky Segments](http://codeforces.com/problemset/problem/121/D)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|323|[Help Greg the Dwarf](http://codeforces.com/problemset/problem/98/C)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only) & Codeforces Beta Round #78 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|324|[Winning Strategy](http://codeforces.com/problemset/problem/97/C)|Codeforces||Yandex.Algorithm 2011 Finals|9|
|<ul><li>- [ ] Done</li></ul>|325|[Archer's Shot](http://codeforces.com/problemset/problem/78/D)|Codeforces||Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|326|[Pasha and Pipe](http://codeforces.com/problemset/problem/518/F)|Codeforces||Codeforces Round #293 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|327|[Mr. Kitayuta vs. Bamboos](http://codeforces.com/problemset/problem/505/E)|Codeforces||Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|328|[Chemistry Experiment](http://codeforces.com/problemset/problem/431/E)|Codeforces||Codeforces Round #247 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|329|[Dividing Kingdom](http://codeforces.com/problemset/problem/260/E)|Codeforces||Codeforces Round #158 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|330|[Optimal Point](http://codeforces.com/problemset/problem/685/C)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|331|[Karen and Cards](http://codeforces.com/problemset/problem/815/D)|Codeforces||Codeforces Round #419 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|332|[Strange Radiation](http://codeforces.com/problemset/problem/832/C)|Codeforces||Codeforces Round #425 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|333|[Road to Home](http://codeforces.com/problemset/problem/721/E)|Codeforces||Codeforces Round #374 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|334|[Soap Time! - 2](http://codeforces.com/problemset/problem/185/E)|Codeforces||Codeforces Round #118 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|335|[Armistice Area Apportionment](http://codeforces.com/problemset/problem/645/G)|Codeforces||CROC 2016 - Elimination Round|10|
|<ul><li>- [ ] Done</li></ul>|336|[Cross Sum](http://codeforces.com/problemset/problem/607/E)|Codeforces||Codeforces Round #336 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|337|[BCPC](http://codeforces.com/problemset/problem/592/E)|Codeforces||Codeforces Round #328 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|338|[Duff in Mafia](http://codeforces.com/problemset/problem/587/D)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|339|[Painting Edges](http://codeforces.com/problemset/problem/576/E)|Codeforces||Codeforces Round #319 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|340|[Campus](http://codeforces.com/problemset/problem/571/D)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|341|[Berland Miners](http://codeforces.com/problemset/problem/533/A)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|342|[Misha and LCP on Tree](http://codeforces.com/problemset/problem/504/E)|Codeforces||Codeforces Round #285 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|343|[Furukawa Nagisa's Tree](http://codeforces.com/problemset/problem/434/E)|Codeforces||Codeforces Round #248 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|344|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces||Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|345|[Looking for Owls](http://codeforces.com/problemset/problem/350/D)|Codeforces||Codeforces Round #203 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|346|[Sheep](http://codeforces.com/problemset/problem/309/E)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|347|[Forward, march!](http://codeforces.com/problemset/problem/11/E)|Codeforces||Codeforces Beta Round #11|10|
|<ul><li>- [ ] Done</li></ul>|348|[Karen and Neighborhood](http://codeforces.com/problemset/problem/815/E)|Codeforces||Codeforces Round #419 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|349|[Mod Mod Mod](http://codeforces.com/problemset/problem/889/E)|Codeforces||Codeforces Round #445 (Div. 1, based on Technocup 2018 Elimination Round 3)|10|
|<ul><li>- [ ] Done</li></ul>|350|[Nikita and game](http://codeforces.com/problemset/problem/842/E)|Codeforces||Codeforces Round #430 (Div. 2)|10|
