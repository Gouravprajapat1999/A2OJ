# 086. Articulation_Point


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Building Bridges](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=722)|Live Archive|2003|World Finals - Beverly Hills|1|
|<ul><li>- [ ] Done</li></ul>|2|[Tourist Guide](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1140)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Network](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=251)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Network](http://acm.tju.edu.cn/toj/showp1026.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Submerging Islands](http://www.spoj.com/problems/SUBMERGE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[VOI 2015 Day 1 - K&#7871; ho&#7841;ch c&#7843;i t&#7893;](http://vn.spoj.com/problems/REFORM/)|SPOJ Vietnam|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Police Query](http://www.spoj.com/problems/POLQUERY/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
