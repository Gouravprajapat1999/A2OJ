# 069. Centroid_Decomposition


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Decoder](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=399)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Query on a tree V](http://www.spoj.com/problems/QTREE5/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|3|[Distance in Tree](http://codeforces.com/problemset/problem/161/D)|Codeforces|VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|4|[Prime Distance On Tree](http://www.codechef.com/problems/PRIMEDST)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|5|[Gao on a tree](http://www.spoj.com/problems/GOT/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|6|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces|Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|7|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces|Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|8|[Vacation](http://www.codechef.com/problems/TESTERS)|CodeChef||6|
|<ul><li>- [ ] Done</li></ul>|9|[Black and White Tree](http://www.codechef.com/problems/GERALD2)|CodeChef||6|
|<ul><li>- [ ] Done</li></ul>|10|[New Year Tree](http://codeforces.com/problemset/problem/379/F)|Codeforces|Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|11|[Union on Tree](http://www.codechef.com/problems/BTREE)|CodeChef||7|
|<ul><li>- [ ] Done</li></ul>|12|[Rowena Ravenclaw's Diadem](http://codeforces.com/problemset/problem/855/D)|Codeforces|Manthan, Codefest 17|8|
|<ul><li>- [ ] Done</li></ul>|13|[Sagheer and Kindergarten](http://codeforces.com/problemset/problem/812/D)|Codeforces|Codeforces Round #417 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|14|[Arkady and a Nobody-men](http://codeforces.com/problemset/problem/860/E)|Codeforces|Codeforces Round #434 (Div. 1, based on Technocup 2018 Elimination Round 1)|9|
