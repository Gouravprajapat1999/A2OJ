# 050. Balanced_Binary_Search_Trees


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Order statistic set](http://www.spoj.com/problems/ORDERSET/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Cube Stacking](http://poj.org/problem?id=1988)|PKU||1|
|<ul><li>- [ ] Done</li></ul>|3|[Matrix](http://www.spoj.com/problems/KPMATRIX/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|4|[Can you answer these queries VI](http://www.spoj.com/problems/GSS6/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|5|[Giá tr&#7883; l&#7899;n nh&#7845;t 3](http://www.spoj.com/problems/QMAX3VN/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|6|[Weird Function](http://www.spoj.com/problems/WEIRDFN/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|7|[Almost Union-Find](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3138)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|8|[Lucy and Palindromes](http://www.codechef.com/problems/PALINDR)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|9|[Robotic Sort](http://www.spoj.com/problems/CERC07S/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|10|[Chef and medium problem](http://www.codechef.com/problems/CHEFC)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|11|[Another Sequence Problem](http://www.spoj.com/problems/SEQ2/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|12|[Twist and whirl -- want to cheat](http://acm.sgu.ru/problem.php?contest=0&problem=187)|SGU||3|
|<ul><li>- [ ] Done</li></ul>|13|[Card Shuffle](http://www.codechef.com/problems/CARDSHUF)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|14|[Temple Queues](http://www.spoj.com/problems/TEMPLEQ/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|15|[Yet another range difference query!](http://www.spoj.com/problems/TREAP/)|SPOJ||4|
|<ul><li>- [ ] Done</li></ul>|16|[``Dynamic'' Inversion](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3141)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|17|[Genetics](http://www.codechef.com/problems/GENETICS)|CodeChef||5|
|<ul><li>- [ ] Done</li></ul>|18|[Graph and Queries](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4225)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|19|[Version Controlled IDE](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3983)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|20|[Yet Another Array Queries Problem](http://codeforces.com/problemset/problem/863/D)|Codeforces|Educational Codeforces Round 29|5|
|<ul><li>- [ ] Done</li></ul>|21|[Robotic Sort](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4148)|UVA||6|
|<ul><li>- [ ] Done</li></ul>|22|[Restructuring Company](http://codeforces.com/problemset/problem/566/D)|Codeforces|VK Cup 2015 - Finals, online mirror|6|
|<ul><li>- [ ] Done</li></ul>|23|[Count The Indexes 2](http://www.spoj.com/problems/CNTINDX2/)|SPOJ||7|
|<ul><li>- [ ] Done</li></ul>|24|[Arnook Defensive Line](http://www.spoj.com/problems/KL11B/)|SPOJ||7|
|<ul><li>- [ ] Done</li></ul>|25|[Asistent](http://www.spoj.com/problems/ASISTENT/)|SPOJ||8|
|<ul><li>- [ ] Done</li></ul>|26|[Hitchhiking in the Baltic States](http://codeforces.com/problemset/problem/809/D)|Codeforces|Codeforces Round #415 (Div. 1)|9|
