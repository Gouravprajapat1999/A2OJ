# 059. All_Pair_Shortest_Path_Floyd-Warshall


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[MPI Maelstrom](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=364)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Arbitrage](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=40)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Arbitrage](http://www.spoj.com/problems/ARBITRAG/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Risk](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=508)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|5|[Page Hopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=762)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|6|[05-2 Rendezvous](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1956)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|7|[Non-Stop Travel](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=277)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|8|[Commandos](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2458)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|9|[Possible Friends](http://www.spoj.com/problems/SOCIALNE/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|10|[Meeting Prof. Miguel...](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1112)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|11|[Thunder Mountain](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1744)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|12|[Trip Routing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=122)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|13|[Greg and Graph](http://codeforces.com/problemset/problem/295/B)|Codeforces|Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|14|[Airlines](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1016)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|15|[Asterix and Obelix](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1187)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|16|[The Orc Attack](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1734)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|17|[106 Miles To Chicago](https://www.urionlinejudge.com.br/judge/en/problems/view/1655)|URI||4|
|<ul><li>- [ ] Done</li></ul>|18|[Road Construction](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1665)|UVA||4|
