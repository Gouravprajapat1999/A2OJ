# 007. data_structures


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Registration System](http://codeforces.com/problemset/problem/4/C)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|2|[Street Parade](http://www.spoj.com/problems/STPAR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Theatre Square](http://codeforces.com/problemset/problem/1/A)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|4|[Can you answer these queries III](http://www.spoj.com/problems/GSS3/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Can you answer these queries II](http://www.spoj.com/problems/GSS2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Can you answer these queries I](http://www.spoj.com/problems/GSS1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Maximum Sum](http://www.spoj.com/problems/KGSS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[How to Handle the Fans](http://www.spoj.com/problems/AKVQLD03/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Division of Nlogonia](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2493)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Banknotes and Coins](https://www.urionlinejudge.com.br/judge/en/problems/view/1021)|URI|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Xenia and Bit Operations](http://codeforces.com/problemset/problem/339/D)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Watchmen](http://codeforces.com/problemset/problem/650/A)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|13|[A and B and Compilation Errors](http://codeforces.com/problemset/problem/519/B)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|14|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Misha and Changing Handles](http://codeforces.com/problemset/problem/501/B)|Codeforces||Codeforces Round #285 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Prison Transfer](http://codeforces.com/problemset/problem/427/B)|Codeforces||Codeforces Round #244 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Sereja and Suffixes](http://codeforces.com/problemset/problem/368/B)|Codeforces||Codeforces Round #215 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Little Girl and Maximum Sum](http://codeforces.com/problemset/problem/276/C)|Codeforces||Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Simple Math](p?ID=347)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|21|[4 Values whose Sum is 0](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1507)|Live Archive|2005|Europe - Southwestern|1|
|<ul><li>- [ ] Done</li></ul>|22|[Snacktower](http://codeforces.com/problemset/problem/767/A)|Codeforces||Codeforces Round #398 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[Airport](http://codeforces.com/problemset/problem/218/B)|Codeforces||Codeforces Round #134 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|24|[Cd and pwd commands](http://codeforces.com/problemset/problem/158/C)|Codeforces||VK Cup 2012 Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|25|[Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3769)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|26|[Hardwood Species](http://acm.tju.edu.cn/toj/showp1388.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|27|[True Friends](http://www.spoj.com/problems/TFRIENDS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|28|[Alternating Current](http://codeforces.com/problemset/problem/343/B)|Codeforces||Codeforces Round #200 (Div. 1) & Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|29|[FIGUREFUL](http://www.spoj.com/problems/ACMCEG2B/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|30|[Chat Order](http://codeforces.com/problemset/problem/637/B)|Codeforces||VK Cup 2016 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|31|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces||Codeforces Round #319 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|32|[Replacement](http://codeforces.com/problemset/problem/570/C)|Codeforces||Codeforces Round #316 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|33|[Geometric Progression](http://codeforces.com/problemset/problem/567/C)|Codeforces||Codeforces Round #Pi (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|34|[Photo to Remember](http://codeforces.com/problemset/problem/522/B)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|35|[Anya and Smartphone](http://codeforces.com/problemset/problem/518/C)|Codeforces||Codeforces Round #293 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|36|[Knight Tournament](http://codeforces.com/problemset/problem/356/A)|Codeforces||Codeforces Round #207 (Div. 1) & Codeforces Round #207 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|37|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces||Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|38|[Greg and Array](http://codeforces.com/problemset/problem/295/A)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|39|[Escape from Stones](http://codeforces.com/problemset/problem/264/A)|Codeforces||Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|40|[Sonya and Queries](http://codeforces.com/problemset/problem/713/A)|Codeforces||Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|41|[Thor](http://codeforces.com/problemset/problem/704/A)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|42|[The Festive Evening](http://codeforces.com/problemset/problem/834/B)|Codeforces||Codeforces Round #426 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|43|[Game of Credit Cards](http://codeforces.com/problemset/problem/777/B)|Codeforces||Codeforces Round #401 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|44|[Karen and Coffee](http://codeforces.com/problemset/problem/816/B)|Codeforces||Codeforces Round #419 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|45|[Hoax or what](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2077)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|46|[Counting heaps](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2391)|Live Archive|2008|Europe - Central|2|
|<ul><li>- [ ] Done</li></ul>|47|[Vasya and Multisets](http://codeforces.com/problemset/problem/1051/C)|Codeforces||Educational Codeforces Round 51 (Rated for Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|48|[Colorful Graph](http://codeforces.com/problemset/problem/246/D)|Codeforces||Codeforces Round #151 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|49|[Little Elephant and Array](http://codeforces.com/problemset/problem/220/B)|Codeforces||Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|50|[Powerful array](http://codeforces.com/problemset/problem/86/D)|Codeforces||Yandex.Algorithm 2011 Round 2|3|
|<ul><li>- [ ] Done</li></ul>|51|[Plug-in](http://codeforces.com/problemset/problem/81/A)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|3|
|<ul><li>- [ ] Done</li></ul>|52|[Regular Bracket Sequence](http://codeforces.com/problemset/problem/26/B)|Codeforces||Codeforces Beta Round #26 (Codeforces format)|3|
|<ul><li>- [ ] Done</li></ul>|53|[Stripe](http://codeforces.com/problemset/problem/18/C)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|54|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces||Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|55|[Level Order Tree Traversal](https://www.urionlinejudge.com.br/judge/en/problems/view/1466)|URI|||3|
|<ul><li>- [ ] Done</li></ul>|56|[Stacks](http://acm.timus.ru/problem.aspx?space=1&num=1220)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|57|[New Reform](http://codeforces.com/problemset/problem/659/E)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|58|[Not Equal on a Segment](http://codeforces.com/problemset/problem/622/C)|Codeforces||Educational Codeforces Round 7|3|
|<ul><li>- [ ] Done</li></ul>|59|[Replace To Make Regular Bracket Sequence](http://codeforces.com/problemset/problem/612/C)|Codeforces||Educational Codeforces Round 4|3|
|<ul><li>- [ ] Done</li></ul>|60|[Bear and Blocks](http://codeforces.com/problemset/problem/573/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|61|[Order Book](http://codeforces.com/problemset/problem/572/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|62|[Mike and Feet](http://codeforces.com/problemset/problem/547/B)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|63|[Glass Carving](http://codeforces.com/problemset/problem/527/C)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|64|[A and B and Interesting Substrings](http://codeforces.com/problemset/problem/519/D)|Codeforces||Codeforces Round #294 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|65|[Misha and Forest](http://codeforces.com/problemset/problem/501/C)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|66|[Interesting Array](http://codeforces.com/problemset/problem/482/B)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|67|[Present](http://codeforces.com/problemset/problem/460/C)|Codeforces||Codeforces Round #262 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|68|[Pashmak and Parmida's problem](http://codeforces.com/problemset/problem/459/D)|Codeforces||Codeforces Round #261 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|69|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|70|[Milking cows](http://codeforces.com/problemset/problem/383/A)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|71|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces||Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|72|[Sereja and Algorithm ](http://codeforces.com/problemset/problem/367/A)|Codeforces||Codeforces Round #215 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|73|[Bubble Sort Graph](http://codeforces.com/problemset/problem/340/D)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|74|[Maximum Absurdity](http://codeforces.com/problemset/problem/332/B)|Codeforces||Codeforces Round #193 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|75|[Dima and Staircase](http://codeforces.com/problemset/problem/272/C)|Codeforces||Codeforces Round #167 (Div. 2) & Codeforces Round #167 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|76|[Good Substrings](http://codeforces.com/problemset/problem/271/D)|Codeforces||Codeforces Round #166 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|77|[Multithreading](http://codeforces.com/problemset/problem/270/B)|Codeforces||Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|78|[Heap Operations](http://codeforces.com/problemset/problem/681/C)|Codeforces||Codeforces Round #357 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|79|[Blue Mary Needs Help Again](http://www.spoj.com/problems/CASHIER/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|80|[Okabe and Boxes](http://codeforces.com/problemset/problem/821/C)|Codeforces||Codeforces Round #420 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|81|[Vasiliy's Multiset](http://codeforces.com/problemset/problem/706/D)|Codeforces||Codeforces Round #367 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|82|[Almost Union-Find](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3138)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|83|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|84|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces||Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|85|[King's Path](http://codeforces.com/problemset/problem/242/C)|Codeforces||Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|86|[Little Elephant and Cards](http://codeforces.com/problemset/problem/204/B)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|87|[After Training](http://codeforces.com/problemset/problem/195/B)|Codeforces||Codeforces Round #123 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|88|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|89|[Find Pair](http://codeforces.com/problemset/problem/160/C)|Codeforces||Codeforces Round #111 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|90|[String Manipulation 1.0](http://codeforces.com/problemset/problem/159/C)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|91|[Anagram Search](http://codeforces.com/problemset/problem/144/C)|Codeforces||Codeforces Round #103 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|92|[New Year Snowmen](http://codeforces.com/problemset/problem/140/C)|Codeforces||Codeforces Round #100|4|
|<ul><li>- [ ] Done</li></ul>|93|[Petya and Divisors](http://codeforces.com/problemset/problem/111/B)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|94|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|95|[Circular RMQ](http://codeforces.com/problemset/problem/52/C)|Codeforces||Codeforces Testing Round #1|4|
|<ul><li>- [ ] Done</li></ul>|96|[SBE201 Linked List](http://www.spoj.com/problems/SBE201P2/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|97|[Ice-cream Tycoon](http://acm.sgu.ru/problem.php?contest=0&problem=311)|SGU|||4|
|<ul><li>- [ ] Done</li></ul>|98|[Friends or Not](http://codeforces.com/problemset/problem/159/A)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|99|[Processing Queries](http://codeforces.com/problemset/problem/644/B)|Codeforces||CROC 2016 - Qualification|4|
|<ul><li>- [ ] Done</li></ul>|100|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces||Codeforces Round #344 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|101|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces||Codeforces Round #343 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|102|[XOR and Favorite Number](http://codeforces.com/problemset/problem/617/E)|Codeforces||Codeforces Round #340 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|103|[Longest k-Good Segment](http://codeforces.com/problemset/problem/616/D)|Codeforces||Educational Codeforces Round 5|4|
|<ul><li>- [ ] Done</li></ul>|104|[Lazy Student](http://codeforces.com/problemset/problem/605/B)|Codeforces||Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|105|[One-Dimensional Battle Ships](http://codeforces.com/problemset/problem/567/D)|Codeforces||Codeforces Round #Pi (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|106|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces||Codeforces Round #311 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|107|[Case of Fugitive](http://codeforces.com/problemset/problem/555/B)|Codeforces||Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|108|[Vanya and Triangles](http://codeforces.com/problemset/problem/552/D)|Codeforces||Codeforces Round #308 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|109|[Clique Problem](http://codeforces.com/problemset/problem/527/D)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|110|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|111|[Ant colony](http://codeforces.com/problemset/problem/474/F)|Codeforces||Codeforces Round #271 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|112|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|113|[Maximum Submatrix 2](http://codeforces.com/problemset/problem/375/B)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|114|[Vessels](http://codeforces.com/problemset/problem/371/D)|Codeforces||Codeforces Round #218 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|115|[Matrix](http://codeforces.com/problemset/problem/364/A)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|116|[Pair of Numbers](http://codeforces.com/problemset/problem/359/D)|Codeforces||Codeforces Round #209 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|117|[Xenia and Tree](http://codeforces.com/problemset/problem/342/E)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|118|[Psychos in a Line](http://codeforces.com/problemset/problem/319/B)|Codeforces||Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|119|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces||Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|120|[Queue](http://codeforces.com/problemset/problem/91/B)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|121|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|122|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|123|[Tree Construction](http://codeforces.com/problemset/problem/675/D)|Codeforces||Codeforces Round #353 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|124|[Money Transfers](http://codeforces.com/problemset/problem/675/C)|Codeforces||Codeforces Round #353 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|125|[Ada and List](http://www.spoj.com/problems/ADALIST/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|126|[Predict Outcome of the Game](http://codeforces.com/problemset/problem/451/C)|Codeforces||Codeforces Round #258 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|127|[Alyona and a tree](http://codeforces.com/problemset/problem/739/B)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|128|[Remove Extra One](http://codeforces.com/problemset/problem/900/C)|Codeforces||Codeforces Round #450 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|129|[Blood Cousins](http://codeforces.com/problemset/problem/208/E)|Codeforces||Codeforces Round #130 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|130|[Suspects](http://codeforces.com/problemset/problem/156/B)|Codeforces||Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|131|[Missile Silos](http://codeforces.com/problemset/problem/144/D)|Codeforces||Codeforces Round #103 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|132|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|133|[Colorful Field](http://codeforces.com/problemset/problem/79/B)|Codeforces||Codeforces Beta Round #71|5|
|<ul><li>- [ ] Done</li></ul>|134|[Unordered Subsequence](http://codeforces.com/problemset/problem/27/C)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|135|[Exposition](http://codeforces.com/problemset/problem/6/E)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|136|[Nested Segments](http://codeforces.com/problemset/problem/652/D)|Codeforces||Educational Codeforces Round 10|5|
|<ul><li>- [ ] Done</li></ul>|137|[Little Artem and Time Machine](http://codeforces.com/problemset/problem/641/E)|Codeforces||VK Cup 2016 - Round 2|5|
|<ul><li>- [ ] Done</li></ul>|138|[Running with Obstacles](http://codeforces.com/problemset/problem/637/D)|Codeforces||VK Cup 2016 - Qualification Round 1|5|
|<ul><li>- [ ] Done</li></ul>|139|[Spy Syndrome 2](http://codeforces.com/problemset/problem/633/C)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|140|[Factory Repairs](http://codeforces.com/problemset/problem/627/B)|Codeforces||8VC Venture Cup 2016 - Final Round|5|
|<ul><li>- [ ] Done</li></ul>|141|[New Year Tree](http://codeforces.com/problemset/problem/620/E)|Codeforces||Educational Codeforces Round 6|5|
|<ul><li>- [ ] Done</li></ul>|142|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces||Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|143|[Lipshitz Sequence](http://codeforces.com/problemset/problem/601/B)|Codeforces||Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|144|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|145|[A Simple Task](http://codeforces.com/problemset/problem/558/E)|Codeforces||Codeforces Round #312 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|146|[Case of Chocolate](http://codeforces.com/problemset/problem/555/C)|Codeforces||Codeforces Round #310 (Div. 1) & Codeforces Round #310 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|147|[Handshakes](http://codeforces.com/problemset/problem/534/D)|Codeforces||Codeforces Round #298 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|148|[Statistics of Recompressing Videos](http://codeforces.com/problemset/problem/523/D)|Codeforces||VK Cup 2015 - Qualification Round 2|5|
|<ul><li>- [ ] Done</li></ul>|149|[R2D2 and Droid Army](http://codeforces.com/problemset/problem/514/D)|Codeforces||Codeforces Round #291 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|150|[Misha and Permutations Summation](http://codeforces.com/problemset/problem/501/D)|Codeforces||Codeforces Round #285 (Div. 2) & Codeforces Round #285 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|151|[Strip](http://codeforces.com/problemset/problem/487/B)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|152|[CGCDSSQ](http://codeforces.com/problemset/problem/475/D)|Codeforces||Bayan 2015 Contest Warm Up|5|
|<ul><li>- [ ] Done</li></ul>|153|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces||Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|154|[The Child and Sequence](http://codeforces.com/problemset/problem/438/D)|Codeforces||Codeforces Round #250 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|155|[Tricky Function](http://codeforces.com/problemset/problem/429/D)|Codeforces||Codeforces Round #245 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|156|[Preparing for the Contest](http://codeforces.com/problemset/problem/377/B)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|157|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces||Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|158|[Sereja ans Anagrams](http://codeforces.com/problemset/problem/367/B)|Codeforces||Codeforces Round #215 (Div. 1) & Codeforces Round #215 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|159|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces||Codeforces Round #200 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|160|[Copying Data](http://codeforces.com/problemset/problem/292/E)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|161|[Connected Components](http://codeforces.com/problemset/problem/292/D)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|162|[Sausage Maximization](http://codeforces.com/problemset/problem/282/E)|Codeforces||Codeforces Round #173 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|163|[Maximum Xor Secondary](http://codeforces.com/problemset/problem/280/B)|Codeforces||Codeforces Round #172 (Div. 1) & Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|164|[Text Editor](http://codeforces.com/problemset/problem/253/C)|Codeforces||Codeforces Round #154 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|165|[Bracket Sequence](http://codeforces.com/problemset/problem/223/A)|Codeforces||Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|166|[Subsegments](http://codeforces.com/problemset/problem/69/E)|Codeforces||Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|167|[Mail Stamps](http://codeforces.com/problemset/problem/29/C)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|168|[Kay and Snowflake](http://codeforces.com/problemset/problem/685/B)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|169|[Cards Sorting](http://codeforces.com/problemset/problem/830/B)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|5|
|<ul><li>- [ ] Done</li></ul>|170|[The Bakery](http://codeforces.com/problemset/problem/833/B)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|171|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces||Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|172|[Leaving Auction](http://codeforces.com/problemset/problem/749/D)|Codeforces||Codeforces Round #388 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|173|[Cartons of milk](http://codeforces.com/problemset/problem/767/D)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|174|[Mahmoud and a Dictionary](http://codeforces.com/problemset/problem/766/D)|Codeforces||Codeforces Round #396 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|175|[Fedor and coupons](http://codeforces.com/problemset/problem/754/D)|Codeforces||Codeforces Round #390 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|176|[Maxim and Array](http://codeforces.com/problemset/problem/721/D)|Codeforces||Codeforces Round #374 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|177|[Vitya and Strange Lesson](http://codeforces.com/problemset/problem/842/D)|Codeforces||Codeforces Round #430 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|178|[Mishka and Interesting sum](http://codeforces.com/problemset/problem/703/D)|Codeforces||Codeforces Round #365 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|179|[Friends and Subsequences](http://codeforces.com/problemset/problem/689/D)|Codeforces||Codeforces Round #361 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|180|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces||Codeforces Round #368 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|181|[Hydra](http://codeforces.com/problemset/problem/243/B)|Codeforces||Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|182|[Two Strings](http://codeforces.com/problemset/problem/223/B)|Codeforces||Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|183|[Lucky Queries](http://codeforces.com/problemset/problem/145/E)|Codeforces||Codeforces Round #104 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|184|[Time to Raid Cowavans](http://codeforces.com/problemset/problem/103/D)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|185|[Buses](http://codeforces.com/problemset/problem/101/B)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|186|[Sum of Medians](http://codeforces.com/problemset/problem/85/D)|Codeforces||Yandex.Algorithm 2011 Round 1|6|
|<ul><li>- [ ] Done</li></ul>|187|[Beaver](http://codeforces.com/problemset/problem/79/C)|Codeforces||Codeforces Beta Round #71|6|
|<ul><li>- [ ] Done</li></ul>|188|[Holes](http://codeforces.com/problemset/problem/13/E)|Codeforces||Codeforces Beta Round #13|6|
|<ul><li>- [ ] Done</li></ul>|189|[Messenger](http://codeforces.com/problemset/problem/631/D)|Codeforces||Codeforces Round #344 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|190|[Subsequences](http://codeforces.com/problemset/problem/597/C)|Codeforces||Testing Round #12|6|
|<ul><li>- [ ] Done</li></ul>|191|[Hiring](http://codeforces.com/problemset/problem/589/G)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|6|
|<ul><li>- [ ] Done</li></ul>|192|[Kefa and Watch](http://codeforces.com/problemset/problem/580/E)|Codeforces||Codeforces Round #321 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|193|[Restructuring Company](http://codeforces.com/problemset/problem/566/D)|Codeforces||VK Cup 2015 - Finals, online mirror|6|
|<ul><li>- [ ] Done</li></ul>|194|[GukiZ and GukiZiana](http://codeforces.com/problemset/problem/551/E)|Codeforces||Codeforces Round #307 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|195|[Infinite Inversions](http://codeforces.com/problemset/problem/540/E)|Codeforces||Codeforces Round #301 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|196|[A Heap of Heaps](http://codeforces.com/problemset/problem/538/F)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|197|[Arthur and Walls](http://codeforces.com/problemset/problem/525/D)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|198|[Closest Equals](http://codeforces.com/problemset/problem/522/D)|Codeforces||VK Cup 2015 - Qualification Round 1|6|
|<ul><li>- [ ] Done</li></ul>|199|[Drazil and Park](http://codeforces.com/problemset/problem/515/E)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|200|[New Year Domino](http://codeforces.com/problemset/problem/500/E)|Codeforces||Good Bye 2014|6|
|<ul><li>- [ ] Done</li></ul>|201|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces||Codeforces Round #277 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|202|[Kindergarten](http://codeforces.com/problemset/problem/484/D)|Codeforces||Codeforces Round #276 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|203|[Appleman and a Sheet of Paper](http://codeforces.com/problemset/problem/461/C)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|204|[Serega and Fun](http://codeforces.com/problemset/problem/455/D)|Codeforces||Codeforces Round #260 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|205|[DZY Loves Fibonacci Numbers](http://codeforces.com/problemset/problem/446/C)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|206|[DZY Loves Colors](http://codeforces.com/problemset/problem/444/C)|Codeforces||Codeforces Round #254 (Div. 1) & Codeforces Round #254 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|207|[Artem and Array ](http://codeforces.com/problemset/problem/442/C)|Codeforces||Codeforces Round #253 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|208|[On Changing Tree](http://codeforces.com/problemset/problem/396/C)|Codeforces||Codeforces Round #232 (Div. 1) & Codeforces Round #232 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|209|[New Year Tree](http://codeforces.com/problemset/problem/379/F)|Codeforces||Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|210|[Watching Fireworks is Fun](http://codeforces.com/problemset/problem/372/C)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|211|[Valera and Queries](http://codeforces.com/problemset/problem/369/E)|Codeforces||Codeforces Round #216 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|212|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces||Codeforces Round #212 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|213|[Oh Sweet Beaverette](http://codeforces.com/problemset/problem/331/A2)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|6|
|<ul><li>- [ ] Done</li></ul>|214|[Ciel and Gondolas](http://codeforces.com/problemset/problem/321/E)|Codeforces||Codeforces Round #190 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|215|[Summer Homework](http://codeforces.com/problemset/problem/316/E1)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|216|[Sereja and Subsequences](http://codeforces.com/problemset/problem/314/C)|Codeforces||Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|217|[Yaroslav and Divisors](http://codeforces.com/problemset/problem/301/D)|Codeforces||Codeforces Round #182 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|218|[Cubes](http://codeforces.com/problemset/problem/520/D)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|219|[Vanya and Treasure](http://codeforces.com/problemset/problem/677/D)|Codeforces||Codeforces Round #355 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|220|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces||Codeforces Round #353 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|221|[Shortest Path](p?ID=294)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|222|[Mister B and PR Shifts](http://codeforces.com/problemset/problem/819/B)|Codeforces||Codeforces Round #421 (Div. 1) & Codeforces Round #421 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|223|[Rooter's Song](http://codeforces.com/problemset/problem/848/B)|Codeforces||Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|224|[Leha and another game about graph](http://codeforces.com/problemset/problem/840/B)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|225|[Boredom](http://codeforces.com/problemset/problem/853/C)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises) & Codeforces Round #433 (Div. 2, based on Olympiad of Metropolises)|6|
|<ul><li>- [ ] Done</li></ul>|226|[Legacy](http://codeforces.com/problemset/problem/786/B)|Codeforces||Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|227|[Mike and Geometry Problem](http://codeforces.com/problemset/problem/689/E)|Codeforces||Codeforces Round #361 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|228|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces||Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|229|[Little Elephant and Tree](http://codeforces.com/problemset/problem/258/E)|Codeforces||Codeforces Round #157 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|230|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces||Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|231|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces||Codeforces Round #143 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|232|[Little Elephant and Inversions](http://codeforces.com/problemset/problem/220/E)|Codeforces||Codeforces Round #136 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|233|[Little Elephant and Shifts](http://codeforces.com/problemset/problem/220/C)|Codeforces||Codeforces Round #136 (Div. 1) & Codeforces Round #136 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|234|[Spider's Web](http://codeforces.com/problemset/problem/216/D)|Codeforces||Codeforces Round #133 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|235|[Counter Attack](http://codeforces.com/problemset/problem/190/E)|Codeforces||Codeforces Round #120 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|236|[Encrypting Messages](http://codeforces.com/problemset/problem/177/D2)|Codeforces||ABBYY Cup 2.0 - Easy|7|
|<ul><li>- [ ] Done</li></ul>|237|[Range Increments](http://codeforces.com/problemset/problem/174/C)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|7|
|<ul><li>- [ ] Done</li></ul>|238|[Beard Graph](http://codeforces.com/problemset/problem/165/D)|Codeforces||Codeforces Round #112 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|239|[Zebra Tower](http://codeforces.com/problemset/problem/159/E)|Codeforces||VK Cup 2012 Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|240|[Mushroom Gnomes - 2](http://codeforces.com/problemset/problem/138/C)|Codeforces||Codeforces Beta Round #99 (Div. 1) & Codeforces Beta Round #99 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|241|[Last Chance](http://codeforces.com/problemset/problem/137/E)|Codeforces||Codeforces Beta Round #98 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|242|[Lucky Array](http://codeforces.com/problemset/problem/121/E)|Codeforces||Codeforces Beta Round #91 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|243|[Ski Base](http://codeforces.com/problemset/problem/91/C)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only) & Codeforces Beta Round #75 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|244|[Embassy Queue](http://codeforces.com/problemset/problem/85/B)|Codeforces||Yandex.Algorithm 2011 Round 1|7|
|<ul><li>- [ ] Done</li></ul>|245|[General Mobilization](http://codeforces.com/problemset/problem/82/C)|Codeforces||Yandex.Algorithm 2011 Qualification 2|7|
|<ul><li>- [ ] Done</li></ul>|246|[Optical Experiment](http://codeforces.com/problemset/problem/67/D)|Codeforces||Manthan 2011|7|
|<ul><li>- [ ] Done</li></ul>|247|[Domino Principle](http://codeforces.com/problemset/problem/56/E)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|248|[Corporation Mail](http://codeforces.com/problemset/problem/56/C)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|249|[Comb](http://codeforces.com/problemset/problem/46/E)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|250|[Parking Lot](http://codeforces.com/problemset/problem/46/D)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|251|[Old Berland Language](http://codeforces.com/problemset/problem/37/C)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|252|[Points](http://codeforces.com/problemset/problem/19/D)|Codeforces||Codeforces Beta Round #19|7|
|<ul><li>- [ ] Done</li></ul>|253|[Ball](http://codeforces.com/problemset/problem/12/D)|Codeforces||Codeforces Beta Round #12 (Div 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|254|[Bindian Signalizing](http://codeforces.com/problemset/problem/5/E)|Codeforces||Codeforces Beta Round #5|7|
|<ul><li>- [ ] Done</li></ul>|255|[Beautiful Subarrays](http://codeforces.com/problemset/problem/665/E)|Codeforces||Educational Codeforces Round 12|7|
|<ul><li>- [ ] Done</li></ul>|256|[Zip-line](http://codeforces.com/problemset/problem/650/D)|Codeforces||Codeforces Round #345 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|257|[Hostname Aliases](http://codeforces.com/problemset/problem/644/C)|Codeforces||CROC 2016 - Qualification|7|
|<ul><li>- [ ] Done</li></ul>|258|[Bear and Contribution](http://codeforces.com/problemset/problem/639/D)|Codeforces||VK Cup 2016 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|259|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces||Codeforces Round #344 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|260|[Package Delivery](http://codeforces.com/problemset/problem/627/C)|Codeforces||8VC Venture Cup 2016 - Final Round|7|
|<ul><li>- [ ] Done</li></ul>|261|[New Year and Three Musketeers](http://codeforces.com/problemset/problem/611/E)|Codeforces||Good Bye 2015|7|
|<ul><li>- [ ] Done</li></ul>|262|[Vika and Segments](http://codeforces.com/problemset/problem/610/D)|Codeforces||Codeforces Round #337 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|263|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces||Codeforces Round #333 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|264|[Happy Tree Party](http://codeforces.com/problemset/problem/593/D)|Codeforces||Codeforces Round #329 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|265|[Guess Your Way Out! II](http://codeforces.com/problemset/problem/558/D)|Codeforces||Codeforces Round #312 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|266|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces||Codeforces Round #311 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|267|[Rooks and Rectangles](http://codeforces.com/problemset/problem/524/E)|Codeforces||VK Cup 2015 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|268|[Traffic Jams in the Land](http://codeforces.com/problemset/problem/498/D)|Codeforces||Codeforces Round #284 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|269|[Treeland Tour](http://codeforces.com/problemset/problem/490/F)|Codeforces||Codeforces Round #279 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|270|[Sign on Fence](http://codeforces.com/problemset/problem/484/E)|Codeforces||Codeforces Round #276 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|271|[Sereja and Squares](http://codeforces.com/problemset/problem/425/D)|Codeforces||Codeforces Round #243 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|272|[Sereja and Two Sequences](http://codeforces.com/problemset/problem/425/C)|Codeforces||Codeforces Round #243 (Div. 1) & Codeforces Round #243 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|273|[Bug in Code](http://codeforces.com/problemset/problem/421/D)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|274|[Bug in Code](http://codeforces.com/problemset/problem/420/C)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2) & Coder-Strike 2014 - Finals (online edition, Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|275|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces||Codeforces Round #234 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|276|[George and Cards](http://codeforces.com/problemset/problem/387/E)|Codeforces||Codeforces Round #227 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|277|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces||Codeforces Round #220 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|278|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces||Codeforces Round #214 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|279|[Fools and Foolproof Roads](http://codeforces.com/problemset/problem/362/D)|Codeforces||Codeforces Round #212 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|280|[Subset Sums](http://codeforces.com/problemset/problem/348/C)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|281|[Iahub and Xors](http://codeforces.com/problemset/problem/341/D)|Codeforces||Codeforces Round #198 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|282|[Students' Revenge](http://codeforces.com/problemset/problem/332/C)|Codeforces||Codeforces Round #193 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|283|[Cats Transport](http://codeforces.com/problemset/problem/311/B)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|284|[Little Girl and Problem on Trees](http://codeforces.com/problemset/problem/276/E)|Codeforces||Codeforces Round #169 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|285|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|286|[Petya and File System](http://codeforces.com/problemset/problem/66/C)|Codeforces||Codeforces Beta Round #61 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|287|[Ada and Mulberry](http://www.spoj.com/problems/ADABERRY/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|288|[Beer Machines](http://www.spoj.com/problems/STJEPAN/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|289|[Crayon](http://www.spoj.com/problems/CRAYON/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|290|[Till I Collapse](http://codeforces.com/problemset/problem/786/C)|Codeforces||Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|291|[Envy](http://codeforces.com/problemset/problem/891/C)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|292|[Alyona and towers](http://codeforces.com/problemset/problem/739/C)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|293|[Anton and Permutation](http://codeforces.com/problemset/problem/785/E)|Codeforces||Codeforces Round #404 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|294|[Ralph And His Tour in Binary Country](http://codeforces.com/problemset/problem/894/D)|Codeforces||Codeforces Round #447 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|295|[Maximum Questions](http://codeforces.com/problemset/problem/900/E)|Codeforces||Codeforces Round #450 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|296|[The Untended Antiquity](http://codeforces.com/problemset/problem/869/E)|Codeforces||Codeforces Round #439 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|297|[Garlands](http://codeforces.com/problemset/problem/707/E)|Codeforces||Codeforces Round #368 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|298|[Working routine](http://codeforces.com/problemset/problem/706/E)|Codeforces||Codeforces Round #367 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|299|[Lucky Arrays](http://codeforces.com/problemset/problem/256/E)|Codeforces||Codeforces Round #156 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|300|[Printer](http://codeforces.com/problemset/problem/253/E)|Codeforces||Codeforces Round #154 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|301|[TorCoder](http://codeforces.com/problemset/problem/240/F)|Codeforces||Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|302|[Anniversary](http://codeforces.com/problemset/problem/226/C)|Codeforces||Codeforces Round #140 (Div. 1) & Codeforces Round #140 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|303|[Parking Lot](http://codeforces.com/problemset/problem/219/E)|Codeforces||Codeforces Round #135 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|304|[Two Permutations](http://codeforces.com/problemset/problem/213/E)|Codeforces||Codeforces Round #131 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|305|[Little Elephant and Strings](http://codeforces.com/problemset/problem/204/E)|Codeforces||Codeforces Round #129 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|306|[Cinema](http://codeforces.com/problemset/problem/200/A)|Codeforces||Codeforces Round #126 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|307|[Building Forest](http://codeforces.com/problemset/problem/195/E)|Codeforces||Codeforces Round #123 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|308|[Thwarting Demonstrations](http://codeforces.com/problemset/problem/191/E)|Codeforces||Codeforces Round #121 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|309|[Optimal Sum](http://codeforces.com/problemset/problem/182/C)|Codeforces||Codeforces Round #117 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|310|[Archaeology](http://codeforces.com/problemset/problem/176/E)|Codeforces||Croc Champ 2012 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|311|[e-Government](http://codeforces.com/problemset/problem/163/E)|Codeforces||VK Cup 2012 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|312|[Smart Cheater](http://codeforces.com/problemset/problem/150/C)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|313|[Competition](http://codeforces.com/problemset/problem/144/E)|Codeforces||Codeforces Round #103 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|314|[Linear Kingdom Races](http://codeforces.com/problemset/problem/115/E)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|315|[Igloo Skyscraper](http://codeforces.com/problemset/problem/91/E)|Codeforces||Codeforces Beta Round #75 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|316|[Chip Play](http://codeforces.com/problemset/problem/89/C)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|317|[Tourist](http://codeforces.com/problemset/problem/76/F)|Codeforces||All-Ukrainian School Olympiad in Informatics|8|
|<ul><li>- [ ] Done</li></ul>|318|[Professor's task](http://codeforces.com/problemset/problem/70/D)|Codeforces||Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|319|[Lucky Tickets](http://codeforces.com/problemset/problem/70/C)|Codeforces||Codeforces Beta Round #64|8|
|<ul><li>- [ ] Done</li></ul>|320|[Petya and Post](http://codeforces.com/problemset/problem/66/E)|Codeforces||Codeforces Beta Round #61 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|321|[Dancing Lessons](http://codeforces.com/problemset/problem/45/C)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|322|[Queue](http://codeforces.com/problemset/problem/38/G)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|323|[Parade](http://codeforces.com/problemset/problem/35/E)|Codeforces||Codeforces Beta Round #35 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|324|[Tricky and Clever Password](http://codeforces.com/problemset/problem/30/E)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|325|[Don't fear, DravDe is kind](http://codeforces.com/problemset/problem/28/D)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|326|[Alex and Complicated Task](http://codeforces.com/problemset/problem/467/E)|Codeforces||Codeforces Round #267 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|327|[Bear and Bowling 4](http://codeforces.com/problemset/problem/660/F)|Codeforces||Educational Codeforces Round 11|8|
|<ul><li>- [ ] Done</li></ul>|328|[Paper task](http://codeforces.com/problemset/problem/653/F)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|329|[Yash And Trees](http://codeforces.com/problemset/problem/633/G)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|330|[Startup Funding](http://codeforces.com/problemset/problem/633/E)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|331|[Zbazi in Zeydabad](http://codeforces.com/problemset/problem/628/E)|Codeforces||Educational Codeforces Round 8|8|
|<ul><li>- [ ] Done</li></ul>|332|[Robot Arm](http://codeforces.com/problemset/problem/618/E)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|8|
|<ul><li>- [ ] Done</li></ul>|333|[Alphabet Permutations](http://codeforces.com/problemset/problem/610/E)|Codeforces||Codeforces Round #337 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|334|[Frogs and mosquitoes](http://codeforces.com/problemset/problem/609/F)|Codeforces||Educational Codeforces Round 3|8|
|<ul><li>- [ ] Done</li></ul>|335|[Power Tree](http://codeforces.com/problemset/problem/607/D)|Codeforces||Codeforces Round #336 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|336|[Board Game](http://codeforces.com/problemset/problem/605/D)|Codeforces||Codeforces Round #335 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|337|[REQ](http://codeforces.com/problemset/problem/594/D)|Codeforces||Codeforces Round #330 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|338|[Yura and Developers](http://codeforces.com/problemset/problem/549/F)|Codeforces||Looksery Cup 2015|8|
|<ul><li>- [ ] Done</li></ul>|339|[Mike and Friends](http://codeforces.com/problemset/problem/547/E)|Codeforces||Codeforces Round #305 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|340|[Place Your Ad Here](http://codeforces.com/problemset/problem/542/A)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|8|
|<ul><li>- [ ] Done</li></ul>|341|[Pudding Monsters](http://codeforces.com/problemset/problem/526/F)|Codeforces||ZeptoLab Code Rush 2015|8|
|<ul><li>- [ ] Done</li></ul>|342|[Birthday](http://codeforces.com/problemset/problem/494/D)|Codeforces||Codeforces Round #282 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|343|[Tourists](http://codeforces.com/problemset/problem/487/E)|Codeforces||Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|344|[Conveyor Belts](http://codeforces.com/problemset/problem/487/D)|Codeforces||Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|345|[Permutation](http://codeforces.com/problemset/problem/452/F)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|8|
|<ul><li>- [ ] Done</li></ul>|346|[Three strings](http://codeforces.com/problemset/problem/452/E)|Codeforces||MemSQL Start[c]UP 2.0 - Round 1|8|
|<ul><li>- [ ] Done</li></ul>|347|[Adam and Tree](http://codeforces.com/problemset/problem/442/D)|Codeforces||Codeforces Round #253 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|348|[Cardboard Box](http://codeforces.com/problemset/problem/436/E)|Codeforces||Zepto Code Rush 2014|8|
|<ul><li>- [ ] Done</li></ul>|349|[Biathlon Track](http://codeforces.com/problemset/problem/424/D)|Codeforces||Codeforces Round #242 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|350|[Cup Trick](http://codeforces.com/problemset/problem/420/D)|Codeforces||Coder-Strike 2014 - Finals (online edition, Div. 1) & Coder-Strike 2014 - Finals (online edition, Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|351|[Mashmokh and Water Tanks](http://codeforces.com/problemset/problem/414/D)|Codeforces||Codeforces Round #240 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|352|[Instant Messanger](http://codeforces.com/problemset/problem/398/D)|Codeforces||Codeforces Round #233 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|353|[Inna and Candy Boxes](http://codeforces.com/problemset/problem/390/C)|Codeforces||Codeforces Round #229 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|354|[Developing Game](http://codeforces.com/problemset/problem/377/D)|Codeforces||Codeforces Round #222 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|355|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces||Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|356|[Jeff and Removing Periods](http://codeforces.com/problemset/problem/351/D)|Codeforces||Codeforces Round #204 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|357|[Optimize!](http://codeforces.com/problemset/problem/338/E)|Codeforces||Codeforces Round #196 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|358|[Shave Beaver!](http://codeforces.com/problemset/problem/331/B2)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|8|
|<ul><li>- [ ] Done</li></ul>|359|[Summer Homework](http://codeforces.com/problemset/problem/316/E3)|Codeforces||ABBYY Cup 3.0|8|
|<ul><li>- [ ] Done</li></ul>|360|[Sereja and Straight Lines](http://codeforces.com/problemset/problem/314/D)|Codeforces||Codeforces Round #187 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|361|[Ilya and Two Numbers](http://codeforces.com/problemset/problem/313/E)|Codeforces||Codeforces Round #186 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|362|[Interval Cubing](http://codeforces.com/problemset/problem/311/D)|Codeforces||Codeforces Round #185 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|363|[Yaroslav and Points](http://codeforces.com/problemset/problem/295/E)|Codeforces||Codeforces Round #179 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|364|[Close Vertices](http://codeforces.com/problemset/problem/293/E)|Codeforces||Croc Champ 2013 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|365|[Cow Tennis Tournament](http://codeforces.com/problemset/problem/283/E)|Codeforces||Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|366|[k-Maximum Subsequence Sum](http://codeforces.com/problemset/problem/280/D)|Codeforces||Codeforces Round #172 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|367|[More Queries to Array...](http://codeforces.com/problemset/problem/266/E)|Codeforces||Codeforces Round #163 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|368|[Ultimate Weirdness of an Array](http://codeforces.com/problemset/problem/671/C)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|369|[Kay and Eternity](http://codeforces.com/problemset/problem/685/D)|Codeforces||Codeforces Round #359 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|370|[Roads in Yusland](http://codeforces.com/problemset/problem/671/D)|Codeforces||Codeforces Round #352 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|371|[Dividing Kingdom II](http://codeforces.com/problemset/problem/687/D)|Codeforces||Codeforces Round #360 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|372|[Destiny](http://codeforces.com/problemset/problem/840/D)|Codeforces||Codeforces Round #429 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|373|[Goodbye Souvenir](http://codeforces.com/problemset/problem/848/C)|Codeforces||Codeforces Round #431 (Div. 1) & Codeforces Round #431 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|374|[Tournament](http://codeforces.com/problemset/problem/878/C)|Codeforces||Codeforces Round #443 (Div. 1) & Codeforces Round #443 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|375|[Animals and Puzzle](http://codeforces.com/problemset/problem/713/D)|Codeforces||Codeforces Round #371 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|376|[Arpa’s letter-marked tree and Mehrdad’s Dokhtar-kosh paths](http://codeforces.com/problemset/problem/741/D)|Codeforces||Codeforces Round #383 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|377|[Vladik and Entertaining Flags](http://codeforces.com/problemset/problem/811/E)|Codeforces||Codeforces Round #416 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|378|[Inversions After Shuffle](http://codeforces.com/problemset/problem/749/E)|Codeforces||Codeforces Round #388 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|379|[Eyes Closed](http://codeforces.com/problemset/problem/895/E)|Codeforces||Codeforces Round #448 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|380|[Memory and Casinos](http://codeforces.com/problemset/problem/712/E)|Codeforces||Codeforces Round #370 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|381|[Donkey and Stars](http://codeforces.com/problemset/problem/249/D)|Codeforces||Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|382|[Friends](http://codeforces.com/problemset/problem/241/B)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|383|[Fence](http://codeforces.com/problemset/problem/232/D)|Codeforces||Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|384|[Zigzag](http://codeforces.com/problemset/problem/228/D)|Codeforces||Codeforces Round #141 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|385|[Noble Knight's Path](http://codeforces.com/problemset/problem/226/E)|Codeforces||Codeforces Round #140 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|386|[Alien DNA](http://codeforces.com/problemset/problem/217/E)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|387|[Cutting a Fence](http://codeforces.com/problemset/problem/212/D)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|388|[Gripping Story](http://codeforces.com/problemset/problem/198/E)|Codeforces||Codeforces Round #125 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|389|[The Next Good String](http://codeforces.com/problemset/problem/196/D)|Codeforces||Codeforces Round #124 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|390|[Two Segments](http://codeforces.com/problemset/problem/193/D)|Codeforces||Codeforces Round #122 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|391|[BRT Contract ](http://codeforces.com/problemset/problem/187/D)|Codeforces||Codeforces Round #119 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|392|[Camping Groups](http://codeforces.com/problemset/problem/173/E)|Codeforces||Croc Champ 2012 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|393|[Buses and People](http://codeforces.com/problemset/problem/160/E)|Codeforces||Codeforces Round #111 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|394|[Freezing with Style](http://codeforces.com/problemset/problem/150/E)|Codeforces||Codeforces Round #107 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|395|[Lucky Pair](http://codeforces.com/problemset/problem/145/D)|Codeforces||Codeforces Round #104 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|396|[Hanger](http://codeforces.com/problemset/problem/74/D)|Codeforces||Codeforces Beta Round #68|9|
|<ul><li>- [ ] Done</li></ul>|397|[Half-decay tree](http://codeforces.com/problemset/problem/68/D)|Codeforces||Codeforces Beta Round #62|9|
|<ul><li>- [ ] Done</li></ul>|398|[Cannon](http://codeforces.com/problemset/problem/47/E)|Codeforces||Codeforces Beta Round #44 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|399|[Map](http://codeforces.com/problemset/problem/15/D)|Codeforces||Codeforces Beta Round #15|9|
|<ul><li>- [ ] Done</li></ul>|400|[Clockwork Bomb](http://codeforces.com/problemset/problem/650/E)|Codeforces||Codeforces Round #345 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|401|[Fibonacci-ish II](http://codeforces.com/problemset/problem/633/H)|Codeforces||Manthan, Codefest 16|9|
|<ul><li>- [ ] Done</li></ul>|402|[Raffles](http://codeforces.com/problemset/problem/626/G)|Codeforces||8VC Venture Cup 2016 - Elimination Round|9|
|<ul><li>- [ ] Done</li></ul>|403|[Xors on Segments](http://codeforces.com/problemset/problem/620/F)|Codeforces||Educational Codeforces Round 6|9|
|<ul><li>- [ ] Done</li></ul>|404|[Pastoral Oddities](http://codeforces.com/problemset/problem/603/E)|Codeforces||Codeforces Round #334 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|405|[A Museum Robbery](http://codeforces.com/problemset/problem/601/E)|Codeforces||Codeforces Round #333 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|406|[Polycarp's Masterpiece](http://codeforces.com/problemset/problem/589/C)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|9|
|<ul><li>- [ ] Done</li></ul>|407|[Duff as a Queen](http://codeforces.com/problemset/problem/587/E)|Codeforces||Codeforces Round #326 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|408|[Bear and Cavalry](http://codeforces.com/problemset/problem/573/D)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|409|[Tavas on the Path](http://codeforces.com/problemset/problem/536/E)|Codeforces||Codeforces Round #299 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|410|[And Yet Another Bracket Sequence](http://codeforces.com/problemset/problem/524/F)|Codeforces||VK Cup 2015 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|411|[Constrained Tree](http://codeforces.com/problemset/problem/513/D2)|Codeforces||Rockethon 2015|9|
|<ul><li>- [ ] Done</li></ul>|412|[Parking Lot](http://codeforces.com/problemset/problem/480/E)|Codeforces||Codeforces Round #274 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|413|[Design Tutorial: Increase the Constraints](http://codeforces.com/problemset/problem/472/G)|Codeforces||Codeforces Round #270|9|
|<ul><li>- [ ] Done</li></ul>|414|[The Classic Problem](http://codeforces.com/problemset/problem/464/E)|Codeforces||Codeforces Round #265 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|415|[Function](http://codeforces.com/problemset/problem/455/E)|Codeforces||Codeforces Round #260 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|416|[Little Pony and Lord Tirek](http://codeforces.com/problemset/problem/453/E)|Codeforces||Codeforces Round #259 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|417|[Chemistry Experiment](http://codeforces.com/problemset/problem/431/E)|Codeforces||Codeforces Round #247 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|418|[Big Problems for Organizers](http://codeforces.com/problemset/problem/418/D)|Codeforces||RCC 2014 Warmup (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|419|[Maze 2D](http://codeforces.com/problemset/problem/413/E)|Codeforces||Coder-Strike 2014 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|420|[k-d-sequence](http://codeforces.com/problemset/problem/407/E)|Codeforces||Codeforces Round #239 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|421|[Sereja and Dividing](http://codeforces.com/problemset/problem/380/E)|Codeforces||Codeforces Round #223 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|422|[Two permutations](http://codeforces.com/problemset/problem/323/C)|Codeforces||Testing Round #7|9|
|<ul><li>- [ ] Done</li></ul>|423|[Ping-Pong](http://codeforces.com/problemset/problem/319/E)|Codeforces||Codeforces Round #189 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|424|[Summer Homework](http://codeforces.com/problemset/problem/316/E2)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|425|[Fetch the Treasure](http://codeforces.com/problemset/problem/311/C)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|426|[Optimizer](http://codeforces.com/problemset/problem/306/B)|Codeforces||Testing Round #6|9|
|<ul><li>- [ ] Done</li></ul>|427|[Tourists](http://codeforces.com/problemset/problem/286/D)|Codeforces||Codeforces Round #176 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|428|[Mirror Room](http://codeforces.com/problemset/problem/274/E)|Codeforces||Codeforces Round #168 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|429|[Maximum Waterfall](http://codeforces.com/problemset/problem/269/D)|Codeforces||Codeforces Round #165 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|430|[Roadside Trees](http://codeforces.com/problemset/problem/264/E)|Codeforces||Codeforces Round #162 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|431|[Rhombus](http://codeforces.com/problemset/problem/263/E)|Codeforces||Codeforces Round #161 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|432|[Dividing Kingdom](http://codeforces.com/problemset/problem/260/E)|Codeforces||Codeforces Round #158 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|433|[Greedy Elevator](http://codeforces.com/problemset/problem/257/E)|Codeforces||Codeforces Round #159 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|434|[Forensic Examination](http://codeforces.com/problemset/problem/666/E)|Codeforces||Codeforces Round #349 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|435|[Bear and Bad Powers of 42](http://codeforces.com/problemset/problem/679/E)|Codeforces||Codeforces Round #356 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|436|[Hitchhiking in the Baltic States](http://codeforces.com/problemset/problem/809/D)|Codeforces||Codeforces Round #415 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|437|[Karen and Cards](http://codeforces.com/problemset/problem/815/D)|Codeforces||Codeforces Round #419 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|438|[Arkady and a Nobody-men](http://codeforces.com/problemset/problem/860/E)|Codeforces||Codeforces Round #434 (Div. 1, based on Technocup 2018 Elimination Round 1)|9|
|<ul><li>- [ ] Done</li></ul>|439|[Timofey and a flat tree](http://codeforces.com/problemset/problem/763/D)|Codeforces||Codeforces Round #395 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|440|[Huffman Coding on Segment](http://codeforces.com/problemset/problem/700/D)|Codeforces||Codeforces Round #364 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|441|[Welcome home, Chtholly](http://codeforces.com/problemset/problem/896/E)|Codeforces||Codeforces Round #449 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|442|[Mike and code of a permutation](http://codeforces.com/problemset/problem/798/E)|Codeforces||Codeforces Round #410 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|443|[Matrix](http://codeforces.com/problemset/problem/243/E)|Codeforces||Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|444|[Cubes](http://codeforces.com/problemset/problem/243/D)|Codeforces||Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|445|[Tape Programming](http://codeforces.com/problemset/problem/238/D)|Codeforces||Codeforces Round #148 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|446|[Heaven Tour](http://codeforces.com/problemset/problem/187/E)|Codeforces||Codeforces Round #119 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|447|[Soap Time! - 2](http://codeforces.com/problemset/problem/185/E)|Codeforces||Codeforces Round #118 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|448|[Gnomes of Might and Magic](http://codeforces.com/problemset/problem/175/F)|Codeforces||Codeforces Round #115|10|
|<ul><li>- [ ] Done</li></ul>|449|[Wizards and Roads](http://codeforces.com/problemset/problem/167/D)|Codeforces||Codeforces Round #114 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|450|[Tree or not Tree](http://codeforces.com/problemset/problem/117/E)|Codeforces||Codeforces Beta Round #88|10|
|<ul><li>- [ ] Done</li></ul>|451|[Name the album](http://codeforces.com/problemset/problem/100/G)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|452|[Shooting Gallery](http://codeforces.com/problemset/problem/44/G)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|453|[Stack](http://codeforces.com/problemset/problem/188/H)|Codeforces||Surprise Language Round #6|10|
|<ul><li>- [ ] Done</li></ul>|454|[MUH and Lots and Lots of Segments](http://codeforces.com/problemset/problem/471/E)|Codeforces||Codeforces Round #269 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|455|[Bear and Chemistry](http://codeforces.com/problemset/problem/639/F)|Codeforces||VK Cup 2016 - Round 1|10|
|<ul><li>- [ ] Done</li></ul>|456|[Frog Fights](http://codeforces.com/problemset/problem/625/E)|Codeforces||Codeforces Round #342 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|457|[Duff is Mad](http://codeforces.com/problemset/problem/587/F)|Codeforces||Codeforces Round #326 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|458|[Painting Edges](http://codeforces.com/problemset/problem/576/E)|Codeforces||Codeforces Round #319 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|459|[Robots protection](http://codeforces.com/problemset/problem/575/I)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|10|
|<ul><li>- [ ] Done</li></ul>|460|[Campus](http://codeforces.com/problemset/problem/571/D)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|461|[Longest Increasing Subsequence](http://codeforces.com/problemset/problem/568/E)|Codeforces||Codeforces Round #315 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|462|[Listening to Music](http://codeforces.com/problemset/problem/543/E)|Codeforces||Codeforces Round #302 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|463|[Duck Hunt](http://codeforces.com/problemset/problem/542/B)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|464|[Summer Dichotomy](http://codeforces.com/problemset/problem/538/H)|Codeforces||Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|465|[Landmarks](http://codeforces.com/problemset/problem/533/D)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|466|[Berland Miners](http://codeforces.com/problemset/problem/533/A)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|467|[ELCA](http://codeforces.com/problemset/problem/482/E)|Codeforces||Codeforces Round #275 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|468|[Dreamoon and Notepad](http://codeforces.com/problemset/problem/477/E)|Codeforces||Codeforces Round #272 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|469|[Meta-universe](http://codeforces.com/problemset/problem/475/F)|Codeforces||Bayan 2015 Contest Warm Up|10|
|<ul><li>- [ ] Done</li></ul>|470|[Banners](http://codeforces.com/problemset/problem/436/F)|Codeforces||Zepto Code Rush 2014|10|
|<ul><li>- [ ] Done</li></ul>|471|[Tricky Password](http://codeforces.com/problemset/problem/418/E)|Codeforces||RCC 2014 Warmup (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|472|[Mashmokh's Designed Problem](http://codeforces.com/problemset/problem/414/E)|Codeforces||Codeforces Round #240 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|473|[Two Rooted Trees](http://codeforces.com/problemset/problem/403/E)|Codeforces||Codeforces Round #236 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|474|[Three Arrays](http://codeforces.com/problemset/problem/392/D)|Codeforces||Codeforces Round #230 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|475|[Supercollider](http://codeforces.com/problemset/problem/391/D2)|Codeforces||Rockethon 2014|10|
|<ul><li>- [ ] Done</li></ul>|476|[Inna and Babies](http://codeforces.com/problemset/problem/374/E)|Codeforces||Codeforces Round #220 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|477|[Two Circles](http://codeforces.com/problemset/problem/363/E)|Codeforces||Codeforces Round #211 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|478|[Escaping on Beaveractor](http://codeforces.com/problemset/problem/331/D3)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|479|[Mystic Carvings](http://codeforces.com/problemset/problem/297/E)|Codeforces||Codeforces Round #180 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|480|[Sequence Transformation](http://codeforces.com/problemset/problem/280/E)|Codeforces||Codeforces Round #172 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|481|[Game with Two Trees](http://codeforces.com/problemset/problem/207/C3)|Codeforces||Abbyy Cup 2.0 - Final (unofficial)|10|
|<ul><li>- [ ] Done</li></ul>|482|[Organizing a Race](http://codeforces.com/problemset/problem/671/E)|Codeforces||Codeforces Round #352 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|483|[New task](http://codeforces.com/problemset/problem/788/E)|Codeforces||Codeforces Round #407 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|484|[Red-Black Cobweb](http://codeforces.com/problemset/problem/833/D)|Codeforces||Codeforces Round #426 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|485|[ALT](http://codeforces.com/problemset/problem/786/E)|Codeforces||Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|486|[Rap God](http://codeforces.com/problemset/problem/786/D)|Codeforces||Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|487|[Arpa’s abnormal DNA and Mehrdad’s deep interest](http://codeforces.com/problemset/problem/741/E)|Codeforces||Codeforces Round #383 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|488|[Lada Malina](http://codeforces.com/problemset/problem/853/E)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises)|10|
|<ul><li>- [ ] Done</li></ul>|489|[Caramel Clouds](http://codeforces.com/problemset/problem/833/E)|Codeforces||Codeforces Round #426 (Div. 1)|10|
