# 056. LIS


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[What Goes Up](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=422)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|2|[Strategic Defense Initiative](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=438)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Building Bridges](http://www.spoj.com/problems/BRIDGE/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|4|[Easy Longest Increasing Subsequence](http://www.spoj.com/problems/ELIS/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|5|[Wavio Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1475)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|6|[Stacking Boxes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=39)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|7|[The Tower of Babylon](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=378)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|8|[In Danger](http://www.spoj.com/problems/DANGER/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|9|[History Grading](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=47)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|10|[Testing the CATCHER](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=167)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|11|[Trainsorting](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2451)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|12|[Another Longest Increasing Subsequence Problem](http://www.spoj.com/problems/LIS2/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|13|[Tower of Cubes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=992)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|14|[Is Bigger Smarter?](http://acm.tju.edu.cn/toj/showp1216.html)|TJU||2|
|<ul><li>- [ ] Done</li></ul>|15|[Supernumbers in a permutation](http://www.spoj.com/problems/SUPPER/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|16|[BATMAN3](http://www.spoj.com/problems/BAT3/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|17|[Murcia's Skyline](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2890)|UVA||2|
|<ul><li>- [ ] Done</li></ul>|18|[Greenhouse Effect](http://codeforces.com/problemset/problem/269/B)|Codeforces|Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|19|[Building Bridges(HARD)](http://www.spoj.com/problems/BRDGHRD/)|SPOJ||3|
|<ul><li>- [ ] Done</li></ul>|20|[Tiling Up Blocks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3637)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|21|[Bubble Sort Graph](http://codeforces.com/problemset/problem/340/D)|Codeforces|Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|3|
