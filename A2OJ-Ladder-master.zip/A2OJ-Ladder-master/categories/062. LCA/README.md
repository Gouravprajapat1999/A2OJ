# 062. LCA


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lowest Common Ancestor](http://www.spoj.com/problems/LCA/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|2|[Query on a tree II](http://www.spoj.com/problems/QTREE2/)|SPOJ||1|
|<ul><li>- [ ] Done</li></ul>|3|[Distance Query](http://www.spoj.com/problems/DISQUERY/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|4|[Ants Colony](https://www.urionlinejudge.com.br/judge/en/problems/view/1135)|URI||3|
|<ul><li>- [ ] Done</li></ul>|5|[Lowest Common Ancestor](http://www.codechef.com/problems/TALCA)|CodeChef||3|
|<ul><li>- [ ] Done</li></ul>|6|[Flea circus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1879)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|7|[Distance in the Tree](http://acm.timus.ru/problem.aspx?space=1&num=1471)|Timus||3|
|<ul><li>- [ ] Done</li></ul>|8|[Ants Colony](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3390)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|9|[Design Tutorial: Inverse the Problem](http://codeforces.com/problemset/problem/472/D)|Codeforces|Codeforces Round #270|4|
|<ul><li>- [ ] Done</li></ul>|10|[Tree 2](http://acm.timus.ru/problem.aspx?space=1&num=1752)|Timus||4|
|<ul><li>- [ ] Done</li></ul>|11|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces|Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|12|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces|Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|13|[Misha, Grisha and Underground](http://codeforces.com/problemset/problem/832/D)|Codeforces|Codeforces Round #425 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|14|[Duff in the Army](http://codeforces.com/problemset/problem/587/C)|Codeforces|Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|15|[FloatingMedian](http://community.topcoder.com/stat?c=problem_statement&pm=6551)|TopCoder|SRM 310 - Div1 medium - Div2 hard] (9990)|6|
|<ul><li>- [ ] Done</li></ul>|16|[Turning Turtles](http://acm.timus.ru/problem.aspx?space=1&num=1699)|Timus||7|
