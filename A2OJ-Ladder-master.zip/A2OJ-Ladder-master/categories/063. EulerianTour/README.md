# 063. EulerianTour


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Play on Words](http://www.spoj.com/problems/WORDS1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[The Necklace](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=995)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[The Postal Worker Rings Once](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=53)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Play on Words](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1070)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|5|[John's trip](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=238)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|6|[Bus Routes](http://acm.timus.ru/problem.aspx?space=1&num=1137)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|7|[Snow Clearing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1144)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Catenyms](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1382)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|9|[Weird journey](http://codeforces.com/problemset/problem/788/B)|Codeforces||Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|10|[Islands and Hotel Chains](http://www.spoj.com/problems/HCHAINS/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|11|[John's trip](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3518)|Live Archive|1995|Europe - Central|6|
|<ul><li>- [ ] Done</li></ul>|12|[Tanya and Password](http://codeforces.com/problemset/problem/508/D)|Codeforces||Codeforces Round #288 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|13|[One-Way Reform](http://codeforces.com/problemset/problem/723/E)|Codeforces||Codeforces Round #375 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|14|[Traveling Graph](http://codeforces.com/problemset/problem/21/D)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|15|[Dominoes](http://codeforces.com/problemset/problem/267/B)|Codeforces||Codeforces Testing Round #5|8|
