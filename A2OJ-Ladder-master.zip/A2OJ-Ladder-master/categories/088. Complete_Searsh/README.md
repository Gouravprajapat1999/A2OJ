# 088. Complete_Searsh


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Ecological Bin Packing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=38)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|2|[Expert Enough?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3678)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|3|[Recycling](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=90)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|4|[Lotto](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=382)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|5|[Don't Get Rooked](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=580)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|6|[Division](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=666)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|7|[Rat Attack](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1301)|UVA|1|
|<ul><li>- [ ] Done</li></ul>|8|[The Wedding](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1603)|UVA|3|
