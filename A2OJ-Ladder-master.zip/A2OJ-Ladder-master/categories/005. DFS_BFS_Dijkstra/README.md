# 005. DFS_BFS_Dijkstra


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[The Benefactor](http://www.spoj.com/problems/BENEFACT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Bitmap](http://www.spoj.com/problems/BITMAP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Lucius Dungeon](http://www.spoj.com/problems/BYTESE1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[The Cats and the Mouse](http://www.spoj.com/problems/CATM/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Key Task](http://www.spoj.com/problems/CERC07K/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[106 miles to Chicago](http://www.spoj.com/problems/CHICAGO/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Cleaning Robot](http://www.spoj.com/problems/CLEANRBT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Highways](http://www.spoj.com/problems/HIGHWAYS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Invitation Cards](http://www.spoj.com/problems/INCARDS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Labyrinth](http://www.spoj.com/problems/LABYR1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Mice and Maze](http://www.spoj.com/problems/MICEMAZE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Laser Phones](http://www.spoj.com/problems/MLASERP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Ones and zeros](http://www.spoj.com/problems/ONEZERO/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[Pouring water](http://www.spoj.com/problems/POUR1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Prime Path](http://www.spoj.com/problems/PPATH/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Vertex Cover](http://www.spoj.com/problems/PT07X/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|17|[Is it a tree](http://www.spoj.com/problems/PT07Y/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Longest path in a tree](http://www.spoj.com/problems/PT07Z/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Almost Shortest Path](http://www.spoj.com/problems/SAMER08A/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Shopping](http://www.spoj.com/problems/SHOP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[The Shortest Path](http://www.spoj.com/problems/SHPATH/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Tic-Tac-Toe ( I )](http://www.spoj.com/problems/TOE1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Tic-Tac-Toe ( II )](http://www.spoj.com/problems/TOE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|24|[A Bug&#8217;s Life](http://www.spoj.com/problems/BUGLIFE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Traffic Network](http://www.spoj.com/problems/TRAFFICN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Making Jumps](http://www.spoj.com/problems/MKJUMPS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Number Maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=870)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Lift Hopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1742)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|29|[Sending email](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1927)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|30|[Knight Moves](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=380)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|31|[Two Gangsters](http://acm.timus.ru/problem.aspx?space=1&num=1409)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|32|[Ice Skating](http://codeforces.com/problemset/problem/217/A)|Codeforces||Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Dijkstra?](http://codeforces.com/problemset/problem/20/C)|Codeforces||Codeforces Alpha Round #20 (Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|35|[Shortest path of the king](http://codeforces.com/problemset/problem/3/A)|Codeforces||Codeforces Beta Round #3|1|
|<ul><li>- [ ] Done</li></ul>|36|[Cobbled streets](http://www.spoj.com/problems/CSTREET/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|37|[You want what filled?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1887)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Word Transformation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=370)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|39|[Page Hopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=762)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|40|[MPI Maelstrom](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=364)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|41|[Continents](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2035)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|42|[prayatna PR](http://www.spoj.com/problems/CAM5/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|43|[ABC Path](http://www.spoj.com/problems/ABCPATH/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|44|[Marble Game](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1808)|Live Archive|2007|World Finals - Tokyo|1|
|<ul><li>- [ ] Done</li></ul>|45|[A Node Too Far](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=272)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|46|[Dungeon Master](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=473)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|47|[Risk](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=508)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|48|[We Ship Cheap](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=703)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|49|[Spreading The News](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=865)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|50|[All Roads Lead Where?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=950)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|51|[Playing with Wheels](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1008)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|52|[Bombs! NO they are Mines!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1594)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|53|[Oil Deposits](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=513)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|54|[Battleships](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3104)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|55|[VALIDATE THE MAZE](http://www.spoj.com/problems/MAKEMAZE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|56|[COSTLY CHESS](http://www.spoj.com/problems/CCHESS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|57|[Sheep](http://www.spoj.com/problems/KOZE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|58|[Lazy Jumping Frog](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1653)|Live Archive|2006|Latin America - South America|1|
|<ul><li>- [ ] Done</li></ul>|59|[Water among Cubes](http://www.spoj.com/problems/WATER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|60|[Slick](http://www.spoj.com/problems/UCV2013H/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|61|[Roads](http://www.spoj.com/problems/ROADS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|62|[Minimum Knight moves !!!](http://www.spoj.com/problems/NAKANJ/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|63|[Labyrinth](http://acm.tju.edu.cn/toj/showp1056.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|64|[Easy Dijkstra Problem](http://www.spoj.com/problems/EZDIJKST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|65|[Unique Path](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4055)|Live Archive|2012|Asia - Jakarta|1|
|<ul><li>- [ ] Done</li></ul>|66|[Fishmonger](http://www.spoj.com/problems/FISHER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|67|[ALL IZZ WELL](http://www.spoj.com/problems/ALLIZWEL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|68|[Network](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=251)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|69|[Following Orders](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=60)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|70|[Til the Cows Come Home](http://poj.org/problem?id=2387)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|71|[Chef and Digit Jumps](http://www.codechef.com/problems/DIGJUMP)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|72|[Sticker Collector Robot](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2931)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|73|[Pizzas](p?ID=326)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|74|[Two Buttons](http://codeforces.com/problemset/problem/520/B)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|75|[Wetlands of Florida](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=410)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|76|[Rank the Languages](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1277)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|77|[Learning Languages](http://codeforces.com/problemset/problem/277/A)|Codeforces||Codeforces Round #170 (Div. 1) & Codeforces Round #170 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|78|[Vertex](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=216)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|79|[Herding](http://www.spoj.com/problems/HERDING/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|80|[Chop Ahoy! Revisited!](http://www.spoj.com/problems/ANARC05H/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|81|[Kefa and Park](http://codeforces.com/problemset/problem/580/C)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|82|[Soldier and Cards](http://codeforces.com/problemset/problem/546/C)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|83|[New Year Transportation](http://codeforces.com/problemset/problem/500/A)|Codeforces||Good Bye 2014|1|
|<ul><li>- [ ] Done</li></ul>|84|[BerSU Ball](http://codeforces.com/problemset/problem/489/B)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|85|[DZY Loves Chessboard](http://codeforces.com/problemset/problem/445/A)|Codeforces||Codeforces Round #254 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|86|[Maze](http://codeforces.com/problemset/problem/377/A)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|87|[Queue at the School](http://codeforces.com/problemset/problem/266/B)|Codeforces||Codeforces Round #163 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|88|[Brackets](http://www.spoj.com/problems/BRCKTS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|89|[NP-Hard Problem](http://codeforces.com/problemset/problem/687/A)|Codeforces||Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|90|[Lost in Localization](http://acm.timus.ru/problem.aspx?space=1&num=1785)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|91|[Eniya](http://acm.timus.ru/problem.aspx?space=1&num=1293)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|92|[Reverse Root](http://acm.timus.ru/problem.aspx?space=1&num=1001)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|93|[A+B Problem](http://acm.timus.ru/problem.aspx?space=1&num=1000)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|94|[Bicycle Codes](http://acm.timus.ru/problem.aspx?space=1&num=1877)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|95|[Nadia Team](p?ID=408)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|96|[Word Capitalization](http://codeforces.com/problemset/problem/281/A)|Codeforces||Codeforces Round #172 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|97|[Mutant Flatworld Explorers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=54)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|98|[Robot Motion](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1057)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|99|[Graph Connectivity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=400)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|100|[Marcus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1393)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|101|[The Seasonal War](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=288)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|102|[Friends](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1549)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|103|[Freckles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=975)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|104|[Theatre Square](http://codeforces.com/problemset/problem/1/A)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|105|[Testing the CATCHER](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=167)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|106|[Intrepid climber](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4841)|Live Archive|2014|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|107|[Brackets II](http://www.spoj.com/problems/BRCKTS2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|108|[Changing Maze](http://www.spoj.com/problems/CHMAZE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|109|[Manhattan](http://www.spoj.com/problems/DISTANCE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|110|[GONDOR](http://www.spoj.com/problems/GONDOR/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|111|[Lucky Numbers](http://www.spoj.com/problems/LUCKYNUM/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|112|[MELE3](http://www.spoj.com/problems/MELE3/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|113|[Slash Maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=646)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|114|[Equidivisions](http://www.spoj.com/problems/EQDIV/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|115|[Treeramids](http://www.spoj.com/problems/PYRA/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|116|[Interesting number](http://www.spoj.com/problems/INUMBER/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|117|[Fire Station](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1219)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|118|[Fill](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1544)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|119|[Babel](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2487)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|120|[Jugs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=512)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|121|[Meeting Prof. Miguel...](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1112)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|122|[Claw Decomposition](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2391)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|123|[Come and Go](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2938)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|124|[Commandos](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2458)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|125|[Dominator](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3053)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|126|[Finding Nemo](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1134)|Live Archive|2004|Asia - Beijing|2|
|<ul><li>- [ ] Done</li></ul>|127|[Grid Colouring](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=726)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|128|[Robot](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=250)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|129|[Shipping Routes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=319)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|130|[The Party, Part I](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1900)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|131|[Runner Pawns](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=884)|Live Archive|2003|Latin America - South America|2|
|<ul><li>- [ ] Done</li></ul>|132|[Meeting For Party](http://www.spoj.com/problems/DCEPC706/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|133|[The longest athletic track](http://acm.tju.edu.cn/toj/showp3517.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|134|[Dungeon Master](http://acm.tju.edu.cn/toj/showp1140.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|135|[Risk](http://acm.tju.edu.cn/toj/showp2033.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|136|[Step out of maze](http://acm.tju.edu.cn/toj/showp3520.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|137|[Game Show Math](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1341)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|138|[Knights in FEN](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1363)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|139|[Erdos Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=985)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|140|[Unlock the Lock](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3312)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|141|[Fire!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2671)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|142|[Maxim and Progressions](http://www.codechef.com/problems/MAXPR)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|143|[Dominos 2](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2513)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|144|[Counting Cells in a Blob](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=812)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|145|[A DP Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=973)|Live Archive|2003|Asia - Tehran|2|
|<ul><li>- [ ] Done</li></ul>|146|[DFSr - Depth Hierarchy](https://www.urionlinejudge.com.br/judge/en/problems/view/1081)|URI|||2|
|<ul><li>- [ ] Done</li></ul>|147|[Escape from Jail](http://www.spoj.com/problems/ESJAIL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|148|[Bear and Three Musketeers](http://codeforces.com/problemset/problem/574/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|149|[Chef and Reversing](http://www.codechef.com/problems/REVERSE)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|150|[The Two Routes](http://codeforces.com/problemset/problem/601/A)|Codeforces||Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|151|[Reposts](http://codeforces.com/problemset/problem/522/A)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|152|[Fox And Names](http://codeforces.com/problemset/problem/510/C)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|153|[Fox And Two Dots](http://codeforces.com/problemset/problem/510/B)|Codeforces||Codeforces Round #290 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|154|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|155|[New Year Permutation](http://codeforces.com/problemset/problem/500/B)|Codeforces||Good Bye 2014|2|
|<ul><li>- [ ] Done</li></ul>|156|[Strongly Connected City](http://codeforces.com/problemset/problem/475/B)|Codeforces||Bayan 2015 Contest Warm Up|2|
|<ul><li>- [ ] Done</li></ul>|157|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces||Codeforces Round #254 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|158|[Valera and Tubes ](http://codeforces.com/problemset/problem/441/C)|Codeforces||Codeforces Round #252 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|159|[Xor-tree](http://codeforces.com/problemset/problem/429/A)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|160|[Checkposts](http://codeforces.com/problemset/problem/427/C)|Codeforces||Codeforces Round #244 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|161|[Dijkstra](http://pl.spoj.com/problems/DIJKSTRA/)|SPOJ Poland|||2|
|<ul><li>- [ ] Done</li></ul>|162|[KATHTHI](http://www.spoj.com/problems/KATHTHI/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|163|[The Alphabet Sticker](p?ID=2)|A2 Online Judge|||2|
|<ul><li>- [ ] Done</li></ul>|164|[The Prime conjecture](http://www.spoj.com/problems/PRIMEZUK/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|165|[The Great Coach, Fegla](p?ID=195)|A2 Online Judge|||2|
|<ul><li>- [ ] Done</li></ul>|166|[Mice and Maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3553)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|167|[Maze Traversal](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1318)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|168|[Forwarding Emails](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3873)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|169|[Andryusha and Colored Balloons](http://codeforces.com/problemset/problem/780/C)|Codeforces||?????????? 2017 - ????? (?????? ??? ??????-??????????)|2|
|<ul><li>- [ ] Done</li></ul>|170|[Tennis Championship](http://codeforces.com/problemset/problem/735/C)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|171|[Timofey and a tree](http://codeforces.com/problemset/problem/763/A)|Codeforces||Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|172|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/505/B)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|173|[Journey](http://codeforces.com/problemset/problem/839/C)|Codeforces||Codeforces Round #428 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|174|[Tobo or not Tobo](http://www.spoj.com/problems/ANARC08A/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|175|[Countdown](http://www.spoj.com/problems/CDOWN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|176|[Chase](http://www.spoj.com/problems/CHASE1/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|177|[Cijevi](http://www.spoj.com/problems/CIJEVI/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|178|[Galou is back!](http://www.spoj.com/problems/GALOU/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|179|[Wandering Queen](http://www.spoj.com/problems/QUEEN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|180|[Strings](http://www.spoj.com/problems/STSTRING/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|181|[Closest Number](http://www.spoj.com/problems/MCLONUM/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|182|[Adventure of Super Mario](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1210)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|183|[Travel in Desert](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1757)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|184|[Walk Through the Forest](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1858)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|185|[Full Tank?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2352)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|186|[Airport Express](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2369)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|187|[Hotel booking](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2682)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|188|[The Tree Root](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1400)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|189|[Railroads](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=980)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|190|[Tree Reconstruction](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1351)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|191|[Colorful Graph](http://codeforces.com/problemset/problem/246/D)|Codeforces||Codeforces Round #151 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|192|[Choosing Capital for Treeland](http://codeforces.com/problemset/problem/219/D)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|193|[Cthulhu](http://codeforces.com/problemset/problem/103/B)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|194|[Mysterious Present](http://codeforces.com/problemset/problem/4/D)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|195|[The New Villa](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=257)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|196|[Ping-Pong (Easy Version)](http://codeforces.com/problemset/problem/320/B)|Codeforces||Codeforces Round #189 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|197|[Fire! Fire!! Fire!!!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1184)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|198|[Amazing Maze](http://www.spoj.com/problems/DCEPC701/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|199|[The PATH](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=542)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|200|[Fox Dividing Cheese](http://codeforces.com/problemset/problem/371/B)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|201|[Monkeys in a Regular Forest](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=717)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|202|[The mysterious X network](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3589)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|203|[THE WEIRD STAIRCASE](http://www.spoj.com/problems/STAR3CAS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|204|[Basic wall maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1990)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|205|[Subway](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1330)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|206|[Mall Mania](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2042)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|207|[The Orc Attack](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1734)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|208|[New to Bangladesh?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1466)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|209|[Rough Roads](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1297)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|210|[Path of the righteous man](http://www.spoj.com/problems/RIOI_2_3/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|211|[Ice Cave](http://codeforces.com/problemset/problem/540/C)|Codeforces||Codeforces Round #301 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|212|[Code](http://www.spoj.com/problems/CODE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|213|[Highest Paid Toll](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3198)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|214|[A short vacation in Disneyland](http://www.spoj.com/problems/PT07F/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|215|[Almost Union-Find](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3138)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|216|[New Reform](http://codeforces.com/problemset/problem/659/E)|Codeforces||Codeforces Round #346 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|217|[Bear and Compressing](http://codeforces.com/problemset/problem/653/B)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|218|[Igor In the Museum](http://codeforces.com/problemset/problem/598/D)|Codeforces||Educational Codeforces Round 1|3|
|<ul><li>- [ ] Done</li></ul>|219|[Cleaner Robot](http://codeforces.com/problemset/problem/589/J)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|3|
|<ul><li>- [ ] Done</li></ul>|220|[Om Nom and Dark Park](http://codeforces.com/problemset/problem/526/B)|Codeforces||ZeptoLab Code Rush 2015|3|
|<ul><li>- [ ] Done</li></ul>|221|[Mr. Kitayuta, the Treasure Hunter](http://codeforces.com/problemset/problem/505/C)|Codeforces||Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|222|[Unbearable Controversy of Being](http://codeforces.com/problemset/problem/489/D)|Codeforces||Codeforces Round #277.5 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|223|[Gargari and Permutations](http://codeforces.com/problemset/problem/463/D)|Codeforces||Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|224|[Valera and Elections](http://codeforces.com/problemset/problem/369/C)|Codeforces||Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|225|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces||Codeforces Round #197 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|226|[Biridian Forest](http://codeforces.com/problemset/problem/329/B)|Codeforces||Codeforces Round #192 (Div. 1) & Codeforces Round #192 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|227|[Coach](http://codeforces.com/problemset/problem/300/B)|Codeforces||Codeforces Round #181 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|228|[Greg and Graph](http://codeforces.com/problemset/problem/295/B)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|229|[Distance in Tree](http://codeforces.com/problemset/problem/161/D)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|230|[Students and Shoelaces](http://codeforces.com/problemset/problem/129/B)|Codeforces||Codeforces Beta Round #94 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|231|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces||Codeforces Round #358 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|232|[Wedding of Sultan](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4027)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|233|[From Dusk Till Dawn](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1128)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|234|[Arpa's loud Owf and Mehrdad's evil plan](http://codeforces.com/problemset/problem/741/A)|Codeforces||Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|235|[Arpa's weak amphitheater and Mehrdad's valuable Hoses](http://codeforces.com/problemset/problem/741/B)|Codeforces||Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|236|[Hongcow Builds A Nation](http://codeforces.com/problemset/problem/744/A)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|237|[Mike and Shortcuts](http://codeforces.com/problemset/problem/689/B)|Codeforces||Codeforces Round #361 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|238|[Eternal Truths](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=869)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|239|[Ocean Currents](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2620)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|240|[Round and Round Maze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=926)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|241|[Always Late](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1283)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|242|[Minefield](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2313)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|243|[Cactus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1451)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|244|[Undoubtedly Lucky Numbers](http://codeforces.com/problemset/problem/244/B)|Codeforces||Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|245|[King's Path](http://codeforces.com/problemset/problem/242/C)|Codeforces||Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|246|[Planets](http://codeforces.com/problemset/problem/229/B)|Codeforces||Codeforces Round #142 (Div. 1) & Codeforces Round #142 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|247|[Forming Teams](http://codeforces.com/problemset/problem/216/B)|Codeforces||Codeforces Round #133 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|248|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|249|[Quantity of Strings](http://codeforces.com/problemset/problem/150/B)|Codeforces||Codeforces Round #107 (Div. 1) & Codeforces Round #107 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|250|[Subway](http://codeforces.com/problemset/problem/131/D)|Codeforces||Codeforces Beta Round #95 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|251|[Statues](http://codeforces.com/problemset/problem/128/A)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|252|[Eternal Victory](http://codeforces.com/problemset/problem/61/D)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|253|[Serial Time!](http://codeforces.com/problemset/problem/60/B)|Codeforces||Codeforces Beta Round #56|4|
|<ul><li>- [ ] Done</li></ul>|254|[Fire Again](http://codeforces.com/problemset/problem/35/C)|Codeforces||Codeforces Beta Round #35 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|255|[Road Map](http://codeforces.com/problemset/problem/34/D)|Codeforces||Codeforces Beta Round #34 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|256|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|257|[Roads not only in Berland](http://codeforces.com/problemset/problem/25/D)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|258|[Roads in Berland](http://codeforces.com/problemset/problem/25/C)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|259|[Here We Go(relians) Again](http://www.spoj.com/problems/GORELIAN/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|260|[Shopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2913)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|261|[Happy Valentine Day (Valentine Maze Game)](http://www.spoj.com/problems/A_W_S_N/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|262|[Go Game](http://acm.tju.edu.cn/toj/showp2846.html)|TJU|||4|
|<ul><li>- [ ] Done</li></ul>|263|[Krochanska is Here!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2892)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|264|[Jzzhu and Cities](http://codeforces.com/problemset/problem/449/B)|Codeforces||Codeforces Round #257 (Div. 1) & Codeforces Round #257 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|265|[Paths and Trees](http://codeforces.com/problemset/problem/545/E)|Codeforces||Codeforces Round #303 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|266|[The Labyrinth](http://codeforces.com/problemset/problem/616/C)|Codeforces||Educational Codeforces Round 5|4|
|<ul><li>- [ ] Done</li></ul>|267|[Lomsat gelral](http://codeforces.com/problemset/problem/600/E)|Codeforces||Educational Codeforces Round 2|4|
|<ul><li>- [ ] Done</li></ul>|268|[Phillip and Trains](http://codeforces.com/problemset/problem/585/B)|Codeforces||Codeforces Round #325 (Div. 1) & Codeforces Round #325 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|269|[Tree Requests](http://codeforces.com/problemset/problem/570/D)|Codeforces||Codeforces Round #316 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|270|[Destroying Roads](http://codeforces.com/problemset/problem/543/B)|Codeforces||Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|271|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|272|[New Year Santa Network](http://codeforces.com/problemset/problem/500/D)|Codeforces||Good Bye 2014|4|
|<ul><li>- [ ] Done</li></ul>|273|[Design Tutorial: Inverse the Problem](http://codeforces.com/problemset/problem/472/D)|Codeforces||Codeforces Round #270|4|
|<ul><li>- [ ] Done</li></ul>|274|[Two Sets](http://codeforces.com/problemset/problem/468/B)|Codeforces||Codeforces Round #268 (Div. 1) & Codeforces Round #268 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|275|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|276|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|277|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|278|[Restore Graph](http://codeforces.com/problemset/problem/404/C)|Codeforces||Codeforces Round #237 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|279|[Propagating tree](http://codeforces.com/problemset/problem/383/C)|Codeforces||Codeforces Round #225 (Div. 1) & Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|280|[Book of Evil](http://codeforces.com/problemset/problem/337/D)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|281|[Ciel the Commander](http://codeforces.com/problemset/problem/321/C)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|282|[Cow Program](http://codeforces.com/problemset/problem/283/B)|Codeforces||Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|283|[Zero Tree](http://codeforces.com/problemset/problem/274/B)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|284|[Dorm Water Supply](http://codeforces.com/problemset/problem/107/A)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|285|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|286|[Tin Cutter](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=244)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|287|[A DP Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3641)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|288|[Cheapest way](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1377)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|289|[Nephren gives a riddle](http://codeforces.com/problemset/problem/896/A)|Codeforces||Codeforces Round #449 (Div. 1) & Codeforces Round #449 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|290|[Connecting Universities](http://codeforces.com/problemset/problem/700/B)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|291|[Alyona and a tree](http://codeforces.com/problemset/problem/739/B)|Codeforces||Codeforces Round #381 (Div. 1) & Codeforces Round #381 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|292|[Chloe and pleasant prizes](http://codeforces.com/problemset/problem/743/D)|Codeforces||Codeforces Round #384 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|293|[Directed Roads](http://codeforces.com/problemset/problem/711/D)|Codeforces||Codeforces Round #369 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|294|[Ilya And The Tree](http://codeforces.com/problemset/problem/842/C)|Codeforces||Codeforces Round #430 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|295|[Garland](http://codeforces.com/problemset/problem/767/C)|Codeforces||Codeforces Round #398 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|296|[Chess Knights](p?ID=142)|A2 Online Judge|||4|
|<ul><li>- [ ] Done</li></ul>|297|[Umnozak](http://www.spoj.com/problems/UMNOZAK/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|298|[Speedy Escape](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2740)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|299|[Text Editor](http://codeforces.com/problemset/problem/253/C)|Codeforces||Codeforces Round #154 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|300|[Blood Cousins](http://codeforces.com/problemset/problem/208/E)|Codeforces||Codeforces Round #130 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|301|[Jumping on Walls](http://codeforces.com/problemset/problem/198/B)|Codeforces||Codeforces Round #125 (Div. 1) & Codeforces Round #125 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|302|[Infinite Maze](http://codeforces.com/problemset/problem/196/B)|Codeforces||Codeforces Round #124 (Div. 1) & Codeforces Round #124 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|303|[Cutting Figure](http://codeforces.com/problemset/problem/193/A)|Codeforces||Codeforces Round #122 (Div. 1) & Codeforces Round #122 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|304|[STL](http://codeforces.com/problemset/problem/190/C)|Codeforces||Codeforces Round #120 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|305|[Missile Silos](http://codeforces.com/problemset/problem/144/D)|Codeforces||Codeforces Round #103 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|306|[Logo Turtle](http://codeforces.com/problemset/problem/132/C)|Codeforces||Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|307|[Cycle](http://codeforces.com/problemset/problem/117/C)|Codeforces||Codeforces Beta Round #88|5|
|<ul><li>- [ ] Done</li></ul>|308|[Volleyball](http://codeforces.com/problemset/problem/95/C)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|309|[Square Earth?](http://codeforces.com/problemset/problem/57/A)|Codeforces||Codeforces Beta Round #53|5|
|<ul><li>- [ ] Done</li></ul>|310|[Mail Stamps](http://codeforces.com/problemset/problem/29/C)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|311|[pSort](http://codeforces.com/problemset/problem/28/B)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|312|[Hierarchy](http://codeforces.com/problemset/problem/17/B)|Codeforces||Codeforces Beta Round #17|5|
|<ul><li>- [ ] Done</li></ul>|313|[Two Paths](http://codeforces.com/problemset/problem/14/D)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|314|[Masud Rana](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2647)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|315|[Chinese Checkers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=800)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|316|[GRAVITY](http://www.spoj.com/problems/GRAVITY/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|317|[Tutorial BFS](http://www.spoj.com/problems/TUTBFS/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|318|[Breaking Good](http://codeforces.com/problemset/problem/507/E)|Codeforces||Codeforces Round #287 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|319|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces||Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|320|[Moodular Arithmetic](http://codeforces.com/problemset/problem/603/B)|Codeforces||Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|321|[Super M](http://codeforces.com/problemset/problem/592/D)|Codeforces||Codeforces Round #328 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|322|[Three States](http://codeforces.com/problemset/problem/590/C)|Codeforces||Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|323|[Vitaly and Cycle](http://codeforces.com/problemset/problem/557/D)|Codeforces||Codeforces Round #311 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|324|[Inversions problem](http://codeforces.com/problemset/problem/513/G1)|Codeforces||Rockethon 2015|5|
|<ul><li>- [ ] Done</li></ul>|325|[Chocolate](http://codeforces.com/problemset/problem/490/D)|Codeforces||Codeforces Round #279 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|326|[Valid Sets](http://codeforces.com/problemset/problem/486/D)|Codeforces||Codeforces Round #277 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|327|[Dima and Bacteria](http://codeforces.com/problemset/problem/400/D)|Codeforces||Codeforces Round #234 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|328|[Tree and Queries](http://codeforces.com/problemset/problem/375/D)|Codeforces||Codeforces Round #221 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|329|[Inna and Dima](http://codeforces.com/problemset/problem/374/C)|Codeforces||Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|330|[Water Tree](http://codeforces.com/problemset/problem/343/D)|Codeforces||Codeforces Round #200 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|331|[Block Tower](http://codeforces.com/problemset/problem/327/D)|Codeforces||Codeforces Round #191 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|332|[Yaroslav and Time](http://codeforces.com/problemset/problem/301/B)|Codeforces||Codeforces Round #182 (Div. 1) & Codeforces Round #182 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|333|[Connected Components](http://codeforces.com/problemset/problem/292/D)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|334|[Cycle in Graph](http://codeforces.com/problemset/problem/263/D)|Codeforces||Codeforces Round #161 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|335|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces||Codeforces Round #112 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|336|[Kay and Snowflake](http://codeforces.com/problemset/problem/685/B)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|337|[Theseus and labyrinth](http://codeforces.com/problemset/problem/676/D)|Codeforces||Codeforces Round #354 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|338|[Comments](http://codeforces.com/problemset/problem/747/E)|Codeforces||Codeforces Round #387 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|339|[Transmissão de Energia](https://www.urionlinejudge.com.br/judge/en/problems/view/2300)|URI|||5|
|<ul><li>- [ ] Done</li></ul>|340|[MergeSort](http://community.topcoder.com/stat?c=problem_statement&pm=1705)|TopCoder||SRM 151 - Div1 medium - Div2 hard] (4560)|5|
|<ul><li>- [ ] Done</li></ul>|341|[Kruskal](http://www.spoj.com/problems/KRUSKAL/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|342|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|343|[Berzerk](http://codeforces.com/problemset/problem/786/A)|Codeforces||Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|344|[Weird journey](http://codeforces.com/problemset/problem/788/B)|Codeforces||Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|345|[Complete The Graph](http://codeforces.com/problemset/problem/715/B)|Codeforces||Codeforces Round #372 (Div. 1) & Codeforces Round #372 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|346|[Misha, Grisha and Underground](http://codeforces.com/problemset/problem/832/D)|Codeforces||Codeforces Round #425 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|347|[An overnight dance in discotheque](http://codeforces.com/problemset/problem/814/D)|Codeforces||Codeforces Round #418 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|348|[Mahmoud and a Dictionary](http://codeforces.com/problemset/problem/766/D)|Codeforces||Codeforces Round #396 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|349|[Persistent Bookcase ](http://codeforces.com/problemset/problem/707/D)|Codeforces||Codeforces Round #368 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|350|[What is for dinner?](http://codeforces.com/problemset/problem/33/A)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|351|[BFS (Binary Fibonacci String)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3192)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|352|[Fixed Partition Contest Management](http://www.spoj.com/problems/CONTEST/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|353|[Dispute](http://codeforces.com/problemset/problem/242/D)|Codeforces||Codeforces Round #149 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|354|[The Road to Berland is Paved With Good Intentions](http://codeforces.com/problemset/problem/228/E)|Codeforces||Codeforces Round #141 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|355|[Game](http://codeforces.com/problemset/problem/213/A)|Codeforces||Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|356|[Police Station](http://codeforces.com/problemset/problem/208/C)|Codeforces||Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|357|[Solitaire](http://codeforces.com/problemset/problem/208/B)|Codeforces||Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|358|[AlgoRace](http://codeforces.com/problemset/problem/187/B)|Codeforces||Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|359|[Chamber of Secrets](http://codeforces.com/problemset/problem/173/B)|Codeforces||Croc Champ 2012 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|360|[Bertown roads](http://codeforces.com/problemset/problem/118/E)|Codeforces||Codeforces Beta Round #89 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|361|[String Problem](http://codeforces.com/problemset/problem/33/B)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|362|[Ant on the Tree](http://codeforces.com/problemset/problem/29/D)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|363|[Road Rally](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3962)|Live Archive|2011|North America - Mid-Atlantic USA|6|
|<ul><li>- [ ] Done</li></ul>|364|[Little Pony and Summer Sun Celebration](http://codeforces.com/problemset/problem/453/C)|Codeforces||Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|365|[Caisa and Tree](http://codeforces.com/problemset/problem/463/E)|Codeforces||Codeforces Round #264 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|366|[Fedor and Essay](http://codeforces.com/problemset/problem/467/D)|Codeforces||Codeforces Round #267 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|367|[Increasing Shortest Path](p?ID=4)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|368|[Graph Coloring](http://codeforces.com/problemset/problem/662/B)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|369|[Polycarp and Hay](http://codeforces.com/problemset/problem/659/F)|Codeforces||Codeforces Round #346 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|370|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|371|[Making Genome in Berland](http://codeforces.com/problemset/problem/638/B)|Codeforces||VK Cup 2016 - Qualification Round 2|6|
|<ul><li>- [ ] Done</li></ul>|372|[Ants in Leaves](http://codeforces.com/problemset/problem/622/E)|Codeforces||Educational Codeforces Round 7|6|
|<ul><li>- [ ] Done</li></ul>|373|[Hamiltonian Spanning Tree](http://codeforces.com/problemset/problem/618/D)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|6|
|<ul><li>- [ ] Done</li></ul>|374|[Invariance of Tree](http://codeforces.com/problemset/problem/576/B)|Codeforces||Codeforces Round #319 (Div. 1) & Codeforces Round #319 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|375|[Love Triangles](http://codeforces.com/problemset/problem/553/C)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|376|[Looksery Party](http://codeforces.com/problemset/problem/549/B)|Codeforces||Looksery Cup 2015|6|
|<ul><li>- [ ] Done</li></ul>|377|[Demiurges Play Again](http://codeforces.com/problemset/problem/538/E)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|378|[Work Group](http://codeforces.com/problemset/problem/533/B)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|6|
|<ul><li>- [ ] Done</li></ul>|379|[Tanya and Password](http://codeforces.com/problemset/problem/508/D)|Codeforces||Codeforces Round #288 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|380|[Mr. Kitayuta's Technology](http://codeforces.com/problemset/problem/505/D)|Codeforces||Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|381|[Information Graph](http://codeforces.com/problemset/problem/466/E)|Codeforces||Codeforces Round #266 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|382|[Divisors](http://codeforces.com/problemset/problem/448/E)|Codeforces||Codeforces Round #256 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|383|[Giving Awards](http://codeforces.com/problemset/problem/412/D)|Codeforces||Coder-Strike 2014 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|384|[Apple Tree](http://codeforces.com/problemset/problem/348/B)|Codeforces||Codeforces Round #202 (Div. 1) & Codeforces Round #202 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|385|[EKG](http://codeforces.com/problemset/problem/316/B2)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|386|[EKG](http://codeforces.com/problemset/problem/316/B1)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|387|[Sereja and Periods](http://codeforces.com/problemset/problem/314/B)|Codeforces||Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|388|[Greg and Friends](http://codeforces.com/problemset/problem/295/C)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|389|[Party](http://codeforces.com/problemset/problem/177/C2)|Codeforces||ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|390|[Party](http://codeforces.com/problemset/problem/177/C1)|Codeforces||ABBYY Cup 2.0 - Easy|6|
|<ul><li>- [ ] Done</li></ul>|391|[Ring Road 2](http://codeforces.com/problemset/problem/27/D)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|392|[World Tour](http://codeforces.com/problemset/problem/666/B)|Codeforces||Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|393|[Gifts by the List](http://codeforces.com/problemset/problem/681/D)|Codeforces||Codeforces Round #357 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|394|[Leha and another game about graph](http://codeforces.com/problemset/problem/840/B)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|395|[Legacy](http://codeforces.com/problemset/problem/786/B)|Codeforces||Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|396|[The Great Mixing](http://codeforces.com/problemset/problem/788/C)|Codeforces||Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|397|[Arpa’s overnight party and Mehrdad’s silent entering](http://codeforces.com/problemset/problem/741/C)|Codeforces||Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|398|[Vladik and Favorite Game](http://codeforces.com/problemset/problem/811/D)|Codeforces||Codeforces Round #416 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|399|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces||Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|400|[Caravans](http://acm.timus.ru/problem.aspx?space=1&num=2034)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|401|[Segment Tree](http://www.spoj.com/problems/SEGTREE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|402|[Hex Tile Equations](http://www.spoj.com/problems/HEXTILE/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|403|[Flight Planning](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=742)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|404|[DRM](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2311)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|405|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces||Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|406|[World Eater Brothers](http://codeforces.com/problemset/problem/238/C)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|407|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces||Codeforces Round #143 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|408|[Weak Memory](http://codeforces.com/problemset/problem/187/C)|Codeforces||Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|409|[Variable, or There and Back Again](http://codeforces.com/problemset/problem/164/A)|Codeforces||VK Cup 2012 Round 3|7|
|<ul><li>- [ ] Done</li></ul>|410|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces||Codeforces Round #111 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|411|[Pairs of Numbers](http://codeforces.com/problemset/problem/134/B)|Codeforces||Codeforces Testing Round #3|7|
|<ul><li>- [ ] Done</li></ul>|412|[General Mobilization](http://codeforces.com/problemset/problem/82/C)|Codeforces||Yandex.Algorithm 2011 Qualification 2|7|
|<ul><li>- [ ] Done</li></ul>|413|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|414|[Chessboard Billiard](http://codeforces.com/problemset/problem/74/C)|Codeforces||Codeforces Beta Round #68|7|
|<ul><li>- [ ] Done</li></ul>|415|[Shortest Path](http://codeforces.com/problemset/problem/59/E)|Codeforces||Codeforces Beta Round #55 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|416|[Knights](http://codeforces.com/problemset/problem/33/D)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|417|[Chocolate](http://codeforces.com/problemset/problem/31/D)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|418|[Fairy](http://codeforces.com/problemset/problem/19/E)|Codeforces||Codeforces Beta Round #19|7|
|<ul><li>- [ ] Done</li></ul>|419|[Event Dates](http://codeforces.com/problemset/problem/45/D)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|420|[Rotate to root](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2735)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|421|[Bear and Forgotten Tree 2](http://codeforces.com/problemset/problem/653/E)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|422|[Pursuit For Artifacts](http://codeforces.com/problemset/problem/652/E)|Codeforces||Educational Codeforces Round 10|7|
|<ul><li>- [ ] Done</li></ul>|423|[Three-dimensional Turtle Super Computer ](http://codeforces.com/problemset/problem/638/D)|Codeforces||VK Cup 2016 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|424|[Road Improvement](http://codeforces.com/problemset/problem/638/C)|Codeforces||VK Cup 2016 - Qualification Round 2|7|
|<ul><li>- [ ] Done</li></ul>|425|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces||Codeforces Round #343 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|426|[Square Root of Permutation](http://codeforces.com/problemset/problem/612/E)|Codeforces||Educational Codeforces Round 4|7|
|<ul><li>- [ ] Done</li></ul>|427|[Acyclic Organic Compounds](http://codeforces.com/problemset/problem/601/D)|Codeforces||Codeforces Round #333 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|428|[Tourist Guide](http://codeforces.com/problemset/problem/589/H)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|7|
|<ul><li>- [ ] Done</li></ul>|429|[Bribes](http://codeforces.com/problemset/problem/575/B)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|430|[Bear and Drawing](http://codeforces.com/problemset/problem/573/C)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|431|[President and Roads](http://codeforces.com/problemset/problem/567/E)|Codeforces||Codeforces Round #Pi (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|432|[Case of Computer Network](http://codeforces.com/problemset/problem/555/E)|Codeforces||Codeforces Round #310 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|433|[Mike and Fish](http://codeforces.com/problemset/problem/547/D)|Codeforces||Codeforces Round #305 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|434|[Data Center Drama](http://codeforces.com/problemset/problem/527/E)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|435|[Treeland Tour](http://codeforces.com/problemset/problem/490/F)|Codeforces||Codeforces Round #279 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|436|[President's Path](http://codeforces.com/problemset/problem/416/E)|Codeforces||Codeforces Round #241 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|437|[Hill Climbing](http://codeforces.com/problemset/problem/406/D)|Codeforces||Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|438|[Graph Cutting](http://codeforces.com/problemset/problem/405/E)|Codeforces||Codeforces Round #238 (Div. 2) & Codeforces Round #238 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|439|[Ksenia and Pawns](http://codeforces.com/problemset/problem/382/D)|Codeforces||Codeforces Round #224 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|440|[Valera and Fools](http://codeforces.com/problemset/problem/369/D)|Codeforces||Codeforces Round #216 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|441|[Dima and Trap Graph](http://codeforces.com/problemset/problem/366/D)|Codeforces||Codeforces Round #214 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|442|[Fools and Foolproof Roads](http://codeforces.com/problemset/problem/362/D)|Codeforces||Codeforces Round #212 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|443|[Lucky Number Representation](http://codeforces.com/problemset/problem/354/E)|Codeforces||Codeforces Round #206 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|444|[Wrong Floyd](http://codeforces.com/problemset/problem/350/E)|Codeforces||Codeforces Round #203 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|445|[Tree-String Problem](http://codeforces.com/problemset/problem/291/E)|Codeforces||Croc Champ 2013 - Qualification Round|7|
|<ul><li>- [ ] Done</li></ul>|446|[Lovely Matrix](http://codeforces.com/problemset/problem/274/D)|Codeforces||Codeforces Round #168 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|447|[Circle of Numbers](http://codeforces.com/problemset/problem/263/C)|Codeforces||Codeforces Round #161 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|448|[Little Elephant and Tree](http://codeforces.com/problemset/problem/258/E)|Codeforces||Codeforces Round #157 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|449|[Snake](http://codeforces.com/problemset/problem/225/D)|Codeforces||Codeforces Round #139 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|450|[Bear and Square Grid](http://codeforces.com/problemset/problem/679/C)|Codeforces||Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|451|[Peterson Polyglot](http://codeforces.com/problemset/problem/778/C)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|452|[Break Up](http://codeforces.com/problemset/problem/700/C)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|453|[Okabe and City](http://codeforces.com/problemset/problem/821/D)|Codeforces||Codeforces Round #420 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|454|[Colorado Potato Beetle](http://codeforces.com/problemset/problem/243/C)|Codeforces||Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|455|[Flights](http://codeforces.com/problemset/problem/241/E)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|8|
|<ul><li>- [ ] Done</li></ul>|456|[T-decomposition](http://codeforces.com/problemset/problem/237/D)|Codeforces||Codeforces Round #147 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|457|[IT Restaurants](http://codeforces.com/problemset/problem/212/E)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|8|
|<ul><li>- [ ] Done</li></ul>|458|[Opening Portals](http://codeforces.com/problemset/problem/196/E)|Codeforces||Codeforces Round #124 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|459|[Cyclic Coloring](http://codeforces.com/problemset/problem/183/C)|Codeforces||Croc Champ 2012 - Final|8|
|<ul><li>- [ ] Done</li></ul>|460|[Archaeology](http://codeforces.com/problemset/problem/176/E)|Codeforces||Croc Champ 2012 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|461|[e-Government](http://codeforces.com/problemset/problem/163/E)|Codeforces||VK Cup 2012 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|462|[Take-off Ramps](http://codeforces.com/problemset/problem/141/D)|Codeforces||Codeforces Round #101 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|463|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|464|[Petya and Tree](http://codeforces.com/problemset/problem/85/C)|Codeforces||Yandex.Algorithm 2011 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|465|[Password](http://codeforces.com/problemset/problem/79/D)|Codeforces||Codeforces Beta Round #71|8|
|<ul><li>- [ ] Done</li></ul>|466|[FreeDiv](http://codeforces.com/problemset/problem/73/D)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|467|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces||Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|468|[Mushroom Strife](http://codeforces.com/problemset/problem/60/C)|Codeforces||Codeforces Beta Round #56|8|
|<ul><li>- [ ] Done</li></ul>|469|[Quarrel](http://codeforces.com/problemset/problem/29/E)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|470|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|471|[Interestring graph and Apples](http://codeforces.com/problemset/problem/9/E)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|472|[Graph basics concepts](http://www.spoj.com/problems/GRAPHS12/)|SPOJ|||8|
|<ul><li>- [ ] Done</li></ul>|473|[Yash And Trees](http://codeforces.com/problemset/problem/633/G)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|474|[The Chocolate Spree](http://codeforces.com/problemset/problem/633/F)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|475|[Kingdom and its Cities](http://codeforces.com/problemset/problem/613/D)|Codeforces||Codeforces Round #339 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|476|[Intergalaxy Trips](http://codeforces.com/problemset/problem/605/E)|Codeforces||Codeforces Round #335 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|477|[Board Game](http://codeforces.com/problemset/problem/605/D)|Codeforces||Codeforces Round #335 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|478|[Run for beer](http://codeforces.com/problemset/problem/575/G)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|8|
|<ul><li>- [ ] Done</li></ul>|479|[CNF 2](http://codeforces.com/problemset/problem/571/C)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|480|[Matching Names](http://codeforces.com/problemset/problem/566/A)|Codeforces||VK Cup 2015 - Finals, online mirror|8|
|<ul><li>- [ ] Done</li></ul>|481|[Playing on Graph](http://codeforces.com/problemset/problem/542/E)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|8|
|<ul><li>- [ ] Done</li></ul>|482|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces||Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|483|[Constrained Tree](http://codeforces.com/problemset/problem/513/D1)|Codeforces||Rockethon 2015|8|
|<ul><li>- [ ] Done</li></ul>|484|[Birthday](http://codeforces.com/problemset/problem/494/D)|Codeforces||Codeforces Round #282 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|485|[Tourists](http://codeforces.com/problemset/problem/487/E)|Codeforces||Codeforces Round #278 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|486|[One-Based Arithmetic](http://codeforces.com/problemset/problem/440/C)|Codeforces||Testing Round #10|8|
|<ul><li>- [ ] Done</li></ul>|487|[Choosing Subtree is Fun](http://codeforces.com/problemset/problem/372/D)|Codeforces||Codeforces Round #219 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|488|[Sereja and Sets](http://codeforces.com/problemset/problem/367/D)|Codeforces||Codeforces Round #215 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|489|[Petya and Pipes](http://codeforces.com/problemset/problem/362/E)|Codeforces||Codeforces Round #212 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|490|[Robot Control](http://codeforces.com/problemset/problem/346/D)|Codeforces||Codeforces Round #201 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|491|[Xenia and Dominoes](http://codeforces.com/problemset/problem/342/D)|Codeforces||Codeforces Round #199 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|492|[Three Swaps](http://codeforces.com/problemset/problem/339/E)|Codeforces||Codeforces Round #197 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|493|[Balance](http://codeforces.com/problemset/problem/317/C)|Codeforces||Codeforces Round #188 (Div. 1) & Codeforces Round #188 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|494|[Polo the Penguin and Trees ](http://codeforces.com/problemset/problem/288/D)|Codeforces||Codeforces Round #177 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|495|[Dominoes](http://codeforces.com/problemset/problem/267/B)|Codeforces||Codeforces Testing Round #5|8|
|<ul><li>- [ ] Done</li></ul>|496|[BerDonalds](http://codeforces.com/problemset/problem/266/D)|Codeforces||Codeforces Round #163 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|497|[Rats](http://codeforces.com/problemset/problem/254/D)|Codeforces||Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|498|[Road Repairs](http://codeforces.com/problemset/problem/240/E)|Codeforces||Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|499|[Meeting Her](http://codeforces.com/problemset/problem/238/E)|Codeforces||Codeforces Round #148 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|500|[Bitonix' Patrol](http://codeforces.com/problemset/problem/217/D)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|501|[Battlefield](http://codeforces.com/problemset/problem/182/A)|Codeforces||Codeforces Round #117 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|502|[BHTML+BCSS](http://codeforces.com/problemset/problem/172/E)|Codeforces||Croc Champ 2012 - Qualification Round|9|
|<ul><li>- [ ] Done</li></ul>|503|[Cycle](http://codeforces.com/problemset/problem/135/D)|Codeforces||Codeforces Beta Round #97 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|504|[Winning Strategy](http://codeforces.com/problemset/problem/97/C)|Codeforces||Yandex.Algorithm 2011 Finals|9|
|<ul><li>- [ ] Done</li></ul>|505|[Track](http://codeforces.com/problemset/problem/83/C)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|506|[Evacuation](http://codeforces.com/problemset/problem/78/E)|Codeforces||Codeforces Beta Round #70 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|507|[Ship's Shortest Path](http://codeforces.com/problemset/problem/75/E)|Codeforces||Codeforces Beta Round #67 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|508|[Harry Potter and the Sorting Hat](http://codeforces.com/problemset/problem/65/D)|Codeforces||Codeforces Beta Round #60|9|
|<ul><li>- [ ] Done</li></ul>|509|[Wormhouse](http://codeforces.com/problemset/problem/62/D)|Codeforces||Codeforces Beta Round #58|9|
|<ul><li>- [ ] Done</li></ul>|510|[Caterpillar](http://codeforces.com/problemset/problem/51/F)|Codeforces||Codeforces Beta Round #48|9|
|<ul><li>- [ ] Done</li></ul>|511|[Trial for Chief](http://codeforces.com/problemset/problem/37/E)|Codeforces||Codeforces Beta Round #37|9|
|<ul><li>- [ ] Done</li></ul>|512|[S&#227;o Jo&#227;o](http://br.spoj.com/problems/SAOJOAO/)|SPOJ Brazil|||9|
|<ul><li>- [ ] Done</li></ul>|513|[Clockwork Bomb](http://codeforces.com/problemset/problem/650/E)|Codeforces||Codeforces Round #345 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|514|[Wilbur and Strings](http://codeforces.com/problemset/problem/596/E)|Codeforces||Codeforces Round #331 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|515|[Superhero's Job](http://codeforces.com/problemset/problem/542/D)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|9|
|<ul><li>- [ ] Done</li></ul>|516|[Cycling City](http://codeforces.com/problemset/problem/521/E)|Codeforces||Codeforces Round #295 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|517|[Strongly Connected City 2](http://codeforces.com/problemset/problem/475/E)|Codeforces||Bayan 2015 Contest Warm Up|9|
|<ul><li>- [ ] Done</li></ul>|518|[The Classic Problem](http://codeforces.com/problemset/problem/464/E)|Codeforces||Codeforces Round #265 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|519|[Game with Points](http://codeforces.com/problemset/problem/386/D)|Codeforces||Testing Round #9|9|
|<ul><li>- [ ] Done</li></ul>|520|[Circling Round Treasures](http://codeforces.com/problemset/problem/375/C)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|521|[Levko and Game](http://codeforces.com/problemset/problem/360/E)|Codeforces||Codeforces Round #210 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|522|[Neatness](http://codeforces.com/problemset/problem/359/E)|Codeforces||Codeforces Round #209 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|523|[Pilgrims](http://codeforces.com/problemset/problem/348/E)|Codeforces||Codeforces Round #202 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|524|[Pumping Stations](http://codeforces.com/problemset/problem/343/E)|Codeforces||Codeforces Round #200 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|525|[The Red Button](http://codeforces.com/problemset/problem/325/E)|Codeforces||MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|526|[Monsters and Diamonds](http://codeforces.com/problemset/problem/325/C)|Codeforces||MemSQL start[c]up Round 1|9|
|<ul><li>- [ ] Done</li></ul>|527|[Fetch the Treasure](http://codeforces.com/problemset/problem/311/C)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|528|[Maze](http://codeforces.com/problemset/problem/123/E)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|529|[Pairs](http://codeforces.com/problemset/problem/81/E)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|9|
|<ul><li>- [ ] Done</li></ul>|530|[Bear and Chase](http://codeforces.com/problemset/problem/679/D)|Codeforces||Codeforces Round #356 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|531|[Simplifying the Farm](http://www.spoj.com/problems/HKRUSKAL/)|SPOJ|||9|
|<ul><li>- [ ] Done</li></ul>|532|[Arkady and a Nobody-men](http://codeforces.com/problemset/problem/860/E)|Codeforces||Codeforces Round #434 (Div. 1, based on Technocup 2018 Elimination Round 1)|9|
|<ul><li>- [ ] Done</li></ul>|533|[Sagheer and Kindergarten](http://codeforces.com/problemset/problem/812/D)|Codeforces||Codeforces Round #417 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|534|[DFS](http://codeforces.com/problemset/problem/1044/F)|Codeforces||Lyft Level 5 Challenge 2018 - Final Round|9|
|<ul><li>- [ ] Done</li></ul>|535|[Tree and Table](http://codeforces.com/problemset/problem/251/E)|Codeforces||Codeforces Round #153 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|536|[Doe Graphs](http://codeforces.com/problemset/problem/232/C)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|537|[Gnomes of Might and Magic](http://codeforces.com/problemset/problem/175/F)|Codeforces||Codeforces Round #115|10|
|<ul><li>- [ ] Done</li></ul>|538|[Battleship](http://codeforces.com/problemset/problem/100/H)|Codeforces||Unknown Language Round #3|10|
|<ul><li>- [ ] Done</li></ul>|539|[Leaders](http://codeforces.com/problemset/problem/97/E)|Codeforces||Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|540|[Harry Potter and Moving Staircases](http://codeforces.com/problemset/problem/65/E)|Codeforces||Codeforces Beta Round #60|10|
|<ul><li>- [ ] Done</li></ul>|541|[Chess](http://codeforces.com/problemset/problem/57/E)|Codeforces||Codeforces Beta Round #53|10|
|<ul><li>- [ ] Done</li></ul>|542|[Baldman and the military](http://codeforces.com/problemset/problem/42/E)|Codeforces||Codeforces Beta Round #41|10|
|<ul><li>- [ ] Done</li></ul>|543|[Bear and Chemistry](http://codeforces.com/problemset/problem/639/F)|Codeforces||VK Cup 2016 - Round 1|10|
|<ul><li>- [ ] Done</li></ul>|544|[Island Puzzle](http://codeforces.com/problemset/problem/627/F)|Codeforces||8VC Venture Cup 2016 - Final Round|10|
|<ul><li>- [ ] Done</li></ul>|545|[Taxi in Berland](http://codeforces.com/problemset/problem/589/M)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|10|
|<ul><li>- [ ] Done</li></ul>|546|[Logistical Questions](http://codeforces.com/problemset/problem/566/C)|Codeforces||VK Cup 2015 - Finals, online mirror|10|
|<ul><li>- [ ] Done</li></ul>|547|[Summer Dichotomy](http://codeforces.com/problemset/problem/538/H)|Codeforces||Codeforces Round #300|10|
|<ul><li>- [ ] Done</li></ul>|548|[Berland Miners](http://codeforces.com/problemset/problem/533/A)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|10|
|<ul><li>- [ ] Done</li></ul>|549|[Misha and LCP on Tree](http://codeforces.com/problemset/problem/504/E)|Codeforces||Codeforces Round #285 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|550|[Wavy numbers](http://codeforces.com/problemset/problem/478/E)|Codeforces||Codeforces Round #273 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|551|[Appleman and a Game](http://codeforces.com/problemset/problem/461/E)|Codeforces||Codeforces Round #263 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|552|[Colored Jenga](http://codeforces.com/problemset/problem/424/E)|Codeforces||Codeforces Round #242 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|553|[Chain Letter](http://codeforces.com/problemset/problem/345/D)|Codeforces||Friday the 13th, Programmers Day|10|
|<ul><li>- [ ] Done</li></ul>|554|[Escaping on Beaveractor](http://codeforces.com/problemset/problem/331/D1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|555|[Princess and Her Shadow](http://codeforces.com/problemset/problem/317/E)|Codeforces||Codeforces Round #188 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|556|[Suns and Rays](http://codeforces.com/problemset/problem/316/F3)|Codeforces||ABBYY Cup 3.0|10|
|<ul><li>- [ ] Done</li></ul>|557|[Suns and Rays](http://codeforces.com/problemset/problem/316/F1)|Codeforces||ABBYY Cup 3.0|10|
|<ul><li>- [ ] Done</li></ul>|558|[Greedy Petya](http://codeforces.com/problemset/problem/290/F)|Codeforces||April Fools Day Contest 2013|10|
|<ul><li>- [ ] Done</li></ul>|559|[Dynamic Programming](p?ID=410)|A2 Online Judge|||10|
|<ul><li>- [ ] Done</li></ul>|560|[#dynamic-programming&nbsp;(168)</span>](http://www.spoj.com/problems/tag/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|561|[Longest Maze Path](http://www.spoj.com/problems/EPIC1305/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|562|[Sloth](http://codeforces.com/problemset/problem/891/D)|Codeforces||Codeforces Round #446 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|563|[Rap God](http://codeforces.com/problemset/problem/786/D)|Codeforces||Codeforces Round #406 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|564|[Nikita and game](http://codeforces.com/problemset/problem/842/E)|Codeforces||Codeforces Round #430 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|565|[The Overdosing Ubiquity](http://codeforces.com/problemset/problem/869/D)|Codeforces||Codeforces Round #439 (Div. 2)|10|
