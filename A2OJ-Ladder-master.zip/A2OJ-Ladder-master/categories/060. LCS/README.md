# 060. LCS


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Aibohphobia](http://www.spoj.com/problems/AIBOHP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Longest Common Subsequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1346)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[History Grading](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=47)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Cross-country](http://www.spoj.com/problems/CRSCNTRY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Is Bigger Smarter?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1072)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Common Subsequence](http://poj.org/problem?id=1458)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Advanced Fruits](http://www.spoj.com/problems/ADFRUITS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Palindrome 2000](http://www.spoj.com/problems/IOIPALIN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Common Subsequence](http://acm.tju.edu.cn/toj/showp1683.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|10|[DNA Sequences](http://www.spoj.com/problems/SAMER08D/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[The Knapsack Problem](http://www.spoj.com/problems/KNAPSACK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[X-MEN](http://www.spoj.com/problems/XMEN/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|13|[Prince and Princess](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1576)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|14|[Gargari and Permutations](http://codeforces.com/problemset/problem/463/D)|Codeforces||Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|15|[Lucky Common Subsequence](http://codeforces.com/problemset/problem/346/B)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|16|[LCS Again](http://codeforces.com/problemset/problem/578/D)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|8|
|<ul><li>- [ ] Done</li></ul>|17|[k-longest Common Sequence](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=778)|Live Archive|2003|Asia - Beijing|10|
