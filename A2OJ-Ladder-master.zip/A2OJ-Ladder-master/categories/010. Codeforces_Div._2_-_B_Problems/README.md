# 010. Codeforces_Div._2_-_B_Problems


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Spreadsheet](http://codeforces.com/problemset/problem/1/B)|Codeforces||Codeforces Beta Round #1|1|
|<ul><li>- [ ] Done</li></ul>|2|[Before an Exam](http://codeforces.com/problemset/problem/4/B)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|3|[Borze](http://codeforces.com/problemset/problem/32/B)|Codeforces||Codeforces Beta Round #32 (Div. 2, Codeforces format)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Sale](http://codeforces.com/problemset/problem/34/B)|Codeforces||Codeforces Beta Round #34 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Present from Lena](http://codeforces.com/problemset/problem/118/B)|Codeforces||Codeforces Beta Round #89 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[Drinks](http://codeforces.com/problemset/problem/200/B)|Codeforces||Codeforces Round #126 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Roadside Trees (Simplified Edition)](http://codeforces.com/problemset/problem/265/B)|Codeforces||Codeforces Round #162 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[Queue at the School](http://codeforces.com/problemset/problem/266/B)|Codeforces||Codeforces Round #163 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|10|[Buttons](http://codeforces.com/problemset/problem/268/B)|Codeforces||Codeforces Round #164 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Little Girl and Game](http://codeforces.com/problemset/problem/276/B)|Codeforces||Codeforces Round #169 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|12|[Books](http://codeforces.com/problemset/problem/279/B)|Codeforces||Codeforces Round #171 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|13|[Ilya and Queries](http://codeforces.com/problemset/problem/313/B)|Codeforces||Codeforces Round #186 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|14|[Hungry Sequence](http://codeforces.com/problemset/problem/327/B)|Codeforces||Codeforces Round #191 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|15|[Road Construction](http://codeforces.com/problemset/problem/330/B)|Codeforces||Codeforces Round #192 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|16|[Xenia and Ringroad](http://codeforces.com/problemset/problem/339/B)|Codeforces||Codeforces Round #197 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|17|[Fence](http://codeforces.com/problemset/problem/363/B)|Codeforces||Codeforces Round #211 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|18|[Sereja and Suffixes](http://codeforces.com/problemset/problem/368/B)|Codeforces||Codeforces Round #215 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|19|[Prison Transfer](http://codeforces.com/problemset/problem/427/B)|Codeforces||Codeforces Round #244 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|20|[Kuriyama Mirai's Stones](http://codeforces.com/problemset/problem/433/B)|Codeforces||Codeforces Round #248 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|21|[Devu, the Dumb Guy](http://codeforces.com/problemset/problem/439/B)|Codeforces||Codeforces Round #251 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|22|[DZY Loves Strings](http://codeforces.com/problemset/problem/447/B)|Codeforces||Codeforces Round #255 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|23|[Suffix Structures](http://codeforces.com/problemset/problem/448/B)|Codeforces||Codeforces Round #256 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|24|[Jzzhu and Sequences](http://codeforces.com/problemset/problem/450/B)|Codeforces||Codeforces Round #257 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Sort the Array](http://codeforces.com/problemset/problem/451/B)|Codeforces||Codeforces Round #258 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|26|[Little Pony and Sort by Shift](http://codeforces.com/problemset/problem/454/B)|Codeforces||Codeforces Round #259 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|27|[Fedya and Maths](http://codeforces.com/problemset/problem/456/B)|Codeforces||Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|28|[Pashmak and Flowers](http://codeforces.com/problemset/problem/459/B)|Codeforces||Codeforces Round #261 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|29|[Caisa and Pylons](http://codeforces.com/problemset/problem/463/B)|Codeforces||Codeforces Round #264 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|30|[Inbox (100500)](http://codeforces.com/problemset/problem/465/B)|Codeforces||Codeforces Round #265 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|31|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces||Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|32|[Worms](http://codeforces.com/problemset/problem/474/B)|Codeforces||Codeforces Round #271 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|33|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|34|[Random Teams](http://codeforces.com/problemset/problem/478/B)|Codeforces||Codeforces Round #273 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|35|[OR in Matrix](http://codeforces.com/problemset/problem/486/B)|Codeforces||Codeforces Round #277 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|36|[BerSU Ball](http://codeforces.com/problemset/problem/489/B)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|37|[Vanya and Lanterns](http://codeforces.com/problemset/problem/492/B)|Codeforces||Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|38|[Lecture](http://codeforces.com/problemset/problem/499/B)|Codeforces||Codeforces Round #284 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|39|[Misha and Changing Handles](http://codeforces.com/problemset/problem/501/B)|Codeforces||Codeforces Round #285 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|40|[Amr and Pins](http://codeforces.com/problemset/problem/507/B)|Codeforces||Codeforces Round #287 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|41|[Anton and currency you all know](http://codeforces.com/problemset/problem/508/B)|Codeforces||Codeforces Round #288 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|42|[Han Solo and Lazer Gun](http://codeforces.com/problemset/problem/514/B)|Codeforces||Codeforces Round #291 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|43|[A and B and Compilation Errors](http://codeforces.com/problemset/problem/519/B)|Codeforces||Codeforces Round #294 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|44|[Two Buttons](http://codeforces.com/problemset/problem/520/B)|Codeforces||Codeforces Round #295 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|45|[Tavas and SaDDas](http://codeforces.com/problemset/problem/535/B)|Codeforces||Codeforces Round #299 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|46|[Quasi Binary](http://codeforces.com/problemset/problem/538/B)|Codeforces||Codeforces Round #300|1|
|<ul><li>- [ ] Done</li></ul>|47|[Equidistant String](http://codeforces.com/problemset/problem/545/B)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|48|[Soldier and Badges](http://codeforces.com/problemset/problem/546/B)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|49|[Preparing Olympiad](http://codeforces.com/problemset/problem/550/B)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|50|[Vanya and Books](http://codeforces.com/problemset/problem/552/B)|Codeforces||Codeforces Round #308 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|51|[Berland National Library](http://codeforces.com/problemset/problem/567/B)|Codeforces||Codeforces Round #Pi (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|52|[Simple Game](http://codeforces.com/problemset/problem/570/B)|Codeforces||Codeforces Round #316 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|53|[Kefa and Company](http://codeforces.com/problemset/problem/580/B)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|54|[Luxurious Houses](http://codeforces.com/problemset/problem/581/B)|Codeforces||Codeforces Round #322 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|55|[Robot's Task](http://codeforces.com/problemset/problem/583/B)|Codeforces||Codeforces Round #323 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|56|[Duff in Love](http://codeforces.com/problemset/problem/588/B)|Codeforces||Codeforces Round #326 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|57|[The Monster and the Squirrel](http://codeforces.com/problemset/problem/592/B)|Codeforces||Codeforces Round #328 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|58|[Wilbur and Array](http://codeforces.com/problemset/problem/596/B)|Codeforces||Codeforces Round #331 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|59|[Chocolate](http://codeforces.com/problemset/problem/617/B)|Codeforces||Codeforces Round #340 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|60|[Wet Shark and Bishops](http://codeforces.com/problemset/problem/621/B)|Codeforces||Codeforces Round #341 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|61|[Beautiful Paintings](http://codeforces.com/problemset/problem/651/B)|Codeforces||Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|62|[Game of Robots](http://codeforces.com/problemset/problem/670/B)|Codeforces||Codeforces Round #350 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|63|[Different is Good](http://codeforces.com/problemset/problem/672/B)|Codeforces||Codeforces Round #352 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|64|[Bear and Finding Criminals](http://codeforces.com/problemset/problem/680/B)|Codeforces||Codeforces Round #356 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|65|[Alyona and Mex](http://codeforces.com/problemset/problem/682/B)|Codeforces||Codeforces Round #358 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|66|[Lovely Palindromes](http://codeforces.com/problemset/problem/688/B)|Codeforces||Codeforces Round #360 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|67|[Cells Not Under Attack](http://codeforces.com/problemset/problem/701/B)|Codeforces||Codeforces Round #364 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|68|[Spider Man](http://codeforces.com/problemset/problem/705/B)|Codeforces||Codeforces Round #366 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|69|[Interesting drink](http://codeforces.com/problemset/problem/706/B)|Codeforces||Codeforces Round #367 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|70|[Bakery](http://codeforces.com/problemset/problem/707/B)|Codeforces||Codeforces Round #368 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|71|[Chris and Magic Square](http://codeforces.com/problemset/problem/711/B)|Codeforces||Codeforces Round #369 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|72|[Memory and Trident](http://codeforces.com/problemset/problem/712/B)|Codeforces||Codeforces Round #370 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|73|[Filya and Homework](http://codeforces.com/problemset/problem/714/B)|Codeforces||Codeforces Round #371 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|74|[Complete the Word](http://codeforces.com/problemset/problem/716/B)|Codeforces||Codeforces Round #372 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|75|[Passwords](http://codeforces.com/problemset/problem/721/B)|Codeforces||Codeforces Round #374 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|76|[Text Document Analysis](http://codeforces.com/problemset/problem/723/B)|Codeforces||Codeforces Round #375 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|77|[Arrival of the General](http://codeforces.com/problemset/problem/144/A)|Codeforces||Codeforces Round #103 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|78|[Cormen --- The Best Friend Of a Man](http://codeforces.com/problemset/problem/732/B)|Codeforces||Codeforces Round #377 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|79|[Parade](http://codeforces.com/problemset/problem/733/B)|Codeforces||Codeforces Round #378 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|80|[Anton and Digits](http://codeforces.com/problemset/problem/734/B)|Codeforces||Codeforces Round #379 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|81|[Soldier and Bananas](http://codeforces.com/problemset/problem/546/A)|Codeforces||Codeforces Round #304 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|82|[Decoding](http://codeforces.com/problemset/problem/746/B)|Codeforces||Codeforces Round #386 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|83|[Chloe and the sequence ](http://codeforces.com/problemset/problem/743/B)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|84|[Blown Garland](http://codeforces.com/problemset/problem/758/B)|Codeforces||Codeforces Round #392 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|85|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces||Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|86|[Mahmoud and a Triangle](http://codeforces.com/problemset/problem/766/B)|Codeforces||Codeforces Round #396 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|87|[Timofey and cubes](http://codeforces.com/problemset/problem/764/B)|Codeforces||Codeforces Round #395 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|88|[Sherlock and his girlfriend](http://codeforces.com/problemset/problem/776/B)|Codeforces||ICM Technex 2017 and Codeforces Round #400 (Div. 1 + Div. 2, combined)|1|
|<ul><li>- [ ] Done</li></ul>|89|[Weird Rounding](http://codeforces.com/problemset/problem/779/B)|Codeforces||Codeforces Round #402 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|90|[Anton and Classes](http://codeforces.com/problemset/problem/785/B)|Codeforces||Codeforces Round #404 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|91|[3-palindrome](http://codeforces.com/problemset/problem/805/B)|Codeforces||Codeforces Round #411 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|92|[Bear and Elections](http://codeforces.com/problemset/problem/574/A)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|93|[Godsend](http://codeforces.com/problemset/problem/841/B)|Codeforces||Codeforces Round #429 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|94|[The number on the board](http://codeforces.com/problemset/problem/835/B)|Codeforces||Codeforces Round #427 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|95|[Keyboard Layouts](http://codeforces.com/problemset/problem/831/B)|Codeforces||Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|1|
|<ul><li>- [ ] Done</li></ul>|96|[Crossword solving](http://codeforces.com/problemset/problem/822/B)|Codeforces||Codeforces Round #422 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|97|[The Eternal Immortality](http://codeforces.com/problemset/problem/869/B)|Codeforces||Codeforces Round #439 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|98|[Hamster Farm](http://codeforces.com/problemset/problem/939/B)|Codeforces||Codeforces Round #464 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|99|[Towers](http://codeforces.com/problemset/problem/37/A)|Codeforces||Codeforces Beta Round #37|1|
|<ul><li>- [ ] Done</li></ul>|100|[Registration System](http://codeforces.com/problemset/problem/4/C)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|101|[Jzzhu and Children](http://codeforces.com/problemset/problem/450/A)|Codeforces||Codeforces Round #257 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|102|[Cards](http://codeforces.com/problemset/problem/701/A)|Codeforces||Codeforces Round #364 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|103|[Coins](http://codeforces.com/problemset/problem/58/B)|Codeforces||Codeforces Beta Round #54 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|104|[Petya and Countryside](http://codeforces.com/problemset/problem/66/B)|Codeforces||Codeforces Beta Round #61 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|105|[Lucky Numbers (easy)](http://codeforces.com/problemset/problem/96/B)|Codeforces||Codeforces Beta Round #77 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|106|[Sum of Digits](http://codeforces.com/problemset/problem/102/B)|Codeforces||Codeforces Beta Round #79 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|107|[Little Pigs and Wolves](http://codeforces.com/problemset/problem/116/B)|Codeforces||Codeforces Beta Round #87 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|108|[Lucky Substring](http://codeforces.com/problemset/problem/122/B)|Codeforces||Codeforces Beta Round #91 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|109|[Opposites Attract](http://codeforces.com/problemset/problem/131/B)|Codeforces||Codeforces Beta Round #95 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|110|[Permutation](http://codeforces.com/problemset/problem/137/B)|Codeforces||Codeforces Beta Round #98 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|111|[Combination](http://codeforces.com/problemset/problem/155/B)|Codeforces||Codeforces Round #109 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|112|[Trace](http://codeforces.com/problemset/problem/157/B)|Codeforces||Codeforces Round #110 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|113|[Unlucky Ticket](http://codeforces.com/problemset/problem/160/B)|Codeforces||Codeforces Round #111 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|114|[Burning Midnight Oil](http://codeforces.com/problemset/problem/165/B)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|115|[Airport](http://codeforces.com/problemset/problem/218/B)|Codeforces||Codeforces Round #134 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|116|[Effective Approach](http://codeforces.com/problemset/problem/227/B)|Codeforces||Codeforces Round #140 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|117|[Big Segment](http://codeforces.com/problemset/problem/242/B)|Codeforces||Codeforces Round #149 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|118|[Increase and Decrease](http://codeforces.com/problemset/problem/246/B)|Codeforces||Codeforces Round #151 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|119|[Little Elephant and Magic Square](http://codeforces.com/problemset/problem/259/B)|Codeforces||Codeforces Round #157 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|120|[Squares](http://codeforces.com/problemset/problem/263/B)|Codeforces||Codeforces Round #161 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|121|[Prime Matrix](http://codeforces.com/problemset/problem/271/B)|Codeforces||Codeforces Round #166 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|122|[Painting Eggs](http://codeforces.com/problemset/problem/282/B)|Codeforces||Codeforces Round #173 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|123|[Find Marble](http://codeforces.com/problemset/problem/285/B)|Codeforces||Codeforces Round #175 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|124|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces||Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|125|[Sail](http://codeforces.com/problemset/problem/298/B)|Codeforces||Codeforces Round #180 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|126|[Archer](http://codeforces.com/problemset/problem/312/B)|Codeforces||Codeforces Round #185 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|127|[Strings of Power](http://codeforces.com/problemset/problem/318/B)|Codeforces||Codeforces Round #188 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|128|[Ciel and Flowers](http://codeforces.com/problemset/problem/322/B)|Codeforces||Codeforces Round #190 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|129|[Simple Molecules](http://codeforces.com/problemset/problem/344/B)|Codeforces||Codeforces Round #200 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|130|[Fixed Points](http://codeforces.com/problemset/problem/347/B)|Codeforces||Codeforces Round #201 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|131|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces||Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|132|[Jeff and Periods](http://codeforces.com/problemset/problem/352/B)|Codeforces||Codeforces Round #204 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|133|[Petya and Staircases](http://codeforces.com/problemset/problem/362/B)|Codeforces||Codeforces Round #212 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|134|[The Fibonacci Segment](http://codeforces.com/problemset/problem/365/B)|Codeforces||Codeforces Round #213 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|135|[Bear and Strings](http://codeforces.com/problemset/problem/385/B)|Codeforces||Codeforces Round #226 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|136|[George and Round](http://codeforces.com/problemset/problem/387/B)|Codeforces||Codeforces Round #227 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|137|[Fox and Cross](http://codeforces.com/problemset/problem/389/B)|Codeforces||Codeforces Round #228 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|138|[Football Kit](http://codeforces.com/problemset/problem/432/B)|Codeforces||Codeforces Round #246 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|139|[Shower Line](http://codeforces.com/problemset/problem/431/B)|Codeforces||Codeforces Round #247 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|140|[DZY Loves Chemistry](http://codeforces.com/problemset/problem/445/B)|Codeforces||Codeforces Round #254 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|141|[Little Dima and Equation](http://codeforces.com/problemset/problem/460/B)|Codeforces||Codeforces Round #262 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|142|[Appleman and Card Game](http://codeforces.com/problemset/problem/462/B)|Codeforces||Codeforces Round #263 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|143|[Chat Online](http://codeforces.com/problemset/problem/469/B)|Codeforces||Codeforces Round #268 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|144|[MUH and Important Things](http://codeforces.com/problemset/problem/471/B)|Codeforces||Codeforces Round #269 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|145|[Design Tutorial: Learn from Life](http://codeforces.com/problemset/problem/472/B)|Codeforces||Codeforces Round #270|2|
|<ul><li>- [ ] Done</li></ul>|146|[Towers](http://codeforces.com/problemset/problem/479/B)|Codeforces||Codeforces Round #274 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|147|[Valuable Resources](http://codeforces.com/problemset/problem/485/B)|Codeforces||Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|148|[Vasya and Wrestling](http://codeforces.com/problemset/problem/493/B)|Codeforces||Codeforces Round #281 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|149|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|150|[Painting Pebbles](http://codeforces.com/problemset/problem/509/B)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|2|
|<ul><li>- [ ] Done</li></ul>|151|[Fox And Two Dots](http://codeforces.com/problemset/problem/510/B)|Codeforces||Codeforces Round #290 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|152|[Drazil and His Happy Friends](http://codeforces.com/problemset/problem/515/B)|Codeforces||Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1) & Codeforces Round #292 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|153|[Tanya and Postcard](http://codeforces.com/problemset/problem/518/B)|Codeforces||Codeforces Round #293 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|154|[Pasha and String](http://codeforces.com/problemset/problem/525/B)|Codeforces||Codeforces Round #297 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|155|[Covered Path](http://codeforces.com/problemset/problem/534/B)|Codeforces||Codeforces Round #298 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|156|[Sea and Islands](http://codeforces.com/problemset/problem/544/B)|Codeforces||Codeforces Round #302 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|157|[Mike and Fun](http://codeforces.com/problemset/problem/548/B)|Codeforces||Codeforces Round #305 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|158|[Ohana Cleans Up](http://codeforces.com/problemset/problem/554/B)|Codeforces||Codeforces Round #309 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|159|[Case of Fake Numbers](http://codeforces.com/problemset/problem/556/B)|Codeforces||Codeforces Round #310 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|160|[Pasha and Tea](http://codeforces.com/problemset/problem/557/B)|Codeforces||Codeforces Round #311 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|161|[Amr and The Large Array](http://codeforces.com/problemset/problem/558/B)|Codeforces||Codeforces Round #312 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|162|[Gerald is into Art](http://codeforces.com/problemset/problem/560/B)|Codeforces||Codeforces Round #313 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|163|[Inventory](http://codeforces.com/problemset/problem/569/B)|Codeforces||Codeforces Round #315 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|164|[Bear and Three Musketeers](http://codeforces.com/problemset/problem/574/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|165|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces||Codeforces Round #319 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|166|[Kolya and Tanya ](http://codeforces.com/problemset/problem/584/B)|Codeforces||Codeforces Round #324 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|167|[Laurenty and Shop](http://codeforces.com/problemset/problem/586/B)|Codeforces||Codeforces Round #325 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|168|[Rebranding](http://codeforces.com/problemset/problem/591/B)|Codeforces||Codeforces Round #327 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|169|[Approximating a Constant Range](http://codeforces.com/problemset/problem/602/B)|Codeforces||Codeforces Round #333 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|170|[More Cowbell](http://codeforces.com/problemset/problem/604/B)|Codeforces||Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|171|[Vika and Squares](http://codeforces.com/problemset/problem/610/B)|Codeforces||Codeforces Round #337 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|172|[Gena's Code](http://codeforces.com/problemset/problem/614/B)|Codeforces||Codeforces Round #339 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|173|[War of the Corporations](http://codeforces.com/problemset/problem/625/B)|Codeforces||Codeforces Round #342 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|174|[Far Relative’s Problem](http://codeforces.com/problemset/problem/629/B)|Codeforces||Codeforces Round #343 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|175|[Print Check](http://codeforces.com/problemset/problem/631/B)|Codeforces||Codeforces Round #344 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|176|[Qualifying Contest](http://codeforces.com/problemset/problem/659/B)|Codeforces||Codeforces Round #346 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|177|[Little Artem and Grasshopper](http://codeforces.com/problemset/problem/641/A)|Codeforces||VK Cup 2016 - Round 2|2|
|<ul><li>- [ ] Done</li></ul>|178|[Restoring Painting](http://codeforces.com/problemset/problem/675/B)|Codeforces||Codeforces Round #353 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|179|[Vanya and Food Processor](http://codeforces.com/problemset/problem/677/B)|Codeforces||Codeforces Round #355 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|180|[Economy Game](http://codeforces.com/problemset/problem/681/B)|Codeforces||Codeforces Round #357 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|181|[Little Robber Girl's Zoo](http://codeforces.com/problemset/problem/686/B)|Codeforces||Codeforces Round #359 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|182|[Barnicle](http://codeforces.com/problemset/problem/697/B)|Codeforces||Codeforces Round #362 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|183|[One Bomb](http://codeforces.com/problemset/problem/699/B)|Codeforces||Codeforces Round #363 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|184|[Mishka and trip](http://codeforces.com/problemset/problem/703/B)|Codeforces||Codeforces Round #365 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|185|[Anatoly and Cockroaches](http://codeforces.com/problemset/problem/719/B)|Codeforces||Codeforces Round #373 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|186|[Coupons and Discounts](http://codeforces.com/problemset/problem/731/B)|Codeforces||Codeforces Round #376 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|187|[Divisibility](http://codeforces.com/problemset/problem/630/J)|Codeforces||Experimental Educational Round: VolBIT Formulas Blitz|2|
|<ul><li>- [ ] Done</li></ul>|188|[Alyona and flowers](http://codeforces.com/problemset/problem/740/B)|Codeforces||Codeforces Round #381 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|189|[Urbanization](http://codeforces.com/problemset/problem/735/B)|Codeforces||Codeforces Round #382 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|190|[Arpa’s obvious problem and Mehrdad’s terrible solution](http://codeforces.com/problemset/problem/742/B)|Codeforces||Codeforces Round #383 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|191|[Parallelogram is Back](http://codeforces.com/problemset/problem/749/B)|Codeforces||Codeforces Round #388 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|192|[Mammoth's Genome Decoding](http://codeforces.com/problemset/problem/747/B)|Codeforces||Codeforces Round #387 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|193|[Bash's Big Day](http://codeforces.com/problemset/problem/757/B)|Codeforces||Codecraft-17 and Codeforces Round #391 (Div. 1 + Div. 2, combined)|2|
|<ul><li>- [ ] Done</li></ul>|194|[Ilya and tic-tac-toe game](http://codeforces.com/problemset/problem/754/B)|Codeforces||Codeforces Round #390 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|195|[Dasha and friends](http://codeforces.com/problemset/problem/761/B)|Codeforces||Codeforces Round #394 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|196|[Code obfuscation](http://codeforces.com/problemset/problem/765/B)|Codeforces||Codeforces Round #397 by Kaspersky Lab and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|2|
|<ul><li>- [ ] Done</li></ul>|197|[Game of Credit Cards](http://codeforces.com/problemset/problem/777/B)|Codeforces||Codeforces Round #401 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|198|[Bear and Friendship Condition](http://codeforces.com/problemset/problem/771/A)|Codeforces||VK Cup 2017 - Round 1|2|
|<ul><li>- [ ] Done</li></ul>|199|[Not Afraid](http://codeforces.com/problemset/problem/787/B)|Codeforces||Codeforces Round #406 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|200|[Find The Bone](http://codeforces.com/problemset/problem/796/B)|Codeforces||Codeforces Round #408 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|201|[Vladik and Complicated Book](http://codeforces.com/problemset/problem/811/B)|Codeforces||Codeforces Round #416 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|202|[Summer sell-off](http://codeforces.com/problemset/problem/810/B)|Codeforces||Codeforces Round #415 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|203|[Mike and strings](http://codeforces.com/problemset/problem/798/B)|Codeforces||Codeforces Round #410 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|204|[Valued Keys](http://codeforces.com/problemset/problem/801/B)|Codeforces||Codeforces Round #409 (rated, Div. 2, based on VK Cup 2017 Round 2)|2|
|<ul><li>- [ ] Done</li></ul>|205|[Karen and Coffee](http://codeforces.com/problemset/problem/816/B)|Codeforces||Codeforces Round #419 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|206|[The Festive Evening](http://codeforces.com/problemset/problem/834/B)|Codeforces||Codeforces Round #426 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|207|[Okabe and Banana Trees](http://codeforces.com/problemset/problem/821/B)|Codeforces||Codeforces Round #420 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|208|[An express train to reveries](http://codeforces.com/problemset/problem/814/B)|Codeforces||Codeforces Round #418 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|209|[Polycarp and Letters](http://codeforces.com/problemset/problem/864/B)|Codeforces||Codeforces Round #436 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|210|[Divisiblity of Differences](http://codeforces.com/problemset/problem/876/B)|Codeforces||Codeforces Round #441 (Div. 2, by Moscow Team Olympiad)|2|
|<ul><li>- [ ] Done</li></ul>|211|[Maximum of Maximums of Minimums](http://codeforces.com/problemset/problem/870/B)|Codeforces||Technocup 2018 - Elimination Round 2|2|
|<ul><li>- [ ] Done</li></ul>|212|[Beautiful Divisors](http://codeforces.com/problemset/problem/893/B)|Codeforces||Educational Codeforces Round 33 (Rated for Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|213|[Proper Nutrition](http://codeforces.com/problemset/problem/898/B)|Codeforces||Codeforces Round #451 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|214|[Magic Forest](http://codeforces.com/problemset/problem/922/B)|Codeforces||Codeforces Round #461 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|215|[Repeated Substitution with Sed](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2638)|Live Archive|2009|Asia - Tokyo|2|
|<ul><li>- [ ] Done</li></ul>|216|[The least round way](http://codeforces.com/problemset/problem/2/B)|Codeforces||Codeforces Beta Round #2|3|
|<ul><li>- [ ] Done</li></ul>|217|[President's Office](http://codeforces.com/problemset/problem/6/B)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|218|[Correct Solution?](http://codeforces.com/problemset/problem/12/B)|Codeforces||Codeforces Beta Round #12 (Div 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|219|[Burglar and Matches](http://codeforces.com/problemset/problem/16/B)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|220|[Phone numbers](http://codeforces.com/problemset/problem/25/B)|Codeforces||Codeforces Beta Round #25 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|221|[Regular Bracket Sequence](http://codeforces.com/problemset/problem/26/B)|Codeforces||Codeforces Beta Round #26 (Codeforces format)|3|
|<ul><li>- [ ] Done</li></ul>|222|[Letter](http://codeforces.com/problemset/problem/43/B)|Codeforces||Codeforces Beta Round #42 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|223|[Easter Eggs](http://codeforces.com/problemset/problem/78/B)|Codeforces||Codeforces Beta Round #70 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|224|[Testing Pants for Sadness](http://codeforces.com/problemset/problem/103/A)|Codeforces||Codeforces Beta Round #80 (Div. 1 Only) & Codeforces Beta Round #80 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|225|[Lucky String](http://codeforces.com/problemset/problem/110/B)|Codeforces||Codeforces Beta Round #84 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|226|[Canvas Frames](http://codeforces.com/problemset/problem/127/B)|Codeforces||Codeforces Beta Round #93 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|227|[Students and Shoelaces](http://codeforces.com/problemset/problem/129/B)|Codeforces||Codeforces Beta Round #94 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|228|[Unary](http://codeforces.com/problemset/problem/133/B)|Codeforces||Codeforces Beta Round #96 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|229|[Ternary Logic](http://codeforces.com/problemset/problem/136/B)|Codeforces||Codeforces Beta Round #97 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|230|[Phone Numbers](http://codeforces.com/problemset/problem/151/B)|Codeforces||Codeforces Round #107 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|231|[Vasya's Calendar](http://codeforces.com/problemset/problem/182/B)|Codeforces||Codeforces Round #117 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|232|[Little Elephant and Numbers](http://codeforces.com/problemset/problem/221/B)|Codeforces||Codeforces Round #136 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|233|[Cosmic Tables](http://codeforces.com/problemset/problem/222/B)|Codeforces||Codeforces Round #137 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|234|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces||Codeforces Round #138 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|235|[Non-square Equation](http://codeforces.com/problemset/problem/233/B)|Codeforces||Codeforces Round #144 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|236|[Reading](http://codeforces.com/problemset/problem/234/B)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|3|
|<ul><li>- [ ] Done</li></ul>|237|[Easy Number Challenge](http://codeforces.com/problemset/problem/236/B)|Codeforces||Codeforces Round #146 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|238|[Physics Practical](http://codeforces.com/problemset/problem/253/B)|Codeforces||Codeforces Round #154 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|239|[Code Parsing](http://codeforces.com/problemset/problem/255/B)|Codeforces||Codeforces Round #156 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|240|[Playing Cubes](http://codeforces.com/problemset/problem/257/B)|Codeforces||Codeforces Round #159 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|241|[Roma and Changing Signs](http://codeforces.com/problemset/problem/262/B)|Codeforces||Codeforces Round #160 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|242|[Multithreading](http://codeforces.com/problemset/problem/270/B)|Codeforces||Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|243|[Cows and Poker Game](http://codeforces.com/problemset/problem/284/B)|Codeforces||Codeforces Round #174 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|244|[Coach](http://codeforces.com/problemset/problem/300/B)|Codeforces||Codeforces Round #181 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|245|[Eugeny and Play List](http://codeforces.com/problemset/problem/302/B)|Codeforces||Codeforces Round #182 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|246|[Sereja and Array](http://codeforces.com/problemset/problem/315/B)|Codeforces||Codeforces Round #187 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|247|[Ping-Pong (Easy Version)](http://codeforces.com/problemset/problem/320/B)|Codeforces||Codeforces Round #189 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|248|[Maximum Absurdity](http://codeforces.com/problemset/problem/332/B)|Codeforces||Codeforces Round #193 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|249|[Routine Problem](http://codeforces.com/problemset/problem/337/B)|Codeforces||Codeforces Round #196 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|250|[Vasya and Public Transport](http://codeforces.com/problemset/problem/355/B)|Codeforces||Codeforces Round #206 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|251|[Flag Day](http://codeforces.com/problemset/problem/357/B)|Codeforces||Codeforces Round #207 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|252|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces||Codeforces Round #209 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|253|[Levko and Permutation](http://codeforces.com/problemset/problem/361/B)|Codeforces||Codeforces Round #210 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|254|[Dima and To-do List](http://codeforces.com/problemset/problem/366/B)|Codeforces||Codeforces Round #214 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|255|[Valera and Contest](http://codeforces.com/problemset/problem/369/B)|Codeforces||Codeforces Round #216 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|256|[Fox Dividing Cheese](http://codeforces.com/problemset/problem/371/B)|Codeforces||Codeforces Round #218 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|257|[Sereja and Stairs](http://codeforces.com/problemset/problem/381/B)|Codeforces||Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|258|[Inna and New Matrix of Candies](http://codeforces.com/problemset/problem/400/B)|Codeforces||Codeforces Round #234 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|259|[Sereja and Contests](http://codeforces.com/problemset/problem/401/B)|Codeforces||Codeforces Round #235 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|260|[Domino Effect](http://codeforces.com/problemset/problem/405/B)|Codeforces||Codeforces Round #238 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|261|[Garland](http://codeforces.com/problemset/problem/408/B)|Codeforces||Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|262|[Mashmokh and Tokens](http://codeforces.com/problemset/problem/415/B)|Codeforces||Codeforces Round #240 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|263|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|264|[Megacity](http://codeforces.com/problemset/problem/424/B)|Codeforces||Codeforces Round #242 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|265|[Pasha Maximizes](http://codeforces.com/problemset/problem/435/B)|Codeforces||Codeforces Round #249 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|266|[The Child and Set](http://codeforces.com/problemset/problem/437/B)|Codeforces||Codeforces Round #250 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|267|[Valera and Fruits](http://codeforces.com/problemset/problem/441/B)|Codeforces||Codeforces Round #252 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|268|[Queue](http://codeforces.com/problemset/problem/490/B)|Codeforces||Codeforces Round #279 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|269|[Modular Equations](http://codeforces.com/problemset/problem/495/B)|Codeforces||Codeforces Round #282 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|270|[Secret Combination](http://codeforces.com/problemset/problem/496/B)|Codeforces||Codeforces Round #283 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|271|[Error Correct System](http://codeforces.com/problemset/problem/527/B)|Codeforces||Codeforces Round #296 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|272|[School Marks](http://codeforces.com/problemset/problem/540/B)|Codeforces||Codeforces Round #301 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|273|[Order Book](http://codeforces.com/problemset/problem/572/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|274|[Finding Team Member](http://codeforces.com/problemset/problem/579/B)|Codeforces||Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|3|
|<ul><li>- [ ] Done</li></ul>|275|[Anton and Lines](http://codeforces.com/problemset/problem/593/B)|Codeforces||Codeforces Round #329 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|276|[Spongebob and Joke](http://codeforces.com/problemset/problem/599/B)|Codeforces||Codeforces Round #332 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|277|[Hamming Distance Sum](http://codeforces.com/problemset/problem/608/B)|Codeforces||Codeforces Round #336 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|278|[Longtail Hedgehog](http://codeforces.com/problemset/problem/615/B)|Codeforces||Codeforces Round #338 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|279|[Coat of Anticubism](http://codeforces.com/problemset/problem/667/B)|Codeforces||Codeforces Round #349 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|280|[Pyramid of Glasses](http://codeforces.com/problemset/problem/676/B)|Codeforces||Codeforces Round #354 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|281|[Mike and Shortcuts](http://codeforces.com/problemset/problem/689/B)|Codeforces||Codeforces Round #361 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|282|[Spotlights](http://codeforces.com/problemset/problem/729/B)|Codeforces||Technocup 2017 - Elimination Round 2|3|
|<ul><li>- [ ] Done</li></ul>|283|[Hongcow Solves A Puzzle](http://codeforces.com/problemset/problem/745/B)|Codeforces||Codeforces Round #385 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|284|[Santa Claus and Keyboard Check](http://codeforces.com/problemset/problem/748/B)|Codeforces||Technocup 2017 - Elimination Round 3|3|
|<ul><li>- [ ] Done</li></ul>|285|[Frodo and pillows](http://codeforces.com/problemset/problem/760/B)|Codeforces||Codeforces Round #393 (Div. 2) (8VC Venture Cup 2017 - Final Round Div. 2 Edition)|3|
|<ul><li>- [ ] Done</li></ul>|286|[Code For 1](http://codeforces.com/problemset/problem/768/B)|Codeforces||Divide by Zero 2017 and Codeforces Round #399 (Div. 1 + Div. 2, combined)|3|
|<ul><li>- [ ] Done</li></ul>|287|[The Meeting Place Cannot Be Changed](http://codeforces.com/problemset/problem/780/B)|Codeforces||?????????? 2017 - ????? (?????? ??? ??????-??????????)|3|
|<ul><li>- [ ] Done</li></ul>|288|[Masha and geometric depression](http://codeforces.com/problemset/problem/789/B)|Codeforces||Codeforces Round #407 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|289|[Sagheer, the Hausmeister](http://codeforces.com/problemset/problem/812/B)|Codeforces||Codeforces Round #417 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|290|[Cutting Carrot](http://codeforces.com/problemset/problem/794/B)|Codeforces||Tinkoff Challenge - Final Round (Codeforces Round #414, rated, Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|291|[T-shirt buying](http://codeforces.com/problemset/problem/799/B)|Codeforces||Playrix Codescapes Cup (Codeforces Round #413, rated, Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|292|[T-Shirt Hunt](http://codeforces.com/problemset/problem/807/B)|Codeforces||Codeforces Round #412 (rated, Div. 2, base on VK Cup 2017 Round 3)|3|
|<ul><li>- [ ] Done</li></ul>|293|[Petya and Exam](http://codeforces.com/problemset/problem/832/B)|Codeforces||Codeforces Round #425 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|294|[Luba And The Ticket](http://codeforces.com/problemset/problem/845/B)|Codeforces||Educational Codeforces Round 27|3|
|<ul><li>- [ ] Done</li></ul>|295|[Black Square](http://codeforces.com/problemset/problem/828/B)|Codeforces||Codeforces Round #423 (Div. 2, rated, based on VK Cup Finals)|3|
|<ul><li>- [ ] Done</li></ul>|296|[Mister B and Angle in Polygon](http://codeforces.com/problemset/problem/820/B)|Codeforces||Codeforces Round #421 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|297|[Balanced Substring](http://codeforces.com/problemset/problem/873/B)|Codeforces||Educational Codeforces Round 30|3|
|<ul><li>- [ ] Done</li></ul>|298|[Lorry](http://codeforces.com/problemset/problem/3/B)|Codeforces||Codeforces Beta Round #3|4|
|<ul><li>- [ ] Done</li></ul>|299|[Center Alignment](http://codeforces.com/problemset/problem/5/B)|Codeforces||Codeforces Beta Round #5|4|
|<ul><li>- [ ] Done</li></ul>|300|[Running Student](http://codeforces.com/problemset/problem/9/B)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|301|[Young Photographer](http://codeforces.com/problemset/problem/14/B)|Codeforces||Codeforces Beta Round #14 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|302|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|303|[Coins](http://codeforces.com/problemset/problem/47/B)|Codeforces||Codeforces Beta Round #44 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|304|[Choosing Symbol Pairs](http://codeforces.com/problemset/problem/50/B)|Codeforces||Codeforces Beta Round #47|4|
|<ul><li>- [ ] Done</li></ul>|305|[Fortune Telling](http://codeforces.com/problemset/problem/59/B)|Codeforces||Codeforces Beta Round #55 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|306|[Serial Time!](http://codeforces.com/problemset/problem/60/B)|Codeforces||Codeforces Beta Round #56|4|
|<ul><li>- [ ] Done</li></ul>|307|[Hard Work](http://codeforces.com/problemset/problem/61/B)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|308|[Settlers' Training](http://codeforces.com/problemset/problem/63/B)|Codeforces||Codeforces Beta Round #59 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|309|[Progress Bar](http://codeforces.com/problemset/problem/71/B)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|310|[Depression](http://codeforces.com/problemset/problem/80/B)|Codeforces||Codeforces Beta Round #69 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|311|[Magical Array](http://codeforces.com/problemset/problem/83/A)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only) & Codeforces Beta Round #72 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|312|[African Crossword](http://codeforces.com/problemset/problem/90/B)|Codeforces||Codeforces Beta Round #74 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|313|[Binary Number](http://codeforces.com/problemset/problem/92/B)|Codeforces||Codeforces Beta Round #75 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|314|[Choosing Laptop](http://codeforces.com/problemset/problem/106/B)|Codeforces||Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|315|[Petya and Square](http://codeforces.com/problemset/problem/112/B)|Codeforces||Codeforces Beta Round #85 (Div. 2 Only)|4|
|<ul><li>- [ ] Done</li></ul>|316|[Hopscotch](http://codeforces.com/problemset/problem/141/B)|Codeforces||Codeforces Round #101 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|317|[Help Kingdom of Far Far Away 2](http://codeforces.com/problemset/problem/143/B)|Codeforces||Codeforces Round #102 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|318|[Meeting](http://codeforces.com/problemset/problem/144/B)|Codeforces||Codeforces Round #103 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|319|[Lucky Mask](http://codeforces.com/problemset/problem/146/B)|Codeforces||Codeforces Round #104 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|320|[Escape](http://codeforces.com/problemset/problem/148/B)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|321|[Steps](http://codeforces.com/problemset/problem/152/B)|Codeforces||Codeforces Round #108 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|322|[Growing Mushrooms](http://codeforces.com/problemset/problem/186/B)|Codeforces||Codeforces Round #118 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|323|[Counting Rhombi](http://codeforces.com/problemset/problem/189/B)|Codeforces||Codeforces Round #119 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|324|[Walking in the Rain](http://codeforces.com/problemset/problem/192/B)|Codeforces||Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|325|[Square](http://codeforces.com/problemset/problem/194/B)|Codeforces||Codeforces Round #122 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|326|[After Training](http://codeforces.com/problemset/problem/195/B)|Codeforces||Codeforces Round #123 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|327|[Limit](http://codeforces.com/problemset/problem/197/B)|Codeforces||Codeforces Round #124 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|328|[Little Elephant and Sorting](http://codeforces.com/problemset/problem/205/B)|Codeforces||Codeforces Round #129 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|329|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces||Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|330|[Olympic Medal](http://codeforces.com/problemset/problem/215/B)|Codeforces||Codeforces Round #132 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|331|[Forming Teams](http://codeforces.com/problemset/problem/216/B)|Codeforces||Codeforces Round #133 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|332|[Special Offer! Super Price 999 Bourles!](http://codeforces.com/problemset/problem/219/B)|Codeforces||Codeforces Round #135 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|333|[Well-known Numbers](http://codeforces.com/problemset/problem/225/B)|Codeforces||Codeforces Round #139 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|334|[Two Tables](http://codeforces.com/problemset/problem/228/B)|Codeforces||Codeforces Round #141 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|335|[Magic, Wizardry and Wonders](http://codeforces.com/problemset/problem/231/B)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|336|[Undoubtedly Lucky Numbers](http://codeforces.com/problemset/problem/244/B)|Codeforces||Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|337|[Chilly Willy](http://codeforces.com/problemset/problem/248/B)|Codeforces||Codeforces Round #152 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|338|[Ancient Prophesy](http://codeforces.com/problemset/problem/260/B)|Codeforces||Codeforces Round #158 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|339|[Dima and Sequence](http://codeforces.com/problemset/problem/272/B)|Codeforces||Codeforces Round #167 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|340|[New Problem](http://codeforces.com/problemset/problem/278/B)|Codeforces||Codeforces Round #170 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|341|[Pipeline](http://codeforces.com/problemset/problem/287/B)|Codeforces||Codeforces Round #176 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|342|[Shaass and Bookshelf](http://codeforces.com/problemset/problem/294/B)|Codeforces||Codeforces Round #178 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|343|[Eight Point Sets](http://codeforces.com/problemset/problem/334/B)|Codeforces||Codeforces Round #194 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|344|[Xenia and Spies](http://codeforces.com/problemset/problem/342/B)|Codeforces||Codeforces Round #199 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|345|[Resort](http://codeforces.com/problemset/problem/350/B)|Codeforces||Codeforces Round #203 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|346|[Dima and Text Messages](http://codeforces.com/problemset/problem/358/B)|Codeforces||Codeforces Round #208 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|347|[Inna and Nine](http://codeforces.com/problemset/problem/374/B)|Codeforces||Codeforces Round #220 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|348|[I.O.U.](http://codeforces.com/problemset/problem/376/B)|Codeforces||Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|349|[Semifinals](http://codeforces.com/problemset/problem/378/B)|Codeforces||Codeforces Round #222 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|350|[Multitasking](http://codeforces.com/problemset/problem/384/B)|Codeforces||Codeforces Round #225 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|351|[Trees in a Row](http://codeforces.com/problemset/problem/402/B)|Codeforces||Codeforces Round #236 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|352|[Marathon](http://codeforces.com/problemset/problem/404/B)|Codeforces||Codeforces Round #237 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|353|[Sereja and Mirroring](http://codeforces.com/problemset/problem/426/B)|Codeforces||Codeforces Round #243 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|354|[Balls Game](http://codeforces.com/problemset/problem/430/B)|Codeforces||Codeforces Round #245 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|355|[Kolya and Tandem Repeat](http://codeforces.com/problemset/problem/443/B)|Codeforces||Codeforces Round #253 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|356|[Wonder Room](http://codeforces.com/problemset/problem/466/B)|Codeforces||Codeforces Round #266 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|357|[Friends and Presents](http://codeforces.com/problemset/problem/483/B)|Codeforces||Codeforces Round #275 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|358|[ZgukistringZ](http://codeforces.com/problemset/problem/551/B)|Codeforces||Codeforces Round #307 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|359|[Pasha and Phone](http://codeforces.com/problemset/problem/595/B)|Codeforces||Codeforces Round #330 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|360|[Testing Robots](http://codeforces.com/problemset/problem/606/B)|Codeforces||Codeforces Round #335 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|361|[Rebus](http://codeforces.com/problemset/problem/663/A)|Codeforces||Codeforces Round #347 (Div. 1) & Codeforces Round #347 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|362|[Problems for Round](http://codeforces.com/problemset/problem/673/B)|Codeforces||Codeforces Round #351 (VK Cup 2016 Round 3, Div. 2 Edition)|4|
|<ul><li>- [ ] Done</li></ul>|363|[Game of the Rows](http://codeforces.com/problemset/problem/839/B)|Codeforces||Codeforces Round #428 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|364|[Race Against Time](http://codeforces.com/problemset/problem/868/B)|Codeforces||Codeforces Round #438 by Sberbank and Barcelona Bootcamp (Div. 1 + Div. 2 combined)|4|
|<ul><li>- [ ] Done</li></ul>|365|[Binary Search](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=221)|Live Archive|2000|Europe - Northeastern|4|
|<ul><li>- [ ] Done</li></ul>|366|[Memory Manager](http://codeforces.com/problemset/problem/7/B)|Codeforces||Codeforces Beta Round #7|5|
|<ul><li>- [ ] Done</li></ul>|367|[Obsession with Robots](http://codeforces.com/problemset/problem/8/B)|Codeforces||Codeforces Beta Round #8|5|
|<ul><li>- [ ] Done</li></ul>|368|[Jumping Jack](http://codeforces.com/problemset/problem/11/B)|Codeforces||Codeforces Beta Round #11|5|
|<ul><li>- [ ] Done</li></ul>|369|[Hierarchy](http://codeforces.com/problemset/problem/17/B)|Codeforces||Codeforces Beta Round #17|5|
|<ul><li>- [ ] Done</li></ul>|370|[Checkout Assistant](http://codeforces.com/problemset/problem/19/B)|Codeforces||Codeforces Beta Round #19|5|
|<ul><li>- [ ] Done</li></ul>|371|[Equation](http://codeforces.com/problemset/problem/20/B)|Codeforces||Codeforces Alpha Round #20 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|372|[Bargaining Table](http://codeforces.com/problemset/problem/22/B)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|373|[pSort](http://codeforces.com/problemset/problem/28/B)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|374|[Sysadmin Bob](http://codeforces.com/problemset/problem/31/B)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|5|
|<ul><li>- [ ] Done</li></ul>|375|[Chess](http://codeforces.com/problemset/problem/38/B)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|376|[Martian Dollar](http://codeforces.com/problemset/problem/41/B)|Codeforces||Codeforces Beta Round #40 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|377|[T-shirts from Sponsor](http://codeforces.com/problemset/problem/46/B)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|378|[Sum](http://codeforces.com/problemset/problem/49/B)|Codeforces||Codeforces Beta Round #46 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|379|[Spoilt Permutation](http://codeforces.com/problemset/problem/56/B)|Codeforces||Codeforces Beta Round #52 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|380|[Energy exchange](http://codeforces.com/problemset/problem/68/B)|Codeforces||Codeforces Beta Round #62|5|
|<ul><li>- [ ] Done</li></ul>|381|[Bets](http://codeforces.com/problemset/problem/69/B)|Codeforces||Codeforces Beta Round #63 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|382|[Facetook Priority Wall](http://codeforces.com/problemset/problem/75/B)|Codeforces||Codeforces Beta Round #67 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|383|[Colorful Field](http://codeforces.com/problemset/problem/79/B)|Codeforces||Codeforces Beta Round #71|5|
|<ul><li>- [ ] Done</li></ul>|384|[Friends](http://codeforces.com/problemset/problem/94/B)|Codeforces||Codeforces Beta Round #76 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|385|[Help Chef Gerasim](http://codeforces.com/problemset/problem/99/B)|Codeforces||Codeforces Beta Round #78 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|386|[Datatypes](http://codeforces.com/problemset/problem/108/B)|Codeforces||Codeforces Beta Round #83 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|387|[PFAST Inc.](http://codeforces.com/problemset/problem/114/B)|Codeforces||Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|388|[Permutations](http://codeforces.com/problemset/problem/124/B)|Codeforces||Codeforces Beta Round #92 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|389|[Martian Clock](http://codeforces.com/problemset/problem/149/B)|Codeforces||Codeforces Round #106 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|390|[Surrounded](http://codeforces.com/problemset/problem/190/B)|Codeforces||Codeforces Round #120 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|391|[Game on Paper](http://codeforces.com/problemset/problem/203/B)|Codeforces||Codeforces Round #128 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|392|[Young Table](http://codeforces.com/problemset/problem/237/B)|Codeforces||Codeforces Round #147 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|393|[Jury Size](http://codeforces.com/problemset/problem/254/B)|Codeforces||Codeforces Round #155 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|394|[Convex Shape](http://codeforces.com/problemset/problem/275/B)|Codeforces||Codeforces Round #168 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|395|[Nearest Fraction](http://codeforces.com/problemset/problem/281/B)|Codeforces||Codeforces Round #172 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|396|[Calendar](http://codeforces.com/problemset/problem/304/B)|Codeforces||Codeforces Round #183 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|397|[Continued Fractions](http://codeforces.com/problemset/problem/305/B)|Codeforces||Codeforces Round #184 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|398|[Two Heaps](http://codeforces.com/problemset/problem/353/B)|Codeforces||Codeforces Round #205 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|399|[Berland Bingo](http://codeforces.com/problemset/problem/370/B)|Codeforces||Codeforces Round #217 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|400|[Making Sequences is Fun](http://codeforces.com/problemset/problem/373/B)|Codeforces||Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|401|[Candy Boxes](http://codeforces.com/problemset/problem/488/B)|Codeforces||Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|402|[Balancer](http://codeforces.com/problemset/problem/440/B)|Codeforces||Testing Round #10|5|
|<ul><li>- [ ] Done</li></ul>|403|[The Queue](http://codeforces.com/problemset/problem/767/B)|Codeforces||Codeforces Round #398 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|404|[Cinema Cashier](http://codeforces.com/problemset/problem/10/B)|Codeforces||Codeforces Beta Round #10|6|
|<ul><li>- [ ] Done</li></ul>|405|[Platforms](http://codeforces.com/problemset/problem/18/B)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|406|[Party](http://codeforces.com/problemset/problem/23/B)|Codeforces||Codeforces Beta Round #23|6|
|<ul><li>- [ ] Done</li></ul>|407|[F1 Champions](http://codeforces.com/problemset/problem/24/B)|Codeforces||Codeforces Beta Round #24|6|
|<ul><li>- [ ] Done</li></ul>|408|[Traffic Lights](http://codeforces.com/problemset/problem/29/B)|Codeforces||Codeforces Beta Round #29 (Div. 2, Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|409|[String Problem](http://codeforces.com/problemset/problem/33/B)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|410|[Land Lot](http://codeforces.com/problemset/problem/48/B)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|411|[Smallest number](http://codeforces.com/problemset/problem/55/B)|Codeforces||Codeforces Beta Round #51|6|
|<ul><li>- [ ] Done</li></ul>|412|[Tyndex.Brome](http://codeforces.com/problemset/problem/62/B)|Codeforces||Codeforces Beta Round #58|6|
|<ul><li>- [ ] Done</li></ul>|413|[Harry Potter and the History of Magic](http://codeforces.com/problemset/problem/65/B)|Codeforces||Codeforces Beta Round #60|6|
|<ul><li>- [ ] Done</li></ul>|414|[Text Messaging](http://codeforces.com/problemset/problem/70/B)|Codeforces||Codeforces Beta Round #64|6|
|<ul><li>- [ ] Done</li></ul>|415|[Train](http://codeforces.com/problemset/problem/74/B)|Codeforces||Codeforces Beta Round #68|6|
|<ul><li>- [ ] Done</li></ul>|416|[Keyboard](http://codeforces.com/problemset/problem/88/B)|Codeforces||Codeforces Beta Round #73 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|417|[Very Interesting Game](http://codeforces.com/problemset/problem/117/B)|Codeforces||Codeforces Beta Round #88|6|
|<ul><li>- [ ] Done</li></ul>|418|[Wallpaper](http://codeforces.com/problemset/problem/139/B)|Codeforces||Codeforces Beta Round #99 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|419|[New Year Cards](http://codeforces.com/problemset/problem/140/B)|Codeforces||Codeforces Round #100|6|
|<ul><li>- [ ] Done</li></ul>|420|[Polygons](http://codeforces.com/problemset/problem/166/B)|Codeforces||Codeforces Round #113 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|421|[Wizards and Minimal Spell](http://codeforces.com/problemset/problem/168/B)|Codeforces||Codeforces Round #114 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|422|[Plane of Tanks: Pro](http://codeforces.com/problemset/problem/175/B)|Codeforces||Codeforces Round #115|6|
|<ul><li>- [ ] Done</li></ul>|423|[Solitaire](http://codeforces.com/problemset/problem/208/B)|Codeforces||Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|424|[Easy Tape Programming](http://codeforces.com/problemset/problem/239/B)|Codeforces||Codeforces Round #148 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|425|[Unsorting Array](http://codeforces.com/problemset/problem/252/B)|Codeforces||Codeforces Round #153 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|426|[Vasily the Bear and Fly](http://codeforces.com/problemset/problem/336/B)|Codeforces||Codeforces Round #195 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|427|[Maximal Area Quadrilateral](http://codeforces.com/problemset/problem/340/B)|Codeforces||Codeforces Round #198 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|428|[Number Busters](http://codeforces.com/problemset/problem/382/B)|Codeforces||Codeforces Round #224 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|429|[Red and Blue Balls](http://codeforces.com/problemset/problem/399/B)|Codeforces||Codeforces Round #233 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|430|[Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3705)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|431|[Laser](http://codeforces.com/problemset/problem/15/B)|Codeforces||Codeforces Beta Round #15|7|
|<ul><li>- [ ] Done</li></ul>|432|[Intersection](http://codeforces.com/problemset/problem/21/B)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|433|[Codeforces World Finals](http://codeforces.com/problemset/problem/30/B)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|434|[Warehouse](http://codeforces.com/problemset/problem/35/B)|Codeforces||Codeforces Beta Round #35 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|435|[Fractal](http://codeforces.com/problemset/problem/36/B)|Codeforces||Codeforces Beta Round #36|7|
|<ul><li>- [ ] Done</li></ul>|436|[Computer Game](http://codeforces.com/problemset/problem/37/B)|Codeforces||Codeforces Beta Round #37|7|
|<ul><li>- [ ] Done</li></ul>|437|[Repaintings](http://codeforces.com/problemset/problem/40/B)|Codeforces||Codeforces Beta Round #39|7|
|<ul><li>- [ ] Done</li></ul>|438|[Game of chess unfinished](http://codeforces.com/problemset/problem/42/B)|Codeforces||Codeforces Beta Round #41|7|
|<ul><li>- [ ] Done</li></ul>|439|[bHTML Tables Analisys](http://codeforces.com/problemset/problem/51/B)|Codeforces||Codeforces Beta Round #48|7|
|<ul><li>- [ ] Done</li></ul>|440|[Blog Photo](http://codeforces.com/problemset/problem/53/B)|Codeforces||Codeforces Beta Round #49 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|441|[Martian Architecture](http://codeforces.com/problemset/problem/57/B)|Codeforces||Codeforces Beta Round #53|7|
|<ul><li>- [ ] Done</li></ul>|442|[Dark Assembly](http://codeforces.com/problemset/problem/105/B)|Codeforces||Codeforces Beta Round #81|7|
|<ul><li>- [ ] Done</li></ul>|443|[Before Exam](http://codeforces.com/problemset/problem/119/B)|Codeforces||Codeforces Beta Round #90|7|
|<ul><li>- [ ] Done</li></ul>|444|[Brand New Easy Problem](http://codeforces.com/problemset/problem/202/B)|Codeforces||Codeforces Round #127 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|445|[Yaroslav and Two Strings](http://codeforces.com/problemset/problem/296/B)|Codeforces||Codeforces Round #179 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|446|[Inna, Dima and Song](http://codeforces.com/problemset/problem/390/B)|Codeforces||Codeforces Round #229 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|447|[Three matrices](http://codeforces.com/problemset/problem/393/B)|Codeforces||Codeforces Round #230 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|448|[On Corruption and Numbers](http://codeforces.com/problemset/problem/397/B)|Codeforces||Codeforces Round #232 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|449|[Rooks and Rectangles](http://codeforces.com/problemset/problem/524/E)|Codeforces||VK Cup 2015 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|450|[Decode](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3364)|Live Archive|1990|North America - East Central NA|7|
|<ul><li>- [ ] Done</li></ul>|451|[Letter A](http://codeforces.com/problemset/problem/13/B)|Codeforces||Codeforces Beta Round #13|8|
|<ul><li>- [ ] Done</li></ul>|452|[Cutting Jigsaw Puzzle](http://codeforces.com/problemset/problem/54/B)|Codeforces||Codeforces Beta Round #50|8|
|<ul><li>- [ ] Done</li></ul>|453|[Need For Brake](http://codeforces.com/problemset/problem/73/B)|Codeforces||Codeforces Beta Round #66|8|
|<ul><li>- [ ] Done</li></ul>|454|[Special Olympics](http://codeforces.com/problemset/problem/199/B)|Codeforces||Codeforces Round #125 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|455|[Very Beautiful Number](http://codeforces.com/problemset/problem/394/B)|Codeforces||Codeforces Round #231 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|456|[Divisibility Rules](http://codeforces.com/problemset/problem/180/B)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|457|[Fence](p?ID=29)|A2 Online Judge|||9|
