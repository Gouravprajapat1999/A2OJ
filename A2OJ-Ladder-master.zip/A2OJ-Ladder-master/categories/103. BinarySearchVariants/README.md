# 103. BinarySearchVariants


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[AgeEncoding](http://community.topcoder.com/stat?c=problem_statement&pm=10589)|TopCoder|SRM 462 - Div1 easy - Div2 medium] (14147)|4|
|<ul><li>- [ ] Done</li></ul>|2|[ImprovingStatistics](http://community.topcoder.com/stat?c=problem_statement&pm=7386)|TopCoder|SRM 338 - Div1 easy - Div2 medium] (10662)|4|
|<ul><li>- [ ] Done</li></ul>|3|[LogCutter](http://community.topcoder.com/stat?c=problem_statement&pm=5955)|TopCoder|SRM 329 - Div1 medium] (10009)|5|
|<ul><li>- [ ] Done</li></ul>|4|[ModularInequality](http://community.topcoder.com/stat?c=problem_statement&pm=6765)|TopCoder|SRM 325 - Div1 medium - Div2 hard] (10005)|6|
|<ul><li>- [ ] Done</li></ul>|5|[StrawberryFieldsOnFire](http://community.topcoder.com/stat?c=problem_statement&pm=6646)|TopCoder|SRM 322 - Div1 hard] (10002)|9|
|<ul><li>- [ ] Done</li></ul>|6|[RPSTournament](http://community.topcoder.com/stat?c=problem_statement&pm=6539)|TopCoder|SRM 339 - Div1 hard] (10663)|9|
