# 101. 0_1_BFS


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[KATHTHI](http://www.spoj.com/problems/KATHTHI/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|2|[Ocean Currents](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2620)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|3|[Three States](http://codeforces.com/problemset/problem/590/C)|Codeforces|Codeforces Round #327 (Div. 1) & Codeforces Round #327 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|4|[Olya and Energy Drinks](http://codeforces.com/problemset/problem/877/D)|Codeforces|Codeforces Round #442 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|5|[Chamber of Secrets](http://codeforces.com/problemset/problem/173/B)|Codeforces|Croc Champ 2012 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|6|[Error](p?ID=28)|A2 Online Judge||7|
