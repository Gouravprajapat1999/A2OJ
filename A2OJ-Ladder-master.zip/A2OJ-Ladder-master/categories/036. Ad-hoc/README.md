# 036. Ad-hoc


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Free spots](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1644)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Automatic Answer](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2542)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Digit Counting](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1997)|Live Archive|2007|Asia - Danang|1|
|<ul><li>- [ ] Done</li></ul>|4|[What's The Frequency, Kenneth?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=440)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Hajj-e-Akbar](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4022)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[The Useless Toy](http://codeforces.com/problemset/problem/834/A)|Codeforces||Codeforces Round #426 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Egypt](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2954)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Beat the Spread!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1753)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|9|[Schedule of a Married Man](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2203)|Live Archive|2008|Asia - Dhaka|1|
|<ul><li>- [ ] Done</li></ul>|10|[Ecological Premium](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1241)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|11|[STONE GAME ](http://www.spoj.com/problems/RESN04/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Minesweeper](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1130)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|13|[WERTYU](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1023)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|14|[Find the Telephone](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1862)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Cost Cutting](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2827)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Barcodes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2787)|Live Archive|2010|World Finals - Harbin|1|
|<ul><li>- [ ] Done</li></ul>|17|[Combination Lock](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1491)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|18|[Enormous Input Test](http://www.spoj.com/problems/INTEST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Hash it!](http://www.spoj.com/problems/HASHIT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Colours A, B, C, D](http://www.spoj.com/problems/ABCD/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Request for Proposal](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1082)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Searching for Nessy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1985)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|23|[TEX Quotes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=208)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Lucky Ticket](http://codeforces.com/problemset/problem/146/A)|Codeforces||Codeforces Round #104 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|25|[Enormous Input Test](http://www.codechef.com/problems/INTEST)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|26|[The 3n + 1 problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=36)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Cola](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2091)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|28|[VOI09 Tr&#242; ch&#417;i v&#7899;i b?ng s&#7889;](http://vn.spoj.com/problems/LINEGAME/)|SPOJ Vietnam|||1|
|<ul><li>- [ ] Done</li></ul>|29|[The Blocks Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=37)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|30|[Word Scramble](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=424)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|31|[List of Conquests](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1361)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|32|[All Integer Average](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1013)|Live Archive|2004|Asia - Dhaka|1|
|<ul><li>- [ ] Done</li></ul>|33|[Blowing Fuses](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=602)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|34|[Event Planning](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2595)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|35|[Ecological Bin Packing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=38)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|36|[The Snail](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=514)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|37|[Newspaper](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2315)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Mobile Casanova](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=190)|Live Archive|2006|Asia - Dhaka|1|
|<ul><li>- [ ] Done</li></ul>|39|[Horror Dash](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2899)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|40|[Rectangles](http://www.spoj.com/problems/AE00/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|41|[Soundex Indexing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=680)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|42|[Division of Nlogonia](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2493)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|43|[Wordfish](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1174)|Live Archive|2006|Asia - Manila|1|
|<ul><li>- [ ] Done</li></ul>|44|[Is It A Tree?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=556)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|45|[Light and Transparencies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=778)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|46|[Permutations](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=882)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|47|[Roman Numerals](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|48|[Find the Format String](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2201)|Live Archive|2008|Asia - Dhaka|2|
|<ul><li>- [ ] Done</li></ul>|49|[Tic Tac Toe](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1304)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|50|[Mapmaker](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=330)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|51|[Simulation Wizardry](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=50)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|52|[O: dah dah dah!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2164)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|53|[The decadary watch](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1624)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|54|[Self-describing Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=990)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|55|[An Experiment by Penny](http://www.spoj.com/problems/CRAN01/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|56|[Determine the Shape](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2900)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|57|[Major Scales](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1469)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|58|[SOLVEIT](http://www.spoj.com/problems/SOLVEIT/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|59|[XOR Equation](http://codeforces.com/problemset/problem/627/A)|Codeforces||8VC Venture Cup 2016 - Final Round|4|
|<ul><li>- [ ] Done</li></ul>|60|[TWO BISHOPS](http://www.spoj.com/problems/TWOBISOP/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|61|[Report](http://codeforces.com/problemset/problem/631/C)|Codeforces||Codeforces Round #344 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|62|[Jerry's Protest](http://codeforces.com/problemset/problem/626/D)|Codeforces||8VC Venture Cup 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|63|[Dinner Hall](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3341)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|64|[Candy Marathon](https://www.urionlinejudge.com.br/judge/en/problems/view/1684)|URI|||7|
