# 040. backtracking


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Passwords](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=569)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Tree Summing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=48)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Don't Get Rooked](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=580)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Expert Enough?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3678)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|6|[23 out of 5](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1285)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Making Jumps](http://www.spoj.com/problems/MKJUMPS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[The Hamming Distance Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=670)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|9|[8 Queens Chess Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=691)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Prime Ring Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=465)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|11|[The House Of Santa Claus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=227)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Sum It Up](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=515)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|13|[ABC Path](http://www.spoj.com/problems/ABCPATH/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[ALL IZZ WELL](http://www.spoj.com/problems/ALLIZWEL/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Back to the 8-Queens](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2026)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Lotto](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=382)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|17|[The Sultan's Successors](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=103)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|18|[At most twice](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=5215)|Live Archive|2015|Latin America|1|
|<ul><li>- [ ] Done</li></ul>|19|[CD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=565)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Hanoi Tower Troubles Again!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1217)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Division](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=666)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Vonny and her dominos](http://www.spoj.com/problems/VONNY/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|23|[Another n-Queen Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2136)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|24|[Knights in FEN](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1363)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|25|[A-Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1871)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|26|[Dividing coins](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3584)|Live Archive|1996|Europe - Northwestern|3|
|<ul><li>- [ ] Done</li></ul>|27|[Digger Octaves](http://www.spoj.com/problems/UCI2009D/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|28|[Winterim Backpacking Trip](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=848)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|29|[Sum It Up](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3320)|Live Archive|1997|North America - Mid-Central USA|3|
|<ul><li>- [ ] Done</li></ul>|30|[Playing Boggle](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2258)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|31|[Run, Run, Runaround Numbers](http://acm.zju.edu.cn/onlinejudge/showProblem.do?problemCode=1275)|ZOJ|||3|
|<ul><li>- [ ] Done</li></ul>|32|[The Boggle Game](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=545)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|33|[Garden of Eden](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=942)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|34|[Monkeys in a Regular Forest](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=717)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|35|[Word Index](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3393)|Live Archive|1995|North America - East Central NA|4|
|<ul><li>- [ ] Done</li></ul>|36|[The Sultan's Successors](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3228)|Live Archive|1991|South Pacific|4|
|<ul><li>- [ ] Done</li></ul>|37|[Prim](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1748)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|38|[Hexagonal Puzzle](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4387)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|39|[Graph Coloring](http://codeforces.com/problemset/problem/662/B)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|6|
|<ul><li>- [ ] Done</li></ul>|40|[The Boggle Game](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3477)|Live Archive|1997|North America - Pacific Northwest|7|
|<ul><li>- [ ] Done</li></ul>|41|[This Means War!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2300)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|42|[Knight Moves](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=502)|Live Archive|2002|North America - Southeast USA|10|
