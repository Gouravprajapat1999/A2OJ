# 111. Minimum_Spanning_Tree


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Lazy Student](http://codeforces.com/problemset/problem/605/B)|Codeforces|Codeforces Round #335 (Div. 1) & Codeforces Round #335 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|2|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces|Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|3|[Minimum spanning tree for each edge](http://codeforces.com/problemset/problem/609/E)|Codeforces|Educational Codeforces Round 3|5|
|<ul><li>- [ ] Done</li></ul>|4|[Hamiltonian Spanning Tree](http://codeforces.com/problemset/problem/618/D)|Codeforces|Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|6|
|<ul><li>- [ ] Done</li></ul>|5|[Edges in MST](http://codeforces.com/problemset/problem/160/D)|Codeforces|Codeforces Round #111 (Div. 2)|7|
