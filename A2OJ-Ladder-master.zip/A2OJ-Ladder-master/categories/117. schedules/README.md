# 117. schedules


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Inna and New Matrix of Candies](http://codeforces.com/problemset/problem/400/B)|Codeforces|Codeforces Round #234 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|2|[Sereja and Brackets](http://codeforces.com/problemset/problem/380/C)|Codeforces|Codeforces Round #223 (Div. 1) & Codeforces Round #223 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|3|[Rock-paper-scissors](http://codeforces.com/problemset/problem/48/A)|Codeforces|School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|4|[New Year Tree Decorations](http://codeforces.com/problemset/problem/379/E)|Codeforces|Good Bye 2013|9|
