# 152. Stable_Marriage


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Stable Marriage Problem](http://www.spoj.com/problems/STABLEMP/)|SPOJ|1|
