# 137. Pigeonhole_principle


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Labyrinth](http://www.spoj.com/problems/LABYR1/)|SPOJ|1|
|<ul><li>- [ ] Done</li></ul>|2|[Halloween treats](http://www.spoj.com/problems/HALLOW/)|SPOJ|2|
