# 001. Dynamic_Programming


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[ACM (ACronymMaker)](http://www.spoj.com/problems/ACMAKER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Alphacode](http://www.spoj.com/problems/ACODE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Assignments](http://www.spoj.com/problems/ASSIGN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Tower of Babylon](http://www.spoj.com/problems/BABTWR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|5|[Philosophers Stone](http://www.spoj.com/problems/BYTESM2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|6|[Bytelandian gold coins](http://www.spoj.com/problems/COINS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|7|[Summing to a Square Prime](http://www.spoj.com/problems/CZ_PROB1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|8|[Tiling a Grid With Dominoes](http://www.spoj.com/problems/GNY07H/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|9|[BLAST](http://www.spoj.com/problems/MBLAST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Coins Game](http://www.spoj.com/problems/MCOINS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|11|[Rectangles Perimeter](http://www.spoj.com/problems/MMAXPER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|12|[Party Schedule](http://www.spoj.com/problems/PARTY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|13|[Permutations](http://www.spoj.com/problems/PERMUT1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|14|[Piggy-Bank](http://www.spoj.com/problems/PIGBANK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|15|[Rent your airplane and make money](http://www.spoj.com/problems/RENT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|16|[Roads](http://www.spoj.com/problems/ROADS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|17|[Candy](http://www.spoj.com/problems/SAMER08C/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|18|[DNA Sequences](http://www.spoj.com/problems/SAMER08D/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|19|[Feynman](http://www.spoj.com/problems/SAMER08F/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|20|[Scuba diver](http://www.spoj.com/problems/SCUBADIV/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|21|[Help the soldier](http://www.spoj.com/problems/SOLDIER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|22|[Sums in a Triangle](http://www.spoj.com/problems/SUMITR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|23|[Trip](http://www.spoj.com/problems/TRIP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|24|[Treats for the Cows](http://www.spoj.com/problems/TRT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|25|[Two Ends](http://www.spoj.com/problems/TWENDS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|26|[Is Bigger Smarter?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1072)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|27|[Unidirectional TSP](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=52)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|28|[Vertex Cover](http://www.spoj.com/problems/PT07X/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|29|[Aibohphobia](http://www.spoj.com/problems/AIBOHP/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|30|[Black or White](http://www.spoj.com/problems/BORW/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|31|[Fool the Police](http://www.spoj.com/problems/FPOLICE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|32|[Palindrome 2000](http://www.spoj.com/problems/IOIPALIN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|33|[Chop Ahoy! Revisited!](http://www.spoj.com/problems/ANARC05H/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|34|[Seinfeld](http://www.spoj.com/problems/ANARC09A/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|35|[Cross-country](http://www.spoj.com/problems/CRSCNTRY/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|36|[In Danger](http://www.spoj.com/problems/DANGER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|37|[Distinct Subsequences](http://www.spoj.com/problems/DSUBSEQ/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|38|[Edit distance](http://www.spoj.com/problems/EDIST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|39|[Fishmonger](http://www.spoj.com/problems/FISHER/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|40|[Adjacent Bit Counts](http://www.spoj.com/problems/GNYR09F/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|41|[The Double HeLiX](http://www.spoj.com/problems/ANARC05B/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|42|[Pocket Money](http://www.spoj.com/problems/LISA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|43|[LATGACH3](http://www.spoj.com/problems/M3TILE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|44|[Mixtures](http://www.spoj.com/problems/MIXTURES/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|45|[No Change](http://www.spoj.com/problems/NOCHANGE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|46|[Square Brackets](http://www.spoj.com/problems/SQRBR/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|47|[Dollars](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=83)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|48|[Let Me Count The Ways](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=293)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|49|[Cutting Sticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=944)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|50|[Dividing coins](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=503)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|51|[Ingenuous Cubrency](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2078)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|52|[Chocolate](http://www.spoj.com/problems/CHOCOLA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|53|[Bee Walk](http://www.spoj.com/problems/MBEEWALK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|54|[Sweet and Sour Rock](http://www.spoj.com/problems/ROCK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|55|[Activities](http://www.spoj.com/problems/ACTIV/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|56|[Martian Mining](http://www.spoj.com/problems/MARTIAN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|57|[Phidias](http://www.spoj.com/problems/PHIDIAS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|58|[Sum of Digits](http://www.spoj.com/problems/CPCRC1C/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|59|[Pilots](http://www.spoj.com/problems/MPILOT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|60|[Tri graphs](http://www.spoj.com/problems/ACPC10D/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|61|[Cut Ribbon](http://codeforces.com/problemset/problem/189/A)|Codeforces||Codeforces Round #119 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|62|[Tetrahedron](http://codeforces.com/problemset/problem/166/E)|Codeforces||Codeforces Round #113 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|63|[A+B Problem](http://poj.org/problem?id=1000)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|64|[Exponentiation](http://poj.org/problem?id=1001)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|65|[Hangover](http://poj.org/problem?id=1003)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|66|[THE DRUNK JAILER](http://poj.org/problem?id=1218)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|67|[Homer Simpson](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1406)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|68|[SuperSale](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1071)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|69|[Luggage](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1605)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|70|[Wedding shopping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2445)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|71|[Maximum Sum](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=44)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|72|[How do you add?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1884)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|73|[Training for final](http://www.spoj.com/problems/TRIKA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|74|[Easy Longest Increasing Subsequence](http://www.spoj.com/problems/ELIS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|75|[K-based Numbers](http://acm.timus.ru/problem.aspx?space=1&num=1009)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|76|[K-based Numbers. Version 2](http://acm.timus.ru/problem.aspx?space=1&num=1012)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|77|[Staircases](http://acm.timus.ru/problem.aspx?space=1&num=1017)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|78|[Binary Apple Tree](http://acm.timus.ru/problem.aspx?space=1&num=1018)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|79|[Lucky Tickets](http://acm.timus.ru/problem.aspx?space=1&num=1036)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|80|[Square Country](http://acm.timus.ru/problem.aspx?space=1&num=1073)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|81|[Binary Lexicographic Sequence](http://acm.timus.ru/problem.aspx?space=1&num=1081)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|82|[Metro](http://acm.timus.ru/problem.aspx?space=1&num=1119)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|83|[Maximum Sum](http://acm.timus.ru/problem.aspx?space=1&num=1146)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|84|[Scientific Conference](http://acm.timus.ru/problem.aspx?space=1&num=1203)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|85|[Flags](http://acm.timus.ru/problem.aspx?space=1&num=1225)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|86|[Milliard Vasya's Function](http://acm.timus.ru/problem.aspx?space=1&num=1353)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|87|[Collecting Beepers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1437)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|88|[Getting in Line](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=152)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|89|[Army](http://codeforces.com/problemset/problem/38/A)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|1|
|<ul><li>- [ ] Done</li></ul>|90|[The Tower of Babylon](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=378)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|91|[Magic Grid](http://www.spoj.com/problems/AMR11A/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|92|[Building Bridges](http://www.spoj.com/problems/BRIDGE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|93|[Largest Submatrix](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=777)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|94|[Take the Land](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1015)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|95|[Non-Decreasing Digits](http://www.spoj.com/problems/NY10E/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|96|[Blueberries](http://www.spoj.com/problems/RPLB/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|97|[DIE HARD](http://www.spoj.com/problems/DIEHARD/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|98|[Save Thy Toys](http://www.spoj.com/problems/DCEPC501/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|99|[0110SS](http://www.spoj.com/problems/IWGBS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|100|[Tile Code](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1905)|Live Archive|2007|Asia - Seoul|1|
|<ul><li>- [ ] Done</li></ul>|101|[Tiling Up Blocks](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=816)|Live Archive|2003|Asia - Kaohsiung|1|
|<ul><li>- [ ] Done</li></ul>|102|[Candy](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2213)|Live Archive|2008|Latin America - South America|1|
|<ul><li>- [ ] Done</li></ul>|103|[Fibonacci Words](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4040)|Live Archive|2012|World Finals - Warsaw|1|
|<ul><li>- [ ] Done</li></ul>|104|[Hotels Along the Croatian Coast](http://www.spoj.com/problems/HOTELS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|105|[Fibonacci Freeze](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=436)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|106|[COSTLY CHESS](http://www.spoj.com/problems/CCHESS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|107|[Soft Drinking](http://codeforces.com/problemset/problem/151/A)|Codeforces||Codeforces Round #107 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|108|[The 3n + 1 problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=36)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|109|[Longest Common Subsequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1346)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|110|[MAXIMUM WOOD CUTTER](http://www.spoj.com/problems/MAXWOODS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|111|[Divisibility](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=977)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|112|[Pearls](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=676)|Live Archive|2002|Europe - Northwestern|1|
|<ul><li>- [ ] Done</li></ul>|113|[Prime Permutations](http://www.codechef.com/problems/PPERM)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|114|[Enormous Input Test](http://www.codechef.com/problems/INTEST)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|115|[Boredom](http://codeforces.com/problemset/problem/455/A)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|116|[Aliens at the train](http://www.spoj.com/problems/ALIEN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|117|[T-primes](http://codeforces.com/problemset/problem/230/B)|Codeforces||Codeforces Round #142 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|118|[Ultra-Fast Mathematician](http://codeforces.com/problemset/problem/61/A)|Codeforces||Codeforces Beta Round #57 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|119|[Making Change](http://acm.tju.edu.cn/toj/showp2768.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|120|[Before an Exam](http://codeforces.com/problemset/problem/4/B)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|121|[The Bale Tower](http://acm.tju.edu.cn/toj/showp2769.html)|TJU|||1|
|<ul><li>- [ ] Done</li></ul>|122|[Robot Instructions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3947)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|123|[Longest Palindrome](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2092)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|124|[Optimal Array Multiplication Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=284)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|125|[Longest Run on a Snowboard](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1226)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|126|[Coin Change](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=615)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|127|[Divisible Group Sums](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1557)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|128|[Strategic Defense Initiative](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=438)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|129|[Vacation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1133)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|130|[Testing the CATCHER](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=167)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|131|[History Grading](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=47)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|132|[Stacking Boxes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=39)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|133|[The Twin Towers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1007)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|134|[Compromise](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=472)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|135|[23 out of 5](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1285)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|136|[Grandpa's Walk](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4049)|Live Archive|2012|Asia - Jakarta|1|
|<ul><li>- [ ] Done</li></ul>|137|[Generations of Tribbles](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4529)|Live Archive|2013| 	North America - Pacific Northwest|1|
|<ul><li>- [ ] Done</li></ul>|138|[Equal Sum Sets](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4673)|Live Archive|2013|Asia - Aizu|1|
|<ul><li>- [ ] Done</li></ul>|139|[Cheap Travel](http://codeforces.com/problemset/problem/466/A)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|140|[k-Tree](http://codeforces.com/problemset/problem/431/C)|Codeforces||Codeforces Round #247 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|141|[Flowers](http://codeforces.com/problemset/problem/474/D)|Codeforces||Codeforces Round #271 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|142|[To the Max](http://poj.org/problem?id=1050)|PKU|||1|
|<ul><li>- [ ] Done</li></ul>|143|[Membership Management](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3068)|Live Archive|2010|Asia - Tokyo|1|
|<ul><li>- [ ] Done</li></ul>|144|[The Great Ball](http://www.spoj.com/problems/BYTESE2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|145|[XOR Maximization](http://www.spoj.com/problems/XMAX/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|146|[Given Length and Sum of Digits...](http://codeforces.com/problemset/problem/489/C)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|147|[The Knapsack Problem](http://www.spoj.com/problems/KNAPSACK/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|148|[Wachovia Bank](http://www.spoj.com/problems/WACHOVIA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|149|[Trip Planning](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2262)|Live Archive|2008|Asia - Taipei|1|
|<ul><li>- [ ] Done</li></ul>|150|[Forming Quiz Teams](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1852)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|151|[Woodcutters](http://codeforces.com/problemset/problem/545/C)|Codeforces||Codeforces Round #303 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|152|[Number of Ways](http://codeforces.com/problemset/problem/466/C)|Codeforces||Codeforces Round #266 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|153|[Histogram](http://www.spoj.com/problems/HIST2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|154|[Two Substrings](http://codeforces.com/problemset/problem/550/A)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|155|[Quasi Binary](http://codeforces.com/problemset/problem/538/B)|Codeforces||Codeforces Round #300|1|
|<ul><li>- [ ] Done</li></ul>|156|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|157|[Fence](http://codeforces.com/problemset/problem/363/B)|Codeforces||Codeforces Round #211 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|158|[Bridging signals](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=932)|Live Archive|2003|Europe - Northwestern|1|
|<ul><li>- [ ] Done</li></ul>|159|[ABC Path](http://www.spoj.com/problems/ABCPATH/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|160|[ShorterSuperSum](http://community.topcoder.com/stat?c=problem_statement&pm=10240)|TopCoder||SRM 467 - Div2 easy] (14151)|1|
|<ul><li>- [ ] Done</li></ul>|161|[Omar](p?ID=1)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|162|[Chat room](http://codeforces.com/problemset/problem/58/A)|Codeforces||Codeforces Beta Round #54 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|163|[Perfection](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=318)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|164|[Joysticks](http://codeforces.com/problemset/problem/651/A)|Codeforces||Codeforces Round #345 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|165|[Kefa and First Steps](http://codeforces.com/problemset/problem/580/A)|Codeforces||Codeforces Round #321 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|166|[Divisibility by Eight](http://codeforces.com/problemset/problem/550/C)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|167|[BerSU Ball](http://codeforces.com/problemset/problem/489/B)|Codeforces||Codeforces Round #277.5 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|168|[Kuriyama Mirai's Stones](http://codeforces.com/problemset/problem/433/B)|Codeforces||Codeforces Round #248 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|169|[Mashmokh and ACM](http://codeforces.com/problemset/problem/414/B)|Codeforces||Codeforces Round #240 (Div. 1) & Codeforces Round #240 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|170|[Sereja and Suffixes](http://codeforces.com/problemset/problem/368/B)|Codeforces||Codeforces Round #215 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|171|[Puzzles](http://codeforces.com/problemset/problem/337/A)|Codeforces||Codeforces Round #196 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|172|[Flipping Game](http://codeforces.com/problemset/problem/327/A)|Codeforces||Codeforces Round #191 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|173|[Ilya and Queries](http://codeforces.com/problemset/problem/313/B)|Codeforces||Codeforces Round #186 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|174|[Binary Search Tree](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2848)|Live Archive|2010|Asia - Daejeon|1|
|<ul><li>- [ ] Done</li></ul>|175|[Drazil and Factorial](http://codeforces.com/problemset/problem/515/C)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|1|
|<ul><li>- [ ] Done</li></ul>|176|[Cleaning Robot](http://www.spoj.com/problems/CLEANRBT/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|177|[Can you answer these queries I](http://www.spoj.com/problems/GSS1/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|178|[Twin Primes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1335)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|179|[Alphacode](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1079)|Live Archive|2004|North America - East Central NA|1|
|<ul><li>- [ ] Done</li></ul>|180|[Positive or Negative](p?ID=348)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|181|[Prime Digital Roots](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=248)|Live Archive|2001|South Pacific|1|
|<ul><li>- [ ] Done</li></ul>|182|[Sums in a Triangle](http://www.codechef.com/problems/SUMTRIAN)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|183|[The jackpot](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1625)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|184|[New Year and Hurry](http://codeforces.com/problemset/problem/750/A)|Codeforces||Good Bye 2016|1|
|<ul><li>- [ ] Done</li></ul>|185|[Cormen --- The Best Friend Of a Man](http://codeforces.com/problemset/problem/732/B)|Codeforces||Codeforces Round #377 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|186|[Jill Rides Again](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=448)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|187|[Watermelon](http://codeforces.com/problemset/problem/4/A)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|188|[QAQ](http://codeforces.com/problemset/problem/894/A)|Codeforces||Codeforces Round #447 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|189|[Simple Math](p?ID=347)|A2 Online Judge|||1|
|<ul><li>- [ ] Done</li></ul>|190|[Anton and Danik](http://codeforces.com/problemset/problem/734/A)|Codeforces||Codeforces Round #379 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|191|[DZY Loves Chessboard](http://codeforces.com/problemset/problem/445/A)|Codeforces||Codeforces Round #254 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|192|[Princess Farida](http://www.spoj.com/problems/FARIDA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|193|[Longest Common Substring](http://www.spoj.com/problems/LCS/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|194|[Buying Apples!](http://www.spoj.com/problems/ABA12C/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|195|[Trees](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1009)|Live Archive|2004|South Pacific|1|
|<ul><li>- [ ] Done</li></ul>|196|[Tiling a Grid With Dominoes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1918)|Live Archive|2007|North America - Greater NY|1|
|<ul><li>- [ ] Done</li></ul>|197|[Bicoloring](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=945)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|198|[I Can Guess the Data Structure!](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3146)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|199|[Prime Path](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1640)|Live Archive|2006|Europe - Northwestern|1|
|<ul><li>- [ ] Done</li></ul>|200|[Party](http://codeforces.com/problemset/problem/115/A)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only) & Codeforces Beta Round #87 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|201|[Exploring Pyramids](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1517)|Live Archive|2005|Europe - Northeastern|1|
|<ul><li>- [ ] Done</li></ul>|202|[Largest Rectangle in a Histogram](http://www.spoj.com/problems/HISTOGRA/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|203|[Mice and Maze](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=426)|Live Archive|2001|Europe - Southwestern|1|
|<ul><li>- [ ] Done</li></ul>|204|[Petya and Strings](http://codeforces.com/problemset/problem/112/A)|Codeforces||Codeforces Beta Round #85 (Div. 2 Only)|1|
|<ul><li>- [ ] Done</li></ul>|205|[What Goes Up](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=422)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|206|[Permutation Arrays](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=423)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|207|[I-Keyboard](http://www.spoj.com/problems/IKEYB/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|208|[Card Sorting](http://www.spoj.com/problems/MCARDS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|209|[Point Connection Game in a Circle](http://www.spoj.com/problems/MCIRGAME/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|210|[Decoding Morse Sequences](http://www.spoj.com/problems/MORSE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|211|[Counting The Way of Bracket Replacement](http://www.spoj.com/problems/MREPLBRC/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|212|[String problem](http://www.spoj.com/problems/MSTRING/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|213|[Partition](http://www.spoj.com/problems/PARTIT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|214|[Particular Palindromes](http://www.spoj.com/problems/PARTPALI/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|215|[Balancing the Stone](http://www.spoj.com/problems/SCALES/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|216|[String Shuffle](http://www.spoj.com/problems/SSHUFFLE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|217|[Street](http://www.spoj.com/problems/STREET/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|218|[Three-coloring of binary trees](http://www.spoj.com/problems/THREECOL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|219|[Up Subsequence](http://www.spoj.com/problems/UPSUB/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|220|[Dab of Backpack](http://www.spoj.com/problems/BACKPACK/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|221|[Dice](http://www.spoj.com/problems/AE2A/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|222|[JEDNAKOST](http://www.spoj.com/problems/JEDNAKOS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|223|[Feline Olympics - Mouseball](http://www.spoj.com/problems/MBALL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|224|[Catch Fish](http://www.spoj.com/problems/MFISH/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|225|[Tourist](http://www.spoj.com/problems/TOURIST/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|226|[Con-Junctions](http://www.spoj.com/problems/VOCV/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|227|[Yoda Goes Palindromic !](http://www.spoj.com/problems/YODA/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|228|[Esferas](http://www.spoj.com/problems/PRUBALL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|229|[Temptation Island](http://www.spoj.com/problems/TEMPTISL/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|230|[Interesting number](http://www.spoj.com/problems/INUMBER/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|231|[Sorting is not easy](http://www.spoj.com/problems/LSORT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|232|[Musketeers](http://www.spoj.com/problems/MUSKET/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|233|[The Courier](http://www.spoj.com/problems/COURIER/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|234|[Deliver pizza](http://www.spoj.com/problems/DP/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|235|[Counting K-Rectangle](http://www.spoj.com/problems/KRECT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|236|[Making A Budget](http://www.spoj.com/problems/MKBUDGET/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|237|[Menu](http://www.spoj.com/problems/MENU/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|238|[Nested Dolls](http://www.spoj.com/problems/MDOLLS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|239|[NERED](http://www.spoj.com/problems/MNERED/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|240|[Another Tree Problem ](http://www.spoj.com/problems/MTREE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|241|[Another Box Problem](http://www.spoj.com/problems/QCJ2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|242|[Tiling](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1300)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|243|[Distinct Subsequences](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1010)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|244|[Queue](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1069)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|245|[Jugs](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=512)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|246|[Game Show Math](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1341)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|247|[Another Problem on Strings](http://codeforces.com/problemset/problem/165/C)|Codeforces||Codeforces Round #112 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|248|[Password](http://codeforces.com/problemset/problem/126/B)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only) & Codeforces Beta Round #93 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|249|[Caesar's Legions](http://codeforces.com/problemset/problem/118/D)|Codeforces||Codeforces Beta Round #89 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|250|[Bar Codes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1662)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|251|[Chest of Drawers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2415)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|252|[Marks Distribution](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1851)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|253|[Flight Planner](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1278)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|254|[Ministry](http://acm.timus.ru/problem.aspx?space=1&num=1029)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|255|[Railway Tickets](http://acm.timus.ru/problem.aspx?space=1&num=1031)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|256|[Anniversary Party](http://acm.timus.ru/problem.aspx?space=1&num=1039)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|257|[Segments](http://acm.timus.ru/problem.aspx?space=1&num=1078)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|258|[False Mirrors](http://acm.timus.ru/problem.aspx?space=1&num=1152)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|259|[Bicolored Horses](http://acm.timus.ru/problem.aspx?space=1&num=1167)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|260|[Brackets Sequence](http://acm.timus.ru/problem.aspx?space=1&num=1183)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|261|[Nudnik Photographer](http://acm.timus.ru/problem.aspx?space=1&num=1260)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|262|[Threeprime Numbers](http://acm.timus.ru/problem.aspx?space=1&num=1586)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|263|[BATMAN1](http://www.spoj.com/problems/BAT1/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|264|[BATMAN2](http://www.spoj.com/problems/BAT2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|265|[Leaves](http://www.spoj.com/problems/NKLEAVES/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|266|[Problem 3](http://www.spoj.com/problems/NOVICE43/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|267|[Chop Ahoy! Revisited!](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1541)|Live Archive|2005|Africa/Middle East - Arab and North Africa|2|
|<ul><li>- [ ] Done</li></ul>|268|[Mosaic](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2609)|Live Archive|2009|North America - Southeast USA|2|
|<ul><li>- [ ] Done</li></ul>|269|[BATMAN3](http://www.spoj.com/problems/BAT3/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|270|[Drop the Triples](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1931)|Live Archive|2007|Latin America - South America|2|
|<ul><li>- [ ] Done</li></ul>|271|[Always on the run](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=531)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|272|[Bit Mask](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1659)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|273|[Space Elevator](http://poj.org/problem?id=2392)|PKU|||2|
|<ul><li>- [ ] Done</li></ul>|274|[Mobile Service](http://www.spoj.com/problems/SERVICE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|275|[Optimal Binary Search Tree](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1245)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|276|[Ice Sculptures](http://codeforces.com/problemset/problem/158/D)|Codeforces||VK Cup 2012 Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|277|[Little Elephant and Painting](http://www.codechef.com/problems/LEPAINT)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|278|[Chopsticks](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1212)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|279|[Beautiful People](http://acm.sgu.ru/problem.php?contest=0&problem=199)|SGU|||2|
|<ul><li>- [ ] Done</li></ul>|280|[Erdos Numbers](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=206)|Live Archive|2000|Europe - Northwestern & Europe - Southwestern & Europe - Mid-Central|2|
|<ul><li>- [ ] Done</li></ul>|281|[Weights and Measures](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1095)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|282|[Handball](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4663)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|283|[String to Palindrome](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1680)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|284|[Black-White Grid](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1674)|Live Archive|2006|Asia - Hanoi|2|
|<ul><li>- [ ] Done</li></ul>|285|[George and Job](http://codeforces.com/problemset/problem/467/C)|Codeforces||Codeforces Round #267 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|286|[Cow Frisbee Team](http://acm.tju.edu.cn/toj/showp3208.html)|TJU|||2|
|<ul><li>- [ ] Done</li></ul>|287|[String Partition](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2225)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|288|[Tower of Cubes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=992)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|289|[Pebble Solitaire](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1592)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|290|[String Computer](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=100)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|291|[Make Palindrome](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1394)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|292|[String Distance and Transform Process](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=467)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|293|[Again Palindrome](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1558)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|294|[Slurpys](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=320)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|295|[The Marriage Interview :-)](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1387)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|296|[Simple Minded Hashing](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1853)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|297|[Murcia's Skyline](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2890)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|298|[Diving for Gold](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=931)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|299|[Trouble of 13-Dots](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1760)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|300|[Longest Match](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1041)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|301|[Sum of Different Primes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3654)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|302|[Walking on the Safe Side](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=766)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|303|[Pebbles](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1996)|Live Archive|2007|North America - Pacific Northwest & North America - Southern California|2|
|<ul><li>- [ ] Done</li></ul>|304|[Game of Sum](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1832)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|305|[Fibonacci System](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2377)|Live Archive|2008|Europe - Northeastern|2|
|<ul><li>- [ ] Done</li></ul>|306|[Painting the balls](http://acm.sgu.ru/problem.php?contest=0&problem=183)|SGU|||2|
|<ul><li>- [ ] Done</li></ul>|307|[Destruction Cannon](https://www.urionlinejudge.com.br/judge/en/problems/view/1288)|URI|||2|
|<ul><li>- [ ] Done</li></ul>|308|[Travelling Salesman](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1643)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|309|[Rain](http://www.spoj.com/problems/RAIN3/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|310|[Fibo](p?ID=150)|A2 Online Judge|||2|
|<ul><li>- [ ] Done</li></ul>|311|[Boxes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1944)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|312|[Counting binary strings](http://www.spoj.com/problems/STRCOUNT/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|313|[Motoboy](https://www.urionlinejudge.com.br/judge/en/problems/view/1286)|URI|||2|
|<ul><li>- [ ] Done</li></ul>|314|[Color the Fence](http://codeforces.com/problemset/problem/349/B)|Codeforces||Codeforces Round #202 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|315|[KTV](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2159)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|316|[Tight Words](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1022)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|317|[Square](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1305)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|318|[Soldier and Number Game](http://codeforces.com/problemset/problem/546/D)|Codeforces||Codeforces Round #304 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|319|[1807](http://www.spoj.com/problems/SMILEY1807/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|320|[Geometric Progression](http://codeforces.com/problemset/problem/567/C)|Codeforces||Codeforces Round #Pi (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|321|[Land Acquisition](http://www.spoj.com/problems/ACQUIRE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|322|[Restoring Password](http://codeforces.com/problemset/problem/94/A)|Codeforces||Codeforces Beta Round #76 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|323|[New Year and Domino](http://codeforces.com/problemset/problem/611/C)|Codeforces||Good Bye 2015|2|
|<ul><li>- [ ] Done</li></ul>|324|[Chain Reaction](http://codeforces.com/problemset/problem/607/A)|Codeforces||Codeforces Round #336 (Div. 1) & Codeforces Round #336 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|325|[Alternative Thinking](http://codeforces.com/problemset/problem/603/A)|Codeforces||Codeforces Round #334 (Div. 1) & Codeforces Round #334 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|326|[Approximating a Constant Range](http://codeforces.com/problemset/problem/602/B)|Codeforces||Codeforces Round #333 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|327|[Modulo Sum](http://codeforces.com/problemset/problem/577/B)|Codeforces||Codeforces Round #319 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|328|[Kyoya and Colored Balls](http://codeforces.com/problemset/problem/553/A)|Codeforces||Codeforces Round #309 (Div. 1) & Codeforces Round #309 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|329|[Covered Path](http://codeforces.com/problemset/problem/534/B)|Codeforces||Codeforces Round #298 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|330|[Photo to Remember](http://codeforces.com/problemset/problem/522/B)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|331|[Reposts](http://codeforces.com/problemset/problem/522/A)|Codeforces||VK Cup 2015 - Qualification Round 1|2|
|<ul><li>- [ ] Done</li></ul>|332|[Mr. Kitayuta's Colorful Graph](http://codeforces.com/problemset/problem/506/D)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|333|[DZY Loves Sequences](http://codeforces.com/problemset/problem/446/A)|Codeforces||Codeforces Round #255 (Div. 1) & Codeforces Round #255 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|334|[Inna and Choose Options](http://codeforces.com/problemset/problem/400/A)|Codeforces||Codeforces Round #234 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|335|[Polo the Penguin and Matrix](http://codeforces.com/problemset/problem/289/B)|Codeforces||Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|336|[Mr. Kitayuta's Gift](http://codeforces.com/problemset/problem/505/A)|Codeforces||Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1) & Codeforces Round #286 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|337|[Dancing Cows](http://www.spoj.com/problems/DCOWS/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|338|[Vasya and String](http://codeforces.com/problemset/problem/676/C)|Codeforces||Codeforces Round #354 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|339|[Bing it](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2765)|Live Archive|2009|Asia - Harbin|2|
|<ul><li>- [ ] Done</li></ul>|340|[Wooden Sticks](http://www.spoj.com/problems/MSTICK/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|341|[Sequence](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4813)|Live Archive|2014|Asia - Kuala Lumpur|2|
|<ul><li>- [ ] Done</li></ul>|342|[Concert Tour](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4865)|Live Archive|2014|Asia - Bangkok|2|
|<ul><li>- [ ] Done</li></ul>|343|[Shopping](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4846)|Live Archive|2014|Asia - Tokyo|2|
|<ul><li>- [ ] Done</li></ul>|344|[Maximum sum on a torus](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1768)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|345|[Maximum Sub-sequence Product](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=728)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|346|[Another Longest Increasing Subsequence Problem](http://www.spoj.com/problems/LIS2/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|347|[Hard problem](http://codeforces.com/problemset/problem/706/C)|Codeforces||Codeforces Round #367 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|348|[Triangular N-Queens Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1573)|Live Archive|2006|North America - Greater NY|2|
|<ul><li>- [ ] Done</li></ul>|349|[Pay the Price](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1254)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|350|[Making Change](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=102)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|351|[Functions again](http://codeforces.com/problemset/problem/788/A)|Codeforces||Codeforces Round #407 (Div. 1) & Codeforces Round #407 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|352|[Tennis Championship](http://codeforces.com/problemset/problem/735/C)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|2|
|<ul><li>- [ ] Done</li></ul>|353|[Timofey and a tree](http://codeforces.com/problemset/problem/763/A)|Codeforces||Codeforces Round #395 (Div. 1) & Codeforces Round #395 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|354|[Pride](http://codeforces.com/problemset/problem/891/A)|Codeforces||Codeforces Round #446 (Div. 1) & Codeforces Round #446 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|355|[Game of Credit Cards](http://codeforces.com/problemset/problem/777/B)|Codeforces||Codeforces Round #401 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|356|[Journey](http://codeforces.com/problemset/problem/839/C)|Codeforces||Codeforces Round #428 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|357|[A DP Problem](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=973)|Live Archive|2003|Asia - Tehran|2|
|<ul><li>- [ ] Done</li></ul>|358|[Polo the Penguin and Strings](http://codeforces.com/problemset/problem/288/A)|Codeforces||Codeforces Round #177 (Div. 1) & Codeforces Round #177 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|359|[Ra-One Numbers](http://www.spoj.com/problems/RAONE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|360|[G-One Numbers](http://www.spoj.com/problems/GONE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|361|[LUCIFER Number](http://www.spoj.com/problems/LUCIFER/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|362|[Squares](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2402)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|363|[Ferry Loading](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1202)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|364|[Unnatural Conditions](http://codeforces.com/problemset/problem/1028/B)|Codeforces||AIM Tech Round 5 (rated, Div. 1 + Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|365|[Sinking Ship](http://codeforces.com/problemset/problem/63/A)|Codeforces||Codeforces Beta Round #59 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|366|[Quadratic Equation](http://www.spoj.com/problems/QUADRATE/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|367|[Candy (Again)](http://www.spoj.com/problems/FCANDY/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|368|[Slikar](http://www.spoj.com/problems/SLIKAR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|369|[Palindromic Subsequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2399)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|370|[String reduction](http://www.spoj.com/problems/STREDUCE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|371|[Paid Roads](http://www.spoj.com/problems/MMINPAID/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|372|[Common Subsequences](http://www.spoj.com/problems/CSUBSEQS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|373|[Even Palindrome](http://www.spoj.com/problems/PALDR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|374|[The Secret of an Aerolite](http://www.spoj.com/problems/AEROLITE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|375|[Hackers' Crackdown](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2925)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|376|[Minus Operation](http://www.spoj.com/problems/MINUS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|377|[Partition the sequence](http://www.spoj.com/problems/SEQPAR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|378|[Traveling by Stagecoach](http://www.spoj.com/problems/TRSTAGE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|379|[Maximum Triangle Area](http://www.spoj.com/problems/MTRIAREA/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|380|[Polygon](http://www.spoj.com/problems/MPOLY/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|381|[Help Bob](http://www.spoj.com/problems/HELPBOB/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|382|[Many polygons](http://www.spoj.com/problems/NGON/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|383|[Fast Food](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=603)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|384|[Budget Travel](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=158)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|385|[Free Candies](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1059)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|386|[Physics Practical](http://codeforces.com/problemset/problem/253/B)|Codeforces||Codeforces Round #154 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|387|[To Add or Not to Add](http://codeforces.com/problemset/problem/231/C)|Codeforces||Codeforces Round #143 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|388|[Barcode](http://codeforces.com/problemset/problem/225/C)|Codeforces||Codeforces Round #139 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|389|[Choosing Capital for Treeland](http://codeforces.com/problemset/problem/219/D)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|390|[Little Elephant and Interval](http://codeforces.com/problemset/problem/204/A)|Codeforces||Codeforces Round #129 (Div. 1) & Codeforces Round #129 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|391|[Distance in Tree](http://codeforces.com/problemset/problem/161/D)|Codeforces||VK Cup 2012 Round 1|3|
|<ul><li>- [ ] Done</li></ul>|392|[Longest Regular Bracket Sequence](http://codeforces.com/problemset/problem/5/C)|Codeforces||Codeforces Beta Round #5|3|
|<ul><li>- [ ] Done</li></ul>|393|[Mysterious Present](http://codeforces.com/problemset/problem/4/D)|Codeforces||Codeforces Beta Round #4 (Div. 2 Only)|3|
|<ul><li>- [ ] Done</li></ul>|394|[The least round way](http://codeforces.com/problemset/problem/2/B)|Codeforces||Codeforces Beta Round #2|3|
|<ul><li>- [ ] Done</li></ul>|395|[ZigZag](http://community.topcoder.com/stat?c=problem_statement&pm=1259)|TopCoder||TCCC '03 Semifinals 3 - Div1 easy] (4493)|3|
|<ul><li>- [ ] Done</li></ul>|396|[BadNeighbors](http://community.topcoder.com/stat?c=problem_statement&pm=2402)|TopCoder||TCCC '04 Round 4 - Div1 easy] (5009)|3|
|<ul><li>- [ ] Done</li></ul>|397|[Hierarchy](http://acm.timus.ru/problem.aspx?space=1&num=1117)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|398|[Gentlemen](http://acm.timus.ru/problem.aspx?space=1&num=1244)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|399|[Minimal Coverage](http://acm.timus.ru/problem.aspx?space=1&num=1303)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|400|[Intervals of Monotonicity](http://acm.timus.ru/problem.aspx?space=1&num=1346)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|401|[Sense of Beauty](http://acm.timus.ru/problem.aspx?space=1&num=1501)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|402|[Mnemonics and Palindromes](http://acm.timus.ru/problem.aspx?space=1&num=1635)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|403|[Raucous Rockers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=414)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|404|[COUNT PAREN](http://www.spoj.com/problems/PAREN/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|405|[How Many O's?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1979)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|406|[Bribe the Prisoners](http://www.spoj.com/problems/GCJ1C09C/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|407|[I-Keyboard](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=162)|Live Archive|2000|Europe - Central|3|
|<ul><li>- [ ] Done</li></ul>|408|[Orchard Trees](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=79)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|409|[Determine it](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1461)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|410|[Car with powers](http://www.spoj.com/problems/POWERCAR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|411|[Make Psycho](http://www.spoj.com/problems/PSYCHO3/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|412|[Most Servings Meal](http://www.spoj.com/problems/MKUHAR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|413|[Term Strategy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2316)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|414|[Best Coalitions](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2705)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|415|[RGBStreet](http://community.topcoder.com/stat?c=problem_statement&pm=6680)|TopCoder||SRM 325 - Div2 medium] (10005)|3|
|<ul><li>- [ ] Done</li></ul>|416|[Cards, bags and coins](http://www.codechef.com/problems/ANUCBC)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|417|[Sereja and Game](http://www.codechef.com/problems/SEAGM)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|418|[Little Elephant and Movies](http://www.codechef.com/problems/LEMOVIE)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|419|[Zeta-Nim Game](http://www.codechef.com/problems/TAKEAWAY)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|420|[The Matrix Game](http://www.codechef.com/problems/SNCK01)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|421|[Pleasing Chief](http://www.codechef.com/problems/CHIEFETT)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|422|[Maximum Absurdity](http://codeforces.com/problemset/problem/332/B)|Codeforces||Codeforces Round #193 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|423|[Building Bridges(HARD)](http://www.spoj.com/problems/BRDGHRD/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|424|[Gargari and Permutations](http://codeforces.com/problemset/problem/463/D)|Codeforces||Codeforces Round #264 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|425|[Fetching Cooking Tools](http://www.codechef.com/problems/TOOLS)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|426|[Color Stripe](http://codeforces.com/problemset/problem/219/C)|Codeforces||Codeforces Round #135 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|427|[Crime Wave - The Sequel](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1687)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|428|[Many Paths, One Destination](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=929)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|429|[Scheduling Lectures](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=548)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|430|[AGTC](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3648)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|431|[Hippity Hopscotch](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1200)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|432|[Little Red Riding Hood](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2008)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|433|[Walking Around Wisely](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=867)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|434|[Probablistic OR](http://www.spoj.com/problems/PROBOR/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|435|[End up with More Teams](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2029)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|436|[Fewest Flops](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2547)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|437|[IOI07 Miners](http://www.spoj.com/problems/NKMINERS/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|438|[Beautiful Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2467)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|439|[Mr. Kitayuta, the Treasure Hunter](http://codeforces.com/problemset/problem/505/C)|Codeforces||Codeforces Round #286 (Div. 2) & Codeforces Round #286 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|440|[Dynamic LCA](http://www.spoj.com/problems/DYNALCA/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|441|[Sum of Digits](http://acm.timus.ru/problem.aspx?space=1&num=1658)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|442|[Tour](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4093)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|443|[Count Paths](p?ID=157)|A2 Online Judge|||3|
|<ul><li>- [ ] Done</li></ul>|444|[Plug-in](http://codeforces.com/problemset/problem/81/A)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|3|
|<ul><li>- [ ] Done</li></ul>|445|[Internet Address](http://codeforces.com/problemset/problem/245/B)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|3|
|<ul><li>- [ ] Done</li></ul>|446|[Petya and Java](http://codeforces.com/problemset/problem/66/A)|Codeforces||Codeforces Beta Round #61 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|447|[Lazy Math Instructor](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=57)|Live Archive|2000|Asia - Tehran|3|
|<ul><li>- [ ] Done</li></ul>|448|[Simple Strings](http://codeforces.com/problemset/problem/665/C)|Codeforces||Educational Codeforces Round 12|3|
|<ul><li>- [ ] Done</li></ul>|449|[Hard Process](http://codeforces.com/problemset/problem/660/C)|Codeforces||Educational Codeforces Round 11|3|
|<ul><li>- [ ] Done</li></ul>|450|[Bear and Compressing](http://codeforces.com/problemset/problem/653/B)|Codeforces||IndiaHacks 2016 - Online Edition (Div. 1 + Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|451|[New Skateboard](http://codeforces.com/problemset/problem/628/B)|Codeforces||Educational Codeforces Round 8|3|
|<ul><li>- [ ] Done</li></ul>|452|[Cards](http://codeforces.com/problemset/problem/626/B)|Codeforces||8VC Venture Cup 2016 - Elimination Round|3|
|<ul><li>- [ ] Done</li></ul>|453|[Longtail Hedgehog](http://codeforces.com/problemset/problem/615/B)|Codeforces||Codeforces Round #338 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|454|[Zuma](http://codeforces.com/problemset/problem/607/B)|Codeforces||Codeforces Round #336 (Div. 1) & Codeforces Round #336 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|455|[Kefa and Dishes](http://codeforces.com/problemset/problem/580/D)|Codeforces||Codeforces Round #321 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|456|[Bear and Blocks](http://codeforces.com/problemset/problem/573/B)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1) & Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|457|[Vanya and Scales](http://codeforces.com/problemset/problem/552/C)|Codeforces||Codeforces Round #308 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|458|[Mike and Feet](http://codeforces.com/problemset/problem/547/B)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|459|[Writing Code](http://codeforces.com/problemset/problem/543/A)|Codeforces||Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|460|[A and B and Interesting Substrings](http://codeforces.com/problemset/problem/519/D)|Codeforces||Codeforces Round #294 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|461|[Ilya and Escalator](http://codeforces.com/problemset/problem/518/D)|Codeforces||Codeforces Round #293 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|462|[Painting Fence](http://codeforces.com/problemset/problem/448/C)|Codeforces||Codeforces Round #256 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|463|[Working out](http://codeforces.com/problemset/problem/429/B)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|464|[Booking System](http://codeforces.com/problemset/problem/416/C)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|465|[Art Union](http://codeforces.com/problemset/problem/416/B)|Codeforces||Codeforces Round #241 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|466|[Long Path](http://codeforces.com/problemset/problem/407/B)|Codeforces||Codeforces Round #239 (Div. 1) & Codeforces Round #239 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|467|[Bear and Prime Numbers](http://codeforces.com/problemset/problem/385/C)|Codeforces||Codeforces Round #226 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|468|[Permutation](http://codeforces.com/problemset/problem/359/B)|Codeforces||Codeforces Round #209 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|469|[Bubble Sort Graph](http://codeforces.com/problemset/problem/340/D)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|3|
|<ul><li>- [ ] Done</li></ul>|470|[Xenia and Weights](http://codeforces.com/problemset/problem/339/C)|Codeforces||Codeforces Round #197 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|471|[Greg and Graph](http://codeforces.com/problemset/problem/295/B)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|472|[Ladder](http://codeforces.com/problemset/problem/279/C)|Codeforces||Codeforces Round #171 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|473|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces||Codeforces Round #169 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|474|[Greenhouse Effect](http://codeforces.com/problemset/problem/269/B)|Codeforces||Codeforces Round #165 (Div. 1) & Codeforces Round #165 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|475|[Good Sequences](http://codeforces.com/problemset/problem/264/B)|Codeforces||Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|476|[Omar Loves Candies](p?ID=10)|A2 Online Judge|||3|
|<ul><li>- [ ] Done</li></ul>|477|[Robbers' watch](http://codeforces.com/problemset/problem/685/A)|Codeforces||Codeforces Round #359 (Div. 1) & Codeforces Round #359 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|478|[Recycling Bottles](http://codeforces.com/problemset/problem/671/A)|Codeforces||Codeforces Round #352 (Div. 1) & Codeforces Round #352 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|479|[Alyona and the Tree](http://codeforces.com/problemset/problem/682/C)|Codeforces||Codeforces Round #358 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|480|[Greedy Hydra](http://www.spoj.com/problems/DRAGON/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|481|[Coloring Trees](http://codeforces.com/problemset/problem/711/C)|Codeforces||Codeforces Round #369 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|482|[Triangles](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4794)|Live Archive|2014|South Pacific|3|
|<ul><li>- [ ] Done</li></ul>|483|[Ada and Game](http://www.spoj.com/problems/ADAGAME/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|484|[An impassioned circulation of affection](http://codeforces.com/problemset/problem/814/C)|Codeforces||Codeforces Round #418 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|485|[The Debut Album](http://acm.timus.ru/problem.aspx?space=1&num=2018)|Timus|||3|
|<ul><li>- [ ] Done</li></ul>|486|[String Popping](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3702)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|487|[FOODIE](http://www.spoj.com/problems/FOODIE/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|488|[Shopping Trip](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2259)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|489|[Arpa's weak amphitheater and Mehrdad's valuable Hoses](http://codeforces.com/problemset/problem/741/B)|Codeforces||Codeforces Round #383 (Div. 1) & Codeforces Round #383 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|490|[Hopeless Coach](http://acm.tju.edu.cn/toj/showp3051.html)|TJU|||3|
|<ul><li>- [ ] Done</li></ul>|491|[Alyona and Spreadsheet](http://codeforces.com/problemset/problem/777/C)|Codeforces||Codeforces Round #401 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|492|[Sagheer, the Hausmeister](http://codeforces.com/problemset/problem/812/B)|Codeforces||Codeforces Round #417 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|493|[Mike and gcd problem](http://codeforces.com/problemset/problem/798/C)|Codeforces||Codeforces Round #410 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|494|[Mahmoud and a Message](http://codeforces.com/problemset/problem/766/C)|Codeforces||Codeforces Round #396 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|495|[Journey](http://codeforces.com/problemset/problem/721/C)|Codeforces||Codeforces Round #374 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|496|[Re-Arrange II](http://www.spoj.com/problems/MAIN112/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|497|[Combo Deal](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1839)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|498|[ACM (ACronym Maker)](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1373)|Live Archive|2005|North America - East Central NA|3|
|<ul><li>- [ ] Done</li></ul>|499|[Save the problem!](http://codeforces.com/problemset/problem/865/A)|Codeforces||MemSQL Start[c]UP 3.0 - Round 2 (onsite finalists)|3|
|<ul><li>- [ ] Done</li></ul>|500|[The Vindictive Coach](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=643)|UVA|||3|
|<ul><li>- [ ] Done</li></ul>|501|[Boy Scouts](http://www.spoj.com/problems/BOYSCOUT/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|502|[Antimonotonicity](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2181)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|503|[Let go to the movies](http://www.spoj.com/problems/ANARC07G/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|504|[Who is The Boss](http://www.spoj.com/problems/VBOSS/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|505|[Drop the Triples](http://www.spoj.com/problems/DTT/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|506|[Najkraci](http://www.spoj.com/problems/NAJKRACI/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|507|[Convex Polygons](http://www.spoj.com/problems/CVXPOLY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|508|[Trees Again](http://www.spoj.com/problems/CNTTREE/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|509|[Batman](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2509)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|510|[Almost Arithmetical Progression](http://codeforces.com/problemset/problem/255/C)|Codeforces||Codeforces Round #156 (Div. 2) & Codeforces Round #156 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|511|[Chilly Willy](http://codeforces.com/problemset/problem/248/B)|Codeforces||Codeforces Round #152 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|512|[Queries for Number of Palindromes](http://codeforces.com/problemset/problem/245/H)|Codeforces||CROC-MBTU 2012, Elimination Round (ACM-ICPC)|4|
|<ul><li>- [ ] Done</li></ul>|513|[Weather](http://codeforces.com/problemset/problem/234/C)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|514|[Hometask](http://codeforces.com/problemset/problem/214/B)|Codeforces||Codeforces Round #131 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|515|[Palindrome pairs](http://codeforces.com/problemset/problem/159/D)|Codeforces||VK Cup 2012 Qualification Round 2|4|
|<ul><li>- [ ] Done</li></ul>|516|[Message](http://codeforces.com/problemset/problem/156/A)|Codeforces||Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|517|[Hometask](http://codeforces.com/problemset/problem/154/A)|Codeforces||Codeforces Round #109 (Div. 1) & Codeforces Round #109 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|518|[Bag of mice](http://codeforces.com/problemset/problem/148/D)|Codeforces||Codeforces Round #105 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|519|[Buns](http://codeforces.com/problemset/problem/106/C)|Codeforces||Codeforces Beta Round #82 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|520|[Enemy is weak](http://codeforces.com/problemset/problem/61/E)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|521|[Eternal Victory](http://codeforces.com/problemset/problem/61/D)|Codeforces||Codeforces Beta Round #57 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|522|[Fatawy](http://www.spoj.com/problems/FATAWY/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|523|[Malevich Strikes Back!](http://acm.timus.ru/problem.aspx?space=1&num=1221)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|524|[Folding](http://acm.timus.ru/problem.aspx?space=1&num=1238)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|525|[Mars Canals](http://acm.timus.ru/problem.aspx?space=1&num=1287)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|526|[Bottle Taps](http://acm.timus.ru/problem.aspx?space=1&num=1326)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|527|[Classmates 2](http://acm.timus.ru/problem.aspx?space=1&num=1362)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|528|[Crack](http://acm.timus.ru/problem.aspx?space=1&num=1410)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|529|[SMS](http://acm.timus.ru/problem.aspx?space=1&num=1427)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|530|[Gasoline Station](http://acm.timus.ru/problem.aspx?space=1&num=1437)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|531|[One-two, One-two 2](http://acm.timus.ru/problem.aspx?space=1&num=1495)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|532|[Lemon Tale](http://acm.timus.ru/problem.aspx?space=1&num=1513)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|533|[Communication Fiend](http://acm.timus.ru/problem.aspx?space=1&num=1741)|Timus|||4|
|<ul><li>- [ ] Done</li></ul>|534|[Chocolate](http://www.spoj.com/problems/SOCOLA/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|535|[ICPC Team Strategy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3681)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|536|[Zeros and Ones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3215)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|537|[BATMAN4](http://www.spoj.com/problems/BAT4/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|538|[Bit by Bit](http://www.spoj.com/problems/DCEPC807/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|539|[The Bridges of Kolsberg](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3613)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|540|[Busy Programmer](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2427)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|541|[Chocolate Box](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1589)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|542|[Digit Sum](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3962)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|543|[Dominoes](http://www.spoj.com/problems/DOMINOES/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|544|[Tiling Dominoes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2245)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|545|[INVITATION FOR TECHOFES](http://www.spoj.com/problems/TECHOFES/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|546|[Expect the Expected](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2422)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|547|[Dumb Bones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1470)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|548|[Minion Circle](http://www.codechef.com/problems/CIRCLE)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|549|[Lov-e Pap Pap-e Polti](http://www.spoj.com/problems/LPPP/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|550|[Little Elephant and Blocks](http://www.codechef.com/problems/LEBLOCKS)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|551|[Pashmak and Graph](http://codeforces.com/problemset/problem/459/E)|Codeforces||Codeforces Round #261 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|552|[Magic, Wizardry and Wonders](http://codeforces.com/problemset/problem/231/B)|Codeforces||Codeforces Round #143 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|553|[Another Assignment Problem](http://www.spoj.com/problems/ASSIGN4/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|554|[Little Pony and Harmony Chest](http://codeforces.com/problemset/problem/453/B)|Codeforces||Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|555|[Matchsticks](http://acm.tju.edu.cn/toj/showp3817.html)|TJU|||4|
|<ul><li>- [ ] Done</li></ul>|556|[Antimatter Ray Clearcutting](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1949)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|557|[Bright Bracelet](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=785)|Live Archive|2003|North America - Mid-Central USA|4|
|<ul><li>- [ ] Done</li></ul>|558|[Fortune Telling](http://codeforces.com/problemset/problem/59/B)|Codeforces||Codeforces Beta Round #55 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|559|[Balanced Numbers](http://www.spoj.com/problems/BALNUM/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|560|[Avoiding Jungle in the Dark](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2540)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|561|[Account Book](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2932)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|562|[Matches](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2370)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|563|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|564|[A Lot of Games](http://codeforces.com/problemset/problem/455/B)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|565|[Red-Green Towers](http://codeforces.com/problemset/problem/478/D)|Codeforces||Codeforces Round #273 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|566|[Number of Paths in the Empire](http://acm.sgu.ru/problem.php?contest=0&problem=407)|SGU|||4|
|<ul><li>- [ ] Done</li></ul>|567|[Civilization](http://codeforces.com/problemset/problem/455/C)|Codeforces||Codeforces Round #260 (Div. 1) & Codeforces Round #260 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|568|[Fools and Roads](http://codeforces.com/problemset/problem/191/C)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|569|[DIVSEQ](http://www.spoj.com/problems/DIVSEQ/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|570|[Dima and Salad](http://codeforces.com/problemset/problem/366/C)|Codeforces||Codeforces Round #214 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|571|[Image Preview](http://codeforces.com/problemset/problem/650/B)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|572|[Babaei and Birthday Cake](http://codeforces.com/problemset/problem/629/D)|Codeforces||Codeforces Round #343 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|573|[XOR Equation](http://codeforces.com/problemset/problem/627/A)|Codeforces||8VC Venture Cup 2016 - Final Round|4|
|<ul><li>- [ ] Done</li></ul>|574|[Once Again...](http://codeforces.com/problemset/problem/582/B)|Codeforces||Codeforces Round #323 (Div. 1) & Codeforces Round #323 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|575|[Gerald and Giant Chess](http://codeforces.com/problemset/problem/559/C)|Codeforces||Codeforces Round #313 (Div. 1) & Codeforces Round #313 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|576|[Arthur and Table](http://codeforces.com/problemset/problem/557/C)|Codeforces||Codeforces Round #311 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|577|[Bad Luck Island](http://codeforces.com/problemset/problem/540/D)|Codeforces||Codeforces Round #301 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|578|[Clique Problem](http://codeforces.com/problemset/problem/527/D)|Codeforces||Codeforces Round #296 (Div. 2) & Codeforces Round #296 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|579|[A and B and Lecture Rooms](http://codeforces.com/problemset/problem/519/E)|Codeforces||Codeforces Round #294 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|580|[Riding in a Lift](http://codeforces.com/problemset/problem/479/E)|Codeforces||Codeforces Round #274 (Div. 2) & Codeforces Round #274 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|581|[Appleman and Tree](http://codeforces.com/problemset/problem/461/B)|Codeforces||Codeforces Round #263 (Div. 1) & Codeforces Round #263 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|582|[Prefixes and Suffixes](http://codeforces.com/problemset/problem/432/D)|Codeforces||Codeforces Round #246 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|583|[Maximum Submatrix 2](http://codeforces.com/problemset/problem/375/B)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|584|[Jeff and Rounding](http://codeforces.com/problemset/problem/351/A)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|585|[Book of Evil](http://codeforces.com/problemset/problem/337/D)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|586|[Shaass and Bookshelf](http://codeforces.com/problemset/problem/294/B)|Codeforces||Codeforces Round #178 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|587|[Cow Program](http://codeforces.com/problemset/problem/283/B)|Codeforces||Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|588|[Zero Tree](http://codeforces.com/problemset/problem/274/B)|Codeforces||Codeforces Round #168 (Div. 1) & Codeforces Round #168 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|589|[Letter](http://codeforces.com/problemset/problem/180/C)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|4|
|<ul><li>- [ ] Done</li></ul>|590|[Round Table Knights](http://codeforces.com/problemset/problem/71/C)|Codeforces||Codeforces Beta Round #65 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|591|[Reberland Linguistics](http://codeforces.com/problemset/problem/666/A)|Codeforces||Codeforces Round #349 (Div. 1) & Codeforces Round #349 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|592|[The Child and Zoo](http://codeforces.com/problemset/problem/437/D)|Codeforces||Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|593|[The Values You Can Make](http://codeforces.com/problemset/problem/687/C)|Codeforces||Codeforces Round #360 (Div. 1) & Codeforces Round #360 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|594|[Ingredients](http://www.spoj.com/problems/INGRED/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|595|[Generate a String](http://codeforces.com/problemset/problem/710/E)|Codeforces||Educational Codeforces Round 16|4|
|<ul><li>- [ ] Done</li></ul>|596|[Forming Teams](http://codeforces.com/problemset/problem/216/B)|Codeforces||Codeforces Round #133 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|597|[Can U Win?](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2400)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|598|[Bridge Building](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=917)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|599|[Cái túi ( Hard version )](http://vn.spoj.com/problems/HUGEKNAP/)|SPOJ Vietnam|||4|
|<ul><li>- [ ] Done</li></ul>|600|[Drazil and Tiles](http://codeforces.com/problemset/problem/515/D)|Codeforces||Codeforces Round #292 (Div. 2) & Codeforces Round #292 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|601|[Going Postal](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4799)|Live Archive|2014|South Pacific|4|
|<ul><li>- [ ] Done</li></ul>|602|[Namit In Trouble](http://www.spoj.com/problems/NGIRL/)|SPOJ|||4|
|<ul><li>- [ ] Done</li></ul>|603|[New Year and Fireworks](http://codeforces.com/problemset/problem/750/D)|Codeforces||Good Bye 2016|4|
|<ul><li>- [ ] Done</li></ul>|604|[Pie Rules](http://codeforces.com/problemset/problem/859/C)|Codeforces||MemSQL Start[c]UP 3.0 - Round 1|4|
|<ul><li>- [ ] Done</li></ul>|605|[Fire](http://codeforces.com/problemset/problem/864/E)|Codeforces||Codeforces Round #436 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|606|[Rent your airplane and make money](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=943)|Live Archive|2003|Europe - Southwestern|4|
|<ul><li>- [ ] Done</li></ul>|607|[Vladik and Memorable Trip](http://codeforces.com/problemset/problem/811/C)|Codeforces||Codeforces Round #416 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|608|[Connecting Universities](http://codeforces.com/problemset/problem/700/B)|Codeforces||Codeforces Round #364 (Div. 1) & Codeforces Round #364 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|609|[Office Keys](http://codeforces.com/problemset/problem/830/A)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals) & Codeforces Round #424 (Div. 2, rated, based on VK Cup Finals)|4|
|<ul><li>- [ ] Done</li></ul>|610|[The Intriguing Obsession](http://codeforces.com/problemset/problem/869/C)|Codeforces||Codeforces Round #439 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|611|[Chloe and pleasant prizes](http://codeforces.com/problemset/problem/743/D)|Codeforces||Codeforces Round #384 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|612|[Divide and conquer](http://www.codechef.com/problems/F6)|CodeChef|||4|
|<ul><li>- [ ] Done</li></ul>|613|[Fire Again](http://codeforces.com/problemset/problem/35/C)|Codeforces||Codeforces Beta Round #35 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|614|[Binary Search](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=221)|Live Archive|2000|Europe - Northeastern|4|
|<ul><li>- [ ] Done</li></ul>|615|[Expression Again](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1631)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|616|[XOR-pyramid](http://codeforces.com/problemset/problem/983/B)|Codeforces||Codeforces Round #483 (Div. 1) [Thanks, Botan Investments and Victor Shaburov!] & Codeforces Round #483 (Div. 2) [Thanks, Botan Investments and Victor Shaburov!]|4|
|<ul><li>- [ ] Done</li></ul>|617|[Party](p?ID=124)|A2 Online Judge|||4|
|<ul><li>- [ ] Done</li></ul>|618|[Python Indentation](http://codeforces.com/problemset/problem/909/C)|Codeforces||Codeforces Round #455 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|619|[Cookies](http://codeforces.com/problemset/problem/70/A)|Codeforces||Codeforces Beta Round #64|4|
|<ul><li>- [ ] Done</li></ul>|620|[Philip J. Fry Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3746)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|621|[Free Parentheses](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3679)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|622|[Assignments](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3090)|Live Archive|2010|Asia - Harbin|4|
|<ul><li>- [ ] Done</li></ul>|623|[DNA Laboratory](http://www.spoj.com/problems/DNALAB/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|624|[Allergy Test](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2738)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|625|[Coin Changing Again](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2226)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|626|[Huffman´s Greed](http://www.spoj.com/problems/GREEDULM/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|627|[Connect Line Segments](http://www.spoj.com/problems/LINE/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|628|[Optimal Cut](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2882)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|629|[Independent Attacking Zones](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2103)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|630|[Clear Symmetry](http://codeforces.com/problemset/problem/201/A)|Codeforces||Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|631|[Dynasty Puzzles](http://codeforces.com/problemset/problem/191/A)|Codeforces||Codeforces Round #121 (Div. 1) & Codeforces Round #121 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|632|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces||Codeforces Round #112 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|633|[Substring and Subsequence](http://codeforces.com/problemset/problem/163/A)|Codeforces||VK Cup 2012 Round 2|5|
|<ul><li>- [ ] Done</li></ul>|634|[Porcelain](http://codeforces.com/problemset/problem/148/E)|Codeforces||Codeforces Round #105 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|635|[Logo Turtle](http://codeforces.com/problemset/problem/132/C)|Codeforces||Codeforces Beta Round #96 (Div. 1) & Codeforces Beta Round #96 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|636|[Games with Rectangle](http://codeforces.com/problemset/problem/128/C)|Codeforces||Codeforces Beta Round #94 (Div. 1 Only) & Codeforces Beta Round #94 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|637|[Spiders](http://codeforces.com/problemset/problem/120/F)|Codeforces||School Regional Team Contest, Saratov, 2011|5|
|<ul><li>- [ ] Done</li></ul>|638|[Petr#](http://codeforces.com/problemset/problem/113/B)|Codeforces||Codeforces Beta Round #86 (Div. 1 Only) & Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|639|[Basketball Team](http://codeforces.com/problemset/problem/107/B)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|640|[Number With The Given Amount Of Divisors](http://codeforces.com/problemset/problem/27/E)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|641|[Bargaining Table](http://codeforces.com/problemset/problem/22/B)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|642|[Checkout Assistant](http://codeforces.com/problemset/problem/19/B)|Codeforces||Codeforces Beta Round #19|5|
|<ul><li>- [ ] Done</li></ul>|643|[Sequence](http://codeforces.com/problemset/problem/13/C)|Codeforces||Codeforces Beta Round #13|5|
|<ul><li>- [ ] Done</li></ul>|644|[A Simple Task](http://codeforces.com/problemset/problem/11/D)|Codeforces||Codeforces Beta Round #11|5|
|<ul><li>- [ ] Done</li></ul>|645|[How many trees?](http://codeforces.com/problemset/problem/9/D)|Codeforces||Codeforces Beta Round #9 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|646|[K-based Numbers. Version 3](http://acm.timus.ru/problem.aspx?space=1&num=1013)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|647|[Ship Routes](http://acm.timus.ru/problem.aspx?space=1&num=1172)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|648|[Train](http://acm.timus.ru/problem.aspx?space=1&num=1276)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|649|[Enterprise](http://acm.timus.ru/problem.aspx?space=1&num=1342)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|650|[Cargo Agency](http://acm.timus.ru/problem.aspx?space=1&num=1371)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|651|[Roadworks](http://acm.timus.ru/problem.aspx?space=1&num=1389)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|652|[Happiness to People!](http://acm.timus.ru/problem.aspx?space=1&num=1463)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|653|[E-mail](http://acm.timus.ru/problem.aspx?space=1&num=1577)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|654|[Anniversary Firework](http://acm.timus.ru/problem.aspx?space=1&num=1776)|Timus|||5|
|<ul><li>- [ ] Done</li></ul>|655|[Atomic Car Race](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3652)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|656|[IPL - CRICKET TOURNAMENT](http://www.spoj.com/problems/IPL1/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|657|[The Islands](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3537)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|658|[Candy](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3298)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|659|[Fibonacci Words](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3895)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|660|[CreatureTraining](http://community.topcoder.com/stat?c=problem_statement&pm=8570)|TopCoder||TCO08 Round 2 - Div1 medium] (12012)|5|
|<ul><li>- [ ] Done</li></ul>|661|[Lucky Common Subsequence](http://codeforces.com/problemset/problem/346/B)|Codeforces||Codeforces Round #201 (Div. 1) & Codeforces Round #201 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|662|[Kalila and Dimna in the Logging Industry](http://codeforces.com/problemset/problem/319/C)|Codeforces||Codeforces Round #189 (Div. 1) & Codeforces Round #189 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|663|[JUMPING DORA](http://www.spoj.com/problems/JUMPDORA/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|664|[GO FOR DIAMONDS](http://www.spoj.com/problems/GO4DIMON/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|665|[Subsequence Problem](http://www.spoj.com/problems/SUBP/)|SPOJ|||5|
|<ul><li>- [ ] Done</li></ul>|666|[Weak Links](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4648)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|667|[Sereja and Bubble Sort](http://www.codechef.com/problems/SEABUB)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|668|[Count Digits](http://www.codechef.com/problems/CNTDIGIT)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|669|[Paint the Tree](http://www.codechef.com/problems/TREERGB)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|670|[Increase Sequence](http://codeforces.com/problemset/problem/466/D)|Codeforces||Codeforces Round #266 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|671|[WordMath](http://community.topcoder.com/stat?c=problem_statement&pm=6572)|TopCoder||Unknown ()|5|
|<ul><li>- [ ] Done</li></ul>|672|[Summing Slopes](http://www.codechef.com/problems/SUMSLOPE)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|673|[Patches](https://www.urionlinejudge.com.br/judge/en/problems/view/1475)|URI|||5|
|<ul><li>- [ ] Done</li></ul>|674|[Promotion](https://www.urionlinejudge.com.br/judge/en/problems/view/1624)|URI|||5|
|<ul><li>- [ ] Done</li></ul>|675|[Hotel](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1551)|Live Archive|2005|Asia - Tehran|5|
|<ul><li>- [ ] Done</li></ul>|676|[Antimatter](http://codeforces.com/problemset/problem/383/D)|Codeforces||Codeforces Round #225 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|677|[Two Paths](http://codeforces.com/problemset/problem/14/D)|Codeforces||Codeforces Beta Round #14 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|678|[Robot Rapping Results Report](http://codeforces.com/problemset/problem/645/D)|Codeforces||CROC 2016 - Elimination Round|5|
|<ul><li>- [ ] Done</li></ul>|679|[Running with Obstacles](http://codeforces.com/problemset/problem/637/D)|Codeforces||VK Cup 2016 - Qualification Round 1|5|
|<ul><li>- [ ] Done</li></ul>|680|[Spy Syndrome 2](http://codeforces.com/problemset/problem/633/C)|Codeforces||Manthan, Codefest 16|5|
|<ul><li>- [ ] Done</li></ul>|681|[Famil Door and Brackets](http://codeforces.com/problemset/problem/629/C)|Codeforces||Codeforces Round #343 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|682|[Wet Shark and Blocks](http://codeforces.com/problemset/problem/621/E)|Codeforces||Codeforces Round #341 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|683|[Running Track](http://codeforces.com/problemset/problem/615/C)|Codeforces||Codeforces Round #338 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|684|[Chocolate Bar](http://codeforces.com/problemset/problem/598/E)|Codeforces||Educational Codeforces Round 1|5|
|<ul><li>- [ ] Done</li></ul>|685|[Restaurant](http://codeforces.com/problemset/problem/597/B)|Codeforces||Testing Round #12|5|
|<ul><li>- [ ] Done</li></ul>|686|[Super M](http://codeforces.com/problemset/problem/592/D)|Codeforces||Codeforces Round #328 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|687|[Minimization](http://codeforces.com/problemset/problem/571/B)|Codeforces||Codeforces Round #317 [AimFund Thanks-Round] (Div. 1) & Codeforces Round #317 [AimFund Thanks-Round] (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|688|[Symmetric and Transitive](http://codeforces.com/problemset/problem/568/B)|Codeforces||Codeforces Round #315 (Div. 1) & Codeforces Round #315 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|689|[Clique in the Divisibility Graph](http://codeforces.com/problemset/problem/566/F)|Codeforces||VK Cup 2015 - Finals, online mirror|5|
|<ul><li>- [ ] Done</li></ul>|690|[Correcting Mistakes](http://codeforces.com/problemset/problem/533/E)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|5|
|<ul><li>- [ ] Done</li></ul>|691|[Inversions problem](http://codeforces.com/problemset/problem/513/G1)|Codeforces||Rockethon 2015|5|
|<ul><li>- [ ] Done</li></ul>|692|[Sums of Digits](http://codeforces.com/problemset/problem/509/C)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|5|
|<ul><li>- [ ] Done</li></ul>|693|[Breaking Good](http://codeforces.com/problemset/problem/507/E)|Codeforces||Codeforces Round #287 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|694|[Obsessive String](http://codeforces.com/problemset/problem/494/B)|Codeforces||Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|695|[Strip](http://codeforces.com/problemset/problem/487/B)|Codeforces||Codeforces Round #278 (Div. 1) & Codeforces Round #278 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|696|[Valid Sets](http://codeforces.com/problemset/problem/486/D)|Codeforces||Codeforces Round #277 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|697|[Pillars](http://codeforces.com/problemset/problem/474/E)|Codeforces||Codeforces Round #271 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|698|[Elimination](http://codeforces.com/problemset/problem/417/A)|Codeforces||RCC 2014 Warmup (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|699|[Upgrading Array](http://codeforces.com/problemset/problem/402/D)|Codeforces||Codeforces Round #236 (Div. 2) & Codeforces Round #236 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|700|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces||Codeforces Round #235 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|701|[Inna and Dima](http://codeforces.com/problemset/problem/374/C)|Codeforces||Codeforces Round #220 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|702|[Counting Rectangles is Fun](http://codeforces.com/problemset/problem/372/B)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|703|[Levko and Array](http://codeforces.com/problemset/problem/360/B)|Codeforces||Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|704|[Dima and Hares](http://codeforces.com/problemset/problem/358/D)|Codeforces||Codeforces Round #208 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|705|[Vasya and Beautiful Arrays](http://codeforces.com/problemset/problem/354/C)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|706|[Jeff and Furik](http://codeforces.com/problemset/problem/351/B)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|707|[The Great Julya Calendar](http://codeforces.com/problemset/problem/331/C1)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|5|
|<ul><li>- [ ] Done</li></ul>|708|[Ciel and Duel](http://codeforces.com/problemset/problem/321/B)|Codeforces||Codeforces Round #190 (Div. 1) & Codeforces Round #190 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|709|[Connected Components](http://codeforces.com/problemset/problem/292/D)|Codeforces||Croc Champ 2013 - Round 1|5|
|<ul><li>- [ ] Done</li></ul>|710|[Choosing Balls](http://codeforces.com/problemset/problem/264/C)|Codeforces||Codeforces Round #162 (Div. 1) & Codeforces Round #162 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|711|[Lucky Tree](http://codeforces.com/problemset/problem/109/C)|Codeforces||Codeforces Beta Round #84 (Div. 1 Only) & Codeforces Beta Round #84 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|712|[Iahub and Permutations](http://codeforces.com/problemset/problem/340/E)|Codeforces||Codeforces Round #198 (Div. 2) & Codeforces Round #198 (Div. 1)|5|
|<ul><li>- [ ] Done</li></ul>|713|[The Unreal Tournament](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1148)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|714|[Bear and Tower of Cubes](http://codeforces.com/problemset/problem/679/B)|Codeforces||Codeforces Round #356 (Div. 1) & Codeforces Round #356 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|715|[Alyona and Strings](http://codeforces.com/problemset/problem/682/D)|Codeforces||Codeforces Round #358 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|716|[Sum](http://codeforces.com/problemset/problem/49/B)|Codeforces||Codeforces Beta Round #46 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|717|[Longest Increasing Sequence](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2494)|UVA|||5|
|<ul><li>- [ ] Done</li></ul>|718|[Mario Kart](p?ID=12)|A2 Online Judge|||5|
|<ul><li>- [ ] Done</li></ul>|719|[Berzerk](http://codeforces.com/problemset/problem/786/A)|Codeforces||Codeforces Round #406 (Div. 1) & Codeforces Round #406 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|720|[The Bakery](http://codeforces.com/problemset/problem/833/B)|Codeforces||Codeforces Round #426 (Div. 1) & Codeforces Round #426 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|721|[An overnight dance in discotheque](http://codeforces.com/problemset/problem/814/D)|Codeforces||Codeforces Round #418 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|722|[Hanoi Factory](http://codeforces.com/problemset/problem/777/E)|Codeforces||Codeforces Round #401 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|723|[Square Subsets](http://codeforces.com/problemset/problem/895/C)|Codeforces||Codeforces Round #448 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|724|[Winter is here](http://codeforces.com/problemset/problem/839/D)|Codeforces||Codeforces Round #428 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|725|[Covering Sets](http://www.codechef.com/problems/COVERING)|CodeChef|||5|
|<ul><li>- [ ] Done</li></ul>|726|[HexagonalBattlefield](http://community.topcoder.com/stat?c=problem_statement&pm=10549)|TopCoder||SRM 449 - Div1 medium] (13903)|5|
|<ul><li>- [ ] Done</li></ul>|727|[Testing the CATCHER](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3171)|Live Archive|1994|World Finals - Phoenix|5|
|<ul><li>- [ ] Done</li></ul>|728|[Paint templates](http://www.spoj.com/problems/PAINTTMP/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|729|[The  Top-Code](http://www.spoj.com/problems/TOPCODE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|730|[Game --- Mouse and Cheese](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2918)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|731|[Bracket Sequence](http://www.spoj.com/problems/LEXBRAC/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|732|[Incrementing The Integer](http://www.spoj.com/problems/ININT/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|733|[Mystic  Craft](http://www.spoj.com/problems/MYSTIC/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|734|[Little Elephant and Elections](http://codeforces.com/problemset/problem/258/B)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|735|[Let's Play Osu!](http://codeforces.com/problemset/problem/235/B)|Codeforces||Codeforces Round #146 (Div. 1) & Codeforces Round #146 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|736|[Fence](http://codeforces.com/problemset/problem/234/F)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|737|[Table](http://codeforces.com/problemset/problem/232/B)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|738|[Towers](http://codeforces.com/problemset/problem/229/D)|Codeforces||Codeforces Round #142 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|739|[Decoding Genome](http://codeforces.com/problemset/problem/222/E)|Codeforces||Codeforces Round #137 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|740|[Relay Race](http://codeforces.com/problemset/problem/213/C)|Codeforces||Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|741|[Numbers](http://codeforces.com/problemset/problem/213/B)|Codeforces||Codeforces Round #131 (Div. 1) & Codeforces Round #131 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|742|[Police Station](http://codeforces.com/problemset/problem/208/C)|Codeforces||Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|743|[Solitaire](http://codeforces.com/problemset/problem/208/B)|Codeforces||Codeforces Round #130 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|744|[AlgoRace](http://codeforces.com/problemset/problem/187/B)|Codeforces||Codeforces Round #119 (Div. 1) & Codeforces Round #119 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|745|[File List](http://codeforces.com/problemset/problem/174/B)|Codeforces||VK Cup 2012 Round 3 (Unofficial Div. 2 Edition)|6|
|<ul><li>- [ ] Done</li></ul>|746|[Wizards and Huge Prize](http://codeforces.com/problemset/problem/167/B)|Codeforces||Codeforces Round #114 (Div. 1) & Codeforces Round #114 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|747|[Phone Talks](http://codeforces.com/problemset/problem/158/E)|Codeforces||VK Cup 2012 Qualification Round 1|6|
|<ul><li>- [ ] Done</li></ul>|748|[Cipher](http://codeforces.com/problemset/problem/156/C)|Codeforces||Codeforces Round #110 (Div. 1) & Codeforces Round #110 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|749|[Coloring Brackets](http://codeforces.com/problemset/problem/149/D)|Codeforces||Codeforces Round #106 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|750|[Lucky Subsequence](http://codeforces.com/problemset/problem/145/C)|Codeforces||Codeforces Round #104 (Div. 1) & Codeforces Round #104 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|751|[Palindromes](http://codeforces.com/problemset/problem/137/D)|Codeforces||Codeforces Beta Round #98 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|752|[Buses](http://codeforces.com/problemset/problem/101/B)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only) & Codeforces Beta Round #79 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|753|[Interesting Game](http://codeforces.com/problemset/problem/87/C)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only) & Codeforces Beta Round #73 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|754|[Two out of Three](http://codeforces.com/problemset/problem/82/D)|Codeforces||Yandex.Algorithm 2011 Qualification 2|6|
|<ul><li>- [ ] Done</li></ul>|755|[Beaver](http://codeforces.com/problemset/problem/79/C)|Codeforces||Codeforces Beta Round #71|6|
|<ul><li>- [ ] Done</li></ul>|756|[Beaver Game](http://codeforces.com/problemset/problem/78/C)|Codeforces||Codeforces Beta Round #70 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|757|[Train](http://codeforces.com/problemset/problem/74/B)|Codeforces||Codeforces Beta Round #68|6|
|<ul><li>- [ ] Done</li></ul>|758|[Partial Teacher](http://codeforces.com/problemset/problem/67/A)|Codeforces||Manthan 2011|6|
|<ul><li>- [ ] Done</li></ul>|759|[Beautiful numbers](http://codeforces.com/problemset/problem/55/D)|Codeforces||Codeforces Beta Round #51|6|
|<ul><li>- [ ] Done</li></ul>|760|[Anfisa the Monkey](http://codeforces.com/problemset/problem/44/E)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|6|
|<ul><li>- [ ] Done</li></ul>|761|[Let's Go Rolling!](http://codeforces.com/problemset/problem/38/E)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|762|[Animals](http://codeforces.com/problemset/problem/35/D)|Codeforces||Codeforces Beta Round #35 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|763|[Wonderful Randomized Sum](http://codeforces.com/problemset/problem/33/C)|Codeforces||Codeforces Beta Round #33 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|764|[Shooting Gallery](http://codeforces.com/problemset/problem/30/C)|Codeforces||Codeforces Beta Round #30 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|765|[Stripe 2](http://codeforces.com/problemset/problem/21/C)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|6|
|<ul><li>- [ ] Done</li></ul>|766|[Fish](http://codeforces.com/problemset/problem/16/E)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|767|[LCIS](http://codeforces.com/problemset/problem/10/D)|Codeforces||Codeforces Beta Round #10|6|
|<ul><li>- [ ] Done</li></ul>|768|[Cinema Cashier](http://codeforces.com/problemset/problem/10/B)|Codeforces||Codeforces Beta Round #10|6|
|<ul><li>- [ ] Done</li></ul>|769|[Looking for Order](http://codeforces.com/problemset/problem/8/C)|Codeforces||Codeforces Beta Round #8|6|
|<ul><li>- [ ] Done</li></ul>|770|[Lizards and Basements 2](http://codeforces.com/problemset/problem/6/D)|Codeforces||Codeforces Beta Round #6 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|771|[ACM Diagnostics](http://acm.timus.ru/problem.aspx?space=1&num=1310)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|772|[Martian Army](http://acm.timus.ru/problem.aspx?space=1&num=1472)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|773|[Eating High](http://acm.timus.ru/problem.aspx?space=1&num=1570)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|774|[Decimation](http://acm.timus.ru/problem.aspx?space=1&num=1611)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|775|[Salary for Robots](http://acm.timus.ru/problem.aspx?space=1&num=1696)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|776|[Alternative Solution](http://acm.timus.ru/problem.aspx?space=1&num=1716)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|777|[Brainwashing Device](http://acm.timus.ru/problem.aspx?space=1&num=1900)|Timus|||6|
|<ul><li>- [ ] Done</li></ul>|778|[Plants vs. Zombies HD SP](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3883)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|779|[Eleven](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4410)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|780|[Ciel and Gondolas](http://codeforces.com/problemset/problem/321/E)|Codeforces||Codeforces Round #190 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|781|[MagicNaming](http://community.topcoder.com/stat?c=problem_statement&pm=11674)|TopCoder||SRM 526.5 - Div2 hard] (14762)|6|
|<ul><li>- [ ] Done</li></ul>|782|[Sort that Queue](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1537)|Live Archive|2005|Africa/Middle East - Arab and North Africa|6|
|<ul><li>- [ ] Done</li></ul>|783|[Oil Skimming](p?ID=222)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|784|[Common Palindrome](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3917)|UVA|||6|
|<ul><li>- [ ] Done</li></ul>|785|[Summing Slopes](http://www.spoj.com/problems/SUMSLOPE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|786|[Maximum Sub-sequence Product](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3284)|Live Archive|1996|Europe - Southeastern|6|
|<ul><li>- [ ] Done</li></ul>|787|[The Maths Lecture](http://codeforces.com/problemset/problem/507/D)|Codeforces||Codeforces Round #287 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|788|[Longest Common Subsequence](http://www.spoj.com/problems/LCS0/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|789|[Snakes](p?ID=284)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|790|[Table Compression](http://codeforces.com/problemset/problem/650/C)|Codeforces||Codeforces Round #345 (Div. 1) & Codeforces Round #345 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|791|[Magic Numbers](http://codeforces.com/problemset/problem/628/D)|Codeforces||Educational Codeforces Round 8|6|
|<ul><li>- [ ] Done</li></ul>|792|[Group Projects](http://codeforces.com/problemset/problem/626/F)|Codeforces||8VC Venture Cup 2016 - Elimination Round|6|
|<ul><li>- [ ] Done</li></ul>|793|[Array GCD](http://codeforces.com/problemset/problem/623/B)|Codeforces||AIM Tech Round (Div. 1) & AIM Tech Round (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|794|[Hamiltonian Spanning Tree](http://codeforces.com/problemset/problem/618/D)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|6|
|<ul><li>- [ ] Done</li></ul>|795|[Subsequences](http://codeforces.com/problemset/problem/597/C)|Codeforces||Testing Round #12|6|
|<ul><li>- [ ] Done</li></ul>|796|[Duff in Beach](http://codeforces.com/problemset/problem/587/B)|Codeforces||Codeforces Round #326 (Div. 1) & Codeforces Round #326 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|797|[Pig and Palindromes](http://codeforces.com/problemset/problem/570/E)|Codeforces||Codeforces Round #316 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|798|[Vanya and Brackets](http://codeforces.com/problemset/problem/552/E)|Codeforces||Codeforces Round #308 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|799|[Road Improvement](http://codeforces.com/problemset/problem/543/D)|Codeforces||Codeforces Round #302 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|800|[Demiurges Play Again](http://codeforces.com/problemset/problem/538/E)|Codeforces||Codeforces Round #300|6|
|<ul><li>- [ ] Done</li></ul>|801|[Work Group](http://codeforces.com/problemset/problem/533/B)|Codeforces||VK Cup 2015 - Round 2 (unofficial online mirror, Div. 1 only)|6|
|<ul><li>- [ ] Done</li></ul>|802|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|803|[???? ?? ?????? - 2 (round version)](http://codeforces.com/problemset/problem/524/B)|Codeforces||VK Cup 2015 - Round 1|6|
|<ul><li>- [ ] Done</li></ul>|804|[Pluses everywhere](http://codeforces.com/problemset/problem/520/E)|Codeforces||Codeforces Round #295 (Div. 2) & Codeforces Round #295 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|805|[Arthur and Brackets](http://codeforces.com/problemset/problem/508/E)|Codeforces||Codeforces Round #288 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|806|[New Year Domino](http://codeforces.com/problemset/problem/500/E)|Codeforces||Good Bye 2014|6|
|<ul><li>- [ ] Done</li></ul>|807|[Special Matrices](http://codeforces.com/problemset/problem/489/F)|Codeforces||Codeforces Round #277.5 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|808|[LIS of Sequence](http://codeforces.com/problemset/problem/486/E)|Codeforces||Codeforces Round #277 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|809|[Kindergarten](http://codeforces.com/problemset/problem/484/D)|Codeforces||Codeforces Round #276 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|810|[Dreamoon and Strings](http://codeforces.com/problemset/problem/476/E)|Codeforces||Codeforces Round #272 (Div. 2) & Codeforces Round #272 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|811|[Fedor and Essay](http://codeforces.com/problemset/problem/467/D)|Codeforces||Codeforces Round #267 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|812|[Substitutes in Number](http://codeforces.com/problemset/problem/464/C)|Codeforces||Codeforces Round #265 (Div. 1) & Codeforces Round #265 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|813|[Jzzhu and Numbers](http://codeforces.com/problemset/problem/449/D)|Codeforces||Codeforces Round #257 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|814|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces||Codeforces Round #247 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|815|[Match & Catch](http://codeforces.com/problemset/problem/427/D)|Codeforces||Codeforces Round #244 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|816|[Cunning Gena](http://codeforces.com/problemset/problem/417/D)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|817|[Minesweeper 1D](http://codeforces.com/problemset/problem/404/D)|Codeforces||Codeforces Round #237 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|818|[New Year Letter](http://codeforces.com/problemset/problem/379/D)|Codeforces||Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|819|[Watching Fireworks is Fun](http://codeforces.com/problemset/problem/372/C)|Codeforces||Codeforces Round #219 (Div. 1) & Codeforces Round #219 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|820|[Insertion Sort](http://codeforces.com/problemset/problem/362/C)|Codeforces||Codeforces Round #212 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|821|[Palindrome](http://codeforces.com/problemset/problem/335/B)|Codeforces||MemSQL start[c]up Round 2 - online version|6|
|<ul><li>- [ ] Done</li></ul>|822|[EKG](http://codeforces.com/problemset/problem/316/B2)|Codeforces||ABBYY Cup 3.0|6|
|<ul><li>- [ ] Done</li></ul>|823|[Sereja and Subsequences](http://codeforces.com/problemset/problem/314/C)|Codeforces||Codeforces Round #187 (Div. 1) & Codeforces Round #187 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|824|[Ilya and Roads](http://codeforces.com/problemset/problem/313/D)|Codeforces||Codeforces Round #186 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|825|[Greg and Friends](http://codeforces.com/problemset/problem/295/C)|Codeforces||Codeforces Round #179 (Div. 1) & Codeforces Round #179 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|826|[Permutation Sum](http://codeforces.com/problemset/problem/285/D)|Codeforces||Codeforces Round #175 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|827|[Yet Another Number Game](http://codeforces.com/problemset/problem/282/D)|Codeforces||Codeforces Round #173 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|828|[Maxim and Restaurant](http://codeforces.com/problemset/problem/261/B)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|829|[Little Elephant and LCM](http://codeforces.com/problemset/problem/258/C)|Codeforces||Codeforces Round #157 (Div. 1) & Codeforces Round #157 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|830|[Two Strings](http://codeforces.com/problemset/problem/223/B)|Codeforces||Codeforces Round #138 (Div. 1) & Codeforces Round #138 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|831|[Trains and Statistic](http://codeforces.com/problemset/problem/675/E)|Codeforces||Codeforces Round #353 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|832|[Least Common Multiple](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4795)|Live Archive|2014|South Pacific|6|
|<ul><li>- [ ] Done</li></ul>|833|[Segment Tree](http://www.spoj.com/problems/SEGTREE/)|SPOJ|||6|
|<ul><li>- [ ] Done</li></ul>|834|[Leha and another game about graph](http://codeforces.com/problemset/problem/840/B)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|835|[Sonya and Problem Wihtout a Legend](http://codeforces.com/problemset/problem/713/C)|Codeforces||Codeforces Round #371 (Div. 1) & Codeforces Round #371 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|836|[Karen and Supermarket](http://codeforces.com/problemset/problem/815/C)|Codeforces||Codeforces Round #419 (Div. 1) & Codeforces Round #419 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|837|[Unusual Sequences](http://codeforces.com/problemset/problem/900/D)|Codeforces||Codeforces Round #450 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|838|[Okabe and El Psy Kongroo](http://codeforces.com/problemset/problem/821/E)|Codeforces||Codeforces Round #420 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|839|[Memory and Scores](http://codeforces.com/problemset/problem/712/D)|Codeforces||Codeforces Round #370 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|840|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces||Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|841|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces||Codeforces Round #384 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|842|[Dynamic Problem Scoring](http://codeforces.com/problemset/problem/773/B)|Codeforces||VK Cup 2017 - Round 3|6|
|<ul><li>- [ ] Done</li></ul>|843|[Array Queries](http://codeforces.com/problemset/problem/797/E)|Codeforces||Educational Codeforces Round 19|6|
|<ul><li>- [ ] Done</li></ul>|844|[Demogorgon](https://www.urionlinejudge.com.br/judge/en/problems/view/2532)|URI|||6|
|<ul><li>- [ ] Done</li></ul>|845|[Save the Python Programmers!](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3128)|Live Archive|2010|North America - Pacific Northwest|6|
|<ul><li>- [ ] Done</li></ul>|846|[Money for Nothing](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=6064)|Live Archive|2017|World Finals - Rapid City|6|
|<ul><li>- [ ] Done</li></ul>|847|[Jill Rides Again](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3194)|Live Archive|1997|World Finals - San Jose|6|
|<ul><li>- [ ] Done</li></ul>|848|[Colored Tiles](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2658)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|849|[Catch Sheep](http://www.spoj.com/problems/XYYHHTT/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|850|[Two Longest Paths](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2923)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|851|[Table Tennis](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2855)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|852|[Number Transformation](http://codeforces.com/problemset/problem/251/C)|Codeforces||Codeforces Round #153 (Div. 1) & Codeforces Round #153 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|853|[Blood Cousins Return](http://codeforces.com/problemset/problem/246/E)|Codeforces||Codeforces Round #151 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|854|[World Eater Brothers](http://codeforces.com/problemset/problem/238/C)|Codeforces||Codeforces Round #148 (Div. 1) & Codeforces Round #148 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|855|[Cactus](http://codeforces.com/problemset/problem/231/E)|Codeforces||Codeforces Round #143 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|856|[Fragile Bridges](http://codeforces.com/problemset/problem/201/C)|Codeforces||Codeforces Round #127 (Div. 1) & Codeforces Round #127 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|857|[Wooden Fence](http://codeforces.com/problemset/problem/182/E)|Codeforces||Codeforces Round #117 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|858|[Cubes](http://codeforces.com/problemset/problem/180/E)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|859|[Word Cut](http://codeforces.com/problemset/problem/176/B)|Codeforces||Croc Champ 2012 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|860|[Spiral Maximum](http://codeforces.com/problemset/problem/173/C)|Codeforces||Croc Champ 2012 - Round 1|7|
|<ul><li>- [ ] Done</li></ul>|861|[Education Reform](http://codeforces.com/problemset/problem/119/C)|Codeforces||Codeforces Beta Round #90|7|
|<ul><li>- [ ] Done</li></ul>|862|[Petya and Spiders](http://codeforces.com/problemset/problem/111/C)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|863|[Lucky Country](http://codeforces.com/problemset/problem/95/E)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|864|[Lucky Numbers](http://codeforces.com/problemset/problem/95/B)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only)|7|
|<ul><li>- [ ] Done</li></ul>|865|[Beavermuncher-0xFF](http://codeforces.com/problemset/problem/77/C)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only) & Codeforces Beta Round #69 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|866|[Big Maximum Sum](http://codeforces.com/problemset/problem/75/D)|Codeforces||Codeforces Beta Round #67 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|867|[LionAge II](http://codeforces.com/problemset/problem/73/C)|Codeforces||Codeforces Beta Round #66|7|
|<ul><li>- [ ] Done</li></ul>|868|[Dot](http://codeforces.com/problemset/problem/69/D)|Codeforces||Codeforces Beta Round #63 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|869|[Optical Experiment](http://codeforces.com/problemset/problem/67/D)|Codeforces||Manthan 2011|7|
|<ul><li>- [ ] Done</li></ul>|870|[Changing a String](http://codeforces.com/problemset/problem/56/D)|Codeforces||Codeforces Beta Round #52 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|871|[First Digit Law](http://codeforces.com/problemset/problem/54/C)|Codeforces||Codeforces Beta Round #50|7|
|<ul><li>- [ ] Done</li></ul>|872|[Right Triangles](http://codeforces.com/problemset/problem/52/B)|Codeforces||Codeforces Testing Round #1|7|
|<ul><li>- [ ] Done</li></ul>|873|[Comb](http://codeforces.com/problemset/problem/46/E)|Codeforces||School Personal Contest #2 (Winter Computer School 2010/11) - Codeforces Beta Round #43 (ACM-ICPC Rules)|7|
|<ul><li>- [ ] Done</li></ul>|874|[Phone Number](http://codeforces.com/problemset/problem/44/H)|Codeforces||School Team Contest #2 (Winter Computer School 2010/11)|7|
|<ul><li>- [ ] Done</li></ul>|875|[Pawn](http://codeforces.com/problemset/problem/41/D)|Codeforces||Codeforces Beta Round #40 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|876|[TV Game](http://codeforces.com/problemset/problem/31/E)|Codeforces||Codeforces Beta Round #31 (Div. 2, Codeforces format)|7|
|<ul><li>- [ ] Done</li></ul>|877|[Seller Bob](http://codeforces.com/problemset/problem/18/D)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|878|[Camels](http://codeforces.com/problemset/problem/14/E)|Codeforces||Codeforces Beta Round #14 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|879|[Lost in Space](http://acm.timus.ru/problem.aspx?space=1&num=1171)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|880|[Archer's Travel](http://acm.timus.ru/problem.aspx?space=1&num=1459)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|881|[Lunar Code](http://acm.timus.ru/problem.aspx?space=1&num=1476)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|882|[Martian Plates](http://acm.timus.ru/problem.aspx?space=1&num=1526)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|883|[Brainfuck](http://acm.timus.ru/problem.aspx?space=1&num=1552)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|884|[Join](http://acm.timus.ru/problem.aspx?space=1&num=1627)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|885|[Yet Another Answer](http://acm.timus.ru/problem.aspx?space=1&num=1745)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|886|[TheProgrammingContestDivOne](http://community.topcoder.com/stat?c=problem_statement&pm=11357)|TopCoder||SRM 502 - Div1 medium] (14431)|7|
|<ul><li>- [ ] Done</li></ul>|887|[Cats Transport](http://codeforces.com/problemset/problem/311/B)|Codeforces||Codeforces Round #185 (Div. 1) & Codeforces Round #185 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|888|[Playing War](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2002)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|889|[Merry-go-round](http://acm.timus.ru/problem.aspx?space=1&num=1817)|Timus|||7|
|<ul><li>- [ ] Done</li></ul>|890|[Yet Another Assignment Problem](http://www.spoj.com/problems/ASSIGN5/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|891|[Component Testing](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4204)|Live Archive|2012|North America - Mid-Atlantic USA & North America - Southern California & North America - Southeast USA|7|
|<ul><li>- [ ] Done</li></ul>|892|[Genetic Engineering](http://codeforces.com/problemset/problem/391/A)|Codeforces||Rockethon 2014|7|
|<ul><li>- [ ] Done</li></ul>|893|[Duckindromes](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4970)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|894|[Binary Table](http://codeforces.com/problemset/problem/662/C)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|7|
|<ul><li>- [ ] Done</li></ul>|895|[Fence Divercity](http://codeforces.com/problemset/problem/659/G)|Codeforces||Codeforces Round #346 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|896|[Zip-line](http://codeforces.com/problemset/problem/650/D)|Codeforces||Codeforces Round #345 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|897|[Intellectual Inquiry](http://codeforces.com/problemset/problem/645/E)|Codeforces||CROC 2016 - Elimination Round|7|
|<ul><li>- [ ] Done</li></ul>|898|[Little Artem and Random Variable](http://codeforces.com/problemset/problem/641/D)|Codeforces||VK Cup 2016 - Round 2|7|
|<ul><li>- [ ] Done</li></ul>|899|[Thief in a Shop](http://codeforces.com/problemset/problem/632/E)|Codeforces||Educational Codeforces Round 9|7|
|<ul><li>- [ ] Done</li></ul>|900|[Product Sum](http://codeforces.com/problemset/problem/631/E)|Codeforces||Codeforces Round #344 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|901|[Famil Door and Roads](http://codeforces.com/problemset/problem/629/E)|Codeforces||Codeforces Round #343 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|902|[Kleofáš and the n-thlon](http://codeforces.com/problemset/problem/601/C)|Codeforces||Codeforces Round #333 (Div. 1) & Codeforces Round #333 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|903|[Top Secret Task](http://codeforces.com/problemset/problem/590/D)|Codeforces||Codeforces Round #327 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|904|[Bulbo](http://codeforces.com/problemset/problem/575/F)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|7|
|<ul><li>- [ ] Done</li></ul>|905|[Ann and Half-Palindrome](http://codeforces.com/problemset/problem/557/E)|Codeforces||Codeforces Round #311 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|906|[Remembering Strings](http://codeforces.com/problemset/problem/543/C)|Codeforces||Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|907|[Quest](http://codeforces.com/problemset/problem/542/F)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|7|
|<ul><li>- [ ] Done</li></ul>|908|[Transmitting Levels](http://codeforces.com/problemset/problem/526/E)|Codeforces||ZeptoLab Code Rush 2015|7|
|<ul><li>- [ ] Done</li></ul>|909|[Darth Vader and Tree](http://codeforces.com/problemset/problem/514/E)|Codeforces||Codeforces Round #291 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|910|[Traffic Jams in the Land](http://codeforces.com/problemset/problem/498/D)|Codeforces||Codeforces Round #284 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|911|[Name That Tune](http://codeforces.com/problemset/problem/498/B)|Codeforces||Codeforces Round #284 (Div. 1) & Codeforces Round #284 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|912|[Treeland Tour](http://codeforces.com/problemset/problem/490/F)|Codeforces||Codeforces Round #279 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|913|[Hiking](http://codeforces.com/problemset/problem/489/E)|Codeforces||Codeforces Round #277.5 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|914|[Devu and Birthday Celebration](http://codeforces.com/problemset/problem/439/E)|Codeforces||Codeforces Round #251 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|915|[Special Grid](http://codeforces.com/problemset/problem/435/D)|Codeforces||Codeforces Round #249 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|916|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|917|[Sereja and Two Sequences](http://codeforces.com/problemset/problem/425/C)|Codeforces||Codeforces Round #243 (Div. 1) & Codeforces Round #243 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|918|[President's Path](http://codeforces.com/problemset/problem/416/E)|Codeforces||Codeforces Round #241 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|919|[Beautiful Pairs of Numbers](http://codeforces.com/problemset/problem/403/D)|Codeforces||Codeforces Round #236 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|920|[Painting The Wall](http://codeforces.com/problemset/problem/398/B)|Codeforces||Codeforces Round #233 (Div. 1) & Codeforces Round #233 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|921|[Captains Mode](http://codeforces.com/problemset/problem/377/C)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|922|[Inna and Sequence ](http://codeforces.com/problemset/problem/374/D)|Codeforces||Codeforces Round #220 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|923|[Valera and Fools](http://codeforces.com/problemset/problem/369/D)|Codeforces||Codeforces Round #216 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|924|[Free Market](http://codeforces.com/problemset/problem/364/B)|Codeforces||Codeforces Round #213 (Div. 1) & Codeforces Round #213 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|925|[Levko and Strings](http://codeforces.com/problemset/problem/360/C)|Codeforces||Codeforces Round #210 (Div. 1) & Codeforces Round #210 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|926|[Lucky Number Representation](http://codeforces.com/problemset/problem/354/E)|Codeforces||Codeforces Round #206 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|927|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces||Codeforces Round #191 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|928|[Game with Powers](http://codeforces.com/problemset/problem/317/D)|Codeforces||Codeforces Round #188 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|929|[Yaroslav and Two Strings](http://codeforces.com/problemset/problem/296/B)|Codeforces||Codeforces Round #179 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|930|[Coin Troubles](http://codeforces.com/problemset/problem/283/C)|Codeforces||Codeforces Round #174 (Div. 1) & Codeforces Round #174 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|931|[Maxim and Matrix](http://codeforces.com/problemset/problem/261/C)|Codeforces||Codeforces Round #160 (Div. 1) & Codeforces Round #160 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|932|[Plus and xor](http://codeforces.com/problemset/problem/76/D)|Codeforces||All-Ukrainian School Olympiad in Informatics|7|
|<ul><li>- [ ] Done</li></ul>|933|[Game](http://codeforces.com/problemset/problem/49/D)|Codeforces||Codeforces Beta Round #46 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|934|[Black and White Tree](http://codeforces.com/problemset/problem/260/D)|Codeforces||Codeforces Round #158 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|935|[Nanami's Digital Board](http://codeforces.com/problemset/problem/433/D)|Codeforces||Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|936|[Divisor Tree](http://codeforces.com/problemset/problem/337/E)|Codeforces||Codeforces Round #196 (Div. 2) & Codeforces Round #196 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|937|[Identify the Number](p?ID=32)|A2 Online Judge|||7|
|<ul><li>- [ ] Done</li></ul>|938|[FibonacciKnapsack](http://community.topcoder.com/stat?c=problem_statement&pm=7481)|TopCoder||SRM 352 - Div1 medium] (10709)|7|
|<ul><li>- [ ] Done</li></ul>|939|[Longest Run on a Snowboard](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1802)|Live Archive|2006|Asia - Coimbatore|7|
|<ul><li>- [ ] Done</li></ul>|940|[Rent your airplane and make money](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3574)|UVA|||7|
|<ul><li>- [ ] Done</li></ul>|941|[Hongcow Buys a Deck of Cards](http://codeforces.com/problemset/problem/744/C)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|942|[On the Bench](http://codeforces.com/problemset/problem/840/C)|Codeforces||Codeforces Round #429 (Div. 1) & Codeforces Round #429 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|943|[Ant Man](http://codeforces.com/problemset/problem/704/B)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|944|[Vladik and chat](http://codeforces.com/problemset/problem/754/C)|Codeforces||Codeforces Round #390 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|945|[Maximum Questions](http://codeforces.com/problemset/problem/900/E)|Codeforces||Codeforces Round #450 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|946|[Ralph and Mushrooms](http://codeforces.com/problemset/problem/894/E)|Codeforces||Codeforces Round #447 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|947|[Fafa and Ancient Mathematics](http://codeforces.com/problemset/problem/935/E)|Codeforces||Codeforces Round #465 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|948|[Pictures with Kittens (hard version)](http://codeforces.com/problemset/problem/1077/F2)|Codeforces||Codeforces Round #521 (Div. 3)|7|
|<ul><li>- [ ] Done</li></ul>|949|[Segment Sum](http://codeforces.com/problemset/problem/1073/E)|Codeforces||Educational Codeforces Round 53 (Rated for Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|950|[Lannister Army](http://www.spoj.com/problems/LARMY/)|SPOJ|||7|
|<ul><li>- [ ] Done</li></ul>|951|[Sweets Problem](http://www.codechef.com/problems/IOPC14L)|CodeChef|||7|
|<ul><li>- [ ] Done</li></ul>|952|[Little Elephant and Broken Sorting](http://codeforces.com/problemset/problem/258/D)|Codeforces||Codeforces Round #157 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|953|[Lucky Arrays](http://codeforces.com/problemset/problem/256/E)|Codeforces||Codeforces Round #156 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|954|[Number Challenge](http://codeforces.com/problemset/problem/235/E)|Codeforces||Codeforces Round #146 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|955|[Gifts](http://codeforces.com/problemset/problem/229/E)|Codeforces||Codeforces Round #142 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|956|[Fractal Detector](http://codeforces.com/problemset/problem/228/C)|Codeforces||Codeforces Round #141 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|957|[Periodical Numbers](http://codeforces.com/problemset/problem/215/E)|Codeforces||Codeforces Round #132 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|958|[IT Restaurants](http://codeforces.com/problemset/problem/212/E)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|8|
|<ul><li>- [ ] Done</li></ul>|959|[Multicolored Marbles](http://codeforces.com/problemset/problem/209/A)|Codeforces||VK Cup 2012 Finals, Practice Session|8|
|<ul><li>- [ ] Done</li></ul>|960|[Name](http://codeforces.com/problemset/problem/180/D)|Codeforces||Codeforces Round #116 (Div. 2, ACM-ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|961|[Polycarpus the Safecracker](http://codeforces.com/problemset/problem/161/E)|Codeforces||VK Cup 2012 Round 1|8|
|<ul><li>- [ ] Done</li></ul>|962|[Help Caretaker](http://codeforces.com/problemset/problem/142/C)|Codeforces||Codeforces Round #102 (Div. 1) & Codeforces Round #102 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|963|[Clearing Up](http://codeforces.com/problemset/problem/141/E)|Codeforces||Codeforces Round #101 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|964|[New Year Garland](http://codeforces.com/problemset/problem/140/E)|Codeforces||Codeforces Round #100|8|
|<ul><li>- [ ] Done</li></ul>|965|[Constants in the language of Shakespeare](http://codeforces.com/problemset/problem/132/D)|Codeforces||Codeforces Beta Round #96 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|966|[Fibonacci Sums](http://codeforces.com/problemset/problem/126/D)|Codeforces||Codeforces Beta Round #93 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|967|[Brackets](http://codeforces.com/problemset/problem/123/C)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only) & Codeforces Beta Round #92 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|968|[Linear Kingdom Races](http://codeforces.com/problemset/problem/115/E)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|969|[Castle](http://codeforces.com/problemset/problem/101/D)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|970|[Widget Library](http://codeforces.com/problemset/problem/89/B)|Codeforces||Codeforces Beta Round #74 (Div. 1 Only) & Codeforces Beta Round #74 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|971|[Beautiful Road](http://codeforces.com/problemset/problem/87/D)|Codeforces||Codeforces Beta Round #73 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|972|[Genetic engineering](http://codeforces.com/problemset/problem/86/C)|Codeforces||Yandex.Algorithm 2011 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|973|[Numbers](http://codeforces.com/problemset/problem/83/D)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|974|[Password](http://codeforces.com/problemset/problem/79/D)|Codeforces||Codeforces Beta Round #71|8|
|<ul><li>- [ ] Done</li></ul>|975|[Tourist](http://codeforces.com/problemset/problem/76/F)|Codeforces||All-Ukrainian School Olympiad in Informatics|8|
|<ul><li>- [ ] Done</li></ul>|976|[Fibonacci army](http://codeforces.com/problemset/problem/72/G)|Codeforces||Unknown Language Round #2|8|
|<ul><li>- [ ] Done</li></ul>|977|[Petya and Post](http://codeforces.com/problemset/problem/66/E)|Codeforces||Codeforces Beta Round #61 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|978|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces||Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|979|[Dead Ends](http://codeforces.com/problemset/problem/53/E)|Codeforces||Codeforces Beta Round #49 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|980|[Bombing](http://codeforces.com/problemset/problem/50/D)|Codeforces||Codeforces Beta Round #47|8|
|<ul><li>- [ ] Done</li></ul>|981|[Common ancestor](http://codeforces.com/problemset/problem/49/E)|Codeforces||Codeforces Beta Round #46 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|982|[What Has Dirichlet Got to Do with That?](http://codeforces.com/problemset/problem/39/E)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|8|
|<ul><li>- [ ] Done</li></ul>|983|[Don't fear, DravDe is kind](http://codeforces.com/problemset/problem/28/D)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|984|[Bath Queue](http://codeforces.com/problemset/problem/28/C)|Codeforces||Codeforces Beta Round #28 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|985|[Broken robot](http://codeforces.com/problemset/problem/24/D)|Codeforces||Codeforces Beta Round #24|8|
|<ul><li>- [ ] Done</li></ul>|986|[Tree](http://codeforces.com/problemset/problem/23/E)|Codeforces||Codeforces Beta Round #23|8|
|<ul><li>- [ ] Done</li></ul>|987|[Flag 2](http://codeforces.com/problemset/problem/18/E)|Codeforces||Codeforces Beta Round #18 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|988|[Balance](http://codeforces.com/problemset/problem/17/C)|Codeforces||Codeforces Beta Round #17|8|
|<ul><li>- [ ] Done</li></ul>|989|[Beads](http://codeforces.com/problemset/problem/8/E)|Codeforces||Codeforces Beta Round #8|8|
|<ul><li>- [ ] Done</li></ul>|990|[Defining Macros](http://codeforces.com/problemset/problem/7/E)|Codeforces||Codeforces Beta Round #7|8|
|<ul><li>- [ ] Done</li></ul>|991|[Yekaterinburg Subway](http://acm.timus.ru/problem.aspx?space=1&num=1267)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|992|[Somali Pirates](http://acm.timus.ru/problem.aspx?space=1&num=1655)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|993|[Frequent Flyer Card](http://acm.timus.ru/problem.aspx?space=1&num=1887)|Timus|||8|
|<ul><li>- [ ] Done</li></ul>|994|[Inventory](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3689)|UVA|||8|
|<ul><li>- [ ] Done</li></ul>|995|[One-Based Arithmetic](http://codeforces.com/problemset/problem/440/C)|Codeforces||Testing Round #10|8|
|<ul><li>- [ ] Done</li></ul>|996|[2048](http://codeforces.com/problemset/problem/413/D)|Codeforces||Coder-Strike 2014 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|997|[Scheme](http://codeforces.com/problemset/problem/22/E)|Codeforces||Codeforces Beta Round #22 (Div. 2 Only)|8|
|<ul><li>- [ ] Done</li></ul>|998|[e-Government](http://codeforces.com/problemset/problem/163/E)|Codeforces||VK Cup 2012 Round 2|8|
|<ul><li>- [ ] Done</li></ul>|999|[The Chocolate Spree](http://codeforces.com/problemset/problem/633/F)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|1000|[Preorder Test](http://codeforces.com/problemset/problem/627/D)|Codeforces||8VC Venture Cup 2016 - Final Round|8|
|<ul><li>- [ ] Done</li></ul>|1001|[Wilbur and Trees](http://codeforces.com/problemset/problem/596/D)|Codeforces||Codeforces Round #331 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1002|[Zublicanes and Mumocrates](http://codeforces.com/problemset/problem/581/F)|Codeforces||Codeforces Round #322 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1003|[LCS Again](http://codeforces.com/problemset/problem/578/D)|Codeforces||Codeforces Round #320 (Div. 1) [Bayan Thanks-Round] & Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|8|
|<ul><li>- [ ] Done</li></ul>|1004|[Flights for Regular Customers](http://codeforces.com/problemset/problem/576/D)|Codeforces||Codeforces Round #319 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1005|[Mausoleum](http://codeforces.com/problemset/problem/567/F)|Codeforces||Codeforces Round #Pi (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1006|[Drazil and Morning Exercise](http://codeforces.com/problemset/problem/516/D)|Codeforces||Codeforces Round #292 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1007|[Inversions problem](http://codeforces.com/problemset/problem/513/G2)|Codeforces||Rockethon 2015|8|
|<ul><li>- [ ] Done</li></ul>|1008|[Progress Monitoring](http://codeforces.com/problemset/problem/509/F)|Codeforces||Codeforces Round #289 (Div. 2, ACM ICPC Rules)|8|
|<ul><li>- [ ] Done</li></ul>|1009|[Birthday](http://codeforces.com/problemset/problem/494/D)|Codeforces||Codeforces Round #282 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1010|[Helping People](http://codeforces.com/problemset/problem/494/C)|Codeforces||Codeforces Round #282 (Div. 1) & Codeforces Round #282 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1011|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1012|[Parcels](http://codeforces.com/problemset/problem/480/D)|Codeforces||Codeforces Round #274 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1013|[Alex and Complicated Task](http://codeforces.com/problemset/problem/467/E)|Codeforces||Codeforces Round #267 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1014|[World of Darkraft - 2](http://codeforces.com/problemset/problem/464/D)|Codeforces||Codeforces Round #265 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1015|[Sereja and Sets](http://codeforces.com/problemset/problem/425/E)|Codeforces||Codeforces Round #243 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1016|[Biathlon Track](http://codeforces.com/problemset/problem/424/D)|Codeforces||Codeforces Round #242 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1017|[Tower of Hanoi](http://codeforces.com/problemset/problem/392/B)|Codeforces||Codeforces Round #230 (Div. 1) & Codeforces Round #230 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1018|[Diverse Substrings](http://codeforces.com/problemset/problem/386/C)|Codeforces||Testing Round #9|8|
|<ul><li>- [ ] Done</li></ul>|1019|[Bear and Floodlight](http://codeforces.com/problemset/problem/385/D)|Codeforces||Codeforces Round #226 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1020|[Vowels](http://codeforces.com/problemset/problem/383/E)|Codeforces||Codeforces Round #225 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1021|[Sereja and Intervals](http://codeforces.com/problemset/problem/367/E)|Codeforces||Codeforces Round #215 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1022|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces||Codeforces Round #207 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1023|[Antichain](http://codeforces.com/problemset/problem/353/E)|Codeforces||Codeforces Round #205 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1024|[Jeff and Brackets](http://codeforces.com/problemset/problem/351/C)|Codeforces||Codeforces Round #204 (Div. 1) & Codeforces Round #204 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1025|[Turtles](http://codeforces.com/problemset/problem/348/D)|Codeforces||Codeforces Round #202 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1026|[Xenia and Dominoes](http://codeforces.com/problemset/problem/342/D)|Codeforces||Codeforces Round #199 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1027|[Painting Square](http://codeforces.com/problemset/problem/300/D)|Codeforces||Codeforces Round #181 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1028|[Greg and Caves](http://codeforces.com/problemset/problem/295/D)|Codeforces||Codeforces Round #179 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1029|[Shaass the Great](http://codeforces.com/problemset/problem/294/E)|Codeforces||Codeforces Round #178 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1030|[Positions in Permutations](http://codeforces.com/problemset/problem/285/E)|Codeforces||Codeforces Round #175 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1031|[Cows and Cool Sequences](http://codeforces.com/problemset/problem/283/D)|Codeforces||Codeforces Round #174 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1032|[The Minimum Number of Variables](http://codeforces.com/problemset/problem/279/D)|Codeforces||Codeforces Round #171 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1033|[Maxim and Increasing Subsequence](http://codeforces.com/problemset/problem/261/D)|Codeforces||Codeforces Round #160 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1034|[Petya and Coloring](http://codeforces.com/problemset/problem/111/D)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only)|8|
|<ul><li>- [ ] Done</li></ul>|1035|[Triangles](http://codeforces.com/problemset/problem/13/D)|Codeforces||Codeforces Beta Round #13|8|
|<ul><li>- [ ] Done</li></ul>|1036|[The Child and Polygon](http://codeforces.com/problemset/problem/437/E)|Codeforces||Codeforces Round #250 (Div. 2) & Codeforces Round #250 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1037|[Roads in Yusland](http://codeforces.com/problemset/problem/671/D)|Codeforces||Codeforces Round #352 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1038|[Vanya and Balloons](http://codeforces.com/problemset/problem/677/E)|Codeforces||Codeforces Round #355 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1039|[Two Melodies](http://codeforces.com/problemset/problem/813/D)|Codeforces||Educational Codeforces Round 22|8|
|<ul><li>- [ ] Done</li></ul>|1040|[Ostap and Tree](http://codeforces.com/problemset/problem/735/E)|Codeforces||Codeforces Round #382 (Div. 2) & Codeforces Round #382 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1041|[Michael and Charging Stations](http://codeforces.com/problemset/problem/853/D)|Codeforces||Codeforces Round #433 (Div. 1, based on Olympiad of Metropolises)|8|
|<ul><li>- [ ] Done</li></ul>|1042|[Find a car](http://codeforces.com/problemset/problem/809/C)|Codeforces||Codeforces Round #415 (Div. 1) & Codeforces Round #415 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1043|[Gosha is hunting](http://codeforces.com/problemset/problem/739/E)|Codeforces||Codeforces Round #381 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|1044|[An unavoidable detour for home](http://codeforces.com/problemset/problem/814/E)|Codeforces||Codeforces Round #418 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1045|[Mishka and Divisors](http://codeforces.com/problemset/problem/703/E)|Codeforces||Codeforces Round #365 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|1046|[E-The dynamic programming problem2](http://acm.tju.edu.cn/toj/showp4173.html)|TJU|||8|
|<ul><li>- [ ] Done</li></ul>|1047|[Liars and Serge](http://codeforces.com/problemset/problem/256/D)|Codeforces||Codeforces Round #156 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1048|[Dormitory](http://codeforces.com/problemset/problem/254/E)|Codeforces||Codeforces Round #155 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1049|[Donkey and Stars](http://codeforces.com/problemset/problem/249/D)|Codeforces||Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1050|[Piglet's Birthday](http://codeforces.com/problemset/problem/248/E)|Codeforces||Codeforces Round #152 (Div. 2) & Codeforces Round #152 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1051|[Meeting Her](http://codeforces.com/problemset/problem/238/E)|Codeforces||Codeforces Round #148 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1052|[Quick Tortoise](http://codeforces.com/problemset/problem/232/E)|Codeforces||Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1053|[Little Elephant and Triangle](http://codeforces.com/problemset/problem/220/D)|Codeforces||Codeforces Round #136 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1054|[Formurosa](http://codeforces.com/problemset/problem/217/C)|Codeforces||Codeforces Round #134 (Div. 1) & Codeforces Round #134 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1055|[Cowboys](http://codeforces.com/problemset/problem/212/C)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|1056|[Little Elephant and Retro Strings](http://codeforces.com/problemset/problem/204/D)|Codeforces||Codeforces Round #129 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1057|[Brand New Problem](http://codeforces.com/problemset/problem/201/D)|Codeforces||Codeforces Round #127 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1058|[T-shirt](http://codeforces.com/problemset/problem/183/D)|Codeforces||Croc Champ 2012 - Final|9|
|<ul><li>- [ ] Done</li></ul>|1059|[Hyper String](http://codeforces.com/problemset/problem/176/D)|Codeforces||Croc Champ 2012 - Round 2|9|
|<ul><li>- [ ] Done</li></ul>|1060|[Power Defence](http://codeforces.com/problemset/problem/175/E)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|1061|[Plane of Tanks: Duel](http://codeforces.com/problemset/problem/175/D)|Codeforces||Codeforces Round #115|9|
|<ul><li>- [ ] Done</li></ul>|1062|[Shoe Store](http://codeforces.com/problemset/problem/166/D)|Codeforces||Codeforces Round #113 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1063|[Garden](http://codeforces.com/problemset/problem/152/E)|Codeforces||Codeforces Round #108 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1064|[Mission Impassable](http://codeforces.com/problemset/problem/150/D)|Codeforces||Codeforces Round #107 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1065|[World of Darkraft](http://codeforces.com/problemset/problem/138/D)|Codeforces||Codeforces Beta Round #99 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1066|[Unambiguous Arithmetic Expression](http://codeforces.com/problemset/problem/115/D)|Codeforces||Codeforces Beta Round #87 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1067|[Crime Management](http://codeforces.com/problemset/problem/107/D)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1068|[Arrangement](http://codeforces.com/problemset/problem/107/C)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1069|[Candies and Stones](http://codeforces.com/problemset/problem/101/E)|Codeforces||Codeforces Beta Round #79 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1070|[Horse Races](http://codeforces.com/problemset/problem/95/D)|Codeforces||Codeforces Beta Round #77 (Div. 1 Only) & Codeforces Beta Round #77 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1071|[Lostborn](http://codeforces.com/problemset/problem/93/E)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1072|[Flags](http://codeforces.com/problemset/problem/93/D)|Codeforces||Codeforces Beta Round #76 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1073|[Two Subsequences](http://codeforces.com/problemset/problem/83/E)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1074|[Pairs](http://codeforces.com/problemset/problem/81/E)|Codeforces||Yandex.Algorithm Open 2011 Qualification 1|9|
|<ul><li>- [ ] Done</li></ul>|1075|[Domino Carpet](http://codeforces.com/problemset/problem/77/D)|Codeforces||Codeforces Beta Round #69 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1076|[Hanger](http://codeforces.com/problemset/problem/74/D)|Codeforces||Codeforces Beta Round #68|9|
|<ul><li>- [ ] Done</li></ul>|1077|[Nuclear Fusion](http://codeforces.com/problemset/problem/71/E)|Codeforces||Codeforces Beta Round #65 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1078|[Information Reform](http://codeforces.com/problemset/problem/70/E)|Codeforces||Codeforces Beta Round #64|9|
|<ul><li>- [ ] Done</li></ul>|1079|[Half-decay tree](http://codeforces.com/problemset/problem/68/D)|Codeforces||Codeforces Beta Round #62|9|
|<ul><li>- [ ] Done</li></ul>|1080|[Sequence of Balls](http://codeforces.com/problemset/problem/67/C)|Codeforces||Manthan 2011|9|
|<ul><li>- [ ] Done</li></ul>|1081|[Journey](http://codeforces.com/problemset/problem/57/D)|Codeforces||Codeforces Beta Round #53|9|
|<ul><li>- [ ] Done</li></ul>|1082|[Writing a Song](http://codeforces.com/problemset/problem/54/D)|Codeforces||Codeforces Beta Round #50|9|
|<ul><li>- [ ] Done</li></ul>|1083|[Caterpillar](http://codeforces.com/problemset/problem/51/F)|Codeforces||Codeforces Beta Round #48|9|
|<ul><li>- [ ] Done</li></ul>|1084|[Ivan the Fool VS Gorynych the Dragon](http://codeforces.com/problemset/problem/48/E)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|1085|[Moon Craters](http://codeforces.com/problemset/problem/39/C)|Codeforces||School Team Contest #1 (Winter Computer School 2010/11)|9|
|<ul><li>- [ ] Done</li></ul>|1086|[Smart Boy](http://codeforces.com/problemset/problem/38/F)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|9|
|<ul><li>- [ ] Done</li></ul>|1087|[Lesson Timetable](http://codeforces.com/problemset/problem/37/D)|Codeforces||Codeforces Beta Round #37|9|
|<ul><li>- [ ] Done</li></ul>|1088|[Triangles](http://codeforces.com/problemset/problem/15/E)|Codeforces||Codeforces Beta Round #15|9|
|<ul><li>- [ ] Done</li></ul>|1089|[Faryuks](http://acm.timus.ru/problem.aspx?space=1&num=1739)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|1090|[Steaks on Board](http://acm.timus.ru/problem.aspx?space=1&num=1895)|Timus|||9|
|<ul><li>- [ ] Done</li></ul>|1091|[Candy Store](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=4230)|Live Archive|2012|North America - Southeast USA|9|
|<ul><li>- [ ] Done</li></ul>|1092|[StackingBoxes](http://community.topcoder.com/stat?c=problem_statement&pm=4660)|TopCoder||SRM 261 - Div1 hard] (7995)|9|
|<ul><li>- [ ] Done</li></ul>|1093|[And Yet Another Bracket Sequence](http://codeforces.com/problemset/problem/524/F)|Codeforces||VK Cup 2015 - Round 1|9|
|<ul><li>- [ ] Done</li></ul>|1094|[Four Divisors](http://codeforces.com/problemset/problem/665/F)|Codeforces||Educational Codeforces Round 12|9|
|<ul><li>- [ ] Done</li></ul>|1095|[Transforming Sequence](http://codeforces.com/problemset/problem/623/E)|Codeforces||AIM Tech Round (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1096|[A Museum Robbery](http://codeforces.com/problemset/problem/601/E)|Codeforces||Codeforces Round #333 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1097|[Sandy and Nuts](http://codeforces.com/problemset/problem/599/E)|Codeforces||Codeforces Round #332 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1098|[Wilbur and Strings](http://codeforces.com/problemset/problem/596/E)|Codeforces||Codeforces Round #331 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1099|[Strange Calculation and Cats](http://codeforces.com/problemset/problem/593/E)|Codeforces||Codeforces Round #329 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1100|[Polycarp's Masterpiece](http://codeforces.com/problemset/problem/589/C)|Codeforces||2015-2016 ACM-ICPC, NEERC, Southern Subregional Contest (Online Mirror, ACM-ICPC Rules, Teams Preferred)|9|
|<ul><li>- [ ] Done</li></ul>|1101|[Bear and Cavalry](http://codeforces.com/problemset/problem/573/D)|Codeforces||Codeforces Round #318 [RussianCodeCup Thanks-Round] (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1102|[Gerald and Path](http://codeforces.com/problemset/problem/559/E)|Codeforces||Codeforces Round #313 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1103|[Superhero's Job](http://codeforces.com/problemset/problem/542/D)|Codeforces||VK Cup 2015 - Round 3 (unofficial online mirror, Div. 1 only)|9|
|<ul><li>- [ ] Done</li></ul>|1104|[Tavas in Kansas](http://codeforces.com/problemset/problem/536/D)|Codeforces||Codeforces Round #299 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1105|[Simplified Nonogram](http://codeforces.com/problemset/problem/534/F)|Codeforces||Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1106|[Pasha and Pipe](http://codeforces.com/problemset/problem/518/F)|Codeforces||Codeforces Round #293 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1107|[Subarray Cuts](http://codeforces.com/problemset/problem/513/E2)|Codeforces||Rockethon 2015|9|
|<ul><li>- [ ] Done</li></ul>|1108|[Subarray Cuts](http://codeforces.com/problemset/problem/513/E1)|Codeforces||Rockethon 2015|9|
|<ul><li>- [ ] Done</li></ul>|1109|[Fox And Travelling](http://codeforces.com/problemset/problem/512/D)|Codeforces||Codeforces Round #290 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1110|[New Year Shopping](http://codeforces.com/problemset/problem/500/F)|Codeforces||Good Bye 2014|9|
|<ul><li>- [ ] Done</li></ul>|1111|[Stairs and Lines](http://codeforces.com/problemset/problem/498/E)|Codeforces||Codeforces Round #284 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1112|[Random Function and Tree](http://codeforces.com/problemset/problem/482/D)|Codeforces||Codeforces Round #275 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1113|[Dreamoon and Binary](http://codeforces.com/problemset/problem/477/D)|Codeforces||Codeforces Round #272 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1114|[Little Pony and Elements of Harmony](http://codeforces.com/problemset/problem/453/D)|Codeforces||Codeforces Round #259 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1115|[Valera and Number](http://codeforces.com/problemset/problem/441/E)|Codeforces||Codeforces Round #252 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1116|[Berland Federalization](http://codeforces.com/problemset/problem/440/D)|Codeforces||Testing Round #10|9|
|<ul><li>- [ ] Done</li></ul>|1117|[Pudding Monsters](http://codeforces.com/problemset/problem/436/D)|Codeforces||Zepto Code Rush 2014|9|
|<ul><li>- [ ] Done</li></ul>|1118|[Tachibana Kanade's Tofu](http://codeforces.com/problemset/problem/433/E)|Codeforces||Codeforces Round #248 (Div. 2) & Codeforces Round #248 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1119|[Largest Submatrix 3](http://codeforces.com/problemset/problem/407/D)|Codeforces||Codeforces Round #239 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1120|[Game with Points](http://codeforces.com/problemset/problem/386/D)|Codeforces||Testing Round #9|9|
|<ul><li>- [ ] Done</li></ul>|1121|[Ksenia and Combinatorics](http://codeforces.com/problemset/problem/382/E)|Codeforces||Codeforces Round #224 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1122|[Red and Black Tree](http://codeforces.com/problemset/problem/375/E)|Codeforces||Codeforces Round #221 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1123|[Xenia and String Problem](http://codeforces.com/problemset/problem/356/E)|Codeforces||Codeforces Round #207 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1124|[Transferring Pyramid](http://codeforces.com/problemset/problem/354/D)|Codeforces||Codeforces Round #206 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1125|[Game with Strings](http://codeforces.com/problemset/problem/354/B)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1126|[Pilgrims](http://codeforces.com/problemset/problem/348/E)|Codeforces||Codeforces Round #202 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1127|[Rectangles and Square](http://codeforces.com/problemset/problem/335/D)|Codeforces||MemSQL start[c]up Round 2 - online version|9|
|<ul><li>- [ ] Done</li></ul>|1128|[Binary Key](http://codeforces.com/problemset/problem/332/E)|Codeforces||Codeforces Round #193 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1129|[The Great Julya Calendar](http://codeforces.com/problemset/problem/331/C3)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|9|
|<ul><li>- [ ] Done</li></ul>|1130|[The Great Julya Calendar](http://codeforces.com/problemset/problem/331/C2)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|9|
|<ul><li>- [ ] Done</li></ul>|1131|[Ciel and Flipboard](http://codeforces.com/problemset/problem/321/D)|Codeforces||Codeforces Round #190 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1132|[PE Lesson](http://codeforces.com/problemset/problem/316/D3)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|1133|[PE Lesson](http://codeforces.com/problemset/problem/316/D2)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|1134|[PE Lesson](http://codeforces.com/problemset/problem/316/D1)|Codeforces||ABBYY Cup 3.0|9|
|<ul><li>- [ ] Done</li></ul>|1135|[Sereja and Squares](http://codeforces.com/problemset/problem/314/E)|Codeforces||Codeforces Round #187 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1136|[Yaroslav and Arrangements](http://codeforces.com/problemset/problem/301/E)|Codeforces||Codeforces Round #182 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1137|[Polo the Penguin and Lucky Numbers](http://codeforces.com/problemset/problem/288/E)|Codeforces||Codeforces Round #177 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1138|[Google Code Jam](http://codeforces.com/problemset/problem/277/D)|Codeforces||Codeforces Round #170 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1139|[Dima and Game](http://codeforces.com/problemset/problem/273/E)|Codeforces||Codeforces Round #167 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1140|[Dima and Figure](http://codeforces.com/problemset/problem/273/D)|Codeforces||Codeforces Round #167 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1141|[Maximum Waterfall](http://codeforces.com/problemset/problem/269/D)|Codeforces||Codeforces Round #165 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1142|[Wall Bars](http://codeforces.com/problemset/problem/268/D)|Codeforces||Codeforces Round #164 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1143|[Roadside Trees](http://codeforces.com/problemset/problem/264/E)|Codeforces||Codeforces Round #162 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1144|[Colorful Stones](http://codeforces.com/problemset/problem/264/D)|Codeforces||Codeforces Round #162 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1145|[Rhombus](http://codeforces.com/problemset/problem/263/E)|Codeforces||Codeforces Round #161 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1146|[Maxim and Calculator](http://codeforces.com/problemset/problem/261/E)|Codeforces||Codeforces Round #160 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1147|[Representative Sampling](http://codeforces.com/problemset/problem/178/F2)|Codeforces||ABBYY Cup 2.0 - Hard|9|
|<ul><li>- [ ] Done</li></ul>|1148|[Maze](http://codeforces.com/problemset/problem/123/E)|Codeforces||Codeforces Beta Round #92 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|1149|[Maximum Longest Increasing Subsequence](http://www.codechef.com/problems/LISA)|CodeChef|||9|
|<ul><li>- [ ] Done</li></ul>|1150|[Research Rover](http://codeforces.com/problemset/problem/722/E)|Codeforces||Intel Code Challenge Elimination Round (Div. 1 + Div. 2, combined)|9|
|<ul><li>- [ ] Done</li></ul>|1151|[Singer House](http://codeforces.com/problemset/problem/830/D)|Codeforces||Codeforces Round #424 (Div. 1, rated, based on VK Cup Finals)|9|
|<ul><li>- [ ] Done</li></ul>|1152|[Hitchhiking in the Baltic States](http://codeforces.com/problemset/problem/809/D)|Codeforces||Codeforces Round #415 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|1153|[Black Widow](http://codeforces.com/problemset/problem/704/C)|Codeforces||Codeforces Round #366 (Div. 1) & Codeforces Round #366 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1154|[Road to Home](http://codeforces.com/problemset/problem/721/E)|Codeforces||Codeforces Round #374 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1155|[DFS](http://codeforces.com/problemset/problem/1044/F)|Codeforces||Lyft Level 5 Challenge 2018 - Final Round|9|
|<ul><li>- [ ] Done</li></ul>|1156|[Fibonacci String Subsequences](http://codeforces.com/problemset/problem/946/F)|Codeforces||Educational Codeforces Round 39 (Rated for Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|1157|[Tree and Table](http://codeforces.com/problemset/problem/251/E)|Codeforces||Codeforces Round #153 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1158|[Cubes](http://codeforces.com/problemset/problem/243/D)|Codeforces||Codeforces Round #150 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1159|[Doe Graphs](http://codeforces.com/problemset/problem/232/C)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1160|[Clever Fat Rat](http://codeforces.com/problemset/problem/185/C)|Codeforces||Codeforces Round #118 (Div. 1) & Codeforces Round #118 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1161|[Mrs. Hudson's Pancakes](http://codeforces.com/problemset/problem/156/E)|Codeforces||Codeforces Round #110 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1162|[Hellish Constraints](http://codeforces.com/problemset/problem/138/E)|Codeforces||Codeforces Beta Round #99 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1163|[Help Shrek and Donkey](http://codeforces.com/problemset/problem/98/E)|Codeforces||Codeforces Beta Round #78 (Div. 1 Only)|10|
|<ul><li>- [ ] Done</li></ul>|1164|[Mutation](http://codeforces.com/problemset/problem/76/C)|Codeforces||All-Ukrainian School Olympiad in Informatics|10|
|<ul><li>- [ ] Done</li></ul>|1165|[World Evil](http://codeforces.com/problemset/problem/62/E)|Codeforces||Codeforces Beta Round #58|10|
|<ul><li>- [ ] Done</li></ul>|1166|[Expression](http://codeforces.com/problemset/problem/58/E)|Codeforces||Codeforces Beta Round #54 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1167|[The Great Marathon](http://codeforces.com/problemset/problem/38/H)|Codeforces||School Personal Contest #1 (Winter Computer School 2010/11) - Codeforces Beta Round #38 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|1168|[Dynamic Assignment Problem](http://www.spoj.com/problems/DAP/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|1169|[Dynamic Programming](p?ID=410)|A2 Online Judge|||10|
|<ul><li>- [ ] Done</li></ul>|1170|[Geometry](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1327)|Live Archive|2005|Asia - Kolkata|10|
|<ul><li>- [ ] Done</li></ul>|1171|[To Hack or not to Hack](http://codeforces.com/problemset/problem/662/E)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|10|
|<ul><li>- [ ] Done</li></ul>|1172|[Combining Slimes](http://codeforces.com/problemset/problem/618/G)|Codeforces||Wunder Fund Round 2016 (Div. 1 + Div. 2 combined)|10|
|<ul><li>- [ ] Done</li></ul>|1173|[Puzzle Lover](http://codeforces.com/problemset/problem/613/E)|Codeforces||Codeforces Round #339 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1174|[Simba on the Circle](http://codeforces.com/problemset/problem/612/F)|Codeforces||Educational Codeforces Round 4|10|
|<ul><li>- [ ] Done</li></ul>|1175|[Digits of Number Pi](http://codeforces.com/problemset/problem/585/F)|Codeforces||Codeforces Round #325 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1176|[Boolean Function](http://codeforces.com/problemset/problem/582/E)|Codeforces||Codeforces Round #323 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1177|[Number of Binominal Coefficients](http://codeforces.com/problemset/problem/582/D)|Codeforces||Codeforces Round #323 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1178|[Kojiro and Furrari](http://codeforces.com/problemset/problem/581/E)|Codeforces||Codeforces Round #322 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1179|[Longest Increasing Subsequence](http://codeforces.com/problemset/problem/568/E)|Codeforces||Codeforces Round #315 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1180|[Kyoya and Train](http://codeforces.com/problemset/problem/553/E)|Codeforces||Codeforces Round #309 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1181|[Inversions problem](http://codeforces.com/problemset/problem/513/G3)|Codeforces||Rockethon 2015|10|
|<ul><li>- [ ] Done</li></ul>|1182|[Subsequences Return](http://codeforces.com/problemset/problem/497/E)|Codeforces||Codeforces Round #283 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1183|[Permanent](http://codeforces.com/problemset/problem/468/E)|Codeforces||Codeforces Round #268 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1184|[An easy problem about trees](http://codeforces.com/problemset/problem/457/F)|Codeforces||MemSQL Start[c]UP 2.0 - Round 2|10|
|<ul><li>- [ ] Done</li></ul>|1185|[Jzzhu and Squares](http://codeforces.com/problemset/problem/449/E)|Codeforces||Codeforces Round #257 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1186|[Banners](http://codeforces.com/problemset/problem/436/F)|Codeforces||Zepto Code Rush 2014|10|
|<ul><li>- [ ] Done</li></ul>|1187|[Colored Jenga](http://codeforces.com/problemset/problem/424/E)|Codeforces||Codeforces Round #242 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1188|[Stock Trading](http://codeforces.com/problemset/problem/391/F1)|Codeforces||Rockethon 2014|10|
|<ul><li>- [ ] Done</li></ul>|1189|[New Year Cactus](http://codeforces.com/problemset/problem/379/G)|Codeforces||Good Bye 2013|10|
|<ul><li>- [ ] Done</li></ul>|1190|[Cookie Clicker](http://codeforces.com/problemset/problem/377/E)|Codeforces||Codeforces Round #222 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1191|[Summer Reading](http://codeforces.com/problemset/problem/370/E)|Codeforces||Codeforces Round #217 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1192|[Vasily the Bear and Painting Square](http://codeforces.com/problemset/problem/336/E)|Codeforces||Codeforces Round #195 (Div. 2)|10|
|<ul><li>- [ ] Done</li></ul>|1193|[Buy One, Get One Free](http://codeforces.com/problemset/problem/335/F)|Codeforces||MemSQL start[c]up Round 2 - online version|10|
|<ul><li>- [ ] Done</li></ul>|1194|[Counting Skyscrapers](http://codeforces.com/problemset/problem/335/E)|Codeforces||MemSQL start[c]up Round 2 - online version|10|
|<ul><li>- [ ] Done</li></ul>|1195|[Deja Vu](http://codeforces.com/problemset/problem/331/E2)|Codeforces||ABBYY Cup 3.0 - Finals (online version)|10|
|<ul><li>- [ ] Done</li></ul>|1196|[Random Ranking](http://codeforces.com/problemset/problem/303/E)|Codeforces||Codeforces Round #183 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1197|[Sequence Transformation](http://codeforces.com/problemset/problem/280/E)|Codeforces||Codeforces Round #172 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1198|[Galaxy Union](http://codeforces.com/problemset/problem/48/G)|Codeforces||School Personal Contest #3 (Winter Computer School 2010/11) - Codeforces Beta Round #45 (ACM-ICPC Rules)|10|
|<ul><li>- [ ] Done</li></ul>|1199|[School](http://codeforces.com/problemset/problem/45/B)|Codeforces||School Team Contest #3 (Winter Computer School 2010/11)|10|
|<ul><li>- [ ] Done</li></ul>|1200|[Forward, march!](http://codeforces.com/problemset/problem/11/E)|Codeforces||Codeforces Beta Round #11|10|
|<ul><li>- [ ] Done</li></ul>|1201|[#dynamic-programming&nbsp;(168)</span>](http://www.spoj.com/problems/tag/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|1202|[Longest Subsequence](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1107)|Live Archive|2004|Asia - Manila|10|
|<ul><li>- [ ] Done</li></ul>|1203|[Selling Numbers](http://codeforces.com/problemset/problem/778/E)|Codeforces||Codeforces Round #402 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1204|[Shake It!](http://codeforces.com/problemset/problem/848/D)|Codeforces||Codeforces Round #431 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1205|[Sloth](http://codeforces.com/problemset/problem/891/D)|Codeforces||Codeforces Round #446 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1206|[Mod Mod Mod](http://codeforces.com/problemset/problem/889/E)|Codeforces||Codeforces Round #445 (Div. 1, based on Technocup 2018 Elimination Round 3)|10|
|<ul><li>- [ ] Done</li></ul>|1207|[Numbers on the blackboard](http://codeforces.com/problemset/problem/878/E)|Codeforces||Codeforces Round #443 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1208|[Caramel Clouds](http://codeforces.com/problemset/problem/833/E)|Codeforces||Codeforces Round #426 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1209|[Days of Floral Colours](http://codeforces.com/problemset/problem/848/E)|Codeforces||Codeforces Round #431 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|1210|[Ada and Zoo](http://www.spoj.com/problems/ADAZOO/)|SPOJ|||10|
|<ul><li>- [ ] Done</li></ul>|1211|[Dynamic Shortest Path](http://codeforces.com/problemset/problem/843/D)|Codeforces||AIM Tech Round 4 (Div. 1)|10|
