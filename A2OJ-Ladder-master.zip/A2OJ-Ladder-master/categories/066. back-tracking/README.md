# 066. back-tracking


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Bit Compressor](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1566)|Live Archive|2006|World Finals - San Antonio|1|
|<ul><li>- [ ] Done</li></ul>|2|[Pyramids](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3138)|Live Archive|2011|World Finals - Orlando|1|
|<ul><li>- [ ] Done</li></ul>|3|[Prime Ring Problem](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=465)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Robots on Ice](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2794)|Live Archive|2010|World Finals - Harbin|1|
|<ul><li>- [ ] Done</li></ul>|5|[CD](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=565)|UVA|||1|
|<ul><li>- [ ] Done</li></ul>|6|[The Cubic End](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1496)|Live Archive|2005|North America - Greater NY|2|
|<ul><li>- [ ] Done</li></ul>|7|[Huffman Codes](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2123)|Live Archive|2008|World Finals - Banff|2|
|<ul><li>- [ ] Done</li></ul>|8|[My T-shirt suits me](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=1986)|UVA|||2|
|<ul><li>- [ ] Done</li></ul>|9|[Pride and Prejudice and Zombies](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3124)|Live Archive|2010|North America - Pacific Northwest|3|
|<ul><li>- [ ] Done</li></ul>|10|[House of Cards](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2452)|Live Archive|2009|World Finals - Stockholm|3|
|<ul><li>- [ ] Done</li></ul>|11|[Tony's Tour](http://poj.org/problem?id=1739)|PKU|||3|
|<ul><li>- [ ] Done</li></ul>|12|[Zombie Swallows](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3122)|Live Archive|2010|North America - Pacific Northwest|4|
|<ul><li>- [ ] Done</li></ul>|13|[Crossword Puzzle](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=235)|Live Archive|2001|World Finals - Vancouver|5|
|<ul><li>- [ ] Done</li></ul>|14|[The Primes](http://poj.org/problem?id=1165)|PKU|||5|
