# 087. Heaps


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Mahesh and his lost array](http://www.codechef.com/problems/ANUMLA)|CodeChef|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Expedition](http://www.spoj.com/problems/EXPEDI/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Promotion](http://www.spoj.com/problems/PRO/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Restaurant Rating](http://www.codechef.com/problems/RRATING)|CodeChef|||2|
|<ul><li>- [ ] Done</li></ul>|5|[The lazy programmer](http://www.spoj.com/problems/LAZYPROG/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|6|[Sequence Median](http://acm.timus.ru/problem.aspx?space=1&num=1306)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|7|[Most Distant Points](http://www.codechef.com/problems/MOSTDIST)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|8|[Heapsort](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1221)|Live Archive|2004|Europe - Northeastern|5|
