# 130. Minkowski_addition


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Separate Points](http://www.spoj.com/problems/SPOINTS/)|SPOJ||4|
|<ul><li>- [ ] Done</li></ul>|2|[Non-Flying Weather](http://acm.timus.ru/problem.aspx?space=1&num=1894)|Timus||9|
|<ul><li>- [ ] Done</li></ul>|3|[Mogohu-Rea Idol](http://codeforces.com/problemset/problem/87/E)|Codeforces|Codeforces Beta Round #73 (Div. 1 Only)|10|
