# 120. Graph_basics_concepts_BFS_DFS


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Tri graphs](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=2968)|Live Archive|2010|Africa/Middle East - Arab Contest|1|
|<ul><li>- [ ] Done</li></ul>|2|[Phone List](http://www.spoj.com/problems/PHONELST/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Vito's Family](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=203)|Live Archive|2000|Europe - Northwestern & Europe - Southwestern|1|
|<ul><li>- [ ] Done</li></ul>|4|[Intrepid climber](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4727)|UVA|||5|
