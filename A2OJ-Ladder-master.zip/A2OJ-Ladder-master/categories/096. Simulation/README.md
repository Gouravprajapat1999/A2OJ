# 096. Simulation


| Checkbox | ID | Problem Name|Online Judge|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Elevador](http://br.spoj.com/problems/ELEVADO2/)|SPOJ Brazil|1|
|<ul><li>- [ ] Done</li></ul>|2|[Beggar My Neighbour](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=98)|UVA|2|
|<ul><li>- [ ] Done</li></ul>|3|[Enumerating Rational Numbers](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=2302)|UVA|3|
|<ul><li>- [ ] Done</li></ul>|4|[Corrida](http://br.spoj.com/problems/CORRID11/)|SPOJ Brazil|3|
|<ul><li>- [ ] Done</li></ul>|5|[Volume da TV](http://br.spoj.com/problems/VOLUME13/)|SPOJ Brazil|4|
|<ul><li>- [ ] Done</li></ul>|6|[Use of Hospital Facilities](http://www.spoj.com/problems/HOSPITAL/)|SPOJ|6|
