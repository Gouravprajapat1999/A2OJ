# 029. bitmasks


| Checkbox | ID | Problem Name|Online Judge|Year|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[K-based Numbers](http://acm.timus.ru/problem.aspx?space=1&num=1009)|Timus|||1|
|<ul><li>- [ ] Done</li></ul>|2|[Histogram](http://www.spoj.com/problems/HIST2/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|3|[Assignments](http://www.spoj.com/problems/ASSIGN/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|4|[Fedor and New Game](http://codeforces.com/problemset/problem/467/B)|Codeforces||Codeforces Round #267 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|5|[Raising Bacteria](http://codeforces.com/problemset/problem/579/A)|Codeforces||Codeforces Round #320 (Div. 2) [Bayan Thanks-Round]|1|
|<ul><li>- [ ] Done</li></ul>|6|[Preparing Olympiad](http://codeforces.com/problemset/problem/550/B)|Codeforces||Codeforces Round #306 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|7|[Tavas and SaDDas](http://codeforces.com/problemset/problem/535/B)|Codeforces||Codeforces Round #299 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|8|[Dreamoon and WiFi](http://codeforces.com/problemset/problem/476/B)|Codeforces||Codeforces Round #272 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|9|[LATGACH3](http://www.spoj.com/problems/M3TILE/)|SPOJ|||1|
|<ul><li>- [ ] Done</li></ul>|10|[Chloe and the sequence ](http://codeforces.com/problemset/problem/743/B)|Codeforces||Codeforces Round #384 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|11|[Lucky Numbers (easy)](http://codeforces.com/problemset/problem/96/B)|Codeforces||Codeforces Beta Round #77 (Div. 2 Only)|2|
|<ul><li>- [ ] Done</li></ul>|12|[Lineup](http://www.spoj.com/problems/LINEUP/)|SPOJ|||2|
|<ul><li>- [ ] Done</li></ul>|13|[Candles](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=3821)|Live Archive|2011|Asia - Dhaka|2|
|<ul><li>- [ ] Done</li></ul>|14|[False Mirrors](http://acm.timus.ru/problem.aspx?space=1&num=1152)|Timus|||2|
|<ul><li>- [ ] Done</li></ul>|15|[Bits](http://codeforces.com/problemset/problem/484/A)|Codeforces||Codeforces Round #276 (Div. 1) & Codeforces Round #276 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|16|[Pebbles](https://icpcarchive.ecs.baylor.edu/index.php?option=onlinejudge&page=show_problem&problem=1996)|Live Archive|2007|North America - Pacific Northwest & North America - Southern California|2|
|<ul><li>- [ ] Done</li></ul>|17|[Array](http://codeforces.com/problemset/problem/224/B)|Codeforces||Codeforces Round #138 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|18|[PICK UP DROP ESCAPE](http://www.spoj.com/problems/CODEIT02/)|SPOJ|||3|
|<ul><li>- [ ] Done</li></ul>|19|[Fetching Cooking Tools](http://www.codechef.com/problems/TOOLS)|CodeChef|||3|
|<ul><li>- [ ] Done</li></ul>|20|[The Child and Set](http://codeforces.com/problemset/problem/437/B)|Codeforces||Codeforces Round #250 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|21|[Kefa and Dishes](http://codeforces.com/problemset/problem/580/D)|Codeforces||Codeforces Round #321 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|22|[Little Girl and Maximum XOR](http://codeforces.com/problemset/problem/276/D)|Codeforces||Codeforces Round #169 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|23|[LLPS](http://codeforces.com/problemset/problem/202/A)|Codeforces||Codeforces Round #127 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|24|[Short Program](http://codeforces.com/problemset/problem/878/A)|Codeforces||Codeforces Round #443 (Div. 1) & Codeforces Round #443 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|25|[Sagheer, the Hausmeister](http://codeforces.com/problemset/problem/812/B)|Codeforces||Codeforces Round #417 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|26|[Undoubtedly Lucky Numbers](http://codeforces.com/problemset/problem/244/B)|Codeforces||Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|27|[The Brand New Function](http://codeforces.com/problemset/problem/243/A)|Codeforces||Codeforces Round #150 (Div. 1) & Codeforces Round #150 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|28|[Tournament](http://codeforces.com/problemset/problem/27/B)|Codeforces||Codeforces Beta Round #27 (Codeforces format, Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|29|[And Or](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4763)|UVA|||4|
|<ul><li>- [ ] Done</li></ul>|30|[Three Logos](http://codeforces.com/problemset/problem/581/D)|Codeforces||Codeforces Round #322 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|31|[Permutations](http://codeforces.com/problemset/problem/513/B2)|Codeforces||Rockethon 2015|4|
|<ul><li>- [ ] Done</li></ul>|32|[Fox And Jumping](http://codeforces.com/problemset/problem/510/D)|Codeforces||Codeforces Round #290 (Div. 2) & Codeforces Round #290 (Div. 1)|4|
|<ul><li>- [ ] Done</li></ul>|33|[Little Pony and Harmony Chest](http://codeforces.com/problemset/problem/453/B)|Codeforces||Codeforces Round #259 (Div. 1) & Codeforces Round #259 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|34|[XOR on Segment](http://codeforces.com/problemset/problem/242/E)|Codeforces||Codeforces Round #149 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|35|[Compatible Numbers](http://codeforces.com/problemset/problem/165/E)|Codeforces||Codeforces Round #112 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|36|[PFAST Inc.](http://codeforces.com/problemset/problem/114/B)|Codeforces||Codeforces Beta Round #86 (Div. 2 Only)|5|
|<ul><li>- [ ] Done</li></ul>|37|[A Simple Task](http://codeforces.com/problemset/problem/11/D)|Codeforces||Codeforces Beta Round #11|5|
|<ul><li>- [ ] Done</li></ul>|38|[New Year Tree](http://codeforces.com/problemset/problem/620/E)|Codeforces||Educational Codeforces Round 6|5|
|<ul><li>- [ ] Done</li></ul>|39|[Mike and Foam](http://codeforces.com/problemset/problem/547/C)|Codeforces||Codeforces Round #305 (Div. 1) & Codeforces Round #305 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|40|[Borya and Hanabi](http://codeforces.com/problemset/problem/442/A)|Codeforces||Codeforces Round #253 (Div. 1) & Codeforces Round #253 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|41|[Roman and Numbers](http://codeforces.com/problemset/problem/401/D)|Codeforces||Codeforces Round #235 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|42|[Fox and Minimal path](http://codeforces.com/problemset/problem/388/B)|Codeforces||Codeforces Round #228 (Div. 1) & Codeforces Round #228 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|43|[Sausage Maximization](http://codeforces.com/problemset/problem/282/E)|Codeforces||Codeforces Round #173 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|44|[Bitwise Formula](http://codeforces.com/problemset/problem/778/B)|Codeforces||Codeforces Round #402 (Div. 1) & Codeforces Round #402 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|45|[Square Subsets](http://codeforces.com/problemset/problem/895/C)|Codeforces||Codeforces Round #448 (Div. 2)|5|
|<ul><li>- [ ] Done</li></ul>|46|[Practice](http://codeforces.com/problemset/problem/234/G)|Codeforces||Codeforces Round #145 (Div. 2, ACM-ICPC Rules) & Codeforces Round #145 (Div. 1, ACM-ICPC Rules)|6|
|<ul><li>- [ ] Done</li></ul>|47|[Table](http://codeforces.com/problemset/problem/232/B)|Codeforces||Codeforces Round #144 (Div. 1) & Codeforces Round #144 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|48|[Fish](http://codeforces.com/problemset/problem/16/E)|Codeforces||Codeforces Beta Round #16 (Div. 2 Only)|6|
|<ul><li>- [ ] Done</li></ul>|49|[Looking for Order](http://codeforces.com/problemset/problem/8/C)|Codeforces||Codeforces Beta Round #8|6|
|<ul><li>- [ ] Done</li></ul>|50|[Sereja and Table ](http://codeforces.com/problemset/problem/425/B)|Codeforces||Codeforces Round #243 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|51|[Anya and Cubes](http://codeforces.com/problemset/problem/525/E)|Codeforces||Codeforces Round #297 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|52|[Second price auction](http://codeforces.com/problemset/problem/513/C)|Codeforces||Rockethon 2015|6|
|<ul><li>- [ ] Done</li></ul>|53|[Devu and Flowers](http://codeforces.com/problemset/problem/451/E)|Codeforces||Codeforces Round #258 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|54|[Jzzhu and Numbers](http://codeforces.com/problemset/problem/449/D)|Codeforces||Codeforces Round #257 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|55|[Random Task](http://codeforces.com/problemset/problem/431/D)|Codeforces||Codeforces Round #247 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|56|[Cunning Gena](http://codeforces.com/problemset/problem/417/D)|Codeforces||RCC 2014 Warmup (Div. 2) & RCC 2014 Warmup (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|57|[New Year Letter](http://codeforces.com/problemset/problem/379/D)|Codeforces||Good Bye 2013|6|
|<ul><li>- [ ] Done</li></ul>|58|[Characteristics of Rectangles](http://codeforces.com/problemset/problem/333/D)|Codeforces||Codeforces Round #194 (Div. 1)|6|
|<ul><li>- [ ] Done</li></ul>|59|[Permutation Sum](http://codeforces.com/problemset/problem/285/D)|Codeforces||Codeforces Round #175 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|60|[Hongcow's Game](http://codeforces.com/problemset/problem/744/B)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|61|[Unusual Sequences](http://codeforces.com/problemset/problem/900/D)|Codeforces||Codeforces Round #450 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|62|[Mahmoud and a xor trip](http://codeforces.com/problemset/problem/766/E)|Codeforces||Codeforces Round #396 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|63|[Vladik and cards](http://codeforces.com/problemset/problem/743/E)|Codeforces||Codeforces Round #384 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|64|[Train Passengers](p?ID=306)|A2 Online Judge|||6|
|<ul><li>- [ ] Done</li></ul>|65|[Snake](http://codeforces.com/problemset/problem/225/D)|Codeforces||Codeforces Round #139 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|66|[Petya and Spiders](http://codeforces.com/problemset/problem/111/C)|Codeforces||Codeforces Beta Round #85 (Div. 1 Only) & Codeforces Beta Round #85 (Div. 2 Only)|7|
|<ul><li>- [ ] Done</li></ul>|67|[Binary Table](http://codeforces.com/problemset/problem/662/C)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|7|
|<ul><li>- [ ] Done</li></ul>|68|[Remembering Strings](http://codeforces.com/problemset/problem/543/C)|Codeforces||Codeforces Round #302 (Div. 1) & Codeforces Round #302 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|69|[Fuzzy Search](http://codeforces.com/problemset/problem/528/D)|Codeforces||Codeforces Round #296 (Div. 1)|7|
|<ul><li>- [ ] Done</li></ul>|70|[Guess the Tree](http://codeforces.com/problemset/problem/429/C)|Codeforces||Codeforces Round #245 (Div. 1) & Codeforces Round #245 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|71|[Inna and Binary Logic](http://codeforces.com/problemset/problem/400/E)|Codeforces||Codeforces Round #234 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|72|[Captains Mode](http://codeforces.com/problemset/problem/377/C)|Codeforces||Codeforces Round #222 (Div. 1) & Codeforces Round #222 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|73|[Axis Walking](http://codeforces.com/problemset/problem/327/E)|Codeforces||Codeforces Round #191 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|74|[Hongcow Buys a Deck of Cards](http://codeforces.com/problemset/problem/744/C)|Codeforces||Codeforces Round #385 (Div. 1) & Codeforces Round #385 (Div. 2)|7|
|<ul><li>- [ ] Done</li></ul>|75|[Password](http://codeforces.com/problemset/problem/79/D)|Codeforces||Codeforces Beta Round #71|8|
|<ul><li>- [ ] Done</li></ul>|76|[Sweets Game](http://codeforces.com/problemset/problem/63/E)|Codeforces||Codeforces Beta Round #59 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|77|[Dead Ends](http://codeforces.com/problemset/problem/53/E)|Codeforces||Codeforces Beta Round #49 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|78|[Traveling Graph](http://codeforces.com/problemset/problem/21/D)|Codeforces||Codeforces Alpha Round #21 (Codeforces format)|8|
|<ul><li>- [ ] Done</li></ul>|79|[Game with Strings](http://codeforces.com/problemset/problem/482/C)|Codeforces||Codeforces Round #275 (Div. 1) & Codeforces Round #275 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|80|[Yash And Trees](http://codeforces.com/problemset/problem/633/G)|Codeforces||Manthan, Codefest 16|8|
|<ul><li>- [ ] Done</li></ul>|81|[2048](http://codeforces.com/problemset/problem/413/D)|Codeforces||Coder-Strike 2014 - Round 2|8|
|<ul><li>- [ ] Done</li></ul>|82|[Bear and Floodlight](http://codeforces.com/problemset/problem/385/D)|Codeforces||Codeforces Round #226 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|83|[Sereja and Sets](http://codeforces.com/problemset/problem/367/D)|Codeforces||Codeforces Round #215 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|84|[Bags and Coins](http://codeforces.com/problemset/problem/356/D)|Codeforces||Codeforces Round #207 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|85|[Xenia and Dominoes](http://codeforces.com/problemset/problem/342/D)|Codeforces||Codeforces Round #199 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|86|[Summer Earnings](http://codeforces.com/problemset/problem/333/E)|Codeforces||Codeforces Round #194 (Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|87|[Memory for Arrays](http://codeforces.com/problemset/problem/309/C)|Codeforces||Croc Champ 2013 - Finals (online version, Div. 1)|8|
|<ul><li>- [ ] Done</li></ul>|88|[The Minimum Number of Variables](http://codeforces.com/problemset/problem/279/D)|Codeforces||Codeforces Round #171 (Div. 2)|8|
|<ul><li>- [ ] Done</li></ul>|89|[Two Sets](http://codeforces.com/problemset/problem/251/D)|Codeforces||Codeforces Round #153 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|90|[Friends](http://codeforces.com/problemset/problem/241/B)|Codeforces||Bayan 2012-2013 Elimination Round (ACM ICPC Rules, English statements)|9|
|<ul><li>- [ ] Done</li></ul>|91|[Quick Tortoise](http://codeforces.com/problemset/problem/232/E)|Codeforces||Codeforces Round #144 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|92|[Bitonix' Patrol](http://codeforces.com/problemset/problem/217/D)|Codeforces||Codeforces Round #134 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|93|[Polycarpus is Looking for Good Substrings](http://codeforces.com/problemset/problem/212/B)|Codeforces||VK Cup 2012 Finals (unofficial online-version)|9|
|<ul><li>- [ ] Done</li></ul>|94|[Brand New Problem](http://codeforces.com/problemset/problem/201/D)|Codeforces||Codeforces Round #127 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|95|[Garden](http://codeforces.com/problemset/problem/152/E)|Codeforces||Codeforces Round #108 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|96|[Arrangement](http://codeforces.com/problemset/problem/107/C)|Codeforces||Codeforces Beta Round #83 (Div. 1 Only) & Codeforces Beta Round #83 (Div. 2 Only)|9|
|<ul><li>- [ ] Done</li></ul>|97|[Two Subsequences](http://codeforces.com/problemset/problem/83/E)|Codeforces||Codeforces Beta Round #72 (Div. 1 Only)|9|
|<ul><li>- [ ] Done</li></ul>|98|[Nuclear Fusion](http://codeforces.com/problemset/problem/71/E)|Codeforces||Codeforces Beta Round #65 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|99|[Circling Round Treasures](http://codeforces.com/problemset/problem/375/C)|Codeforces||Codeforces Round #221 (Div. 1) & Codeforces Round #221 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|100|[Gambling Nim](http://codeforces.com/problemset/problem/662/A)|Codeforces||CROC 2016 - Final Round [Private, For Onsite Finalists Only]|9|
|<ul><li>- [ ] Done</li></ul>|101|[Sandy and Nuts](http://codeforces.com/problemset/problem/599/E)|Codeforces||Codeforces Round #332 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|102|[Simplified Nonogram](http://codeforces.com/problemset/problem/534/F)|Codeforces||Codeforces Round #298 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|103|[Misha and XOR](http://codeforces.com/problemset/problem/504/D)|Codeforces||Codeforces Round #285 (Div. 1)|9|
|<ul><li>- [ ] Done</li></ul>|104|[Design Tutorial: Increase the Constraints](http://codeforces.com/problemset/problem/472/G)|Codeforces||Codeforces Round #270|9|
|<ul><li>- [ ] Done</li></ul>|105|[Valera and Number](http://codeforces.com/problemset/problem/441/E)|Codeforces||Codeforces Round #252 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|106|[Game with Strings](http://codeforces.com/problemset/problem/354/B)|Codeforces||Codeforces Round #206 (Div. 1) & Codeforces Round #206 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|107|[Dasha and cyclic table](http://codeforces.com/problemset/problem/754/E)|Codeforces||Codeforces Round #390 (Div. 2)|9|
|<ul><li>- [ ] Done</li></ul>|108|[Robot in Basement](http://codeforces.com/problemset/problem/97/D)|Codeforces||Yandex.Algorithm 2011 Finals|10|
|<ul><li>- [ ] Done</li></ul>|109|[Mutation](http://codeforces.com/problemset/problem/76/C)|Codeforces||All-Ukrainian School Olympiad in Informatics|10|
|<ul><li>- [ ] Done</li></ul>|110|[Boolean Function](http://codeforces.com/problemset/problem/582/E)|Codeforces||Codeforces Round #323 (Div. 1)|10|
|<ul><li>- [ ] Done</li></ul>|111|[Party](http://codeforces.com/problemset/problem/575/C)|Codeforces||Bubble Cup 8 - Finals [Online Mirror]|10|
|<ul><li>- [ ] Done</li></ul>|112|[Restoring Map](http://codeforces.com/problemset/problem/566/E)|Codeforces||VK Cup 2015 - Finals, online mirror|10|
|<ul><li>- [ ] Done</li></ul>|113|[Vasily the Bear and Painting Square](http://codeforces.com/problemset/problem/336/E)|Codeforces||Codeforces Round #195 (Div. 2)|10|
