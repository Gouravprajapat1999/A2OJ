# 099. digit_dp


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[LUCIFER Number](http://www.spoj.com/problems/LUCIFER/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|2|[G-One Numbers](http://www.spoj.com/problems/GONE/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|3|[Ra-One Numbers](http://www.spoj.com/problems/RAONE/)|SPOJ||2|
|<ul><li>- [ ] Done</li></ul>|4|[Magic Numbers](http://codeforces.com/problemset/problem/628/D)|Codeforces|Educational Codeforces Round 8|6|
|<ul><li>- [ ] Done</li></ul>|5|[Salazar Slytherin's Locket](http://codeforces.com/problemset/problem/855/E)|Codeforces|Manthan, Codefest 17|7|
|<ul><li>- [ ] Done</li></ul>|6|[Igor and Interesting Numbers](http://codeforces.com/problemset/problem/747/F)|Codeforces|Codeforces Round #387 (Div. 2)|9|
