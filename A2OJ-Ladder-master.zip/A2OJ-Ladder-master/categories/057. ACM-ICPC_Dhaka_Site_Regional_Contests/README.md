# 057. ACM-ICPC_Dhaka_Site_Regional_Contests


| Checkbox | ID | Problem Name|Online Judge|Contest|Difficulty Level|
|:---:|:---:|:---:|:---:|:---:|:---:|
|<ul><li>- [ ] Done</li></ul>|1|[Vanya and Lanterns](http://codeforces.com/problemset/problem/492/B)|Codeforces|Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|2|[The Dole Queue](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=69)|UVA||1|
|<ul><li>- [ ] Done</li></ul>|3|[Vanya and Cubes](http://codeforces.com/problemset/problem/492/A)|Codeforces|Codeforces Round #280 (Div. 2)|1|
|<ul><li>- [ ] Done</li></ul>|4|[Vanya and Exams](http://codeforces.com/problemset/problem/492/C)|Codeforces|Codeforces Round #280 (Div. 2)|2|
|<ul><li>- [ ] Done</li></ul>|5|[Falling Ants](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4447)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|6|[GCD XOR](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4454)|UVA||3|
|<ul><li>- [ ] Done</li></ul>|7|[Vasya and Basketball](http://codeforces.com/problemset/problem/493/C)|Codeforces|Codeforces Round #281 (Div. 2)|3|
|<ul><li>- [ ] Done</li></ul>|8|[Dromicpalin Substrings](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4456)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|9|[Vanya and Computer Game](http://codeforces.com/problemset/problem/492/D)|Codeforces|Codeforces Round #280 (Div. 2)|4|
|<ul><li>- [ ] Done</li></ul>|10|[Pattern Locker](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4450)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|11|[Radar Installation](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3634)|UVA||4|
|<ul><li>- [ ] Done</li></ul>|12|[Air Raid](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=3625)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|13|[Two Points Revisited](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4452)|UVA||5|
|<ul><li>- [ ] Done</li></ul>|14|[Watching the Kangaroo](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4453)|UVA||6|
|<ul><li>- [ ] Done</li></ul>|15|[Vanya and Field](http://codeforces.com/problemset/problem/492/E)|Codeforces|Codeforces Round #280 (Div. 2)|6|
|<ul><li>- [ ] Done</li></ul>|16|[Fiasco](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4455)|UVA||7|
|<ul><li>- [ ] Done</li></ul>|17|[Game of MJ](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4448)|UVA||7|
|<ul><li>- [ ] Done</li></ul>|18|[Game of Throne](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4449)|UVA||9|
|<ul><li>- [ ] Done</li></ul>|19|[Fill the Cuboid](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4457)|UVA||9|
|<ul><li>- [ ] Done</li></ul>|20|[Pearl Chains](https://uva.onlinejudge.org/index.php?option=onlinejudge&page=show_problem&problem=4451)|UVA||9|
